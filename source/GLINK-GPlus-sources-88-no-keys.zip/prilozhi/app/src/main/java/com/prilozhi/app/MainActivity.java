package com.prilozhi.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.net.Uri;
import android.nfc.NfcAdapter;
import android.nfc.cardemulation.CardEmulation;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.prilozhi.app.net.ManifestBuilder;
import com.prilozhi.app.net.OutItem;
import com.prilozhi.app.nfc.CardService;
import com.prilozhi.app.nfc.TapReader;
import com.prilozhi.app.svc.TransferService;
import com.prilozhi.app.ui.BackdropView;
import com.prilozhi.app.ui.IslandView;
import com.prilozhi.app.util.Haptics;
import com.prilozhi.app.util.State;
import com.prilozhi.app.util.UpdateManager;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements State.Listener, TapReader.Listener {

    private static final int REQ_FILES = 11;
    private static final int REQ_TREE = 12;
    private static final int REQ_CONTACT = 13;
    private static final int REQ_CAMERA = 14;
    private static final int REQ_PERMS = 21;

    private final Handler main = new Handler(Looper.getMainLooper());
    private IslandView island;
    private BackdropView backdrop;
    private LinearLayout itemsContainer, incomingPanel, incomingActions, gatePanel;
    private TextView incomingTitle, incomingBody, gateText;
    private Button incomingOpen, incomingInstall;
    private NfcAdapter nfcAdapter;
    private TapReader tapReader;
    private boolean resumed = false;
    private com.prilozhi.app.security.PublicIdGate publicIdGate;
    private boolean publicIdRequested;
    private String gateNext = null;
    private Uri pendingCameraUri;
    private boolean cooldownWake = false;
    private Boolean readerOn = null;

    private SoundPool soundPool;
    private int sndTap, sndDone, sndErr;

    private android.graphics.LinearGradient titleShader;
    private android.graphics.Matrix titleMatrix;
    private android.animation.ValueAnimator titleFlow;
    private float titleShaderWidth;
    private boolean funMode;
    // Only the visible GS LOGO project tile plays; its local WebView never loads the network.
    private android.webkit.WebView gsLogoTileWeb;
    private View gsLogoTileIcon;
    private boolean gsLogoTilePlaying;
    private boolean serverStatusChecking;
    private final Runnable serverStatusLoop = new Runnable() {
        @Override public void run() {
            if (!resumed) return;
            if (!serverStatusChecking) {
                serverStatusChecking = true;
                new Thread(() -> {
                    String value = com.prilozhi.app.util.ServerIndicator.check(BuildConfig.GLINK_RELAY_URL);
                    main.post(() -> {
                        serverStatusChecking = false;
                        if (resumed && !isFinishing() && !isDestroyed()) {
                            TextView indicator = findViewById(R.id.server_indicator);
                            if (indicator != null) indicator.setText(value);
                        }
                    });
                }, "glink-server-status").start();
            }
            main.postDelayed(this, 60_000);
        }
    };

    private final Runnable returnToReady = () -> {
        State st = State.get();
        if (st.mode == State.Mode.SUCCESS || st.mode == State.Mode.ERROR) refreshArmedState();
    };

    private final Runnable updLoop = new Runnable() {
        @Override
        public void run() {
            checkUpdate(new UpdateManager(MainActivity.this), false);
            main.postDelayed(this, 60_000); // only while open, without a network request storm
        }
    };

    private boolean gplusCycleRunning = false;
    private final Runnable gplusNfcCycle = new Runnable() {
        @Override public void run() {
            if (!resumed || !com.prilozhi.app.identity.GPlusNfcStore.active()) {
                gplusCycleRunning = false;
                if (resumed) updateNfcMode();
                return;
            }
            if (State.get().sessionActive) { main.postDelayed(this, 300); return; }
            setReader(true);
            main.postDelayed(() -> {
                if (!resumed || !gplusCycleRunning || !com.prilozhi.app.identity.GPlusNfcStore.active()) return;
                if (!State.get().sessionActive) setReader(false);
                main.postDelayed(gplusNfcCycle, 1300 + Math.abs(State.get().deviceId.hashCode() % 350));
            }, 650);
        }
    };

    private final Runnable nfcCycle = new Runnable() {
        @Override
        public void run() {
            State st = State.get();
            if (!resumed || st.sessionActive) return;
            if (st.mode != State.Mode.READY_SEND) return;
            // отправитель: в основном «карта», короткими окнами — читатель
            setReader(true);
            main.postDelayed(() -> {
                if (resumed && !State.get().sessionActive
                        && State.get().mode == State.Mode.READY_SEND) {
                    setReader(false);
                    main.postDelayed(nfcCycle, 2600);
                }
            }, 500);
        }
    };

    // ------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        edgeToEdge();
        setContentView(R.layout.activity_main);

        island = findViewById(R.id.island);
        // GLKUI v2: полный GPU-рендер интерфейса (3D-ускоритель)
        island.setOnPickListener(pick -> routePick(pick));
        // Metro-анимация входа: заголовок и островок въезжают сдвигом (turnstile)
        View tvIn = findViewById(R.id.title);
        if (tvIn != null) {
            tvIn.setAlpha(0f);
            tvIn.setTranslationX(-56f);
            tvIn.animate().alpha(1f).translationX(0f).setDuration(320)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
        }
        View subIn = findViewById(R.id.subtitle);
        if (subIn != null) {
            subIn.setAlpha(0f);
            subIn.setTranslationX(-40f);
            subIn.animate().alpha(1f).translationX(0f).setStartDelay(70).setDuration(320)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
        }
        island.setAlpha(0f);
        island.animate().alpha(1f).setStartDelay(120).setDuration(300).start();
        TextView sub = findViewById(R.id.subtitle);
        sub.setText("Передача файлов! GLINK v" + UpdateManager.currentVersionName(this));

        TextView titleView = findViewById(R.id.title);
        titleView.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            if (titleView.getWidth() > 0 && (titleShader == null || titleShaderWidth != titleView.getWidth())) {
                configureTitleShine(titleView);
            }
            alignHeaderLogo(titleView);
        });
        titleView.post(() -> { configureTitleShine(titleView); alignHeaderLogo(titleView); });
        publicIdGate = new com.prilozhi.app.security.PublicIdGate(this, findViewById(R.id.glink_device_id),
                () -> gatePanel != null && gatePanel.getVisibility() != View.VISIBLE && !updChecking
                        && (updDialog == null || !updDialog.isShowing()));

        backdrop = findViewById(R.id.backdrop);
        View scrollV = findViewById(R.id.scroll);
        scrollV.setAlpha(0f);
        scrollV.setTranslationY(26f);
        scrollV.animate().alpha(1f).translationY(0f).setDuration(520)
                .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();

        itemsContainer = findViewById(R.id.items_container);
        incomingPanel = findViewById(R.id.incoming_panel);
        incomingTitle = findViewById(R.id.incoming_title);
        incomingBody = findViewById(R.id.incoming_body);
        incomingActions = findViewById(R.id.incoming_actions);
        incomingOpen = findViewById(R.id.incoming_open);
        incomingInstall = findViewById(R.id.incoming_install);
        gatePanel = findViewById(R.id.gate_panel);
        gateText = findViewById(R.id.gate_text);

        Button resend = findViewById(R.id.btn_resend);
        resend.setOnClickListener(v -> {
            State st = State.get();
            synchronized (st.outbound) {
                st.outbound.addAll(st.lastSentItems);
            }
            st.addHistory("Снова в очереди", st.lastSentItems.size() + " элемент(ов)", true);
            st.notifyChanged();
            refreshArmedState();
            Toast.makeText(this, "Приложите телефоны — улетит снова", Toast.LENGTH_SHORT).show();
        });

        setupFunPanel();
        setupGsLogo();
        buildLinker();
        checkUpdate(new UpdateManager(this), false);
        com.prilozhi.app.net.RelayTransfer.startPresence(this); // Wi-Fi: мы видны устройствам рядом

        Button gateBtn = findViewById(R.id.gate_btn);
        gateBtn.setOnClickListener(v -> openNextGateStep());
        Button incomingCopy = findViewById(R.id.incoming_copy);
        incomingCopy.setOnClickListener(v -> {
            State st = State.get();
            String txt = st.incomingLink != null ? st.incomingLink : st.incomingText;
            if (txt != null) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("GLINK", txt));
                Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
            }
        });
        incomingInstall.setOnClickListener(v -> {
            String uri = State.get().receivedApkUri;
            if (uri != null) {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(Uri.parse(uri),
                            "application/vnd.android.package-archive");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(this, "Не удалось открыть установщик", Toast.LENGTH_SHORT).show();
                }
            }
        });
        incomingOpen.setOnClickListener(v -> {
            State st = State.get();
            if (st.incomingLink != null) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(st.incomingLink)));
                } catch (Exception ignored) {
                }
            }
        });

        View root = findViewById(R.id.root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top;
            if (Build.VERSION.SDK_INT >= 30) {
                top = insets.getInsets(WindowInsets.Type.systemBars()).top;
            } else {
                top = insets.getSystemWindowInsetTop();
            }
            island.setTopInset(top);
            float d = getResources().getDisplayMetrics().density;
            android.widget.FrameLayout.LayoutParams closeLp = (android.widget.FrameLayout.LayoutParams)
                    findViewById(R.id.btn_fun_exit_circle).getLayoutParams();
            closeLp.topMargin = top + Math.round(22 * d);
            findViewById(R.id.btn_fun_exit_circle).setLayoutParams(closeLp);
            findViewById(R.id.fun_scroll).setPadding(Math.round(20*d), top + Math.round(100*d),
                    Math.round(20*d), Math.round(28*d));
            return insets;
        });

        soundPool = new SoundPool.Builder()
                .setMaxStreams(3)
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build())
                .build();
        sndTap = soundPool.load(this, R.raw.glink_tap, 1);
        sndDone = soundPool.load(this, R.raw.glink_done, 1);
        sndErr = soundPool.load(this, R.raw.glink_error, 1);

        tapReader = new TapReader(this, this);
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_PERMS);
        }

        handleIntent(getIntent());
        State.get().addListener(this);
        refreshArmedState();
        onStateChanged(State.get());
    }

    private void edgeToEdge() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
        } else {
            w.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
    }

    // ------------------------------------------------------------------
    // Жизненный цикл

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        for (int id : new int[]{R.id.header_logo_web, R.id.fun_logo_web}) {
            android.webkit.WebView animation = findViewById(id);
            if (animation != null) animation.onResume();
        }
        if (gsLogoTileWeb != null) gsLogoTileWeb.post(() -> syncGsLogoTilePlayback(true));
        boolean otherInstallerPending = updApkUri != null || gplusReadyUri != null || gplusAwaitInstallPermission;
        if (updApkUri != null && !isFinishing() && !isDestroyed()) {
            try { UpdateManager.install(this, updApkUri); } catch (Exception ignored) { }
        }
        if (gplusAwaitInstallPermission) {
            gplusAwaitInstallPermission=false;
            if (getPackageManager().canRequestPackageInstalls() && gplusReadyUri!=null) { Uri ready=gplusReadyUri;gplusReadyUri=null;installGPlus(ready); }
            else Toast.makeText(this,"Для установки G+ разрешите установку приложений из GLINK",Toast.LENGTH_LONG).show();
        } else if (gplusReadyUri!=null && updApkUri==null) { Uri ready=gplusReadyUri;gplusReadyUri=null;installGPlus(ready); }
        if (!otherInstallerPending) {
            if (vpnAwaitInstallPermission) {
                vpnAwaitInstallPermission = false;
                if (getPackageManager().canRequestPackageInstalls() && vpnReadyUri != null) {
                    Uri ready = vpnReadyUri; vpnReadyUri = null; installVpnExp(ready);
                } else {
                    vpnReadyUri = null;
                    Toast.makeText(this, "Для установки разрешите установку приложений из GLINK", Toast.LENGTH_LONG).show();
                }
            } else if (vpnReadyUri != null) {
                Uri ready = vpnReadyUri; vpnReadyUri = null; installVpnExp(ready);
            } else if (playlandAwaitInstallPermission) {
                playlandAwaitInstallPermission = false;
                if (getPackageManager().canRequestPackageInstalls() && playlandReadyUri != null) {
                    Uri ready = playlandReadyUri; playlandReadyUri = null; installPlayland(ready);
                } else {
                    playlandReadyUri = null;
                    Toast.makeText(this, "Для установки разрешите установку приложений из GLINK", Toast.LENGTH_LONG).show();
                }
            } else if (playlandReadyUri != null) {
                Uri ready = playlandReadyUri; playlandReadyUri = null; installPlayland(ready);
            }
        }
        if(com.prilozhi.app.util.GPlusDownload.hasPending(getApplicationContext()))
            new Thread(() -> com.prilozhi.app.util.GPlusDownload.cleanupAfterInstalled(getApplicationContext()), "glink-gplus-cleanup").start();
        try {
            if (nfcAdapter != null) {
                CardEmulation.getInstance(nfcAdapter).setPreferredService(this,
                        new ComponentName(this, CardService.class));
            }
        } catch (Throwable ignored) {
        }
        main.removeCallbacks(updLoop);
        main.postDelayed(updLoop, 300);
        main.removeCallbacks(serverStatusLoop);
        main.post(serverStatusLoop);
        refreshGate();
        if (publicIdGate != null) publicIdGate.onResume();
        if (publicIdRequested) {
            publicIdRequested = false;
            main.post(() -> { if (resumed && publicIdGate != null) publicIdGate.openPublicId(); });
        }
        TextView tv = findViewById(R.id.title);
        if (!funMode && titleShader != null && tv.getWidth() > 0) startTitleFlow(tv, tv.getWidth());
        refreshArmedState();
        updateNfcMode();
        if (State.get().gplusContactDone != null) onStateChanged(State.get());
    }

    private boolean btDiscoverAsked = false;

    /** Отправитель: файлы сразу шифруются и заливаются на серверный релей. */
    private void btArmSender() {
        try {
            com.prilozhi.app.net.RelayTransfer.ensureUpload(this);
        } catch (Throwable ignored) {
        }
    }

    /** Транспорт теперь серверный: Bluetooth не используется и не трогается. */
    private void btTryPowerOff() {
    }

    @Override
    protected void onPause() {
        if (publicIdGate != null) publicIdGate.onPause();
        // серверы GFCAS/Bluetooth НЕ глушим: передача обязана жить в фоне
        main.removeCallbacks(updLoop);
        main.removeCallbacks(serverStatusLoop);
        stopTitleFlow();
        for (int id : new int[]{R.id.header_logo_web, R.id.fun_logo_web}) {
            android.webkit.WebView animation = findViewById(id);
            if (animation != null) animation.onPause();
        }
        try {
            if (nfcAdapter != null) {
                CardEmulation.getInstance(nfcAdapter).unsetPreferredService(this);
            }
        } catch (Throwable ignored) {
        }
        resumed = false;
        syncGsLogoTilePlayback(true);
        main.removeCallbacks(nfcCycle);
        main.removeCallbacks(gplusNfcCycle);
        gplusCycleRunning = false;
        setReader(false);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (soundPool != null) {
            soundPool.release();
            soundPool = null;
        }
        stopTitleFlow();
        if (gsLogoTileWeb != null) {
            android.webkit.WebView animation = gsLogoTileWeb;
            gsLogoTileWeb = null;
            gsLogoTileIcon = null;
            animation.stopLoading();
            if (animation.getParent() instanceof android.view.ViewGroup)
                ((android.view.ViewGroup) animation.getParent()).removeView(animation);
            animation.destroy();
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------
    // NFC-режимы

    private void setReader(boolean on) {
        if (nfcAdapter == null || !resumed && on) {
            if (!on) readerOn = false;
            if (on) return;
        }
        if (readerOn != null && readerOn == on) return;
        readerOn = on;
        try {
            if (on) {
                Bundle opts = new Bundle();
                opts.putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 250);
                nfcAdapter.enableReaderMode(this, tapReader, TapReader.readerFlags(), opts);
            } else {
                nfcAdapter.disableReaderMode(this);
            }
        } catch (Throwable ignored) {
        }
    }

    private void updateNfcMode() {
        if (!resumed || nfcAdapter == null) return;
        State st = State.get();
        if (st.sessionActive) return; // передача по NFC идёт — не трогаем радио
        if (System.currentTimeMillis() < st.cooldownUntil) {
            setReader(false);
            if (!cooldownWake) {
                cooldownWake = true;
                long left = st.cooldownUntil - System.currentTimeMillis();
                main.postDelayed(() -> {
                    cooldownWake = false;
                    updateNfcMode();
                }, left + 250);
            }
            return;
        }
        main.removeCallbacks(nfcCycle);
        if (com.prilozhi.app.identity.GPlusNfcStore.active()) {
            if (!gplusCycleRunning) {
                gplusCycleRunning = true;
                setReader(false);
                main.postDelayed(gplusNfcCycle, Math.abs(st.deviceId.hashCode() % 700));
            }
            return;
        }
        if (gplusCycleRunning) {
            gplusCycleRunning = false;
            main.removeCallbacks(gplusNfcCycle);
        }
        switch (st.mode) {
            case TRANSFER:
            case TAP:
            case CONNECTING:
                setReader(false); // мы — карта, читатель не нужен
                break;
            case READY_SEND: {
                setReader(false);
                long phase = Math.abs(st.deviceId.hashCode()) % 1200;
                main.postDelayed(nfcCycle, phase);
                break;
            }
            default:
                setReader(true); // приём: читатель всегда наготове
                break;
        }
    }

    private void refreshArmedState() {
        State st = State.get();
        if (st.mode == State.Mode.TRANSFER || st.mode == State.Mode.CONNECTING
                || st.mode == State.Mode.TAP) return;
        if (nfcAdapter != null && !nfcAdapter.isEnabled()) {
            st.setMode(State.Mode.IDLE, "Включите NFC", "Касание недоступно без NFC");
            return;
        }
        if (st.hasOutbound()) {
            st.setMode(State.Mode.READY_SEND, "Готово к передаче",
                    "Приложите второй телефон сверху");
            btArmSender();
        } else {
            btDiscoverAsked = false; // очередь пуста — в следующий раз спросим видимость заново
                st.setMode(State.Mode.READY_RECV, "Приём включён",
                    "Приложите к телефону-отправителю");
        }
    }

    private String lastApkPreviewKey = "";

    /** Превью полученного APK: настоящие иконка и имя приложения перед установкой. */
    private void showApkPreview(android.widget.ImageView prev, String uriStr) {
        if (uriStr == null || uriStr.equals(lastApkPreviewKey)) {
            prev.setVisibility(View.VISIBLE);
            return;
        }
        lastApkPreviewKey = uriStr;
        prev.setVisibility(View.VISIBLE);
        new Thread(() -> {
            try {
                java.io.File tmp = new java.io.File(getCacheDir(), "apk_preview.apk");
                try (java.io.InputStream in = getContentResolver().openInputStream(Uri.parse(uriStr));
                     java.io.OutputStream out = new java.io.FileOutputStream(tmp)) {
                    byte[] b = new byte[128 * 1024];
                    int n;
                    while ((n = in.read(b)) != -1) out.write(b, 0, n);
                }
                android.content.pm.PackageInfo pi = getPackageManager()
                        .getPackageArchiveInfo(tmp.getAbsolutePath(), 0);
                if (pi == null || pi.applicationInfo == null) return;
                pi.applicationInfo.sourceDir = tmp.getAbsolutePath();
                pi.applicationInfo.publicSourceDir = tmp.getAbsolutePath();
                android.graphics.drawable.Drawable icon = pi.applicationInfo.loadIcon(getPackageManager());
                CharSequence label = pi.applicationInfo.loadLabel(getPackageManager());
                String ver = pi.versionName != null ? pi.versionName : "";
                runOnUiThread(() -> {
                    prev.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
                    prev.setImageDrawable(icon);
                    incomingInstall.setText("Установить " + label);
                    incomingBody.setText(incomingBody.getText()
                            + "\nПриложение: " + label + (ver.isEmpty() ? "" : " v" + ver));
                });
            } catch (Throwable ignored) {
            }
        }, "glink-apk-preview").start();
    }

    // ------------------------------------------------------------------
    // Состояние -> UI

    @Override
    public void onStateChanged(State state) {
        if (resumed && state.gplusContactDone != null) {
            String who = state.gplusContactDone;
            state.gplusContactDone = null;
            Toast.makeText(this, "Контакт G+ добавлен: " + who, Toast.LENGTH_LONG).show();
            // Let the HCE commit response leave the radio before switching activities.
            main.postDelayed(() -> {
                if (!resumed || isFinishing()) return;
                try {
                    Intent launch = getPackageManager().getLaunchIntentForPackage("grp.gs.gplus");
                    if (launch != null) startActivity(launch);
                } catch (Exception ignored) { }
            }, 1200);
        }
        // текст «касание принято, можно разносить» теперь рисует сам островок (режим TAP)
        if (state.gfcasToast != null) {
            String gt = state.gfcasToast;
            state.gfcasToast = null;
            Toast.makeText(this, gt, Toast.LENGTH_LONG).show();
        }
        rebuildItems(state);
        boolean hasReceived;
        synchronized (state.lastReceived) {
            hasReceived = !state.lastReceived.isEmpty();
        }
        if (hasReceived) {
            android.widget.ImageView prev = findViewById(R.id.incoming_preview);
            String firstImg = null;
            synchronized (state.lastReceivedUris) {
                for (int k = 0; k < state.lastReceived.size()
                        && k < state.lastReceivedUris.size(); k++) {
                    String nm = state.lastReceived.get(k).toLowerCase();
                    if (nm.endsWith(".jpg") || nm.endsWith(".jpeg") || nm.endsWith(".png")
                            || nm.endsWith(".webp") || nm.endsWith(".gif")
                            || nm.endsWith(".mp4") || nm.endsWith(".mkv") || nm.endsWith(".webm")
                            || nm.endsWith(".mov") || nm.endsWith(".3gp")) {
                        firstImg = state.lastReceivedUris.get(k);
                        break;
                    }
                }
            }
            if (firstImg != null && prev != null) {
                try {
                    Uri u = Uri.parse(firstImg);
                    prev.setImageBitmap(getContentResolver().loadThumbnail(
                            u, new android.util.Size(720, 420), null));
                    prev.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
                    prev.setVisibility(View.VISIBLE);
                    final String fu = firstImg;
                    prev.setOnClickListener(v -> {
                        try {
                            Intent vi = new Intent(Intent.ACTION_VIEW);
                            vi.setDataAndType(Uri.parse(fu), "image/*");
                            vi.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(vi);
                        } catch (Exception ignored) {
                        }
                    });
                } catch (Exception e) {
                    prev.setVisibility(View.GONE);
                }
            } else if (prev != null && state.receivedApkUri != null) {
                showApkPreview(prev, state.receivedApkUri);
            } else if (prev != null) {
                prev.setVisibility(View.GONE);
            }
            // лента превью ВСЕХ принятых медиа: тап по миниатюре — большое превью выше
            LinearLayout thumbs = findViewById(R.id.incoming_thumbs);
            View thumbsScroll = findViewById(R.id.incoming_thumbs_scroll);
            if (thumbs != null) {
                thumbs.removeAllViews();
                int shown = 0;
                synchronized (state.lastReceivedUris) {
                    for (int k = 0; k < state.lastReceived.size()
                            && k < state.lastReceivedUris.size() && shown < 12; k++) {
                        String nm = state.lastReceived.get(k).toLowerCase();
                        boolean media = nm.endsWith(".jpg") || nm.endsWith(".jpeg") || nm.endsWith(".png")
                                || nm.endsWith(".webp") || nm.endsWith(".gif") || nm.endsWith(".mp4")
                                || nm.endsWith(".mkv") || nm.endsWith(".webm") || nm.endsWith(".mov");
                        if (!media) continue;
                        final String fu = state.lastReceivedUris.get(k);
                        try {
                            android.widget.ImageView tv2 = new android.widget.ImageView(this);
                            float dd = getResources().getDisplayMetrics().density;
                            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                                    (int) (62 * dd), (int) (62 * dd));
                            tlp.rightMargin = (int) (8 * dd);
                            tv2.setLayoutParams(tlp);
                            tv2.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
                            tv2.setImageBitmap(getContentResolver().loadThumbnail(
                                    Uri.parse(fu), new android.util.Size(160, 160), null));
                            tv2.setOnClickListener(v -> {
                                android.widget.ImageView pv = findViewById(R.id.incoming_preview);
                                if (pv != null) {
                                    try {
                                        pv.setImageBitmap(getContentResolver().loadThumbnail(
                                                Uri.parse(fu), new android.util.Size(720, 420), null));
                                        pv.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90)
                                                .withEndAction(() -> pv.animate().scaleX(1f).scaleY(1f)
                                                        .setDuration(160).start()).start();
                                    } catch (Exception ignored) {
                                    }
                                }
                            });
                            tv2.setAlpha(0f);
                            tv2.animate().alpha(1f).setDuration(280).setStartDelay(shown * 60L).start();
                            thumbs.addView(tv2);
                            shown++;
                        } catch (Exception ignored) {
                        }
                    }
                }
                if (thumbsScroll != null) thumbsScroll.setVisibility(shown > 1 ? View.VISIBLE : View.GONE);
            }
            StringBuilder body = new StringBuilder();
            synchronized (state.lastReceived) {
                for (String n : state.lastReceived) body.append("• ").append(n).append("\n");
            }
            body.append("Сохранено в папку Загрузки/GLINK");
            boolean wasGone = incomingPanel.getVisibility() != View.VISIBLE;
            incomingPanel.setVisibility(View.VISIBLE);
            if (wasGone) {
                incomingPanel.setAlpha(0f);
                incomingPanel.setTranslationY(26f);
                incomingPanel.animate().alpha(1f).translationY(0f).setDuration(380)
                        .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            }
            incomingTitle.setText("Получено");
            incomingBody.setText(body.toString().trim());
            incomingActions.setVisibility(View.VISIBLE);
            incomingInstall.setVisibility(state.receivedApkUri != null
                    ? View.VISIBLE : View.GONE);
            incomingInstall.setText("Установить приложение");
            findViewById(R.id.incoming_copy).setVisibility(View.GONE);
            incomingOpen.setVisibility(View.GONE);
            if (state.mode == State.Mode.SUCCESS) {
                View sc = findViewById(R.id.scroll);
                if (sc != null) sc.post(() -> sc.scrollTo(0, incomingPanel.getTop()));
            }
        } else if (state.receivedApkUri != null) {
            incomingPanel.setVisibility(View.VISIBLE);
            incomingTitle.setText("Получен APK-файл");
            incomingBody.setText("Приложение сохранено в Загрузки/GLINK. Нажмите «Установить приложение», чтобы поставить его.");
            incomingActions.setVisibility(View.VISIBLE);
            incomingInstall.setVisibility(View.VISIBLE);
            incomingInstall.setText("Установить приложение");
            findViewById(R.id.incoming_copy).setVisibility(View.GONE);
            incomingOpen.setVisibility(View.GONE);
        } else if (state.incomingText != null || state.incomingLink != null) {
            incomingPanel.setVisibility(View.VISIBLE);
            incomingInstall.setVisibility(View.GONE);
            findViewById(R.id.incoming_copy).setVisibility(View.VISIBLE);
            if (state.incomingLink != null) {
                incomingTitle.setText("Ссылка");
                incomingBody.setText(state.incomingLink);
                incomingActions.setVisibility(View.VISIBLE);
                incomingOpen.setVisibility(View.VISIBLE);
            } else {
                incomingTitle.setText("Полученный текст");
                incomingBody.setText(state.incomingText);
                incomingActions.setVisibility(View.VISIBLE);
                incomingOpen.setVisibility(View.GONE);
            }
        }
        View resendBtn = findViewById(R.id.btn_resend);
        if (resendBtn != null) {
            boolean canResend = state.mode == State.Mode.SUCCESS
                    && state.lastSentItems != null && !state.lastSentItems.isEmpty()
                    && !state.hasOutbound();
            resendBtn.setVisibility(canResend ? View.VISIBLE : View.GONE);
        }
        execFunCommand(state);
        maybeShowWifiOffer(state);
        if (state.mode == State.Mode.ERROR || state.mode == State.Mode.SUCCESS) {
            main.removeCallbacks(returnToReady);
            main.postDelayed(returnToReady, state.mode == State.Mode.SUCCESS ? 2200 : 3200);
        }
        updateNfcMode();
    }

    private String lastItemsSig = "";

    private void rebuildItems(State state) {
        if (itemsContainer == null) return;
        List<OutItem> items;
        synchronized (state.outbound) {
            items = new ArrayList<>(state.outbound);
        }
        // во время передачи прогресс нотифится постоянно: не перестраиваем список,
        // если состав не менялся — иначе строки мигают и анимация перезапускается
        StringBuilder sigB = new StringBuilder();
        for (OutItem it : items) sigB.append(it.kind).append(':').append(it.label()).append(':').append(it.size).append('|');
        String sig = sigB.toString();
        if (sig.equals(lastItemsSig) && itemsContainer.getChildCount() == items.size() + (items.isEmpty() ? 0 : 1)) return;
        lastItemsSig = sig;
        itemsContainer.removeAllViews();
        float d = getResources().getDisplayMetrics().density;

        if (!items.isEmpty()) {
            // шапка предпросмотра: сколько файлов и общий размер + очистить всё
            long tot = 0;
            for (OutItem it : items) {
                if (it.size > 0 && it.kind != OutItem.KIND_TEXT && it.kind != OutItem.KIND_FUN) tot += it.size;
            }
            LinearLayout head = new LinearLayout(this);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.setPadding((int) (14 * d), (int) (6 * d), (int) (6 * d), (int) (2 * d));
            TextView ht = new TextView(this);
            ht.setText("К ОТПРАВКЕ: " + items.size() + (tot > 0 ? " · " + com.prilozhi.app.util.Fmt.size(tot) : ""));
            ht.setTextColor(0xFF8FE3C0);
            ht.setTextSize(11.5f);
            ht.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            head.addView(ht);
            Button clear = new Button(this);
            clear.setText("Очистить всё");
            clear.setTextSize(11f);
            clear.setTextColor(0xFFFFB74D);
            clear.setBackgroundColor(0x00000000);
            clear.setOnClickListener(v -> {
                synchronized (state.outbound) {
                    state.outbound.clear();
                }
                state.notifyChanged();
                refreshArmedState();
            });
            head.addView(clear);
            itemsContainer.addView(head);
        }

        for (OutItem it : items) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setBackgroundResource(R.drawable.bg_card);
            row.setPadding((int) (10 * d), (int) (8 * d), (int) (8 * d), (int) (8 * d));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = (int) (8 * d);
            row.setLayoutParams(lp);

            // превью: миниатюра фото/видео или цветной значок типа
            android.widget.ImageView thumb = new android.widget.ImageView(this);
            thumb.setLayoutParams(new LinearLayout.LayoutParams((int) (44 * d), (int) (44 * d)));
            boolean gotThumb = false;
            if (it.uri != null && it.mime != null
                    && (it.mime.startsWith("image/") || it.mime.startsWith("video/"))) {
                try {
                    android.graphics.Bitmap bm = getContentResolver().loadThumbnail(
                            it.uri, new android.util.Size(128, 128), null);
                    if (bm != null) {
                        thumb.setImageBitmap(bm);
                        thumb.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
                        gotThumb = true;
                    }
                } catch (Exception ignored) {
                }
            }
            if (!gotThumb) {
                // своя иконка по типу контента (не логотип приложения!)
                int iconRes;
                if (it.kind == OutItem.KIND_TEXT) iconRes = it.isLink ? R.drawable.ic_type_link : R.drawable.ic_type_text;
                else if (it.kind == OutItem.KIND_FUN) iconRes = R.drawable.ic_type_fun;
                else if (it.kind == OutItem.KIND_TREE) iconRes = R.drawable.ic_type_folder;
                else iconRes = R.drawable.ic_type_file;
                thumb.setImageResource(iconRes);
                thumb.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
                thumb.setPadding((int) (9 * d), (int) (9 * d), (int) (9 * d), (int) (9 * d));
                thumb.setBackgroundColor(0xFF1B1B26);
            }
            // одинаковое скругление превью у всех типов: 10dp
            final float thumbCorner = 10 * d;
            thumb.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View v, android.graphics.Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), thumbCorner);
                }
            });
            thumb.setClipToOutline(true);
            row.addView(thumb);

            LinearLayout texts = new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            texts.setPadding((int) (10 * d), 0, 0, 0);
            texts.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            TextView tv = new TextView(this);
            tv.setText(it.label());
            tv.setTextColor(getColor(R.color.text_primary));
            tv.setTextSize(13.5f);
            tv.setMaxLines(1);
            tv.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            texts.addView(tv);
            TextView sub = new TextView(this);
            if (it.kind == OutItem.KIND_TEXT) {
                int chars = it.text != null ? it.text.length() : 0;
                sub.setText(it.typeLabel() + (chars > 0 ? " · " + chars + " симв." : ""));
            } else if (it.kind == OutItem.KIND_FUN) {
                sub.setText("Прикол · GLINKFUN/1");
            } else {
                sub.setText(it.typeLabel() + (it.size > 0 ? " · " + com.prilozhi.app.util.Fmt.size(it.size) : ""));
            }
            sub.setTextColor(0xFF9E97C4);
            sub.setTextSize(11.5f);
            texts.addView(sub);
            row.addView(texts);

            Button del = new Button(this);
            del.setText("✕");
            del.setTextColor(getColor(R.color.amber));
            del.setBackgroundResource(R.drawable.btn_secondary);
            del.setOnClickListener(v -> {
                synchronized (state.outbound) {
                    state.outbound.remove(it);
                }
                state.notifyChanged();
                refreshArmedState();
            });
            row.addView(del);
            row.setAlpha(0f);
            row.setTranslationX(42f);
            row.animate().alpha(1f).translationX(0f).setDuration(240)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
            itemsContainer.addView(row);
        }
        itemsContainer.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
    }

    // ------------------------------------------------------------------
    // Выбор контента (вызывается островком)

    private boolean wifiOfferShowing = false;

    /** Wi-Fi: список устройств рядом (телефоны и ПК с открытой страницей GLINK). */
    private void showWifiDevicesDialog() {
        State st = State.get();
        if (!st.hasOutbound()) {
            Toast.makeText(this, "Сначала выберите, что отправить — потом устройство по Wi-Fi",
                    Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Ищу устройства рядом…", Toast.LENGTH_SHORT).show();
        com.prilozhi.app.net.RelayTransfer.fetchDevices(devices -> {
            if (devices.isEmpty()) {
                String reason = State.get().wifiStatus;
                Toast.makeText(this, reason == null || reason.isEmpty()
                                ? "Нет доступных обновлённых устройств: откройте GLINK на телефоне или на ПК"
                                : reason,
                        Toast.LENGTH_LONG).show();
                return;
            }
            String[] names = new String[devices.size()];
            for (int i = 0; i < devices.size(); i++) names[i] = devices.get(i)[1];
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Отправить по Wi-Fi")
                    .setItems(names, (d, w) -> {
                        String[] dev = devices.get(w);
                        com.prilozhi.app.net.RelayTransfer.offerTo(this, dev[0], dev[1], dev[2]);
                        Toast.makeText(this, "Отправляю на " + dev[1] + "…", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
        });
    }

    /** Входящее Wi-Fi предложение: принять или отклонить. */
    private void maybeShowWifiOffer(State state) {
        if (state.offerSession == null || state.offerSession.isEmpty() || wifiOfferShowing) return;
        wifiOfferShowing = true;
        final String sess = state.offerSession;
        final String key = state.offerKey;
        final String from = state.offerFrom;
        state.offerSession = null;
        state.offerKey = null;
        new android.app.AlertDialog.Builder(this)
                .setTitle("Передача по Wi-Fi")
                .setMessage(from + " хочет передать вам файлы. Принять?")
                .setPositiveButton("Принять", (d, w) -> {
                    wifiOfferShowing = false;
                    com.prilozhi.app.net.RelayTransfer.ackOffer(sess);
                    startPcReceive(sess, key.replace('-', '+').replace('_', '/'));
                })
                .setNegativeButton("Отклонить", (d, w) -> {
                    wifiOfferShowing = false;
                    com.prilozhi.app.net.RelayTransfer.ackOffer(sess);
                })
                .setOnCancelListener(d -> {
                    wifiOfferShowing = false;
                    com.prilozhi.app.net.RelayTransfer.ackOffer(sess);
                })
                .show();
    }

    private void soundTick() {
        try {
            android.media.ToneGenerator tg = new android.media.ToneGenerator(
                    android.media.AudioManager.STREAM_MUSIC, 22);
            tg.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 45);
            main.postDelayed(tg::release, 120);
        } catch (Exception ignored) {
        }
        try {
            island.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
        } catch (Exception ignored) {
        }
    }

    public void routePick(String pick) {
        if (pick == null) return;
        if ("__close".equals(pick)) {
            moveTaskToBack(true); // приложение «улетает», но не закрывается
            return;
        }
        if ("__wifi".equals(pick)) {
            showWifiDevicesDialog();
            return;
        }
        switch (pick) {
            case "media": pickByMime(new String[]{"image/*", "video/*"}); break;
            case "music": pickByMime(new String[]{"audio/*"}); break;
            case "files": pickFiles(); break;
            case "folder": pickFolder(); break;
            case "apps": showAppsDialog(); break;
            case "camera": takePhoto(); break;
            case "text": showTextInput(); break;
            case "contact": pickContact(); break;
            case "geo": shareGeo(); break;
            default: break;
        }
    }

    private void pickByMime(String[] mimes) {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, REQ_FILES);
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось открыть выбор файлов", Toast.LENGTH_SHORT).show();
        }
    }

    private void pickFiles() {
        pickByMime(new String[]{"*/*"});
    }

    private void pickFolder() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, REQ_TREE);
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось открыть выбор папки", Toast.LENGTH_SHORT).show();
        }
    }

    private void showAppsDialog() {
        try {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> all = pm.getInstalledApplications(0);
            List<ApplicationInfo> apps = new ArrayList<>();
            for (ApplicationInfo a : all) {
                if (a.sourceDir != null && (a.flags & ApplicationInfo.FLAG_SYSTEM) == 0) apps.add(a);
            }
            apps.sort((x, y) -> pm.getApplicationLabel(x).toString()
                    .compareToIgnoreCase(pm.getApplicationLabel(y).toString()));
            String[] names = new String[apps.size()];
            for (int i = 0; i < apps.size(); i++) names[i] = pm.getApplicationLabel(apps.get(i)).toString();
            new AlertDialog.Builder(this)
                    .setTitle("Какое приложение отправить?")
                    .setItems(names, (d, w) -> {
                        ApplicationInfo app = apps.get(w);
                        String label = pm.getApplicationLabel(app).toString();
                        File f = new File(app.publicSourceDir);
                        addOutbound(OutItem.file(Uri.fromFile(f),
                                label.replaceAll("[^a-zA-Zа-яА-Я0-9 _.-]", "") + ".apk",
                                "application/vnd.android.package-archive",
                                f.exists() ? f.length() : -1));
                    })
                    .show();
        } catch (Exception e) {
            Toast.makeText(this, "Список приложений недоступен", Toast.LENGTH_SHORT).show();
        }
    }

    private void showTextInput() {
        EditText et = new EditText(this);
        et.setHint("Текст или ссылка…");
        et.setMinLines(2);
        new AlertDialog.Builder(this)
                .setTitle("Что отправить?")
                .setView(et)
                .setPositiveButton("В очередь", (d, w) -> {
                    String t = et.getText().toString().trim();
                    if (!t.isEmpty()) addOutbound(OutItem.text(t, isLink(t)));
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void addFromClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip() != null
                && cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence t = cm.getPrimaryClip().getItemAt(0).getText();
            if (t != null && t.length() > 0) {
                addOutbound(OutItem.text(t.toString(), isLink(t.toString())));
                return;
            }
        }
        Toast.makeText(this, "Буфер обмена пуст", Toast.LENGTH_SHORT).show();
    }

    private void pickContact() {
        try {
            startActivityForResult(new Intent(Intent.ACTION_PICK,
                    ContactsContract.Contacts.CONTENT_URI), REQ_CONTACT);
        } catch (Exception e) {
            Toast.makeText(this, "Контакты недоступны", Toast.LENGTH_SHORT).show();
        }
    }

    private void takePhoto() {
        try {
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME,
                    "GLINK_" + System.currentTimeMillis() + ".jpg");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GLINK");
            pendingCameraUri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(i, REQ_CAMERA);
        } catch (Exception e) {
            Toast.makeText(this, "Камера недоступна", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareGeo() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_PERMS);
            Toast.makeText(this, "Разрешите геопозицию и попробуйте ещё раз", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            android.location.LocationManager lm =
                    (android.location.LocationManager) getSystemService(LOCATION_SERVICE);
            android.location.Location best = null;
            if (lm == null) throw new IllegalStateException("Location service unavailable");
            for (String pr : lm.getProviders(true)) {
                // With approximate-only permission Android may reject GPS, but still allow network.
                try {
                    android.location.Location l = lm.getLastKnownLocation(pr);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (SecurityException ignored) { }
            }
            if (best == null) {
                Toast.makeText(this, "Позиция пока не определена", Toast.LENGTH_LONG).show();
                return;
            }
            String link = "https://maps.google.com/?q=" + best.getLatitude() + "," + best.getLongitude();
            addOutbound(OutItem.text("Моя геопозиция: " + link, true));
        } catch (Exception e) {
            Toast.makeText(this, "Геопозиция недоступна", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleContactPicked(Uri uri) {
        try {
            String name = "Контакт";
            StringBuilder vcf = new StringBuilder("BEGIN:VCARD\nVERSION:3.0\n");
            Cursor c = getContentResolver().query(uri, null, null, null, null);
            String id = null;
            if (c != null) {
                if (c.moveToFirst()) {
                    id = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID));
                    name = c.getString(c.getColumnIndexOrThrow(
                            ContactsContract.Contacts.DISPLAY_NAME));
                }
                c.close();
            }
            vcf.append("FN:").append(name).append("\n");
            if (id != null) {
                Cursor ph = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?",
                        new String[]{id}, null);
                if (ph != null) {
                    while (ph.moveToNext()) {
                        vcf.append("TEL:").append(ph.getString(ph.getColumnIndexOrThrow(
                                ContactsContract.CommonDataKinds.Phone.NUMBER))).append("\n");
                    }
                    ph.close();
                }
                Cursor em = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Email.CONTENT_URI, null,
                        ContactsContract.CommonDataKinds.Email.CONTACT_ID + "=?",
                        new String[]{id}, null);
                if (em != null) {
                    while (em.moveToNext()) {
                        vcf.append("EMAIL:").append(em.getString(em.getColumnIndexOrThrow(
                                ContactsContract.CommonDataKinds.Email.ADDRESS))).append("\n");
                    }
                    em.close();
                }
            }
            vcf.append("END:VCARD\n");
            File f = new File(getCacheDir(),
                    name.replaceAll("[^a-zA-Zа-яА-Я0-9 _-]", "") + ".vcf");
            try (FileOutputStream fos = new FileOutputStream(f)) {
                fos.write(vcf.toString().getBytes(StandardCharsets.UTF_8));
            }
            addOutbound(OutItem.file(Uri.fromFile(f), f.getName(), "text/vcard", f.length()));
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось прочитать контакт", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILES) {
            if (resultCode != RESULT_OK || data == null) return;
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < clip.getItemCount(); i++) {
                    Uri u = clip.getItemAt(i).getUri();
                    if (u != null) addOutbound(itemFromUri(u));
                }
            } else if (data.getData() != null) {
                addOutbound(itemFromUri(data.getData()));
            }
        } else if (requestCode == REQ_TREE) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
            Uri tree = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(tree,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            String name = "Папка";
            try (Cursor c = getContentResolver().query(tree, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int idx = c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                    if (idx >= 0) name = c.getString(idx);
                }
            } catch (Exception ignored) {
            }
            addOutbound(OutItem.tree(tree, name));
        } else if (requestCode == REQ_CONTACT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                handleContactPicked(data.getData());
            }
        } else if (requestCode == REQ_CAMERA) {
            if (resultCode == RESULT_OK && pendingCameraUri != null) {
                addOutbound(OutItem.file(pendingCameraUri, "Фото с камеры.jpg", "image/jpeg", -1));
            }
            pendingCameraUri = null;
        }
    }

    private OutItem itemFromUri(Uri u) {
        try {
            getContentResolver().takePersistableUriPermission(u,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        String name = null;
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {
        }
        long size = ManifestBuilder.querySize(this, u);
        String mime = getContentResolver().getType(u);
        return OutItem.file(u, name != null ? name : "file", mime, size);
    }

    private boolean isLink(String t) {
        return t != null && (t.startsWith("http://") || t.startsWith("https://")
                || t.startsWith("www."));
    }

    private void addOutbound(OutItem it) {
        State st = State.get();
        synchronized (st.outbound) {
            st.outbound.add(it);
        }
        st.addHistory("Добавлено в очередь", it.label(), true);
        st.notifyChanged();
        refreshArmedState();
    }

    // ------------------------------------------------------------------
    // Интенты извне

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        String pick = intent.getStringExtra("pick");
        if (pick != null) {
            intent.removeExtra("pick");
            main.post(() -> routePick(pick));
            return;
        }
        String action = intent.getAction();
        if ("grp.gs.glink.action.SHOW_PUBLIC_ID".equals(action)) {
            intent.setAction(Intent.ACTION_MAIN);
            if (resumed && publicIdGate != null) publicIdGate.openPublicId();
            else publicIdRequested = true;
            return;
        }
        if (Intent.ACTION_SEND.equals(action) || Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            // «Поделиться» из любого приложения: файлы/пачки — в очередь одним пакетом
            java.util.List<OutItem> batch = new java.util.ArrayList<>();
            if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
                ArrayList<Uri> list = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                if (list != null) {
                    for (Uri u : list) if (u != null) batch.add(itemFromUri(u));
                }
            } else {
                Uri stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                if (stream != null) batch.add(itemFromUri(stream));
            }
            if (batch.isEmpty()) {
                String text = intent.getStringExtra(Intent.EXTRA_TEXT);
                if (text == null || text.isEmpty()) text = intent.getStringExtra(Intent.EXTRA_SUBJECT);
                if (text != null && !text.isEmpty()) {
                    batch.add(OutItem.text(text, isLink(text)));
                }
            }
            if (!batch.isEmpty()) {
                State st = State.get();
                synchronized (st.outbound) {
                    st.outbound.addAll(batch);
                }
                st.addHistory("Добавлено через «Поделиться»", batch.size() + " элемент(ов)", true);
                st.notifyChanged();
                refreshArmedState(); // заливка на сервер стартует сразу, один раз
                Toast.makeText(this, "GLINK: добавлено " + batch.size()
                        + " — заливка на сервер уже идёт, приложите телефоны", Toast.LENGTH_LONG).show();
            }
            intent.setAction(Intent.ACTION_MAIN);
        }
    }

    /** Получение выбранным устройством: ключ уже расшифрован локально. */
    private void startPcReceive(String session, String keyB64) {
        State st = State.get();
        if (st.mode == State.Mode.TRANSFER) return;
        st.sessionActive = true;
        st.peerName = "Устройство";
        st.tapDoneAt = System.currentTimeMillis();
        TransferService.start(this);
        st.setMode(State.Mode.TRANSFER, "Передача: подключение…", "Скачиваю с сервера GrapeScript");
        synchronized (st.lastReceived) {
            st.lastReceived.clear();
            st.lastReceivedUris.clear();
        }
        new Thread(() -> {
            boolean done = com.prilozhi.app.net.RelayTransfer.receive(
                    getApplicationContext(), session, keyB64,
                    new com.prilozhi.app.net.ReceiveStore(getApplicationContext()));
            st.sessionActive = false;
            if (done) {
                st.progress = 1f;
                st.cooldownUntil = System.currentTimeMillis() + 5000;
                st.setMode(State.Mode.SUCCESS, "Готово!", "Получено по Wi-Fi");
                runOnUiThread(() -> onNfcTransfer(true, "Получено по Wi-Fi"));
            } else {
                String msg = "Не удалось получить: " + st.gfcasPhase;
                st.setMode(State.Mode.ERROR, "Не удалось передать", msg);
                runOnUiThread(() -> onNfcTransfer(false, msg));
            }
            st.notifyChanged();
        }, "glink-pc-receive").start();
    }

    // ------------------------------------------------------------------
    // TapReader.Listener

    @Override
    public void onTransferStarted(String peerName) {
        runOnUiThread(() -> {
            TransferService.start(this);
            play(sndTap);
            Haptics.tap(this);
        });
    }

    @Override
    public void onNfcTransfer(boolean ok, String message) {
        runOnUiThread(() -> {
            State st = State.get();
            if (ok) btTryPowerOff();
            if (ok) {
                play(sndDone);
                st.addHistory("Обмен по NFC с " + (st.peerName != null ? st.peerName : "телефоном"),
                        st.receivedApkUri != null
                                ? "Получен APK — можно установить"
                                : "Файлы сохранены в Загрузки/GLINK", true);
            } else if (st.mode == State.Mode.ERROR) {
                play(sndErr);
                st.addHistory("Ошибка передачи по NFC", message, false);
            } else {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                refreshArmedState();
            }
            st.notifyChanged();
        });
    }

    // ------------------------------------------------------------------
    // Гейт разрешений

    private void setControlsEnabled(boolean en) {
        // Выбор контента живёт в островке; гейт перекрывает экран панелью.
    }

    private void refreshGate() {
        List<String> lines = new ArrayList<>();
        String first = null;

        boolean nfcOk = nfcAdapter != null && nfcAdapter.isEnabled();
        lines.add((nfcOk ? "✓ " : "✗ ") + "Включён NFC");
        if (!nfcOk) first = "nfc";

        // Интернет: единственный транспорт — серверный релей (разрешение + сеть онлайн)
        boolean netPermOk = checkSelfPermission(Manifest.permission.INTERNET)
                == PackageManager.PERMISSION_GRANTED;
        boolean netOn = false;
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager)
                    getSystemService(Context.CONNECTIVITY_SERVICE);
            android.net.Network nw = cm != null ? cm.getActiveNetwork() : null;
            android.net.NetworkCapabilities caps = nw != null ? cm.getNetworkCapabilities(nw) : null;
            netOn = caps != null && caps.hasCapability(
                    android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Throwable ignored) {
        }
        lines.add((netPermOk && netOn ? "✓ " : "✗ ") + "Интернет для передачи (сервер GrapeScript)");
        if ((!netPermOk || !netOn) && first == null) first = "net";

        boolean notifOk;
        try {
            android.app.NotificationManager nm2 =
                    (android.app.NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notifOk = nm2 != null && nm2.areNotificationsEnabled();
        } catch (Throwable t) {
            notifOk = true;
        }
        lines.add((notifOk ? "✓ " : "✗ ") + "Уведомления о передаче");
        if (!notifOk && first == null) first = "notif";

        boolean storageOk;
        if (Build.VERSION.SDK_INT >= 30) {
            storageOk = Environment.isExternalStorageManager();
        } else {
            storageOk = checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED;
        }
        lines.add((storageOk ? "✓ " : "✗ ") + "Доступ к хранилищу");
        if (!storageOk && first == null) first = "storage";

        boolean installOk = Build.VERSION.SDK_INT < 26
                || getPackageManager().canRequestPackageInstalls();
        lines.add((installOk ? "✓ " : "✗ ") + "Установка обновлений GLINK");
        if (!installOk && first == null) first = "install";

        gateNext = first;
        if (first == null) {
            gatePanel.setVisibility(View.GONE);
        } else {
            gatePanel.setVisibility(View.VISIBLE);
            StringBuilder sb = new StringBuilder();
            for (String l : lines) sb.append(l).append("\n");
            gateText.setText(sb.toString().trim());
        }
    }

    private void openNextGateStep() {
        if (gateNext == null) {
            refreshGate();
            return;
        }
        try {
            switch (gateNext) {
                case "nfc":
                    startActivity(new Intent(Settings.ACTION_NFC_SETTINGS));
                    break;
                case "net":
                    try {
                        startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                    } catch (Exception e) {
                        startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
                    }
                    break;
                case "notif":
                    if (Build.VERSION.SDK_INT >= 33) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_PERMS);
                    } else {
                        Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                        i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                        startActivity(i);
                    }
                    break;
                case "storage":
                    if (Build.VERSION.SDK_INT >= 30) {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                    Uri.parse("package:" + getPackageName())));
                        } catch (Exception e) {
                            startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                        }
                    } else {
                        requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERMS);
                    }
                    break;
                case "install":
                    if (Build.VERSION.SDK_INT >= 26) {
                        startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:" + getPackageName())));
                    }
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            Toast.makeText(this, "Откройте настройки вручную", Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------------
    // Секретная панель приколов и логотип

    private void setupFunPanel() {
        LinearLayout funPanel = findViewById(R.id.fun_panel);
        funPanel.removeAllViews();
        addFunTile(funPanel, "LOGO", "Логотип на весь экран", "Отправить фирменный знак", 0xFF9B30C9);
        addFunTile(funPanel, "SALUTE", "Виноградный салют", "Весёлый сигнал на островке", 0xFF8B5CF6);
        addFunTile(funPanel, "RAIN", "Виноградный дождь", "Гроздья плавно падают по экрану", 0xFF9644D8);
        addFunTile(funPanel, "VIBRO", "Вибра-ритм", "Короткий ритм на телефоне", 0xFF30C685);
        addFunTile(funPanel, "DISCO", "Дискотека", "Мягкое движение цветных огней", 0xFFCC5BAF);
        addFunTile(funPanel, "QUAKE", "Землетрясение", "Экран ненадолго встряхнётся", 0xFFEBA046);
        addFunTile(funPanel, "FLIP", "Перевёрнутый экран", "Повернуть экран на несколько секунд", 0xFF4A94DD);
        addFunTile(funPanel, "SIREN", "Сирена", "Звуковой сигнал и вибрация", 0xFFE36D7A);
        addFunTile(funPanel, "TORCH", "Маячок", "Мигание фонарика", 0xFFE3B94B);
        addFunTile(funPanel, "PULSE", "Сердечный пульс", "Ритм тук-тук", 0xFFDF629A);
        addFunTile(funPanel, "CONFETTI", "Конфетти", "Цветной праздник на экране", 0xFF26B77E);
        addFunTile(funPanel, "ORBIT", "Орбита GS", "Цветные точки кружатся вокруг центра", 0xFF7F57C8);
        addFunTile(funPanel, "STARS", "Звёздный полёт", "Мягкие звёзды летят навстречу", 0xFF438FC3);
        addFunTile(funPanel, "WAVES", "Виноградные волны", "Плавные расходящиеся круги", 0xFF21A993);

        View logo = findViewById(R.id.header_logo);
        final int[] taps = {0};
        final long[] last = {0};
        View.OnClickListener logoClick = v -> {
            long now = android.os.SystemClock.uptimeMillis();
            if (now - last[0] > 1800) taps[0] = 0;
            last[0] = now;
            if (++taps[0] >= 3) {
                taps[0] = 0;
                v.animate().cancel();
                v.setScaleX(1f); v.setScaleY(1f);
                setFunMode(true);
            } else {
                // A local, gentle response; it never adds a prank to an outgoing transfer.
                v.animate().cancel();
                v.animate().scaleX(.94f).scaleY(.94f).setDuration(90)
                        .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()).start();
            }
        };
        logo.setOnClickListener(logoClick);
        findViewById(R.id.btn_fun_exit_circle).setOnClickListener(v -> setFunMode(false));
    }

    private void setFunMode(boolean visible) {
        funMode = visible;
        if (visible) island.collapse();
        findViewById(R.id.scroll).setVisibility(visible ? View.GONE : View.VISIBLE);
        island.setVisibility(visible ? View.GONE : View.VISIBLE);
        findViewById(R.id.fun_screen).setVisibility(visible ? View.VISIBLE : View.GONE);
        if (visible) {
            ((android.widget.ScrollView) findViewById(R.id.fun_scroll)).scrollTo(0, 0);
            stopTitleFlow();
        } else {
            TextView title = findViewById(R.id.title);
            if (resumed && titleShader != null) startTitleFlow(title, title.getWidth());
        }
        if (gsLogoTileWeb != null) gsLogoTileWeb.post(() -> syncGsLogoTilePlayback(true));
    }

    @Override
    public void onBackPressed() {
        if (funMode) { setFunMode(false); return; }
        super.onBackPressed();
    }

    private void addFunTile(LinearLayout panel, String command, String title, String description, int accent) {
        float d = getResources().getDisplayMetrics().density;
        com.prilozhi.app.ui.GlassTileLayout row = new com.prilozhi.app.ui.GlassTileLayout(this);
        row.setAccentColor(accent);
        row.setPadding(Math.round(14*d), Math.round(11*d), Math.round(14*d), Math.round(11*d));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = Math.round(10*d);
        row.setLayoutParams(lp);
        com.prilozhi.app.ui.FunIconView icon = new com.prilozhi.app.ui.FunIconView(this, command, accent);
        row.addView(icon, new LinearLayout.LayoutParams(Math.round(46*d), Math.round(46*d)));
        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(0, -2, 1);
        textLp.leftMargin = Math.round(12*d);
        text.setLayoutParams(textLp);
        TextView name = new TextView(this);
        name.setText(title); name.setTextSize(15); name.setTextColor(0xFFFFFFFF);
        name.setTypeface(android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL));
        TextView detail = new TextView(this);
        detail.setText(description); detail.setTextSize(12.5f); detail.setTextColor(0xD1FFFFFF);
        text.addView(name); text.addView(detail); row.addView(text);
        TextView arrow = new TextView(this);
        arrow.setText("›"); arrow.setTextSize(24); arrow.setTextColor(getColor(R.color.green_soft));
        row.addView(arrow);
        row.setClickable(true);
        row.setContentDescription(title + ". " + description);
        row.setOnClickListener(v -> queueFun(command));
        panel.addView(row);
    }

    private void queueFun(String cmd) {
        State st = State.get();
        synchronized (st.outbound) {
            // ПРИКОЛ — ТОЛЬКО ОДИН и отдельной передачей: второй не добавляем вообще
            for (OutItem it : st.outbound) {
                if (it.kind == OutItem.KIND_FUN) {
                    Toast.makeText(this, "За один раз — только один прикол!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            if (!st.outbound.isEmpty()) {
                Toast.makeText(this, "Сначала отправьте выбранное — прикол летит отдельно",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            st.outbound.add(OutItem.fun(cmd));
        }
        st.notifyChanged();
        refreshArmedState();
        setFunMode(false);
        Toast.makeText(this, "Приложите телефоны зад к заду — прикол улетит касанием",
                Toast.LENGTH_SHORT).show();
    }


    private void execFunCommand(State state) {
        String cmd = state.incomingFun;
        if (cmd == null || cmd.isEmpty()) return;
        state.incomingFun = null;
        View overlay = findViewById(R.id.fun_overlay);
        View img = findViewById(R.id.fun_overlay_img);
        View rootV = findViewById(R.id.root);
        switch (cmd) {
            case "LOGO":
                overlay.setVisibility(View.VISIBLE);
                img.setVisibility(View.VISIBLE);
                overlay.setAlpha(0f);
                overlay.animate().alpha(1f).setDuration(350).start();
                Haptics.success(this);
                main.postDelayed(() -> overlay.animate().alpha(0f).setDuration(400)
                        .withEndAction(() -> overlay.setVisibility(View.GONE)).start(), 5200);
                break;
            case "RAIN":
            case "DISCO":
            case "CONFETTI":
            case "ORBIT":
            case "STARS":
            case "WAVES": {
                overlay.animate().cancel();
                overlay.setAlpha(1f);
                overlay.setBackgroundColor(0xE90A0715);
                overlay.setVisibility(View.VISIBLE);
                img.setVisibility(View.GONE);
                com.prilozhi.app.ui.FunEffectView effect = findViewById(R.id.fun_effect);
                effect.play(cmd, () -> {
                    overlay.setVisibility(View.GONE);
                    overlay.setBackgroundColor(0xF5000000);
                    img.setVisibility(View.VISIBLE);
                });
                Haptics.tap(this);
                break;
            }
            case "QUAKE": { // землетрясение: экран трясётся
                final int[] step = {0};
                Runnable[] tick = new Runnable[1];
                tick[0] = () -> {
                    if (step[0] >= 16) {
                        rootV.setTranslationX(0);
                        rootV.setTranslationY(0);
                        return;
                    }
                    rootV.setTranslationX((float) (Math.random() * 28 - 14));
                    rootV.setTranslationY((float) (Math.random() * 20 - 10));
                    step[0]++;
                    main.postDelayed(tick[0], 55);
                };
                tick[0].run();
                Haptics.error(this);
                break;
            }
            case "FLIP": // экран вверх ногами на 5 секунд
                rootV.animate().rotation(180f).setDuration(500).start();
                Haptics.tap(this);
                main.postDelayed(() -> rootV.animate().rotation(0f).setDuration(500).start(), 5000);
                break;
            case "SIREN": // сирена тонами телефона
                new Thread(() -> {
                    try {
                        android.media.ToneGenerator tg = new android.media.ToneGenerator(
                                android.media.AudioManager.STREAM_MUSIC, 85);
                        for (int i = 0; i < 4; i++) {
                            tg.startTone(android.media.ToneGenerator.TONE_DTMF_1, 220);
                            Thread.sleep(260);
                            tg.startTone(android.media.ToneGenerator.TONE_DTMF_9, 220);
                            Thread.sleep(260);
                        }
                        tg.release();
                    } catch (Exception ignored) {
                    }
                }, "glink-fun-siren").start();
                try {
                    android.os.Vibrator vib2 = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
                    if (vib2 != null) vib2.vibrate(android.os.VibrationEffect
                            .createWaveform(new long[]{0, 200, 120, 200, 120, 200, 120, 200}, -1));
                } catch (Exception ignored) {
                }
                Toast.makeText(this, "Сирена от друга!", Toast.LENGTH_SHORT).show();
                break;
            case "TORCH": { // маячок: фонарик мигает
                try {
                    android.hardware.camera2.CameraManager cm =
                            (android.hardware.camera2.CameraManager) getSystemService(CAMERA_SERVICE);
                    String camId = null;
                    for (String id : cm.getCameraIdList()) {
                        android.hardware.camera2.CameraCharacteristics ch =
                                cm.getCameraCharacteristics(id);
                        Boolean fl = ch.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                        Integer facing = ch.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING);
                        if (fl != null && fl && facing != null
                                && facing == android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK) {
                            camId = id;
                            break;
                        }
                        if (fl != null && fl && camId == null) camId = id;
                    }
                    if (camId != null) {
                        final String cid = camId;
                        final boolean[] torchOk = {true};
                        for (int i = 0; i < 6; i++) {
                            final boolean on = i % 2 == 0;
                            main.postDelayed(() -> {
                                try { cm.setTorchMode(cid, on); }
                                catch (Exception e) { torchOk[0] = false; }
                                if (!torchOk[0]) {
                                    // фонарь занят/запрещён — мигаем экраном, прикол всё равно виден
                                    overlay.setVisibility(View.VISIBLE);
                                    img.setVisibility(View.GONE);
                                    overlay.setBackgroundColor(on ? 0xF5FFF6D8 : 0xF5000000);
                                    if (!on) main.postDelayed(() -> overlay.setVisibility(View.GONE), 200);
                                }
                            }, i * 220L);
                        }
                    }
                } catch (Exception ignored) {
                }
                Toast.makeText(this, "Маячок от друга!", Toast.LENGTH_SHORT).show();
                break;
            }
            case "PULSE": // сердечный пульс: вибрация тук-тук + пульс островка
                try {
                    android.os.Vibrator vib = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
                    if (vib != null) vib.vibrate(android.os.VibrationEffect
                            .createWaveform(new long[]{0, 130, 130, 130, 420, 130, 130, 130, 420}, -1));
                } catch (Exception ignored) {
                }
                island.pulse();
                main.postDelayed(() -> island.pulse(), 900);
                break;
            case "VIBRO":
                try {
                    android.os.Vibrator vib = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
                    if (vib != null) vib.vibrate(android.os.VibrationEffect
                            .createWaveform(new long[]{0, 90, 70, 90, 70, 200, 90, 300}, -1));
                } catch (Exception ignored) {
                }
                Toast.makeText(this, "Вибра-ритм от друга!", Toast.LENGTH_SHORT).show();
                break;
            case "SALUTE":
            default:
                island.pulse();
                Haptics.success(this);
                Toast.makeText(this, "Виноградный салют от друга!", Toast.LENGTH_LONG).show();
                break;
        }
    }

    private void setupGsLogo() {
        setupGsAnimation(R.id.header_logo_web, R.id.header_logo_fallback);
        setupGsAnimation(R.id.fun_logo_web, R.id.fun_logo_fallback);
    }

    /** The local Lottie bundle has no network access; keep the static mark if it cannot render. */
    private void setupGsAnimation(int webId, int fallbackId) {
        setupGsAnimation(findViewById(webId), findViewById(fallbackId));
    }

    private void setupGsAnimation(android.webkit.WebView web, View fallback) {
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setBlockNetworkLoads(true);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setWebViewClient(new android.webkit.WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(android.webkit.WebView v,
                    android.webkit.WebResourceRequest request) { return true; }
            @Override public void onPageFinished(android.webkit.WebView v, String url) {
                revealGsAnimation(v, fallback, 0);
                if (v == gsLogoTileWeb) syncGsLogoTilePlayback(true);
            }
        });
        web.loadUrl("file:///android_asset/gs_logo.html");
    }

    private void revealGsAnimation(android.webkit.WebView web, View fallback, int tries) {
        if (isFinishing() || isDestroyed() || web.getParent() == null || tries >= 20) return;
        web.evaluateJavascript("Boolean(window.__gsReady)", ready -> {
            if ("true".equals(ready)) fallback.setVisibility(View.GONE);
            else web.postDelayed(() -> revealGsAnimation(web, fallback, tries + 1), 250);
        });
    }

    /** Pause the small Lottie when scrolled away, the fun screen is open, or the app is backgrounded. */
    private void syncGsLogoTilePlayback(boolean force) {
        android.webkit.WebView animation = gsLogoTileWeb;
        if (animation == null) return;
        android.graphics.Rect visible = new android.graphics.Rect();
        View icon = gsLogoTileIcon;
        boolean play = resumed && !funMode && icon != null && icon.isShown()
                && icon.getGlobalVisibleRect(visible) && visible.width() > 0 && visible.height() > 0;
        if (!force && play == gsLogoTilePlaying) return;
        gsLogoTilePlaying = play;
        if (play) animation.onResume();
        // `anim` belongs to this local WebView, not the header or other WebViews.
        animation.evaluateJavascript("if(window.anim){window.anim." + (play ? "play()" : "pause()") + ";}", null);
        if (!play) animation.onPause();
    }

    // ------------------------------------------------------------------
    // Линкер (проекты GrapeScript)

    private void buildLinker() {
        LinearLayout box = findViewById(R.id.linker_container);
        if (box == null) return;
        box.removeAllViews();
        addLinkerTile(box, R.drawable.linker_glink, "GLINK — хаб GrapeScript",
                "Главное приложение компании: передача файлов и доступ ко всем проектам GrapeScript",
                "https://GrapeGG-developer.github.io/GLINK/", 0xFF26DC49);
        addLinkerTile(box, R.drawable.linker_web, "GLINK ВЕБ — ДЛЯ ПК",
                "Отправка файлов с компьютера на телефон прямо из браузера — без установки",
                BuildConfig.GLINK_RELAY_URL + "/glink/send", 0xFF1FD6A0);
        addLinkerTile(box, R.drawable.linker_gsynk, "GSYNK",
                "Автоматизация и глубокое управление смартфонов, и просто мультитул на все случаи!",
                "https://GrapeGG-developer.github.io/GSYNK/", 0xFF9B30C9);
        addLinkerTile(box, R.drawable.linker_loltube, "ЛОЛТУБ",
                "Независимая платформа для публикации и просмотра контента! + Телеканал \"ФаНтОмАс\"℗!",
                "https://grapescript.gitverse.site/loltube-download/", 0xFF6A48E8);
        addLinkerTile(box, R.drawable.linker_robo, "ROBOBATTLE GAMES©",
                "Платформа увлекательных игр от GS!",
                "https://GrapeGG-developer.github.io/RoboBattle-Web/", 0xFF53A5CA);
        addLinkerTile(box, R.drawable.linker_gshift, "GRAPESHIFT",
                "Анонимный шифратор и дешифратор, шифр — Gshift!",
                "https://GrapeGG-developer.github.io/gshift/", 0xFF17B978);
        addLinkerTile(box, R.drawable.linker_gs_logo, "GS LOGO",
                "Анимированный логотип GrapeScript", "https://grapegg-developer.github.io/GRAPESCRIPT/", 0xFFB449C4);
        addLinkerTile(box, R.drawable.linker_gplayland, "PLAYLAND",
                "Игры и Studio · только телефон", null, 0xFF0088FF, true, false);
        addLinkerTile(box, R.drawable.linker_gplus, "G+ — мессенджер",
                "Общение с контактами через GLINK", null, 0xFF6D36BF, true, false);
        addLinkerTile(box, R.drawable.linker_justgrape, "Твой ВПН",
                "Экспериментальная версия · серверы пока недоступны", null, 0xFF4E7D64, true, true);
        View scroll = findViewById(R.id.scroll);
        scroll.setOnScrollChangeListener((v, x, y, oldX, oldY) -> syncGsLogoTilePlayback(false));
    }

    private void addLinkerTile(LinearLayout box, int iconRes, String name,
                               String desc, String url, int accentColor) {
        addLinkerTile(box, iconRes, name, desc, url, accentColor, false, false);
    }

    private void addLinkerTile(LinearLayout box, int iconRes, String name,
                               String desc, String url, int accentColor,
                               boolean experimental, boolean justGrapePreview) {
        float d = getResources().getDisplayMetrics().density;
        com.prilozhi.app.ui.GlassTileLayout row = new com.prilozhi.app.ui.GlassTileLayout(this);
        // Rounded, translucent project colour over a genuinely blurred animated backdrop.
        row.setAccentColor(accentColor);
        row.setPadding((int) (14 * d), (int) (12 * d), (int) (14 * d), (int) (12 * d));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (10 * d);
        row.setLayoutParams(lp);

        android.widget.ImageView iv = new android.widget.ImageView(this);
        iv.setImageResource(iconRes);
        // одинаковое скругление иконок всех проектов (у GLINK иконка приложения — квадратная)
        final float corner = 12 * d;
        iv.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override
            public void getOutline(View v, android.graphics.Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), corner);
            }
        });
        iv.setClipToOutline(true);
        int sz = (int) (46 * d);
        if (iconRes == R.drawable.linker_gs_logo) {
            android.widget.FrameLayout icon = new android.widget.FrameLayout(this);
            icon.setOutlineProvider(iv.getOutlineProvider());
            icon.setClipToOutline(true);
            android.graphics.drawable.GradientDrawable backdrop = new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    new int[]{0xFF2F1139, 0xFF162528, 0xFF103520});
            backdrop.setCornerRadius(corner);
            icon.setBackground(backdrop);
            icon.addView(iv, new android.widget.FrameLayout.LayoutParams(-1, -1));
            android.webkit.WebView animation = new android.webkit.WebView(this);
            animation.setFocusable(false);
            animation.setClickable(false);
            animation.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            icon.addView(animation, new android.widget.FrameLayout.LayoutParams(-1, -1));
            // A transparent target forwards icon taps to the same tile as taps on its text.
            View iconTap = new View(this);
            iconTap.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            iconTap.setOnClickListener(v -> row.performClick());
            icon.addView(iconTap, new android.widget.FrameLayout.LayoutParams(-1, -1));
            row.addView(icon, new LinearLayout.LayoutParams(sz, sz));
            gsLogoTileWeb = animation;
            gsLogoTileIcon = icon;
            icon.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, oright, ob) -> syncGsLogoTilePlayback(false));
            setupGsAnimation(animation, iv);
        } else {
            iv.setLayoutParams(new LinearLayout.LayoutParams(sz, sz));
            row.addView(iv);
        }

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        clp.leftMargin = (int) (12 * d);
        col.setLayoutParams(clp);
        TextView nm = new TextView(this);
        nm.setTypeface(android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL));
        nm.setText(name);
        nm.setTextColor(0xFFFFFFFF);
        nm.setTextSize(15);
        if (experimental) {
            LinearLayout title = new LinearLayout(this);
            title.setOrientation(LinearLayout.HORIZONTAL);
            title.setGravity(android.view.Gravity.CENTER_VERTICAL);
            // Keep the flag visible on narrow screens; only the title may ellipsize.
            nm.setMaxLines(1);
            nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
            title.addView(nm, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            com.prilozhi.app.ui.ExperimentalBadgeView badge = new com.prilozhi.app.ui.ExperimentalBadgeView(this);
            LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            badgeLp.leftMargin = Math.round(6 * d);
            badgeLp.rightMargin = Math.round(5 * d);
            title.addView(badge, badgeLp);
            col.addView(title);
        } else {
            col.addView(nm);
        }
        TextView ds = new TextView(this);
        ds.setText(desc);
        ds.setTextColor(0xC9FFFFFF);
        ds.setTextSize(12.5f);
        col.addView(ds);
        row.addView(col);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextColor(getColor(R.color.green_soft));
        arrow.setTextSize(24);
        row.addView(arrow);

        if (iconRes == R.drawable.linker_gplayland) {
            row.setTag("gplaylandg_tile");
            row.setContentDescription("PLAYLAND, EXP. Открыть или установить.");
            row.setClickable(true);
            row.setOnClickListener(v -> openOrInstallPlayland());
        } else if (justGrapePreview) {
            com.prilozhi.app.ui.VpnExpTile.bind(row, this::downloadVpnExp);
        } else {
            row.setClickable(true);
            row.setOnClickListener(v -> {
                if (url == null) {
                    Intent launch = getPackageManager().getLaunchIntentForPackage("grp.gs.gplus");
                    if (launch != null) {
                        new Thread(() -> com.prilozhi.app.util.GPlusDownload.cleanupAfterInstalled(getApplicationContext()), "glink-gplus-cleanup").start();
                        startActivity(launch);
                    } else offerGPlusDownload();
                    return;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show();
                }
            });
        }
        box.addView(row);
    }

    // ------------------------------------------------------------------
    // Автообновление (обязательное, в фоне)

    private android.app.Dialog updDialog;
    private Uri updApkUri;
    private long updDlStartAt;
    private long updDlLastBytes;
    private float updDlSpeed;

    private volatile boolean updChecking = false;
    private volatile boolean checkingGPlusDownload = false;
    private Uri gplusReadyUri;
    private boolean gplusAwaitInstallPermission;
    private Uri vpnReadyUri;
    private boolean vpnAwaitInstallPermission;
    private Uri playlandReadyUri;
    private boolean playlandAwaitInstallPermission;

    private void downloadVpnExp() {
        if (isFinishing() || isDestroyed()) return;
        float density = getResources().getDisplayMetrics().density;
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding((int)(22*density), (int)(8*density), (int)(22*density), (int)(8*density));
        TextView warning = new TextView(this);
        warning.setText("Серверы пока недоступны. VPN не подключается.");
        content.addView(warning);
        TextView state = new TextView(this);
        state.setText("Подключение…");
        content.addView(state);
        android.widget.ProgressBar progress = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        content.addView(progress);
        AlertDialog panel = new AlertDialog.Builder(this).setTitle("Скачиваем «Твой ВПН» · EXP")
                .setView(content).setNegativeButton("Скрыть", null).create();
        panel.show();
        com.prilozhi.app.util.VpnExpDownload.download(getApplicationContext(), new com.prilozhi.app.util.VpnExpDownload.Callback() {
            @Override public void onProgress(long done, long total) {
                if (isFinishing() || isDestroyed()) return;
                if (total > 0) {
                    progress.setProgress((int)(done * 1000 / total));
                    state.setText((done * 100 / total) + "% · " + com.prilozhi.app.util.Fmt.size(done)
                            + " из " + com.prilozhi.app.util.Fmt.size(total));
                }
            }
            @Override public void onDone(Uri uri, String error) {
                if (isFinishing() || isDestroyed()) return;
                if (panel.isShowing()) panel.dismiss();
                if (uri == null) {
                    Toast.makeText(MainActivity.this, error, Toast.LENGTH_LONG).show();
                    return;
                }
                vpnReadyUri = uri;
                if (resumed && updApkUri == null && gplusReadyUri == null && !gplusAwaitInstallPermission) {
                    Uri ready = vpnReadyUri;
                    vpnReadyUri = null;
                    installVpnExp(ready);
                }
            }
        });
    }

    private void installVpnExp(Uri uri) {
        if (uri == null || isFinishing() || isDestroyed()) return;
        if (!getPackageManager().canRequestPackageInstalls()) {
            vpnReadyUri = uri;
            AlertDialog permission = new AlertDialog.Builder(this).setTitle("Установка «Твой ВПН» · EXP")
                    .setMessage("Разрешите GLINK устанавливать приложения в настройках Android. Затем Android попросит подтвердить установку.")
                    .setNegativeButton("Отмена", (d,w) -> vpnReadyUri = null)
                    .setPositiveButton("Настройки", (d,w) -> {
                        try {
                            vpnAwaitInstallPermission = true;
                            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
                        } catch (Exception e) {
                            vpnAwaitInstallPermission = false;
                            vpnReadyUri = null;
                            Toast.makeText(this, "Не удалось открыть настройки", Toast.LENGTH_SHORT).show();
                        }
                    }).create();
            permission.setOnCancelListener(d -> vpnReadyUri = null);
            permission.show();
            return;
        }
        try { UpdateManager.install(this, uri); }
        catch (Exception e) { Toast.makeText(this, "Не удалось открыть системную установку", Toast.LENGTH_LONG).show(); }
    }

    private void openOrInstallPlayland() {
        if (isFinishing() || isDestroyed()) return;
        try {
            android.content.pm.PackageInfo installed = getPackageManager().getPackageInfo(
                    com.prilozhi.app.util.GPlaylandPolicy.PACKAGE, 0);
            if (installed != null && installed.getLongVersionCode() >= com.prilozhi.app.util.GPlaylandPolicy.VERSION_CODE) {
                Intent launch = getPackageManager().getLaunchIntentForPackage(com.prilozhi.app.util.GPlaylandPolicy.PACKAGE);
                if (launch != null) {
                    startActivity(launch);
                    return;
                }
            }
        } catch (android.content.pm.PackageManager.NameNotFoundException ignored) {
        }
        downloadPlayland();
    }

    private void downloadPlayland() {
        if (isFinishing() || isDestroyed()) return;
        float density = getResources().getDisplayMetrics().density;
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding((int)(22*density), (int)(8*density), (int)(22*density), (int)(8*density));
        TextView state = new TextView(this);
        state.setText("Подключение…");
        content.addView(state);
        android.widget.ProgressBar progress = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        content.addView(progress);
        AlertDialog panel = new AlertDialog.Builder(this).setTitle("Скачиваем PLAYLAND · EXP")
                .setView(content).setNegativeButton("Скрыть", null).create();
        panel.show();
        com.prilozhi.app.util.GPlaylandDownload.download(getApplicationContext(), new com.prilozhi.app.util.GPlaylandDownload.Callback() {
            @Override public void onProgress(long done, long total) {
                if (isFinishing() || isDestroyed()) return;
                if (total > 0) {
                    progress.setProgress((int)(done * 1000 / total));
                    state.setText((done * 100 / total) + "% · " + com.prilozhi.app.util.Fmt.size(done)
                            + " из " + com.prilozhi.app.util.Fmt.size(total));
                }
            }
            @Override public void onDone(Uri uri, String error) {
                if (isFinishing() || isDestroyed()) return;
                if (panel.isShowing()) panel.dismiss();
                if (uri == null) {
                    Toast.makeText(MainActivity.this, error, Toast.LENGTH_LONG).show();
                    return;
                }
                playlandReadyUri = uri;
                if (resumed && updApkUri == null && gplusReadyUri == null && !gplusAwaitInstallPermission && vpnReadyUri == null) {
                    Uri ready = playlandReadyUri;
                    playlandReadyUri = null;
                    installPlayland(ready);
                }
            }
        });
    }

    private void installPlayland(Uri uri) {
        if (uri == null || isFinishing() || isDestroyed()) return;
        if (!getPackageManager().canRequestPackageInstalls()) {
            playlandReadyUri = uri;
            AlertDialog permission = new AlertDialog.Builder(this).setTitle("Установка PLAYLAND · EXP")
                    .setMessage("Разрешите GLINK устанавливать приложения в настройках Android. Затем Android попросит подтвердить установку.")
                    .setNegativeButton("Отмена", (d,w) -> playlandReadyUri = null)
                    .setPositiveButton("Настройки", (d,w) -> {
                        try {
                            playlandAwaitInstallPermission = true;
                            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
                        } catch (Exception e) {
                            playlandAwaitInstallPermission = false;
                            playlandReadyUri = null;
                            Toast.makeText(this, "Не удалось открыть настройки", Toast.LENGTH_SHORT).show();
                        }
                    }).create();
            permission.setOnCancelListener(d -> playlandReadyUri = null);
            permission.show();
            return;
        }
        try { UpdateManager.install(this, uri); }
        catch (Exception e) { Toast.makeText(this, "Не удалось открыть системную установку PLAYLAND", Toast.LENGTH_LONG).show(); }
    }

    private void offerGPlusDownload() {
        if (checkingGPlusDownload) return;
        checkingGPlusDownload = true;
        Toast.makeText(this, "Проверяем доступность G+…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            Uri pending=com.prilozhi.app.util.GPlusDownload.verifiedPending(getApplicationContext());
            com.prilozhi.app.util.GPlusDownload.Info info=pending==null?com.prilozhi.app.util.GPlusDownload.fetch():null;
            runOnUiThread(() -> {
                checkingGPlusDownload = false;
                if (!resumed || isFinishing() || isDestroyed()) return;
                AlertDialog.Builder dialog = new AlertDialog.Builder(this).setTitle("G+");
                if(pending!=null)dialog.setMessage("G+ уже скачан и проверен. Открыть системную установку?")
                        .setNegativeButton("Отмена",null).setPositiveButton("Установить",(d,w)->installGPlus(pending));
                else if(info!=null)dialog.setMessage("Скачать G+ прямо в GLINK? Перед установкой приложение проверит размер, SHA-256 и подпись.")
                        .setNegativeButton("Отмена",null).setPositiveButton("Скачать",(d,w)->downloadGPlus(info));
                else dialog.setMessage("G+ ещё не опубликован или сейчас недоступен.").setPositiveButton("Понятно",null);
                dialog.show();
            });
        }, "glink-gplus-offer").start();
    }

    private void downloadGPlus(com.prilozhi.app.util.GPlusDownload.Info info){
        float density=getResources().getDisplayMetrics().density;
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding((int)(22*density),(int)(8*density),(int)(22*density),(int)(8*density));
        TextView state=new TextView(this);state.setText("Подключение…");content.addView(state);
        android.widget.ProgressBar progress=new android.widget.ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(1000);content.addView(progress);
        AlertDialog panel=new AlertDialog.Builder(this).setTitle("Скачиваем G+").setView(content).setNegativeButton("Скрыть",null).create();panel.show();
        com.prilozhi.app.util.GPlusDownload.download(getApplicationContext(),info,new com.prilozhi.app.util.GPlusDownload.Callback(){
            @Override public void onProgress(long done,long total){if(isFinishing()||isDestroyed())return;if(total>0){progress.setProgress((int)(done*1000/total));state.setText((done*100/total)+"% · "+com.prilozhi.app.util.Fmt.size(done)+" из "+com.prilozhi.app.util.Fmt.size(total));}}
            @Override public void onDone(Uri uri,String error){
                if(!isFinishing()&&!isDestroyed()&&panel.isShowing())panel.dismiss();
                if(uri==null){if(!isFinishing()&&!isDestroyed())Toast.makeText(MainActivity.this,error,Toast.LENGTH_LONG).show();return;}
                gplusReadyUri=uri;
                if(resumed&&!isFinishing()&&!isDestroyed()&&updApkUri==null){Uri ready=gplusReadyUri;gplusReadyUri=null;installGPlus(ready);}
            }
        });
    }

    private void installGPlus(Uri uri){
        if(uri==null||isFinishing()||isDestroyed())return;
        if(!getPackageManager().canRequestPackageInstalls()){
            gplusReadyUri=uri;
            AlertDialog permission=new AlertDialog.Builder(this).setTitle("Установка G+")
                    .setMessage("Разрешите GLINK устанавливать приложения в настройках Android. Затем Android попросит подтвердить установку G+.")
                    .setNegativeButton("Отмена",(d,w)->gplusReadyUri=null)
                    .setPositiveButton("Настройки",(d,w)->{try{gplusAwaitInstallPermission=true;startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())));}catch(Exception e){gplusAwaitInstallPermission=false;gplusReadyUri=null;Toast.makeText(this,"Не удалось открыть настройки",Toast.LENGTH_SHORT).show();}}).create();
            permission.setOnCancelListener(d->gplusReadyUri=null);permission.show();return;
        }
        try{UpdateManager.install(this,uri);}catch(Exception e){Toast.makeText(this,"Не удалось открыть системную установку G+",Toast.LENGTH_LONG).show();}
    }

    private void checkUpdate(UpdateManager updater, boolean manual) {
        if (!resumed || isFinishing() || isDestroyed() || updChecking) return;
        updChecking = true;
        if (updater == null) updater = new UpdateManager(this);
        final UpdateManager up = updater;
        up.check((available, info, error) -> {
            updChecking = false;
            if (!resumed || isFinishing() || isDestroyed()) return;
            if (available) {
                State st = State.get();
                st.setMode(State.Mode.CONNECTING, "Есть обновление!",
                        "GLINK " + info.versionName);
                showUpdatePanel(up, info);
            } else {
                if (publicIdGate != null) publicIdGate.scheduleSetup();
                if (!manual) return;
                Toast.makeText(this, error != null
                        ? "Не удалось проверить обновление: " + error
                        : "У вас последняя версия GLINK", Toast.LENGTH_LONG).show();
                refreshArmedState();
            }
        });
    }

    /** Кастомная обязательная панель обновления в стиле приложения. */
    private void showUpdatePanel(UpdateManager up, UpdateManager.Info info) {
        if (updDialog != null && updDialog.isShowing()) return;
        View root = getLayoutInflater().inflate(R.layout.dialog_update, null);
        TextView versions = root.findViewById(R.id.upd_versions);
        versions.setText(UpdateManager.currentVersionName(this).toLowerCase(java.util.Locale.ROOT)
                + "  →  " + info.versionName.toLowerCase(java.util.Locale.ROOT));
        TextView sizeTv = root.findViewById(R.id.upd_size);
        sizeTv.setText(info.size > 0
                ? "размер обновления: " + com.prilozhi.app.util.Fmt.size(info.size)
                : "размер уточнится при загрузке");
        LinearLayout notesBox = root.findViewById(R.id.upd_notes);
        String notes = info.notes != null ? info.notes.trim() : "";
        if (notes.isEmpty()) notes = "Улучшения и исправления";
        float d = getResources().getDisplayMetrics().density;
        for (String part : notes.split("[;\\n]")) {
            String line = part.trim();
            if (line.isEmpty()) continue;
            LinearLayout rowL = new LinearLayout(this);
            rowL.setOrientation(LinearLayout.HORIZONTAL);
            rowL.setGravity(android.view.Gravity.TOP);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = (int) (4 * d);
            rowL.setLayoutParams(rlp);
            View sq = new View(this);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                    (int) (7 * d), (int) (7 * d));
            slp.topMargin = (int) (5 * d);
            sq.setLayoutParams(slp);
            sq.setBackgroundColor(getColor(R.color.green));
            rowL.addView(sq);
            TextView tv = new TextView(this);
            tv.setText(line);
            tv.setTextColor(getColor(R.color.text_primary));
            tv.setTextSize(13);
            tv.setTypeface(android.graphics.Typeface.create("sans-serif-light",
                    android.graphics.Typeface.NORMAL));
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tlp.leftMargin = (int) (10 * d);
            tv.setLayoutParams(tlp);
            rowL.addView(tv);
            notesBox.addView(rowL);
        }
        android.widget.ProgressBar bar = root.findViewById(R.id.upd_progress);
        TextView status = root.findViewById(R.id.upd_status);
        Button btn = root.findViewById(R.id.upd_btn);
        android.widget.ImageView icon = root.findViewById(R.id.upd_icon);
        // статичный логотип: скругление 12dp, как у иконок проектов в Линкере, без анимаций
        final float updCorner = 12 * d;
        icon.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override
            public void getOutline(View v, android.graphics.Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), updCorner);
            }
        });
        icon.setClipToOutline(true);
        icon.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);

        android.app.Dialog dlg = new android.app.Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dlg.setContentView(root);
        dlg.setCancelable(false);
        dlg.setCanceledOnTouchOutside(false);
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawable(
                    new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            dlg.getWindow().setLayout(
                    (int) (getResources().getDisplayMetrics().widthPixels * 0.92f),
                    android.view.WindowManager.LayoutParams.WRAP_CONTENT);
        }
        updDialog = dlg;
        dlg.setOnDismissListener(dd -> updDialog = null);
        // GRRLG: настоящее размытие интерфейса под окном (Android 12+)
        if (Build.VERSION.SDK_INT >= 31 && dlg.getWindow() != null) {
            try {
                dlg.getWindow().addFlags(
                        android.view.WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
                android.view.WindowManager.LayoutParams lp = dlg.getWindow().getAttributes();
                lp.setBlurBehindRadius(28);
                dlg.getWindow().setAttributes(lp);
            } catch (Throwable ignored) {
            }
        }
        dlg.show();
        // панель въезжает снизу (Metro-сдвиг), строки — каскадом, иконка пульсирует
        root.setAlpha(0f);
        root.setTranslationY(60f);
        root.setScaleX(0.96f);
        root.setScaleY(0.96f);
        root.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(340)
                .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
        if (root instanceof android.view.ViewGroup) {
            android.view.ViewGroup inner = (android.view.ViewGroup)
                    ((android.view.ViewGroup) root).getChildAt(0);
            if (inner != null) {
                for (int ci = 0; ci < inner.getChildCount(); ci++) {
                    View child = inner.getChildAt(ci);
                    child.setAlpha(0f);
                    child.setTranslationX(-36f);
                    child.animate().alpha(1f).translationX(0f)
                            .setStartDelay(90 + ci * 70L).setDuration(300)
                            .setInterpolator(new android.view.animation.DecelerateInterpolator())
                            .start();
                }
            }
        }

        btn.setOnClickListener(v -> {
            if (updApkUri != null) {
                UpdateManager.install(this, updApkUri);
            } else {
                startUpdateDownload(up, info, bar, status, btn, icon);
            }
        });
        // загрузка стартует сама — обновление обязательное
        root.postDelayed(() -> startUpdateDownload(up, info, bar, status, btn, icon), 650);
    }

    private void startUpdateDownload(UpdateManager up, UpdateManager.Info info,
                                     android.widget.ProgressBar bar, TextView status,
                                     Button btn, android.widget.ImageView icon) {
        if (updApkUri != null) return;
        if (Build.VERSION.SDK_INT >= 26
                && !getPackageManager().canRequestPackageInstalls()) {
            status.setText("Сначала разрешите установку приложений GLINK в настройках");
            btn.setText("открыть настройки");
            btn.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) {
                }
            });
            return;
        }
        btn.setText("скачивание…");
        btn.setEnabled(false);
        status.setText("подключение…");
        updDlStartAt = System.currentTimeMillis();
        updDlLastBytes = 0;
        updDlSpeed = 0;
        up.download(info, new UpdateManager.DlCallback() {
            @Override
            public void onProgress(long done, long total) {
                long elapsed = Math.max(1, System.currentTimeMillis() - updDlStartAt);
                float inst = done * 1000f / elapsed; // средняя скорость загрузки
                updDlSpeed = updDlSpeed <= 0 ? inst : updDlSpeed * 0.5f + inst * 0.5f;
                updDlLastBytes = done;
                if (total > 0) {
                    bar.setProgress((int) (done * 1000 / total));
                    int pct = (int) (done * 100 / total);
                    status.setText(pct + "% · " + com.prilozhi.app.util.Fmt.size(done)
                            + " из " + com.prilozhi.app.util.Fmt.size(total)
                            + (updDlSpeed > 0 ? " · " + com.prilozhi.app.util.Fmt.speed(updDlSpeed) : ""));
                } else {
                    status.setText("скачано " + com.prilozhi.app.util.Fmt.size(done));
                }
            }

            @Override
            public void onDone(Uri apkUri, String error) {
                if (apkUri != null) {
                    updApkUri = apkUri;
                    bar.setProgress(1000);
                    status.setText(resumed ? "обновление скачано — открываю установку…" : "обновление скачано — установка при возвращении");
                    // без плашки кнопки: текст здесь — просто фаза, установка откроется сама
                    btn.setText("установка…");
                    btn.setEnabled(false);
                    State.get().addHistory("Скачано обновление GLINK", info.versionName, true);
                    if (resumed && !isFinishing() && !isDestroyed()) UpdateManager.install(MainActivity.this, apkUri);
                } else {
                    status.setText("ошибка загрузки: " + error);
                    btn.setText("повторить");
                    btn.setEnabled(true);
                }
            }
        });
    }

    private void downloadUpdate(UpdateManager up, UpdateManager.Info info) {
        State st = State.get();
        if (Build.VERSION.SDK_INT >= 26
                && !getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Сначала разрешите установку приложений GLINK",
                    Toast.LENGTH_LONG).show();
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
            refreshArmedState();
            return;
        }
        TransferService.start(this);
        st.total = 0;
        st.transferred = 0;
        st.setMode(State.Mode.TRANSFER, "Скачиваю GLINK " + info.versionName + "…", "Обновление");
        up.download(info, new UpdateManager.DlCallback() {
            @Override
            public void onProgress(long done, long total) {
                st.transferred = done;
                st.total = total;
                if (total > 0) st.progress = Math.min(1f, (float) ((double) done / total));
                st.notifyChanged(true);
            }

            @Override
            public void onDone(Uri apkUri, String error) {
                if (apkUri != null) {
                    st.progress = 1f;
                    st.setMode(State.Mode.SUCCESS, "Обновление скачано", "Открываю установку…");
                    st.addHistory("Скачано обновление GLINK", info.versionName, true);
                    updApkUri = apkUri;
                    if (resumed && !isFinishing() && !isDestroyed()) UpdateManager.install(MainActivity.this, apkUri);
                } else {
                    st.setMode(State.Mode.ERROR, "Ошибка обновления", error);
                    play(sndErr);
                }
                st.notifyChanged();
            }
        });
    }

    // ------------------------------------------------------------------
    // Мелочи

    /** The highlight starts outside the left edge and ends beyond the right edge. */
    private void configureTitleShine(TextView titleView) {
        float w = titleView.getWidth();
        if (w <= 0) return;
        titleShaderWidth = w;
        float band = w * .55f;
        titleShader = new android.graphics.LinearGradient(-band, 0, band, 0,
                new int[]{0xFF16BD76, 0xFF22D98B, 0xFFD0FFE8, 0xFF22D98B, 0xFF16BD76},
                new float[]{0f, .30f, .50f, .70f, 1f}, android.graphics.Shader.TileMode.CLAMP);
        titleView.getPaint().setShader(titleShader);
        titleMatrix = new android.graphics.Matrix();
        if (!funMode) startTitleFlow(titleView, w);
    }

    private void alignHeaderLogo(TextView title) {
        View logo = findViewById(R.id.header_logo);
        if (logo == null || title.getWidth() <= 0) return;
        android.graphics.Rect ink = new android.graphics.Rect();
        String text = title.getText().toString();
        title.getPaint().getTextBounds(text, 0, text.length(), ink);
        if (ink.height() <= 0) return;
        // The official Lottie composition is 2631 × 1216; retain the original aspect ratio.
        int height = Math.max(1, Math.round(ink.height() * .92f));
        int width = Math.max(1, Math.round(height * (2631f / 1216f)));
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) logo.getLayoutParams();
        if (lp.width != width || lp.height != height) {
            lp.width = width; lp.height = height; logo.setLayoutParams(lp);
            logo.post(() -> alignHeaderLogo(title));
            return;
        }
        float textCenter = title.getTop() + title.getBaseline() + (ink.top + ink.bottom) * .5f;
        float logoCenter = logo.getTop() + logo.getHeight() * .5f;
        // The original transparent PNG's visible artwork is slightly top-weighted.
        logo.setTranslationY(textCenter - logoCenter + getResources().getDisplayMetrics().density);
    }

    private void startTitleFlow(TextView titleView, float ww) {
        stopTitleFlow();
        if (ww <= 0 || titleShader == null || titleMatrix == null) return;
        titleFlow = android.animation.ValueAnimator.ofFloat(0f, 1f);
        titleFlow.setDuration(5200);
        titleFlow.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        titleFlow.setRepeatMode(android.animation.ValueAnimator.RESTART);
        titleFlow.setInterpolator(new android.view.animation.LinearInterpolator());
        titleFlow.addUpdateListener(a -> {
            float phase = (float) a.getAnimatedValue();
            float band = ww * .55f;
            titleMatrix.reset();
            titleMatrix.postTranslate(-band + (ww + 2 * band) * phase, 0);
            titleShader.setLocalMatrix(titleMatrix);
            titleView.invalidate();
        });
        titleFlow.start();
    }

    private void stopTitleFlow() {
        if (titleFlow != null) {
            titleFlow.cancel();
            titleFlow = null;
        }
    }

    private void play(int soundId) {
        if (soundPool != null && soundId != 0) {
            try {
                soundPool.play(soundId, 0.65f, 0.65f, 1, 0, 1f);
            } catch (Throwable ignored) {
            }
        }
    }
}
