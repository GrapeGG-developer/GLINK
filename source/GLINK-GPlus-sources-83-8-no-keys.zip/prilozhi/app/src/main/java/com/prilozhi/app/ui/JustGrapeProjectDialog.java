package com.prilozhi.app.ui;

import android.app.Activity;
import android.app.AlertDialog;

/** Honest placeholder until an independent, real JustGrape website and service exist. */
public final class JustGrapeProjectDialog {
    private JustGrapeProjectDialog() { }

    public static void show(Activity activity) {
        new AlertDialog.Builder(activity)
                .setTitle("Твой ВПН · EXP")
                .setMessage("Независимый экспериментальный проект JustGrape. Пока доступны только демонстрационные экраны: работающих VPN-серверов и защищённого подключения нет. Ссылка появится после запуска проекта.")
                .setPositiveButton("Понятно", null)
                .show();
    }
}
