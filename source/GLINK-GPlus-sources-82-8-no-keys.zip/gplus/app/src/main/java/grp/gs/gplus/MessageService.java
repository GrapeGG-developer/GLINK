package grp.gs.gplus;

import android.Manifest;
import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import grp.gs.protocol.Protocol;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Own foreground polling, no Google push. Android and vendor battery policies may stop it. */
public final class MessageService extends Service {
    private static final String SERVICE_CHANNEL="gplus_connection", MESSAGE_CHANNEL="gplus_messages";
    private ScheduledExecutorService executor;
    private GPlusStore store;private GlinkBridge bridge;private GPlusApi api;private ChatEngine engine;private GroupEngine groups;
    @Override public void onCreate(){
        super.onCreate();NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(SERVICE_CHANNEL,"Фоновое соединение G+",NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(MESSAGE_CHANNEL,"Сообщения G+",NotificationManager.IMPORTANCE_DEFAULT));
        Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification running=new Notification.Builder(this,SERVICE_CHANNEL).setSmallIcon(R.drawable.ic_gplus_notify).setContentTitle("G+ на связи").setContentText("Фоновая проверка сообщений").setOngoing(true).setContentIntent(pi).build();
        startForeground(4701,running);
        store=new GPlusStore(this);bridge=new GlinkBridge(this);api=new GPlusApi(BuildConfig.GPLUS_API_BASE,bridge);engine=new ChatEngine(bridge,api,store);groups=new GroupEngine(bridge,api,store);
        executor=Executors.newSingleThreadScheduledExecutor();executor.scheduleWithFixedDelay(this::poll,1,30,TimeUnit.SECONDS);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){return START_STICKY;}
    private void poll(){
        try{
            if(!getSharedPreferences("gplus_settings",MODE_PRIVATE).getBoolean("background_messages",true))return;
            String nick=getSharedPreferences("gplus_settings",MODE_PRIVATE).getString("nickname","");if(nick==null||nick.isEmpty())return;
            if(!api.isSignedIn())api.login(nick);
            try{MediaReceipts.flush(api,store);}catch(GPlusApi.ApiException e){if(e.status==401)api.login(nick);}catch(Exception ignored){}
            List<Protocol.Card> contacts=store.contacts();String self=bridge.id();
            for(Protocol.Card peer:contacts){
                if(Thread.currentThread().isInterrupted())return;
                try{
                    String chat=Protocol.directChat(self,peer.id);long last=store.notified(chat);
                    try{engine.sync(peer,false);}catch(GPlusApi.ApiException e){if(e.status!=401)throw e;api.login(nick);engine.sync(peer,false);}
                    long cursor=store.cursor(chat);if(cursor<=last)continue;
                    boolean interesting=false;CallSignal.Offer incoming=null;for(ChatEngine.Message m:engine.messagesAfter(peer,last)){
                        if(m.seq<=last||!peer.id.equals(m.sender))continue;String type=m.content.optString("type");if("text".equals(type)||"file".equals(type)||"poll".equals(type)||"sticker".equals(type))interesting=true;CallSignal.Offer offer=CallSignal.parseOffer(m,peer.id,System.currentTimeMillis());if(offer!=null)incoming=offer;else if(incoming!=null&&CallSignal.isEnd(m,peer.id,incoming.call,System.currentTimeMillis()))incoming=null;
                    }
                    if(chat.equals(AppPresence.visibleChat)){store.markNotified(chat,cursor);continue;}
                    if(interesting||incoming!=null){if(notificationsAllowed()){showMessage(peer,incoming!=null);store.markNotified(chat,cursor);}}
                    else store.markNotified(chat,cursor);
                }catch(Exception ignored){}
            }
            for(SignedGroup group:groups.discover()){
                if(Thread.currentThread().isInterrupted())return;
                try{long last=store.notified(group.id);try{groups.sync(group,false);}catch(GPlusApi.ApiException e){if(e.status!=401)throw e;api.login(nick);groups.sync(group,false);}long cursor=store.cursor(group.id);if(cursor<=last)continue;boolean interesting=false;for(ChatEngine.Message m:groups.messagesAfter(group,last))if(m.seq>last&&!self.equals(m.sender)&&("text".equals(m.content.optString("type"))||"file".equals(m.content.optString("type"))||"poll".equals(m.content.optString("type"))||"sticker".equals(m.content.optString("type")))){interesting=true;break;}if(group.id.equals(AppPresence.visibleChat)){store.markNotified(group.id,cursor);continue;}if(interesting){if(notificationsAllowed()){showGroup(group);store.markNotified(group.id,cursor);}}else store.markNotified(group.id,cursor);}catch(Exception ignored){}
            }
        }catch(Exception ignored){}
    }
    private boolean notificationsAllowed(){return Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}
    private void showMessage(Protocol.Card peer,boolean incomingCall){
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("peer_id",peer.id);
        int notificationId=0x50000000|(peer.id.hashCode()&0x0fffffff);
        PendingIntent pi=PendingIntent.getActivity(this,notificationId,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,MESSAGE_CHANNEL).setSmallIcon(R.drawable.ic_gplus_notify).setContentTitle(peer.display).setContentText(incomingCall?"Входящий звонок G+":"Новое сообщение G+").setAutoCancel(true).setContentIntent(pi).build();
        ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).notify(notificationId,n);
    }
    private void showGroup(SignedGroup group){
        Intent open=new Intent(this,GroupActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("group_id",group.id);int notificationId=0x60000000|(group.id.hashCode()&0x0fffffff);PendingIntent pi=PendingIntent.getActivity(this,notificationId,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification n=new Notification.Builder(this,MESSAGE_CHANNEL).setSmallIcon(R.drawable.ic_gplus_notify).setContentTitle(group.title).setContentText("Новое сообщение G+").setAutoCancel(true).setContentIntent(pi).build();((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).notify(notificationId,n);
    }
    @Override public void onTimeout(int startId,int fgsType){stopSelf(startId);}
    @Override public void onDestroy(){if(executor!=null)executor.shutdownNow();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
