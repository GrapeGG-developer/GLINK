package grp.gs.protocol;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.AlgorithmParameters;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.ECParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;

/** Ephemeral P-256 agreement and per-direction AES-GCM frames for an opaque relay.
 * Public keys MUST be exchanged in authenticated, peer-bound signaling; this class alone does not authenticate peers. */
public final class CallCrypto {
    private static final byte[] MAGIC={'G','C','F','1'},KDF="G+ CALL KEY v1\0".getBytes(StandardCharsets.UTF_8),FRAME="G+ CALL FRAME v1\0".getBytes(StandardCharsets.UTF_8);
    public static final int AUDIO=1,VIDEO=2,CONFIG=3,CONTROL=4,MAX_PAYLOAD=96*1024-4-1-8-8-16;
    private CallCrypto(){}
    public static KeyPair ephemeral()throws Exception{KeyPairGenerator g=KeyPairGenerator.getInstance("EC");g.initialize(new ECGenParameterSpec("secp256r1"),new SecureRandom());return g.generateKeyPair();}
    private static byte[] pack(byte[] domain,byte[]... fields)throws Exception{ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);out.write(domain);for(byte[] f:fields){out.writeInt(f.length);out.write(f);}out.flush();return bytes.toByteArray();}
    private static byte[] utf8(String s){return s.getBytes(StandardCharsets.UTF_8);}
    private static byte[] hmac(byte[] key,byte[] data)throws Exception{Mac m=Mac.getInstance("HmacSHA256");m.init(new SecretKeySpec(key,"HmacSHA256"));return m.doFinal(data);}
    private static byte[] expand(byte[] prk,byte[] info,int size)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] prev=new byte[0];for(int i=1;out.size()<size;i++){if(i>255)throw new SecurityException("HKDF too long");ByteArrayOutputStream input=new ByteArrayOutputStream();input.write(prev);input.write(info);input.write(i);prev=hmac(prk,input.toByteArray());out.write(prev);}return Arrays.copyOf(out.toByteArray(),size);}
    private static PublicKey ecPublic(byte[] raw)throws Exception{
        if(raw==null||raw.length<80||raw.length>160)throw new SecurityException("Invalid ephemeral key");PublicKey p=KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(raw));if(!(p instanceof ECPublicKey))throw new SecurityException("Not EC");AlgorithmParameters ap=AlgorithmParameters.getInstance("EC");ap.init(new ECGenParameterSpec("secp256r1"));ECParameterSpec expected=ap.getParameterSpec(ECParameterSpec.class),actual=((ECPublicKey)p).getParams();if(!expected.getCurve().equals(actual.getCurve())||!expected.getGenerator().equals(actual.getGenerator())||!expected.getOrder().equals(actual.getOrder())||expected.getCofactor()!=actual.getCofactor())throw new SecurityException("Wrong curve");return p;
    }
    public static Session derive(KeyPair own,byte[] otherPublic,boolean caller,String chat,String call,String callerId,String calleeId)throws Exception{
        if(own==null||own.getPrivate()==null||own.getPublic()==null||!Protocol.validEventId(call)||!Protocol.validId(callerId)||!Protocol.validId(calleeId)||callerId.equals(calleeId)||!Protocol.directChat(callerId,calleeId).equals(chat))throw new SecurityException("Invalid call context");
        byte[] mine=own.getPublic().getEncoded();ecPublic(mine);PublicKey peer=ecPublic(otherPublic);byte[] first=caller?mine:otherPublic,second=caller?otherPublic:mine;
        byte[] context=pack(KDF,utf8(chat),utf8(call),utf8(callerId),utf8(calleeId),first,second),salt=MessageDigest.getInstance("SHA-256").digest(context);KeyAgreement agreement=KeyAgreement.getInstance("ECDH");agreement.init(own.getPrivate());agreement.doPhase(peer,true);byte[] shared=agreement.generateSecret(),prk=hmac(salt,shared),material=expand(prk,context,72);Arrays.fill(shared,(byte)0);Arrays.fill(prk,(byte)0);
        byte[] tx=Arrays.copyOfRange(material,caller?0:32,caller?32:64),rx=Arrays.copyOfRange(material,caller?32:0,caller?64:32),txPrefix=Arrays.copyOfRange(material,caller?64:68,caller?68:72),rxPrefix=Arrays.copyOfRange(material,caller?68:64,caller?72:68);Arrays.fill(material,(byte)0);
        return new Session(chat,call,caller?callerId:calleeId,caller?calleeId:callerId,tx,rx,txPrefix,rxPrefix);
    }
    public static final class Packet {public final int kind;public final long sequence,timestamp;public final byte[] payload;Packet(int k,long s,long t,byte[] p){kind=k;sequence=s;timestamp=t;payload=p;}}
    public static final class Session implements AutoCloseable {
        private final String chat,call,self,peer;private final byte[] tx,rx,txPrefix,rxPrefix;private long sendSeq,receiveSeq;private boolean closed;
        private Session(String chat,String call,String self,String peer,byte[] tx,byte[] rx,byte[] tp,byte[] rp){this.chat=chat;this.call=call;this.self=self;this.peer=peer;this.tx=tx;this.rx=rx;txPrefix=tp;rxPrefix=rp;}
        private byte[] aad(String from,String to,byte[] header)throws Exception{return pack(FRAME,utf8(chat),utf8(call),utf8(from),utf8(to),header);}
        private static byte[] nonce(byte[] prefix,long seq){return ByteBuffer.allocate(12).put(prefix).putLong(seq).array();}
        public synchronized byte[] seal(int kind,long timestamp,byte[] plain)throws Exception{
            if(closed||kind<AUDIO||kind>CONTROL||timestamp<0||plain==null||plain.length>MAX_PAYLOAD||sendSeq==Long.MAX_VALUE)throw new SecurityException("Invalid call frame");long seq=++sendSeq;byte[] header=ByteBuffer.allocate(21).put(MAGIC).put((byte)kind).putLong(seq).putLong(timestamp).array();Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(tx,"AES"),new GCMParameterSpec(128,nonce(txPrefix,seq)));c.updateAAD(aad(self,peer,header));byte[] encrypted=c.doFinal(plain);return ByteBuffer.allocate(header.length+encrypted.length).put(header).put(encrypted).array();
        }
        public synchronized Packet open(byte[] frame)throws Exception{
            if(closed||frame==null||frame.length<37||frame.length>MAX_PAYLOAD+37)throw new SecurityException("Invalid call frame");ByteBuffer b=ByteBuffer.wrap(frame);byte[] magic=new byte[4];b.get(magic);int kind=b.get()&255;long seq=b.getLong(),timestamp=b.getLong();if(!Arrays.equals(magic,MAGIC)||kind<AUDIO||kind>CONTROL||seq<=receiveSeq||timestamp<0)throw new SecurityException("Invalid or replayed call frame");byte[] header=Arrays.copyOf(frame,21),encrypted=Arrays.copyOfRange(frame,21,frame.length);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(rx,"AES"),new GCMParameterSpec(128,nonce(rxPrefix,seq)));c.updateAAD(aad(peer,self,header));byte[] plain=c.doFinal(encrypted);receiveSeq=seq;return new Packet(kind,seq,timestamp,plain);
        }
        @Override public synchronized void close(){closed=true;Arrays.fill(tx,(byte)0);Arrays.fill(rx,(byte)0);Arrays.fill(txPrefix,(byte)0);Arrays.fill(rxPrefix,(byte)0);}
    }
}
