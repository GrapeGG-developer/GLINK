package grp.gs.gplus;

import static org.junit.Assert.*;
import java.net.HttpURLConnection;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import org.junit.Test;

public class NetworkTimeoutsTest {
    @Test public void mediaBudgetIsBoundedAndGrowsWithFile() {
        assertEquals(180_000, NetworkTimeouts.mediaReadMs(1));
        assertTrue(NetworkTimeouts.mediaReadMs(50L*1024*1024)>NetworkTimeouts.mediaReadMs(1));
        assertEquals(1_800_000, NetworkTimeouts.mediaReadMs(Long.MAX_VALUE));
        assertTrue(NetworkTimeouts.API_READ_MS > 22_490);
        try { NetworkTimeouts.mediaReadMs(-1); fail(); } catch(IllegalArgumentException expected) {}
    }

    @Test public void coldStartLongerThanOldFifteenSecondLimitSucceeds() throws Exception {
        try (ServerSocket server=new ServerSocket(0)) {
            FutureTask<Void> worker=new FutureTask<>(()->{
                try(Socket socket=server.accept()) {
                    socket.setSoTimeout(5000);
                    java.io.InputStream in=socket.getInputStream(); int previous=0,crlfs=0,value;
                    while((value=in.read())!=-1){if(previous=='\r' && value=='\n')crlfs++; else if(value!='\r')crlfs=0;previous=value;if(crlfs==2)break;}
                    Thread.sleep(16_000);
                    try(OutputStream out=socket.getOutputStream()){out.write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok".getBytes(StandardCharsets.US_ASCII));out.flush();}
                }
                return null;
            });
            Thread thread=new Thread(worker,"test-cold-start");thread.setDaemon(true);thread.start();
            HttpURLConnection c=(HttpURLConnection)new URL("http://127.0.0.1:"+server.getLocalPort()+"/health").openConnection();
            c.setConnectTimeout(NetworkTimeouts.CONNECT_MS);c.setReadTimeout(NetworkTimeouts.API_READ_MS);
            try { assertEquals(200,c.getResponseCode());assertEquals('o',c.getInputStream().read()); } finally {c.disconnect();}
            worker.get(2,TimeUnit.SECONDS);
        }
    }
}
