package com.prilozhi.app.identity;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.Process;

/** Dedicated, signature-protected public-identity bridge for gPLAYLANDg.
 * It never signs, decrypts, exposes a private key, or grants G+ access. */
public final class GPlayIdentityProvider extends ContentProvider {
    public static final String PERMISSION = "grp.gs.glink.permission.GPLAYLAND_IDENTITY";

    @Override public boolean onCreate() { return true; }

    @Override public Bundle call(String method, String arg, Bundle extras) {
        if (Binder.getCallingUid() != Process.myUid()) {
            if (getContext() == null) throw new SecurityException("Context unavailable");
            getContext().enforceCallingPermission(PERMISSION, "PLAYLAND identity requires the GrapeScript signature");
        }
        if (!"get_public_identity".equals(method)) throw new IllegalArgumentException("Unsupported identity operation");
        try {
            Bundle result = new Bundle();
            result.putString("id", InstallationIdentity.publicId());
            result.putByteArray("public_key", InstallationIdentity.publicKey());
            return result;
        } catch (Exception unavailable) {
            throw new IllegalStateException("GLINK identity is unavailable", unavailable);
        }
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String order) {
        throw new UnsupportedOperationException();
    }
    @Override public String getType(Uri uri) { return null; }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String where, String[] args) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String where, String[] args) {
        throw new UnsupportedOperationException();
    }
}
