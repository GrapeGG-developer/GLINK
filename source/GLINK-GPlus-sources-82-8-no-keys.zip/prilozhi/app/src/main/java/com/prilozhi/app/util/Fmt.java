package com.prilozhi.app.util;

import java.util.Locale;

public final class Fmt {
    private Fmt() {
    }

    public static String size(long bytes) {
        if (bytes < 0) return "—";
        if (bytes < 1024) return bytes + " Б";
        double kb = bytes / 1024.0;
        if (kb < 1024) return dec(kb) + " КБ";
        double mb = kb / 1024.0;
        if (mb < 1024) return dec(mb) + " МБ";
        double gb = mb / 1024.0;
        return dec(gb) + " ГБ";
    }

    public static String speed(double bytesPerSec) {
        return size((long) Math.max(0, bytesPerSec)) + "/с";
    }

    public static String dec(double v) {
        String s;
        if (v >= 100) s = String.format(Locale.US, "%.0f", v);
        else if (v >= 10) s = String.format(Locale.US, "%.1f", v);
        else s = String.format(Locale.US, "%.2f", v);
        return s.replace('.', ',');
    }
}
