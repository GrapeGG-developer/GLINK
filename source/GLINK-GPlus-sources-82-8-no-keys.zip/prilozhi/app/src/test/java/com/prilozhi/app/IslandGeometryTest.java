package com.prilozhi.app;

import com.prilozhi.app.ui.IslandGeometry;
import org.junit.Test;
import static org.junit.Assert.*;

/** Geometry is tested at realistic screen densities, not just mdpi. */
public class IslandGeometryTest {
    @Test public void collapsedBodyIsSquareAtEveryDensity() {
        for (float d : new float[]{0.75f, 1f, 1.5f, 2f, 2.75f, 3f, 4f}) {
            assertEquals(IslandGeometry.widthPx(d), IslandGeometry.targetHeightPx(false, d), 0.0001f);
        }
    }
    @Test public void openingAndClosingNeverOvershootAndFinishExactlyRound() {
        for (float d : new float[]{1f, 2.75f, 4f}) {
            float v = IslandGeometry.widthPx(d);
            for (int i = 0; i < 240; i++) {
                float n = IslandGeometry.nextHeightPx(v, true, d, 1f / 60f);
                assertTrue(n >= v && n <= IslandGeometry.targetHeightPx(true, d));
                v = n;
            }
            assertEquals(IslandGeometry.targetHeightPx(true, d), v, 0f);
            for (int i = 0; i < 240; i++) {
                float n = IslandGeometry.nextHeightPx(v, false, d, 1f / 30f);
                assertTrue(n <= v && n >= IslandGeometry.widthPx(d));
                v = n;
            }
            assertEquals(IslandGeometry.widthPx(d), v, 0f);
            assertFalse(IslandGeometry.animating(v, false, d));
        }
    }
    @Test public void switchingDirectionDoesNotJump() {
        float d = 2.75f;
        float mid = IslandGeometry.nextHeightPx(IslandGeometry.widthPx(d), true, d, 1f / 60f);
        float next = IslandGeometry.nextHeightPx(mid, false, d, 1f / 60f);
        assertTrue(next < mid && next > IslandGeometry.widthPx(d));
    }
    @Test public void invalidLongFrameDoesNotOvershoot() {
        float d = 3f;
        float n = IslandGeometry.nextHeightPx(IslandGeometry.widthPx(d), true, d, 10f);
        assertTrue(n < IslandGeometry.targetHeightPx(true, d));
        assertTrue(n > IslandGeometry.widthPx(d));
    }
}
