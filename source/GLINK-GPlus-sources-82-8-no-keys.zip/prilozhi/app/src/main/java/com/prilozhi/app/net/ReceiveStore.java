package com.prilozhi.app.net;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class ReceiveStore {

    public static class Out {
        public final Uri uri;
        public final OutputStream stream;

        Out(Uri uri, OutputStream stream) {
            this.uri = uri;
            this.stream = stream;
        }
    }

    private final Context ctx;
    private final String sessionLabel;
    private final java.util.Set<String> usedNames = new java.util.HashSet<>();

    public ReceiveStore(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.sessionLabel = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date())
                + "-" + (System.currentTimeMillis() % 1000);
    }

    public String sessionLabel() {
        return sessionLabel;
    }

    public Out open(String relPath, String mime) throws IOException {
        // Санитизируем по сегментам, чтобы не разрушить структуру папок
        String[] segs = relPath.replace("\\", "/").split("/");
        StringBuilder clean = new StringBuilder();
        for (String seg : segs) {
            if (seg == null || seg.trim().isEmpty() || seg.equals(".") || seg.equals("..")) continue;
            if (clean.length() > 0) clean.append('/');
            clean.append(ManifestBuilder.sanitize(seg));
        }
        relPath = clean.length() > 0 ? clean.toString() : "file.bin";
        String dir = "";
        String name = relPath;
        int slash = relPath.lastIndexOf('/');
        if (slash >= 0) {
            dir = relPath.substring(0, slash);
            name = relPath.substring(slash + 1);
        }
        if (name.isEmpty()) name = "file.bin";
        // Дубликаты имён в одной сессии: "файл (1).txt", "файл (2).txt"…
        String key = (dir + "/" + name).toLowerCase();
        if (!usedNames.add(key)) {
            int dot = name.lastIndexOf('.');
            String stem = dot > 0 ? name.substring(0, dot) : name;
            String ext = dot > 0 ? name.substring(dot) : "";
            int n = 1;
            String candidate;
            do {
                candidate = stem + " (" + (n++) + ")" + ext;
            } while (!usedNames.add((dir + "/" + candidate).toLowerCase()));
            name = candidate;
        }

        String relDir = "Download/GLINK/" + sessionLabel + (dir.isEmpty() ? "" : "/" + dir);

        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, mime != null ? mime : "application/octet-stream");
        v.put(MediaStore.Downloads.RELATIVE_PATH, relDir);
        if (Build.VERSION.SDK_INT >= 29) {
            v.put(MediaStore.Downloads.IS_PENDING, 1);
        }

        ContentResolver cr = ctx.getContentResolver();
        Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new IOException("Не удалось создать файл " + name);
        try {
            OutputStream os = cr.openOutputStream(uri);
            if (os == null) throw new IOException("Не удалось открыть поток " + name);
            return new Out(uri, os);
        } catch (Exception e) {
            delete(uri); // this is the pending row just created by this call
            throw new IOException("Не удалось открыть поток " + name, e);
        }
    }

    /** Удаляет недостроенный/повреждённый файл из Загрузок. */
    public void delete(Uri uri) {
        try {
            ctx.getContentResolver().delete(uri, null, null);
        } catch (Throwable ignored) {
        }
    }

    public void finish(Uri uri) throws IOException {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.IS_PENDING, 0);
                if (ctx.getContentResolver().update(uri, v, null, null) != 1)
                    throw new IOException("Не удалось завершить сохранение файла");
            }
        } catch (Exception e) { throw new IOException("Не удалось завершить сохранение файла", e); }
    }

    public Uri saveText(String fileName, String text) throws IOException {
        Out out = open(fileName, "text/plain");
        try {
            try (OutputStream stream = out.stream) { stream.write(text.getBytes("UTF-8")); }
            finish(out.uri);
            return out.uri;
        } catch (Exception e) {
            delete(out.uri);
            throw new IOException("Не удалось сохранить текст", e);
        }
    }
}
