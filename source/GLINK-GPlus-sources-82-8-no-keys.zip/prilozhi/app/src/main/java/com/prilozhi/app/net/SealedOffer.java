package com.prilozhi.app.net;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Wrap a GSENC1 session key for one recipient. The relay sees only an ephemeral
 * P-256 public key, a nonce and authenticated ciphertext; it never receives the
 * raw session key from v2 clients. An unverified discovery server can still
 * substitute an entire recipient identity, so this is not a verification UI.
 */
public final class SealedOffer {
    public static final String PREFIX = "g2.";
    private static final byte[] DOMAIN = "GLINK-WIFI-SEALED-2\0".getBytes(StandardCharsets.UTF_8);
    private SealedOffer() {}

    public static KeyPair newTransportKey() throws Exception {
        KeyPairGenerator gen = KeyPairGenerator.getInstance("EC");
        gen.initialize(new ECGenParameterSpec("secp256r1"), new SecureRandom());
        return gen.generateKeyPair();
    }

    public static String b64(byte[] value) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value);
    }

    public static byte[] unb64(String value) {
        return Base64.getUrlDecoder().decode(value);
    }

    public static byte[] context(String session, String recipient) {
        if (session == null || recipient == null || !session.matches("[A-Za-z0-9_-]{6,64}")
                || !recipient.matches("[A-Za-z0-9_-]{6,64}")) {
            throw new IllegalArgumentException("Invalid recipient or session");
        }
        byte[] suffix = (session + "\0" + recipient).getBytes(StandardCharsets.UTF_8);
        byte[] out = Arrays.copyOf(DOMAIN, DOMAIN.length + suffix.length);
        System.arraycopy(suffix, 0, out, DOMAIN.length, suffix.length);
        return out;
    }

    private static byte[] hkdf(byte[] secret, byte[] salt, byte[] info) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(salt, "HmacSHA256"));
        byte[] prk = mac.doFinal(secret);
        mac.init(new SecretKeySpec(prk, "HmacSHA256"));
        mac.update(info);
        mac.update((byte) 1);
        byte[] key = mac.doFinal();
        Arrays.fill(prk, (byte) 0);
        return key;
    }

    private static byte[] agree(PrivateKey own, PublicKey peer) throws Exception {
        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(own);
        ka.doPhase(peer, true);
        return ka.generateSecret();
    }

    private static PublicKey parsePublic(byte[] encoded) throws Exception {
        if (encoded == null || encoded.length < 80 || encoded.length > 150) {
            throw new IllegalArgumentException("Invalid P-256 public key");
        }
        PublicKey key = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(encoded));
        if (!(key instanceof java.security.interfaces.ECPublicKey)
                || !((java.security.interfaces.ECPublicKey) key).getParams().getOrder().equals(
                    new java.math.BigInteger("FFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551", 16))) {
            throw new IllegalArgumentException("Invalid EC curve");
        }
        return key;
    }

    public static String seal(String publicKey, byte[] rawKey, String session, String recipient) throws Exception {
        if (rawKey == null || rawKey.length != 32) throw new IllegalArgumentException("Expected 32-byte key");
        PublicKey target = parsePublic(unb64(publicKey));
        KeyPair ephemeral = newTransportKey();
        byte[] ep = ephemeral.getPublic().getEncoded();
        byte[] nonce = new byte[12];
        new SecureRandom().nextBytes(nonce);
        byte[] aad = context(session, recipient);
        byte[] shared = agree(ephemeral.getPrivate(), target);
        byte[] wrapKey = hkdf(shared, nonce, aad);
        Arrays.fill(shared, (byte) 0);
        Cipher aes = Cipher.getInstance("AES/GCM/NoPadding");
        aes.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(wrapKey, "AES"), new GCMParameterSpec(128, nonce));
        aes.updateAAD(aad);
        byte[] encrypted = aes.doFinal(rawKey);
        Arrays.fill(wrapKey, (byte) 0);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(2); out.write((ep.length >> 8) & 255); out.write(ep.length & 255);
        out.write(ep); out.write(nonce); out.write(encrypted);
        return PREFIX + b64(out.toByteArray());
    }

    public static byte[] open(PrivateKey own, String envelope, String session, String recipient) throws Exception {
        if (envelope == null || !envelope.startsWith(PREFIX) || envelope.length() > 512) {
            throw new IllegalArgumentException("Unsupported Wi-Fi offer");
        }
        byte[] in = unb64(envelope.substring(PREFIX.length()));
        if (in.length < 3 || in[0] != 2) throw new IllegalArgumentException("Invalid offer");
        int epLength = ((in[1] & 255) << 8) | (in[2] & 255);
        if (epLength < 80 || epLength > 150 || in.length != 3 + epLength + 12 + 48) {
            throw new IllegalArgumentException("Invalid offer length");
        }
        byte[] ep = Arrays.copyOfRange(in, 3, 3 + epLength);
        byte[] nonce = Arrays.copyOfRange(in, 3 + epLength, 3 + epLength + 12);
        byte[] encrypted = Arrays.copyOfRange(in, 3 + epLength + 12, in.length);
        byte[] aad = context(session, recipient);
        byte[] shared = agree(own, parsePublic(ep));
        byte[] wrapKey = hkdf(shared, nonce, aad);
        Arrays.fill(shared, (byte) 0);
        Cipher aes = Cipher.getInstance("AES/GCM/NoPadding");
        aes.init(Cipher.DECRYPT_MODE, new SecretKeySpec(wrapKey, "AES"), new GCMParameterSpec(128, nonce));
        aes.updateAAD(aad);
        byte[] raw = aes.doFinal(encrypted);
        Arrays.fill(wrapKey, (byte) 0);
        if (raw.length != 32) throw new IllegalArgumentException("Invalid session key");
        return raw;
    }
}
