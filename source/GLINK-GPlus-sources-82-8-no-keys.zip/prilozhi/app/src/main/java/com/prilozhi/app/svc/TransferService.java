package com.prilozhi.app.svc;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import com.prilozhi.app.MainActivity;
import com.prilozhi.app.R;
import com.prilozhi.app.util.Fmt;
import com.prilozhi.app.util.State;

public class TransferService extends Service implements State.Listener {

    private static final String CHANNEL = "transfer";
    private static final int NOTIF_ID = 7;

    private WifiManager.WifiLock wifiLock;
    private PowerManager.WakeLock wakeLock;
    private NotificationManager nm;

    public static void start(Context ctx) {
        Intent i = new Intent(ctx, TransferService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                ctx.startForegroundService(i);
            } else {
                ctx.startService(i);
            }
        } catch (Throwable ignored) {
        }
    }

    public static final String ACT_PAUSE = "com.prilozhi.app.T_PAUSE";
    public static final String ACT_RESUME = "com.prilozhi.app.T_RESUME";
    public static final String ACT_CANCEL = "com.prilozhi.app.T_CANCEL";

    public static void stop(Context ctx) {
        try {
            ctx.stopService(new Intent(ctx, TransferService.class));
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL,
                    getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            if (nm != null) nm.createNotificationChannel(ch);
        }

        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "prilozhi:transfer");
                wakeLock.setReferenceCounted(false);
                // не держим телефон дольше самой передачи: короткий лимит + продление по ходу
                wakeLock.acquire(5 * 60 * 1000L);
            }
        } catch (Throwable ignored) {
        }

        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, buildNotification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(NOTIF_ID, buildNotification());
            }
        } catch (Throwable ignored) {
        }
        State.get().addListener(this);
    }

    private Notification buildNotification() {
        State st = State.get();
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, piFlags);

        String title;
        String text;
        if (st.relayUploading) {
            title = "Загрузка на сервер…";
            text = Math.round(st.progress * 100) + "% · " + Fmt.speed(st.speed)
                    + (st.currentFile != null && !st.currentFile.isEmpty() ? " · " + st.currentFile : "");
        } else if (st.relayUploaded && st.mode != State.Mode.TRANSFER && st.peerProgress >= 0f) {
            title = "Друг скачал: " + Math.round(st.peerProgress * 100) + "%";
            text = "Файл уходит с сервера GrapeScript на телефон друга";
        } else if (st.mode == State.Mode.TRANSFER) {
            title = st.title;
            text = Math.round(st.progress * 100) + "% · " + Fmt.speed(st.speed)
                    + (st.currentFile != null && !st.currentFile.isEmpty() ? " · " + st.currentFile : "");
        } else {
            title = getString(R.string.notif_transfer);
            text = st.subtitle != null ? st.subtitle : "";
        }

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setOnlyAlertOnce(true)
                .setOngoing(true);
        if (st.relayUploading || st.mode == State.Mode.TRANSFER) {
            if (st.transferPaused) {
                b.addAction(0, "Продолжить", actionIntent(ACT_RESUME, 2));
            } else {
                b.addAction(0, "Пауза", actionIntent(ACT_PAUSE, 1));
            }
            b.addAction(0, "Отмена", actionIntent(ACT_CANCEL, 3));
        }
        return b.build();
    }

    /** Android 15: система вызывает при исчерпании лимита dataSync FGS. */
    @Override
    public void onTimeout(int startId, int fgsType) {
        stopSelf();
    }

    private PendingIntent actionIntent(String action, int req) {
        Intent i = new Intent(this, TransferService.class);
        i.setAction(action);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        if (Build.VERSION.SDK_INT >= 26) {
            return PendingIntent.getForegroundService(this, req, i, flags);
        }
        return PendingIntent.getService(this, req, i, flags);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            State st = State.get();
            switch (intent.getAction()) {
                case ACT_PAUSE:
                    st.transferPaused = true;
                    st.notifyChanged();
                    break;
                case ACT_RESUME:
                    st.transferPaused = false;
                    st.notifyChanged();
                    break;
                case ACT_CANCEL:
                    st.transferCancelled = true;
                    st.transferPaused = false;
                    st.notifyChanged();
                    break;
                default:
                    break;
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onStateChanged(State state) {
        // WakeLock живёт только пока реально идёт передача/заливка
        try {
            boolean active = state.mode == State.Mode.TRANSFER || state.relayUploading;
            if (wakeLock != null) {
                if (active && !wakeLock.isHeld()) wakeLock.acquire(5 * 60 * 1000L);
                if (!active && wakeLock.isHeld()
                        && (state.mode == State.Mode.SUCCESS || state.mode == State.Mode.ERROR)) {
                    wakeLock.release();
                }
            }
        } catch (Throwable ignored) {
        }
        try {
            if (nm != null) nm.notify(NOTIF_ID, buildNotification());
        } catch (Throwable ignored) {
        }
        if (!state.sessionActive && state.mode != State.Mode.TRANSFER
                && !state.relayUploading && !state.peerWatch) {
            if (state.mode == State.Mode.SUCCESS || state.mode == State.Mode.ERROR
                    || state.mode == State.Mode.READY_SEND || state.mode == State.Mode.READY_RECV
                    || state.mode == State.Mode.IDLE) {
                stopSelf();
            }
        }
    }

    @Override
    public void onDestroy() {
        State.get().removeListener(this);
        try {
            if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        } catch (Throwable ignored) {
        }
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
