package com.prilozhi.app.identity;

import android.content.Context;
import android.util.AtomicFile;
import com.google.crypto.tink.Aead;
import com.google.crypto.tink.BinaryKeysetReader;
import com.google.crypto.tink.BinaryKeysetWriter;
import com.google.crypto.tink.HybridDecrypt;
import com.google.crypto.tink.KeyTemplates;
import com.google.crypto.tink.KeysetHandle;
import com.google.crypto.tink.hybrid.HybridConfig;
import com.google.crypto.tink.integration.android.AndroidKeystoreKmsClient;
import com.prilozhi.app.net.StreamCompat;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

/** G+ HPKE keyset belongs to GLINK, so reinstalling G+ alone does not replace it. */
public final class GPlusCryptoIdentity {
    private static final String ALIAS = "glink_gplus_hpke_master_v1";
    private static final String URI = "android-keystore://" + ALIAS;
    private static final String FILE = "gplus_hpke_v1.keyset";
    private static final byte[] AAD = "G+ KEYSET v1\0".getBytes(StandardCharsets.UTF_8);
    private static KeysetHandle cached;
    private GPlusCryptoIdentity() {}

    private static synchronized KeysetHandle keyset(Context ctx) throws Exception {
        if (cached != null) return cached;
        HybridConfig.register();
        File path = new File(ctx.getNoBackupFilesDir(), FILE);
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (path.exists() && !ks.containsAlias(ALIAS)) throw new IllegalStateException("G+ key protection unavailable");
        Aead master = path.exists() ? new AndroidKeystoreKmsClient().getAead(URI)
                : AndroidKeystoreKmsClient.getOrGenerateNewAeadKey(URI);
        if (path.exists()) {
            byte[] encrypted;
            try (FileInputStream in = new FileInputStream(path)) { encrypted = StreamCompat.readAll(in, 32768); }
            cached = KeysetHandle.readWithAssociatedData(BinaryKeysetReader.withBytes(encrypted), master, AAD);
        } else {
            KeysetHandle created = KeysetHandle.generateNew(KeyTemplates.get("DHKEM_P256_HKDF_SHA256_HKDF_SHA256_AES_128_GCM"));
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            created.writeWithAssociatedData(BinaryKeysetWriter.withOutputStream(buffer), master, AAD);
            AtomicFile file = new AtomicFile(path); FileOutputStream out = null;
            try { out = file.startWrite(); out.write(buffer.toByteArray()); file.finishWrite(out); }
            catch (Exception e) { if (out != null) file.failWrite(out); throw e; }
            cached = created;
        }
        return cached;
    }

    public static byte[] publicKeyset(Context ctx) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        keyset(ctx).getPublicKeysetHandle().writeNoSecret(BinaryKeysetWriter.withOutputStream(out));
        return out.toByteArray();
    }
    public static byte[] decrypt(Context ctx, byte[] ciphertext, byte[] context) throws Exception {
        if (ciphertext == null || ciphertext.length < 20 || ciphertext.length > 131072
                || context == null || context.length < 1 || context.length > 1024)
            throw new IllegalArgumentException("Invalid encrypted G+ envelope");
        return keyset(ctx).getPrimitive(HybridDecrypt.class).decrypt(ciphertext, context);
    }
}
