package com.prilozhi.app.util;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

public final class Haptics {
    private Haptics() {
    }

    private static Vibrator vibrator(Context c) {
        if (Build.VERSION.SDK_INT >= 31) {
            VibratorManager vm = (VibratorManager) c.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            return vm != null ? vm.getDefaultVibrator() : null;
        }
        return (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
    }

    public static void tap(Context c) {
        vibrate(c, new long[]{0, 25, 45, 35}, new int[]{0, 190, 0, 255});
    }

    public static void success(Context c) {
        vibrate(c, new long[]{0, 18, 70, 35, 60, 55}, new int[]{0, 170, 0, 210, 0, 255});
    }

    public static void error(Context c) {
        vibrate(c, new long[]{0, 45, 55, 45}, new int[]{0, 200, 0, 190});
    }

    public static void tick(Context c) {
        vibrate(c, new long[]{0, 12}, new int[]{0, 110});
    }

    private static void vibrate(Context c, long[] timings, int[] amps) {
        try {
            Vibrator v = vibrator(c);
            if (v == null || !v.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createWaveform(timings, amps, -1));
            } else {
                v.vibrate(timings, -1);
            }
        } catch (Throwable ignored) {
        }
    }
}
