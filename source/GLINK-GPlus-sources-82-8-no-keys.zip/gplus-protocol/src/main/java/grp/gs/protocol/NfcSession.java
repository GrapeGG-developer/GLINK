package grp.gs.protocol;

import java.io.ByteArrayOutputStream;
import java.security.SecureRandom;
import java.util.Arrays;

/** One HCE contact session. Pure Java so retries and proofs can be tested without NFC hardware. */
public final class NfcSession {
    public interface Host {
        byte[] ownCard() throws Exception;
        byte[] signDigest(byte[] digest) throws Exception;
        void acceptCard(byte[] card) throws Exception;
        void setContactActive(boolean active);
    }
    private static final int PAGE=180;
    private final Host host;
    private final SecureRandom random;
    private ByteArrayOutputStream input;
    private int page;
    private byte[] peer,own,readerNonce,hceNonce,lastPage,lastCommit;
    private boolean active;
    public NfcSession(Host host){this(host,new SecureRandom());}
    NfcSession(Host host,SecureRandom random){this.host=host;this.random=random;}
    private static byte[] sw(int code){return new byte[]{(byte)(code>>8),(byte)code};}
    private static byte[] page(byte[] data,int p){
        int from=p*PAGE;if(from>=data.length)return sw(0x9000);int to=Math.min(data.length,from+PAGE);
        byte[] out=Arrays.copyOfRange(data,from,to+2);out[out.length-2]=(byte)0x90;out[out.length-1]=0;return out;
    }
    private void clearTransfer(){input=null;page=0;peer=null;own=null;lastPage=null;if(active){active=false;host.setContactActive(false);}}
    public synchronized void reset(){clearTransfer();readerNonce=null;hceNonce=null;lastCommit=null;}
    public synchronized byte[] process(byte[] cmd){
        try{
            if(cmd==null||cmd.length<2)return sw(0x6700);
            switch(cmd[1]&255){
                case 0xA4: reset();return sw(0x9000);
                case 0xD9:
                    if(cmd.length!=37||(cmd[4]&255)!=32)return sw(0x6700);
                    reset();readerNonce=Arrays.copyOfRange(cmd,5,37);hceNonce=new byte[32];random.nextBytes(hceNonce);return page(hceNonce,0);
                case 0xDA:return writePage(cmd);
                case 0xCB:if(peer==null||own==null||cmd.length<3)return sw(0x6985);return page(own,cmd[2]&255);
                case 0xCD:
                    if(peer==null||own==null||readerNonce==null||hceNonce==null)return sw(0x6985);
                    return page(host.signDigest(Protocol.nfcProof(peer,own,readerNonce,hceNonce,"hce")),0);
                case 0xDC:
                    if(cmd.length<6||(cmd[4]&255)!=cmd.length-5)return sw(0x6700);
                    byte[] sig=Arrays.copyOfRange(cmd,5,cmd.length);
                    if(lastCommit!=null&&Arrays.equals(lastCommit,sig))return sw(0x9000);
                    if(peer==null||own==null||readerNonce==null||hceNonce==null)return sw(0x6985);
                    Protocol.Card reader=Protocol.decodeCard(peer);
                    if(!Protocol.verifySignature(reader.identityPublic,Protocol.nfcProof(peer,own,readerNonce,hceNonce,"reader"),sig))return sw(0x6982);
                    host.acceptCard(peer);reset();lastCommit=sig;return sw(0x9000);
                default:return sw(0x6D00);
            }
        }catch(Exception e){return sw(0x6F00);}
    }
    private byte[] writePage(byte[] cmd)throws Exception{
        if(cmd.length<6)return sw(0x6700);
        int index=cmd[2]&255,last=cmd[3]&255,length=cmd[4]&255;
        if(length<1||length>PAGE||cmd.length!=length+5||(last!=0&&last!=1))return sw(0x6700);
        if(readerNonce==null||hceNonce==null)return sw(0x6985);
        if(lastPage!=null&&Arrays.equals(lastPage,cmd))return sw(0x9000);
        if(index==0){clearTransfer();own=host.ownCard();if(own==null)return sw(0x6A82);input=new ByteArrayOutputStream();active=true;host.setContactActive(true);}
        if(input==null||index!=page)return sw(0x6A86);
        if(input.size()+length>Protocol.MAX_CARD){reset();return sw(0x6A84);}
        input.write(cmd,5,length);page++;
        if(last==1){byte[] incoming=input.toByteArray();Protocol.Card theirs=Protocol.decodeCard(incoming),ours=Protocol.decodeCard(own);if(theirs.id.equals(ours.id)){reset();return sw(0x6985);}peer=incoming;input=null;}
        lastPage=cmd.clone();return sw(0x9000);
    }
}
