package com.prilozhi.app.util;

import java.security.MessageDigest;
import java.util.Locale;

public final class VpnExpPolicy {
    public static final String APK_URL = "https://raw.githubusercontent.com/GrapeGG-developer/GLINK/main/JustGrape-EXP-0.2.1.apk";
    public static final long APK_SIZE = 2232834L;
    public static final String APK_SHA256 = "c1408213f3fc32a7f4eb77e0ba241185bb138bf787fd4fe4550c4c7bf1459e3c";
    public static final String PACKAGE = "app.justgrape.yourvpn.preview.next";
    public static final long VERSION_CODE = 3L;
    public static final String VERSION_NAME = "0.2.1-exp";
    public static final String CERT_SHA256 = "bef26157a7fb91e5bf3cf4bff2d7124347ee73a503eda9820d4cb35445807ca6";
    public static final String FILE_NAME = "YourVPN-EXP-" + APK_SHA256.substring(0, 24) + ".apk";

    private VpnExpPolicy() { }

    static boolean validName(String value) {
        return FILE_NAME.equals(value);
    }

    static void verifyCandidate(String packageName, long versionCode, String versionName, byte[][] signatures) throws Exception {
        if (!PACKAGE.equals(packageName) || versionCode != VERSION_CODE || !VERSION_NAME.equals(versionName)
                || signatures == null || signatures.length != 1 || signatures[0] == null) {
            throw new SecurityException("Неверный APK приложения");
        }
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(signatures[0]);
        StringBuilder hex = new StringBuilder(64);
        for (byte b : hash) hex.append(String.format(Locale.ROOT, "%02x", b & 255));
        if (!CERT_SHA256.equals(hex.toString())) throw new SecurityException("Неверная подпись APK");
    }
}
