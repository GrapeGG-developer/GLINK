package com.prilozhi.app.util;

import org.junit.Test;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.cert.CertificateFactory;
import java.util.Locale;
import static org.junit.Assert.*;

public class VpnExpPolicyTest {
    private static byte[] certificate() throws Exception {
        try (InputStream in = VpnExpPolicyTest.class.getResourceAsStream("/yourvpn-exp-signing-cert.pem")) {
            assertNotNull(in);
            return CertificateFactory.getInstance("X.509").generateCertificate(in).getEncoded();
        }
    }
    private static void candidate(String name, long code, String version, byte[][] signatures) throws Exception {
        VpnExpPolicy.verifyCandidate(name, code, version, signatures);
    }
    private static String digest(byte[] bytes) throws Exception {
        StringBuilder s = new StringBuilder();
        for (byte b : MessageDigest.getInstance("SHA-256").digest(bytes)) s.append(String.format(Locale.ROOT, "%02x", b & 255));
        return s.toString();
    }
    private static void expectRejected(RunnableWithException r) throws Exception {
        try { r.run(); fail("must reject"); } catch (SecurityException expected) { }
    }
    private interface RunnableWithException { void run() throws Exception; }

    @Test public void officialDemoCandidateIsAccepted() throws Exception {
        candidate(VpnExpPolicy.PACKAGE, 1L, "0.1.0-preview", new byte[][]{certificate()});
    }
    @Test public void wrongPackageIsRejected() throws Exception {
        expectRejected(() -> candidate("grp.gs.glink", 1L, "0.1.0-preview", new byte[][]{certificate()}));
    }
    @Test public void wrongVersionCodeIsRejected() throws Exception {
        expectRejected(() -> candidate(VpnExpPolicy.PACKAGE, 2L, "0.1.0-preview", new byte[][]{certificate()}));
    }
    @Test public void wrongVersionNameIsRejected() throws Exception {
        expectRejected(() -> candidate(VpnExpPolicy.PACKAGE, 1L, "0.1.0-release", new byte[][]{certificate()}));
    }
    @Test public void wrongSignerIsRejected() throws Exception {
        expectRejected(() -> candidate(VpnExpPolicy.PACKAGE, 1L, "0.1.0-preview", new byte[][]{new byte[]{1,2,3}}));
    }
    @Test public void missingAndMultipleSignersAreRejected() throws Exception {
        expectRejected(() -> candidate(VpnExpPolicy.PACKAGE, 1L, "0.1.0-preview", null));
        expectRejected(() -> candidate(VpnExpPolicy.PACKAGE, 1L, "0.1.0-preview", new byte[0][]));
        expectRejected(() -> candidate(VpnExpPolicy.PACKAGE, 1L, "0.1.0-preview", new byte[][]{certificate(),certificate()}));
    }
    @Test public void onlyExactPrivateInstallerFilenameIsAccepted() {
        assertTrue(VpnExpPolicy.validName(VpnExpPolicy.FILE_NAME));
        assertFalse(VpnExpPolicy.validName(null));
        assertFalse(VpnExpPolicy.validName("../" + VpnExpPolicy.FILE_NAME));
        assertFalse(VpnExpPolicy.validName(VpnExpPolicy.FILE_NAME + "?x=1"));
        assertFalse(VpnExpPolicy.validName("GPlus-install-1-0123456789abcdef01234567.apk"));
    }
    @Test public void exactPayloadIsCopiedAndProgressReported() throws Exception {
        byte[] data = "synthetic safe test data".getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        final long[] progress={0};
        UpdateManager.copyAndVerify(new ByteArrayInputStream(data), out, data.length, digest(data), count -> progress[0]=count);
        assertArrayEquals(data,out.toByteArray()); assertEquals(data.length,progress[0]);
    }
    @Test public void tamperedPayloadIsRejected() throws Exception {
        byte[] data = "synthetic safe test data".getBytes(StandardCharsets.UTF_8);
        String expected = digest(data); data[0] ^= 1;
        expectRejected(() -> UpdateManager.copyAndVerify(new ByteArrayInputStream(data), null, data.length, expected, null));
    }
    @Test public void truncatedAndOversizedPayloadsAreRejected() throws Exception {
        byte[] data = "synthetic safe test data".getBytes(StandardCharsets.UTF_8); String expected = digest(data);
        expectRejected(() -> UpdateManager.copyAndVerify(new ByteArrayInputStream(data), null, data.length + 1L, expected, null));
        expectRejected(() -> UpdateManager.copyAndVerify(new ByteArrayInputStream(data), null, data.length - 1L, expected, null));
    }
    @Test public void policyIsPinnedToPublicGitHubAndPreview() {
        assertEquals("https://raw.githubusercontent.com/GrapeGG-developer/GLINK/main/JustGrape-EXP-DEMO.apk", VpnExpPolicy.APK_URL);
        assertEquals(7226394L, VpnExpPolicy.APK_SIZE);
        assertEquals("app.justgrape.yourvpn.preview", VpnExpPolicy.PACKAGE);
        assertEquals("0.1.0-preview", VpnExpPolicy.VERSION_NAME);
    }
}
