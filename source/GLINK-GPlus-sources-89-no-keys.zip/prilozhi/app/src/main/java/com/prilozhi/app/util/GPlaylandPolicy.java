package com.prilozhi.app.util;

import java.security.MessageDigest;
import java.util.Locale;

public final class GPlaylandPolicy {
    public static final String APK_URL =
            "https://github.com/GrapeGG-developer/GLINK/releases/download/glink-3.3.7.0.0.0/gPLAYLANDg-EXP.apk";
    public static final long APK_SIZE = 79225626L;
    public static final String APK_SHA256 = "0046c33c921be95ab4b4eb0e5daa9d601398bf05d1130b22ae9dbafb42ed5915";
    public static final String PACKAGE = "app.grapescript.gplaylandg";
    public static final long VERSION_CODE = 10001L;
    public static final String VERSION_NAME = "1.0.0.0.0 EXP";
    public static final String CERT_SHA256 = "32fdf77aa29b2b054b5c0eebf0a495eb424f8e84ec0fe55afe35c95ea95cf852";
    public static final String FILE_NAME = "gPLAYLANDg-EXP-" + APK_SHA256.substring(0, 24) + ".apk";

    private GPlaylandPolicy() { }

    static boolean validName(String value) {
        return FILE_NAME.equals(value);
    }

    static void verifyCandidate(String packageName, long versionCode, String versionName, byte[][] signatures) throws Exception {
        if (!PACKAGE.equals(packageName) || versionCode != VERSION_CODE || !VERSION_NAME.equals(versionName)
                || signatures == null || signatures.length != 1 || signatures[0] == null) {
            throw new SecurityException("Неверный APK приложения");
        }
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(signatures[0]);
        StringBuilder hex = new StringBuilder(64);
        for (byte b : hash) hex.append(String.format(Locale.ROOT, "%02x", b & 255));
        if (!CERT_SHA256.equals(hex.toString())) throw new SecurityException("Неверная подпись APK");
    }
}
