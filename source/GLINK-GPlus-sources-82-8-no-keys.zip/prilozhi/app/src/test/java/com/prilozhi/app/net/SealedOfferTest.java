package com.prilozhi.app.net;

import org.junit.Test;
import java.security.KeyPair;
import java.security.SecureRandom;
import java.util.Arrays;
import static org.junit.Assert.*;

public class SealedOfferTest {
    private static final String SESSION = "abcd1234abcd1234ab";
    private static final String RECIPIENT = "abcd-EFGH-ijkl-MNOP";

    @Test public void roundTripAndNoPlaintextKeyInEnvelope() throws Exception {
        KeyPair recipient = SealedOffer.newTransportKey();
        byte[] key = new byte[32]; new SecureRandom().nextBytes(key);
        String sealed = SealedOffer.seal(SealedOffer.b64(recipient.getPublic().getEncoded()), key, SESSION, RECIPIENT);
        assertTrue(sealed.startsWith("g2."));
        assertFalse(sealed.contains(SealedOffer.b64(key)));
        assertArrayEquals(key, SealedOffer.open(recipient.getPrivate(), sealed, SESSION, RECIPIENT));
        assertNotEquals(sealed, SealedOffer.seal(SealedOffer.b64(recipient.getPublic().getEncoded()), key, SESSION, RECIPIENT));
    }
    @Test public void wrongPrivateKeyCannotOpen() throws Exception {
        KeyPair recipient = SealedOffer.newTransportKey(), other = SealedOffer.newTransportKey();
        String sealed = SealedOffer.seal(SealedOffer.b64(recipient.getPublic().getEncoded()), new byte[32], SESSION, RECIPIENT);
        try { SealedOffer.open(other.getPrivate(), sealed, SESSION, RECIPIENT); fail("must reject other private key"); } catch (java.security.GeneralSecurityException expected) { }
    }
    @Test public void sessionAndRecipientAreAuthenticated() throws Exception {
        KeyPair kp = SealedOffer.newTransportKey();
        String sealed = SealedOffer.seal(SealedOffer.b64(kp.getPublic().getEncoded()), new byte[32], SESSION, RECIPIENT);
        try { SealedOffer.open(kp.getPrivate(), sealed, "anotherSession", RECIPIENT); fail(); } catch (java.security.GeneralSecurityException expected) { }
        try { SealedOffer.open(kp.getPrivate(), sealed, SESSION, "otherRecipient"); fail(); } catch (java.security.GeneralSecurityException expected) { }
    }
    @Test public void tamperingIsRejected() throws Exception {
        KeyPair kp = SealedOffer.newTransportKey();
        String sealed = SealedOffer.seal(SealedOffer.b64(kp.getPublic().getEncoded()), new byte[32], SESSION, RECIPIENT);
        byte[] wire = SealedOffer.unb64(sealed.substring(3)); wire[wire.length - 1] ^= 1;
        try { SealedOffer.open(kp.getPrivate(), "g2." + SealedOffer.b64(wire), SESSION, RECIPIENT); fail(); } catch (java.security.GeneralSecurityException expected) { }
    }
    @Test public void noLegacyFallbackOrShortKeys() throws Exception {
        KeyPair kp = SealedOffer.newTransportKey();
        for (String value : Arrays.asList("", SealedOffer.b64(new byte[32]), "g2.AA", "g2." + SealedOffer.b64(new byte[300]))) {
            try { SealedOffer.open(kp.getPrivate(), value, SESSION, RECIPIENT); fail("legacy or malformed must be rejected"); } catch (IllegalArgumentException expected) { }
        }
        try { SealedOffer.seal(SealedOffer.b64(kp.getPublic().getEncoded()), new byte[31], SESSION, RECIPIENT); fail(); } catch (IllegalArgumentException expected) { }
    }
}
