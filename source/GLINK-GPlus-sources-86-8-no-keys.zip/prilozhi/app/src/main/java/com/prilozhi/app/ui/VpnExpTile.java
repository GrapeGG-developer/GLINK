package com.prilozhi.app.ui;

import android.view.View;

public final class VpnExpTile {
    private VpnExpTile() { }

    public static void bind(View tile, Runnable download) {
        if (tile == null || download == null) throw new IllegalArgumentException("tile and download are required");
        tile.setTag("yourvpn_exp_tile");
        tile.setClickable(true);
        tile.setOnClickListener(v -> download.run());
    }
}
