'use strict';
// Windows PC makes an outbound TLS-verified connection to the stateless Render
// gateway. The only locally reachable backend is 127.0.0.1; no NAT is needed.
const { WebSocket } = require('ws');
const dns = require('node:dns');
const { TunnelMux, MAX_FRAME } = require('./tunnel-stream');
const { fragmentedTlsAgent } = require('./tls-handshake-fallback');
const SAFE_NETWORK_CODES = new Set([
  'ECONNRESET','ECONNREFUSED','ETIMEDOUT','EHOSTUNREACH','ENETUNREACH',
  'ENOTFOUND','EAI_AGAIN','EPROTO','ERR_SSL_WRONG_VERSION_NUMBER',
  'UNABLE_TO_GET_ISSUER_CERT_LOCALLY','UNABLE_TO_VERIFY_LEAF_SIGNATURE',
  'SELF_SIGNED_CERT_IN_CHAIN','DEPTH_ZERO_SELF_SIGNED_CERT','CERT_HAS_EXPIRED',
  'CERT_NOT_YET_VALID','ERR_TLS_CERT_ALTNAME_INVALID','ERR_TLS_HANDSHAKE_TIMEOUT'
]);
// Never log arbitrary error messages, response bodies, URLs, paths or credentials.
function safeNetworkDiagnostic(error) {
  if (error && SAFE_NETWORK_CODES.has(error.code)) return 'WSS_NETWORK_' + error.code;
  if (error && error.message === 'Opening handshake has timed out') return 'WSS_HANDSHAKE_TIMEOUT';
  return 'WSS_NETWORK_OTHER';
}
function originUrl(s) {
  const u = new URL(s);
  if (u.protocol !== 'https:' || u.username || u.password || u.pathname !== '/' || u.search || u.hash) throw Error('HTTPS coordinator origin required');
  return u.origin;
}
// A TCP endpoint may accept connections but never complete TLS. On the next
// reconnect, prefer another address returned by the system resolver rather
// than repeatedly choosing the same one. The requested hostname is unchanged:
// Node still uses it for SNI, certificate verification and the Host header.
function rotatingLookup(resolve = dns.lookup, onCount = () => {}) {
  let turn = 0;
  return (hostname, options, callback) => {
    if (typeof options === 'function') { callback = options; options = {}; }
    if (typeof options === 'number') options = { family:options };
    options ||= {};
    const query = { all:true, family:options.family || 0, hints:options.hints || 0, verbatim:true };
    let callbackCalled = false;
    try {
      resolve(hostname, query, (error, addresses) => {
        callbackCalled = true;
        if (error) return callback(error);
        const unique = [], seen = new Set();
        for (const item of Array.isArray(addresses) ? addresses : []) {
          if (!item || typeof item.address !== 'string' || (item.family !== 4 && item.family !== 6)) continue;
          const key = item.family + ':' + item.address;
          if (!seen.has(key)) { seen.add(key); unique.push({ address:item.address, family:item.family }); }
        }
        if (!unique.length) { const e = Error('No usable address'); e.code = 'ENOTFOUND'; return callback(e); }
        onCount(unique.length);
        const offset = turn++ % unique.length;
        const ordered = unique.slice(offset).concat(unique.slice(0, offset));
        if (options.all) callback(null, ordered);
        else callback(null, ordered[0].address, ordered[0].family);
      });
    } catch (error) {
      if (callbackCalled) throw error;
      process.nextTick(callback, error);
    }
  };
}
// An explicitly enabled Node proxy must retain control of its own DNS lookup.
function nodeProxyEnabled(env = process.env, args = process.execArgv) {
  return env.NODE_USE_ENV_PROXY === '1' || /(?:^|\s)--use-env-proxy(?:\s|$)/.test(env.NODE_OPTIONS || '') || args.includes('--use-env-proxy');
}
function startTunnel({ coordinator, secret, port, onState = () => {}, onDiagnostic = () => {}, handshakeTimeoutMs = 15000, authTimeoutMs = 10000 }) {
  coordinator = originUrl(coordinator);
  if (!/^[A-Za-z0-9_-]{32,128}$/.test(secret) || !Number.isInteger(port) || port < 1 || port > 65535) throw Error('Invalid tunnel settings');
  if (!Number.isInteger(handshakeTimeoutMs) || handshakeTimeoutMs < 10 || handshakeTimeoutMs > 120000 || !Number.isInteger(authTimeoutMs) || authTimeoutMs < 10 || authTimeoutMs > 120000) throw Error('Invalid tunnel timeouts');
  if (process.env.NODE_TLS_REJECT_UNAUTHORIZED === '0') throw Error('TLS verification must remain enabled');
  const u = new URL('/gserver/tunnel', coordinator); u.protocol = 'wss:';
  let addressCount = 1, dialNumber = 0;
  const direct = !nodeProxyEnabled();
  const lookup = direct ? rotatingLookup(dns.lookup, count => { addressCount = Math.max(1, Math.min(count, 16)); }) : undefined;
  let closed = false, ws = null, timer = null, attempt = 0, mux = null;
  function reconnect() {
    if (closed || timer) return;
    const delay = Math.min(30000, 1000 * (2 ** Math.min(attempt++, 5))) + Math.floor(Math.random() * 500);
    timer = setTimeout(() => { timer = null; connect(); }, delay); timer.unref();
  }
  function connect() {
    if (closed) return; onState('connecting');
    // Try each system DNS address normally, then with a fragmented TLS
    // ClientHello. This does not change the requested host or trust policy.
    const useFallback = direct && Math.floor(dialNumber++ / addressCount) % 2 === 1;
    const agent = useFallback ? fragmentedTlsAgent() : undefined;
    const w = new WebSocket(u, { perMessageDeflate:false, maxPayload:MAX_FRAME, handshakeTimeout:handshakeTimeoutMs,
      rejectUnauthorized:true, ...(lookup ? {lookup} : {}), ...(agent ? {agent} : {}) }); ws = w;
    let ready = false, phase = 'handshake', authTimeout = null, failureReported = false;
    const report = code => { if (!closed && !failureReported) { failureReported = true; onDiagnostic(code); } };
    const initial = (data, binary) => {
      if (binary || data.length > 1024) { report('WSS_INVALID_RESPONSE'); return w.terminate(); }
      let value; try { value = JSON.parse(data.toString('utf8')); } catch (_) { report('WSS_INVALID_RESPONSE'); return w.terminate(); }
      if (!value || value.v !== 1 || value.type !== 'ready') { report('WSS_INVALID_RESPONSE'); return w.terminate(); }
      ready = true; clearTimeout(authTimeout); w.off('message', initial);
      mux = new TunnelMux(w, { connectPort: port }); attempt = 0; dialNumber = 0; onState('online');
    };
    w.on('open', () => {
      // The server's auth timeout begins after WebSocket upgrade, not while
      // DNS, TCP, proxy negotiation and TLS are still establishing the socket.
      phase = 'authentication';
      authTimeout = setTimeout(() => { if (!ready) { report('WSS_AUTH_TIMEOUT'); w.terminate(); } }, authTimeoutMs);
      authTimeout.unref();
      try { w.send(JSON.stringify({ v: 1, type: 'auth', secret })); }
      catch (_) { report('WSS_AUTH_SEND_FAILED'); w.terminate(); }
    });
    w.on('message', initial);
    w.on('unexpected-response', (_request, response) => {
      const status = Number(response.statusCode);
      report(Number.isInteger(status) && status >= 100 && status <= 599 ? 'WSS_HTTP_' + status : 'WSS_HTTP_OTHER');
      response.on('error', () => {}); response.resume(); w.terminate();
    });
    w.on('error', error => report(safeNetworkDiagnostic(error)));
    w.on('close', () => {
      clearTimeout(authTimeout); if (agent) agent.destroy(); if (ws === w) ws = null;
      if (!ready) report(phase === 'authentication' ? 'WSS_AUTH_NOT_CONFIRMED' : 'WSS_CLOSED_BEFORE_UPGRADE');
      if (mux) { mux.shutdown(); mux = null; }
      if (!closed) { onState('offline'); reconnect(); }
    });
  }
  connect();
  return { close() { closed = true; clearTimeout(timer); if (mux) mux.shutdown(); if (ws) ws.terminate(); } };
}
module.exports = { startTunnel, originUrl, safeNetworkDiagnostic, rotatingLookup, nodeProxyEnabled };
