package com.prilozhi.app.net;

import android.content.Context;
import android.util.Base64;

import com.prilozhi.app.util.State;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CRC32;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * ЕДИНСТВЕННЫЙ транспорт GLINK с версии 1.5: серверный релей GrapeScript.
 * Отправитель СРАЗУ после выбора файлов шифрует поток (ключи рождаются на
 * телефоне, ключ уходит партнёру только через NFC-касание) и заливает его на
 * настроенный защищённый релей /glink/*. Получатель после касания
 * скачивает шифротекст на максимальной скорости сети и расшифровывает на месте.
 * Сервер хранит только шифротекст и не знает ключа.
 * Поток внутри шифра — как раньше: [len:4][манифест] + на файл [size:8][байты][crc32:8].
 */
public final class RelayTransfer {

    // Build-time URL permits a future GSERVER without silently falling back to an insecure relay.
    public static final String BASE = com.prilozhi.app.BuildConfig.GLINK_RELAY_URL;
    private static final String MAGIC = "GSENC1";
    private static final int CHUNK = 64 * 1024;

    private static final java.util.concurrent.ConcurrentMap<String,SealedUpload> SEALED_UPLOADS = new java.util.concurrent.ConcurrentHashMap<>();
    private static final java.util.concurrent.atomic.AtomicReference<String> WATCH_SESSION = new java.util.concurrent.atomic.AtomicReference<>();
    private static String queueSignature(List<OutItem> items) {
        StringBuilder b = new StringBuilder();
        for (OutItem item : items) b.append(item.selectionId).append(';');
        return b.toString();
    }
    private static boolean queueMatches(State st, String signature) {
        synchronized (st.outbound) { return !st.outbound.isEmpty() && queueSignature(st.outbound).equals(signature); }
    }
    /** NFC never exposes a stale session after the selected queue changes. */
    public static synchronized String[] nfcSessionSnapshot() {
        State st = State.get(); String session = st.relaySession, key = st.relayKeyB64;
        return session == null || session.isEmpty() || key == null || key.isEmpty()
                || !st.relayUploaded || !queueMatches(st, st.relaySig)
                ? null : new String[]{session, key};
    }

    private RelayTransfer() {
    }

    // ------------------------------------------------------------------
    // ОТПРАВИТЕЛЬ

    /** A changed queue waits for the current upload; retries reuse only sealed ciphertext. */
    public static synchronized void ensureUpload(Context ctx) {
        State st = State.get(); List<OutItem> items;
        synchronized (st.outbound) {
            if (st.outbound.isEmpty()) return;
            items = new ArrayList<>(st.outbound);
        }
        final String sig = queueSignature(items);
        if (st.relayUploading) return;
        if (sig.equals(st.relaySig) && st.relayUploaded) return;
        final Context app = ctx.getApplicationContext();
        boolean resume = sig.equals(st.relaySig) && !st.transferCancelled
                && SEALED_UPLOADS.containsKey(st.relaySession);
        if (!resume) {
            st.relaySig = sig; st.relayUploaded = false;
            synchronized (st) { st.wifiTargetId = null; st.wifiTargetName = null; st.wifiTargetKey = null; }
            SecureRandom rnd = new SecureRandom(); byte[] sb = new byte[9]; rnd.nextBytes(sb);
            StringBuilder sess = new StringBuilder();
            for (byte b : sb) sess.append(String.format("%02x", b));
            st.relaySession = sess.toString(); byte[] key = new byte[32]; rnd.nextBytes(key);
            st.relayKeyB64 = Base64.encodeToString(key, Base64.NO_WRAP);
        }
        final String session = st.relaySession, keyB64 = st.relayKeyB64;
        final boolean resuming = resume;
        st.relayUploading = true;
        new Thread(() -> upload(app, items, session, keyB64, sig, resuming), "glink-relay-up").start();
    }

    private static synchronized void finishUpload(Context ctx, String session, String signature) {
        State st = State.get();
        if (!session.equals(st.relaySession)) return;
        st.relayUploading = false; st.notifyChanged();
        if (!queueMatches(st, signature) && st.hasOutbound()) ensureUpload(ctx);
    }

    private static void waitWhilePaused(State st) throws InterruptedException {
        while (st.transferPaused && !st.transferCancelled) Thread.sleep(350);
    }

    private static void throwIfCancelled(State st) throws IOException {
        if (st.transferCancelled) throw new IOException("CANCELLED");
    }

    private static void purgeServer(String session) {
        try {
            HttpURLConnection d = (HttpURLConnection)
                    new URL(BASE + "/glink/done/" + session).openConnection();
            d.setRequestMethod("POST");
            d.setConnectTimeout(8000);
            d.getResponseCode();
            d.disconnect();
        } catch (Throwable ignored) {
        }
    }

    private static void upload(Context ctx, List<OutItem> items, String session, String keyB64, String signature, boolean resume) {
        State st = State.get();
        st.transferCancelled = false;
        st.transferPaused = false;
        File encFile = new File(ctx.getCacheDir(), "relay_up_" + session + ".enc");
        boolean createdHere = false;
        try {
            ManifestBuilder.Built built = ManifestBuilder.build(ctx, items);
            JSONArray filesArr = new JSONArray();
            long total = 0;
            for (ManifestBuilder.SendFile f : built.files) {
                if (f.size < 0) throw new IOException("Неизвестен размер файла: " + f.path);
                JSONObject o = new JSONObject();
                o.put("p", f.path);
                o.put("s", f.size);
                o.put("m", f.mime);
                filesArr.put(o);
                if (f.size > Long.MAX_VALUE - total) throw new IOException("Слишком большой размер передачи");
                total += f.size;
            }
            JSONObject man = new JSONObject();
            man.put("t", "manifest");
            man.put("from", st.deviceName);
            man.put("files", filesArr);
            if (built.fun != null && !built.fun.isEmpty()) man.put("fun", built.fun);
            if (built.text != null && !built.text.isEmpty()) man.put("text", built.text);
            if (built.link != null && !built.link.isEmpty()) man.put("link", built.link);

            st.total = total;
            st.transferred = 0;
            st.filesTotal = built.files.size();
            st.filesDone = 0;
            st.currentFile = "Шифрование…";
            st.relayPhase = "ШИФРОВАНИЕ";
            st.notifyChanged(true);
            com.prilozhi.app.svc.TransferService.start(ctx);

            if (resume) {
                SealedUpload seal = SEALED_UPLOADS.get(session);
                if (seal == null || !seal.matches(encFile)) {
                    SEALED_UPLOADS.remove(session);
                    throw new IOException("Локальная зашифрованная копия изменилась; нужна новая сессия");
                }
            } else {
            if (!encFile.createNewFile()) throw new IOException("Зашифрованный файл сессии уже существует");
            createdHere = true;
            java.security.MessageDigest ciphertextHash = SealedUpload.sha256();
            // Keep memory bounded on phones; larger inputs are streamed.
            java.util.List<byte[]> ramFiles = null;
            if (total > 0 && total <= 16L * 1024 * 1024) {
                st.currentFile = "Предзагрузка в память…";
                st.notifyChanged(true);
                ramFiles = new java.util.ArrayList<>();
                for (ManifestBuilder.SendFile f : built.files) {
                    throwIfCancelled(st);
                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                    byte[] rb = new byte[CHUNK];
                    try (InputStream rin = new BufferedInputStream(f.opener.open(), 128 * 1024)) {
                        int rn;
                        while ((rn = rin.read(rb)) != -1) {
                            if (rn > f.size - bos.size()) throw new IOException("Размер файла изменился: " + f.path);
                            bos.write(rb, 0, rn);
                        }
                        if (bos.size() != f.size) throw new IOException("Размер файла изменился: " + f.path);
                    }
                    ramFiles.add(bos.toByteArray());
                }
            }

            // ФАЗА 1: шифруем весь поток в локальный файл (его потом льём частями)
            try (EncryptSink sink = new EncryptSink(
                    new java.security.DigestOutputStream(new BufferedOutputStream(new FileOutputStream(encFile), 128 * 1024), ciphertextHash),
                    Base64.decode(keyB64, Base64.DEFAULT))) {
            byte[] manBytes = man.toString().getBytes(StandardCharsets.UTF_8);
            byte[] lenB = new byte[]{
                    (byte) ((manBytes.length >> 24) & 0xFF), (byte) ((manBytes.length >> 16) & 0xFF),
                    (byte) ((manBytes.length >> 8) & 0xFF), (byte) (manBytes.length & 0xFF)};
            sink.write(lenB, 0, 4);
            sink.write(manBytes, 0, manBytes.length);
            byte[] buf = new byte[CHUNK];
            int fileIdx = 0;
            for (ManifestBuilder.SendFile f : built.files) {
                st.currentFile = f.path;
                st.notifyChanged(true);
                byte[] sz = new byte[8];
                long v = f.size;
                for (int i = 7; i >= 0; i--) {
                    sz[i] = (byte) (v & 0xFF);
                    v >>= 8;
                }
                sink.write(sz, 0, 8);
                CRC32 crc = new CRC32();
                long actualFileSize = 0;
                if (ramFiles != null) {
                    byte[] data = ramFiles.get(fileIdx);
                    actualFileSize = data.length;
                    if (actualFileSize != f.size) throw new IOException("Размер файла изменился: " + f.path);
                    crc.update(data, 0, data.length);
                    sink.write(data, 0, data.length);
                    st.transferred += data.length;
                    if (total > 0) {
                        st.progress = Math.min(1f, (float) ((double) st.transferred / total)) * 0.15f;
                    }
                    st.notifyChanged(true);
                }
                try (InputStream in = ramFiles != null
                        ? new java.io.ByteArrayInputStream(new byte[0])
                        : new BufferedInputStream(f.opener.open(), 128 * 1024)) {
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        waitWhilePaused(st);
                        throwIfCancelled(st);
                        if (n > f.size - actualFileSize) throw new IOException("Размер файла изменился: " + f.path);
                        actualFileSize += n;
                        crc.update(buf, 0, n);
                        sink.write(buf, 0, n);
                        st.transferred += n;
                        if (total > 0) {
                            st.progress = Math.min(1f, (float) ((double) st.transferred / total)) * 0.15f;
                        }
                        st.notifyChanged(true);
                    }
                }
                if (actualFileSize != f.size) throw new IOException("Размер файла изменился: " + f.path);
                byte[] cb = new byte[8];
                long cv = crc.getValue();
                for (int i = 7; i >= 0; i--) {
                    cb[i] = (byte) (cv & 0xFF);
                    cv >>= 8;
                }
                sink.write(cb, 0, 8);
                st.filesDone++;
                fileIdx++;
                st.notifyChanged(true);
            }
            sink.finish();
            }
            SEALED_UPLOADS.put(session, new SealedUpload(encFile.length(), ciphertextHash.digest()));
            }

            // ФАЗА 2: продолжение по тем же запечатанным зашифрованным байтам
            long encSize = encFile.length();
            int chunkSize = 6 * 1024 * 1024; // ускорение: части крупнее
            int nChunks = (int) Math.max(1, (encSize + chunkSize - 1) / chunkSize);
            st.relayPhase = "ЗАГРУЗКА";
            st.currentFile = "Подключаемся к серверу…";
            st.notifyChanged(true);
            java.util.Set<Integer> have = fetchChunkList(session);
            st.currentFile = "Загрузка на сервер…";
            st.notifyChanged(true);
            final java.util.concurrent.atomic.AtomicLong uploadedBytes =
                    new java.util.concurrent.atomic.AtomicLong(0);
            for (int part : have) uploadedBytes.addAndGet(chunkLen(encSize, chunkSize, part));
            final long fTotal = total;
            final long fEnc = encSize;
            // УСКОРЕНИЕ: три части летят одновременно — канал не простаивает
            java.util.List<Integer> todo = new java.util.ArrayList<>();
            for (int i = 0; i < nChunks; i++) if (!have.contains(i)) todo.add(i);
            java.util.concurrent.ExecutorService pool =
                    java.util.concurrent.Executors.newFixedThreadPool(4); // ускорение: 4 потока
            java.util.concurrent.atomic.AtomicReference<Throwable> chunkError =
                    new java.util.concurrent.atomic.AtomicReference<>();
            for (int idx : todo) {
                final int partIdx = idx;
                pool.submit(() -> {
                    try {
                        waitWhilePaused(st);
                        throwIfCancelled(st);
                        int len = (int) chunkLen(encSize, chunkSize, partIdx);
                        byte[] data = new byte[len];
                        try (java.io.RandomAccessFile r =
                                     new java.io.RandomAccessFile(encFile, "r")) {
                            r.seek((long) partIdx * chunkSize);
                            r.readFully(data, 0, len);
                        }
                        boolean sentPart = false;
                        for (int attempt = 0; attempt < 6 && !sentPart; attempt++) {
                            waitWhilePaused(st);
                            throwIfCancelled(st);
                            sentPart = postChunk(session, partIdx, nChunks, data, len);
                            if (!sentPart) {
                                Thread.sleep(1200);
                                if (meta(session) >= 0) sentPart = true;
                            }
                        }
                        if (!sentPart) throw new IOException("Часть " + partIdx + " не ушла на сервер");
                        long up = uploadedBytes.addAndGet(len);
                        st.progress = 0.15f + 0.85f * (float) ((double) up / Math.max(1, fEnc));
                        st.transferred = (long) (fTotal * Math.min(1f, (float) ((double) up / Math.max(1, fEnc))));
                        st.notifyChanged(true);
                    } catch (Throwable t) {
                        chunkError.compareAndSet(null, t);
                    }
                });
            }
            pool.shutdown();
            while (!pool.awaitTermination(30, java.util.concurrent.TimeUnit.SECONDS)) {
                if (st.transferCancelled) {
                    pool.shutdownNow();
                    throw new IOException("CANCELLED");
                }
            }
            if (chunkError.get() != null) throw new IOException(chunkError.get());
            if (meta(session) < 0) {
                st.relayPhase = "СЕРВЕР НЕ СОБРАЛ ФАЙЛ";
                return;
            }
            if (session.equals(st.relaySession)) {
                st.relayUploaded = true;
                st.relayPhase = "НА СЕРВЕРЕ";
                if (queueMatches(st, signature)) sendPendingWifiOffer(session, keyB64);
                st.currentFile = "Готово к передаче";
                st.progress = 1f;
                startPeerWatch(session);
                st.notifyChanged();
            }
        } catch (Throwable t) {
            if (st.transferCancelled) purgeServer(session);
            if (session.equals(st.relaySession)) {
                if (st.transferCancelled) {
                    st.relayPhase = "ОТМЕНЕНО";
                    st.relaySig = "";
                    st.currentFile = "Загрузка отменена";
                } else {
                    st.relayPhase = "ЗАГРУЗКА: " + t.getClass().getSimpleName()
                            + " (части сохранены на сервере)";
                }
            }
        } finally {
            if (st.transferCancelled || (createdHere && !SEALED_UPLOADS.containsKey(session))) {
                SEALED_UPLOADS.remove(session); encFile.delete();
            }
            finishUpload(ctx, session, signature);
        }
    }

    private static long chunkLen(long total, int chunkSize, int idx) {
        long from = (long) idx * chunkSize;
        return Math.max(0, Math.min(chunkSize, total - from));
    }

    private static java.util.Set<Integer> fetchChunkList(String session) {
        java.util.Set<Integer> have = new java.util.HashSet<>();
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(BASE + "/glink/chunks/" + session).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(90000);
            if (c.getResponseCode() / 100 == 2) {
                byte[] b = StreamCompat.readAll(c.getInputStream(), 4 * 1024 * 1024);
                JSONArray arr = new JSONObject(new String(b, StandardCharsets.UTF_8))
                        .optJSONArray("have");
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) have.add(arr.getInt(i));
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.disconnect();
        }
        return have;
    }

    private static boolean postChunk(String session, int idx, int count, byte[] data, int len) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(
                    BASE + "/glink/chunk/" + session + "?i=" + idx + "&n=" + count
                            + "&ttl=" + State.get().linkTtlHours).openConnection();
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setFixedLengthStreamingMode(len);
            c.setConnectTimeout(20000);
            c.setReadTimeout(120000);
            c.setRequestProperty("Content-Type", "application/octet-stream");
            try (OutputStream os = c.getOutputStream()) {
                os.write(data, 0, len);
            }
            // Socket write is not durable storage: show confirmation as a separate phase.
            State st = State.get();
            if (session.equals(st.relaySession) && st.relayUploading && !st.transferCancelled) {
                st.currentFile = "Сервер сохраняет часть…";
                st.notifyChanged(true);
            }
            return c.getResponseCode() / 100 == 2;
        } catch (Throwable t) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    // ------------------------------------------------------------------
    // Wi-Fi v2: recipient's independent ECDH transport key seals each session key.
    // No legacy plaintext fallback. Discovery keys are not manually verified.
    private static volatile boolean presenceStarted = false;
    private static volatile String wifiId = "";
    private static volatile String wifiBearer = "";
    private static volatile long wifiBearerUntil = 0;
    private static volatile String lastShownOffer = "";
    private static Context wifiContext;

    private static synchronized void authenticateWifi(Context ctx) throws Exception {
        if (!wifiBearer.isEmpty() && android.os.SystemClock.elapsedRealtime() < wifiBearerUntil) return;
        byte[] identityPub = com.prilozhi.app.identity.InstallationIdentity.publicKey();
        byte[] transportPub = com.prilozhi.app.identity.TransportIdentity.get(ctx).getPublic().getEncoded();
        String expected = com.prilozhi.app.identity.InstallationIdentity.publicId();
        JSONObject challenge = jsonRequest("/glink/device/challenge", "POST",
                new JSONObject().put("publicKey", SealedOffer.b64(identityPub)).toString(), null);
        if (challenge.optInt("v") != 2 || !expected.equals(challenge.optString("id")))
            throw new IOException("Сервер GLINK нужно обновить");
        String nonceString = challenge.getString("nonce");
        byte[] nonce = SealedOffer.unb64(nonceString);
        byte[] signature = com.prilozhi.app.identity.InstallationIdentity.signWifiChallenge(nonce, transportPub);
        JSONObject auth = jsonRequest("/glink/device/auth", "POST", new JSONObject()
                .put("nonce", nonceString).put("transportKey", SealedOffer.b64(transportPub))
                .put("signature", SealedOffer.b64(signature)).put("name", State.get().deviceName).toString(), null);
        if (auth.optInt("v") != 2 || !expected.equals(auth.optString("id"))
                || auth.optString("token").isEmpty()) throw new IOException("Ошибка авторизации GLINK");
        wifiId = expected;
        wifiBearer = auth.getString("token");
        long duration = Math.max(30_000L, Math.min(60 * 60_000L, auth.optLong("expiresIn", 0L)) - 30_000L);
        wifiBearerUntil = android.os.SystemClock.elapsedRealtime() + duration;
        State.get().wifiStatus = "";
    }

    private static JSONObject wifiRequest(Context ctx, String path, String method, String body) throws Exception {
        authenticateWifi(ctx);
        try {
            return jsonRequest(path, method, body, wifiBearer);
        } catch (UnauthorizedException e) {
            synchronized (RelayTransfer.class) { wifiBearer = ""; wifiBearerUntil = 0; }
            authenticateWifi(ctx);
            return jsonRequest(path, method, body, wifiBearer);
        }
    }

    /** Start presence without retaining the Activity. Android may suspend it in the background. */
    public static synchronized void startPresence(Context ctx) {
        if (presenceStarted) return;
        wifiContext = ctx.getApplicationContext();
        presenceStarted = true;
        new Thread(() -> {
            int tick = 0;
            while (true) {
                try {
                    authenticateWifi(wifiContext);
                    if (tick % 5 == 0) wifiRequest(wifiContext, "/glink/presence", "POST",
                            new JSONObject().put("name", State.get().deviceName).toString());
                    JSONObject response = wifiRequest(wifiContext, "/glink/offers/" + wifiId, "GET", null);
                    if (response.optInt("v") != 2) throw new IOException("Сервер GLINK нужно обновить");
                    JSONArray offers = response.optJSONArray("offers");
                    State st = State.get();
                    if (offers != null && offers.length() > 0 && !st.sessionActive && st.offerSession == null) {
                        JSONObject o = offers.getJSONObject(0);
                        String session = o.optString("s", "");
                        if (!session.equals(lastShownOffer)) {
                            try {
                                byte[] raw = SealedOffer.open(com.prilozhi.app.identity.TransportIdentity
                                        .get(wifiContext).getPrivate(), o.optString("k", ""), session, wifiId);
                                String decoded = Base64.encodeToString(raw, Base64.NO_WRAP);
                                java.util.Arrays.fill(raw, (byte) 0);
                                lastShownOffer = session;
                                st.offerFrom = o.optString("from", "Устройство");
                                st.offerKey = decoded;
                                st.offerSession = session;
                                st.notifyChanged();
                            } catch (Exception badOffer) {
                                // Reject old plaintext offers, invalid keys and tampered envelopes.
                                ackOffer(session);
                            }
                        }
                    }
                } catch (Exception ignored) {
                    State.get().wifiStatus = "Защищённый Wi-Fi недоступен: проверьте сеть и обновление сервера GLINK";
                }
                tick++;
                try { Thread.sleep(5000); } catch (InterruptedException e) { return; }
            }
        }, "glink-presence-v2").start();
    }

    public interface DevicesCallback {
        void onDevices(java.util.List<String[]> devices);
    }

    public static void fetchDevices(DevicesCallback cb) {
        new Thread(() -> {
            java.util.List<String[]> out = new java.util.ArrayList<>();
            try {
                if (wifiContext == null) throw new IOException("GLINK ещё не запущен");
                authenticateWifi(wifiContext);
                JSONObject response = jsonRequest("/glink/devices?me=" + wifiId, "GET", null, null);
                if (response.optInt("v") != 2) throw new IOException("Сервер GLINK нужно обновить");
                JSONArray arr = response.optJSONArray("devices");
                if (arr != null) for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    String id = o.optString("id"), pub = o.optString("enc");
                    if (id.matches("[A-Za-z0-9_-]{19}") && pub.length() >= 100 && pub.length() <= 220)
                        out.add(new String[]{id, o.optString("name", "Устройство"), pub});
                }
                State.get().wifiStatus = "";
            } catch (Exception e) {
                State.get().wifiStatus = "Защищённый Wi-Fi недоступен: проверьте сеть и обновление сервера GLINK";
            }
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> cb.onDevices(out));
        }, "glink-devices-v2").start();
    }

    private static void sendPendingWifiOffer(String session, String keyB64) {
        State st = State.get();
        final String toId, toName, recipientKey;
        synchronized (st) {
            if (st.wifiTargetId == null) return;
            toId = st.wifiTargetId; toName = st.wifiTargetName; recipientKey = st.wifiTargetKey;
            st.wifiTargetId = null; st.wifiTargetName = null; st.wifiTargetKey = null;
        }
        try {
            postOffer(toId, recipientKey, session, keyB64, st.deviceName);
            st.relayPhase = "ОТПРАВЛЕНО ПО WI-FI: " + toName;
            st.wifiStatus = "";
        } catch (Exception e) {
            st.relayPhase = "WI-FI: НЕ УДАЛОСЬ ОТПРАВИТЬ";
            st.wifiStatus = "Не удалось отправить: обновите сервер и проверьте устройство получателя";
        }
        st.notifyChanged();
    }

    /** Encrypt the session key to the chosen device, immediately or when upload finishes. */
    public static void offerTo(Context ctx, String toId, String toName, String recipientKey) {
        State st = State.get();
        final boolean ready;
        final String ss, kk;
        synchronized (st) {
            st.wifiTargetId = toId; st.wifiTargetName = toName; st.wifiTargetKey = recipientKey;
            ready = st.relayUploaded && st.relaySession != null && st.relayKeyB64 != null;
            ss = st.relaySession; kk = st.relayKeyB64;
        }
        if (ready) new Thread(() -> sendPendingWifiOffer(ss, kk), "glink-offer-v2").start();
        else ensureUpload(ctx);
        st.notifyChanged();
    }

    public static void ackOffer(String session) {
        if (session == null || !session.matches("[A-Za-z0-9_-]{6,64}")) return;
        new Thread(() -> {
            try {
                wifiRequest(wifiContext, "/glink/offer-ack", "POST", new JSONObject()
                        .put("to", wifiId).put("s", session).toString());
            } catch (Exception ignored) { }
        }, "glink-ack-v2").start();
    }

    private static void postOffer(String toId, String recipientKey, String session, String keyB64, String fromName) throws Exception {
        byte[] raw = Base64.decode(keyB64, Base64.DEFAULT);
        String sealed;
        try { sealed = SealedOffer.seal(recipientKey, raw, session, toId); }
        finally { java.util.Arrays.fill(raw, (byte) 0); }
        JSONObject response = jsonRequest("/glink/offer", "POST", new JSONObject().put("to", toId)
                .put("s", session).put("k", sealed).put("from", fromName).toString(), null);
        if (!response.optBoolean("ok") || response.optInt("v") != 2)
            throw new IOException("Сервер GLINK нужно обновить");
    }

    private static final class UnauthorizedException extends IOException {}
    private static JSONObject jsonRequest(String path, String method, String body, String token) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(BASE + path).openConnection();
        try {
            c.setRequestMethod(method);
            c.setConnectTimeout(10000);
            c.setReadTimeout(90000);
            c.setUseCaches(false);
            if (token != null) c.setRequestProperty("Authorization", "Bearer " + token);
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
            }
            int code = c.getResponseCode();
            if (code == 401) throw new UnauthorizedException();
            if (code / 100 != 2) throw new IOException("Relay HTTP " + code);
            byte[] bytes = StreamCompat.readAll(c.getInputStream(), 4 * 1024 * 1024);
            return new JSONObject(new String(bytes, StandardCharsets.UTF_8));
        } finally { c.disconnect(); }
    }

    /** Смена срока жизни уже залитого файла (островок: 1 -> 6 -> 24 ч). */
    public static void updateTtl(String session, int hours) {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(
                        BASE + "/glink/ttl/" + session + "?h=" + hours).openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(8000);
                c.getResponseCode();
                c.disconnect();
            } catch (Throwable ignored) {
            }
        }, "glink-ttl").start();
    }

    /** Отправитель следит, сколько уже скачал друг: опрос /glink/prog. */
    private static void startPeerWatch(String session) {
        State st = State.get();
        if (session.equals(WATCH_SESSION.getAndSet(session))) return;
        st.peerWatch = true;
        st.peerProgress = -1f;
        new Thread(() -> {
            long deadline = System.currentTimeMillis() + 30L * 60 * 1000;
            try {
                while (System.currentTimeMillis() < deadline && session.equals(WATCH_SESSION.get()) && session.equals(st.relaySession)) {
                    try {
                        HttpURLConnection c = (HttpURLConnection)
                                new URL(BASE + "/glink/prog/" + session).openConnection();
                        c.setConnectTimeout(8000);
                        c.setReadTimeout(8000);
                        if (c.getResponseCode() / 100 == 2) {
                            byte[] b = StreamCompat.readAll(c.getInputStream(), 4 * 1024 * 1024);
                            JSONObject o = new JSONObject(new String(b, StandardCharsets.UTF_8));
                            long got = o.optLong("got", 0), tot = o.optLong("total", 0);
                            if (tot > 0 && session.equals(WATCH_SESSION.get()) && session.equals(st.relaySession)) {
                                st.peerProgress = Math.min(1f, (float) ((double) got / tot));
                                st.notifyChanged(true);
                                if (got >= tot) break;
                            }
                        } else if (st.peerProgress >= 0f) {
                            break; // файл забрали и удалили с сервера — друг закончил
                        }
                        c.disconnect();
                    } catch (Throwable ignored) {
                    }
                    Thread.sleep(1500);
                }
            } catch (InterruptedException ignored) {
            } finally {
                if (WATCH_SESSION.compareAndSet(session, null)) {
                    st.peerWatch = false;st.notifyChanged();
                }
            }
        }, "glink-peer-watch").start();
    }

    /** Получатель докладывает серверу, сколько уже скачал (для экрана отправителя). */
    private static void reportProgress(String session, long got, long total) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(
                    BASE + "/glink/prog/" + session + "?got=" + got + "&total=" + total)
                    .openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(6000);
            c.setReadTimeout(6000);
            c.getResponseCode();
            c.disconnect();
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------
    // ПОЛУЧАТЕЛЬ

    public static boolean receive(Context ctx, String session, String keyB64, ReceiveStore store) {
        State st = State.get();
        st.transferCancelled = false;
        st.transferPaused = false;
        if (session == null || session.isEmpty() || keyB64 == null || keyB64.isEmpty()) return false;
        // ждём, пока отправитель дозальёт (касание могло быть раньше конца заливки)
        long deadline = System.currentTimeMillis() + 240_000;
        boolean ready = false;
        while (System.currentTimeMillis() < deadline) {
            if (st.transferCancelled) return false;
            if (meta(session) >= 0) {
                ready = true;
                break;
            }
            st.gfcasPhase = "Жду загрузку друга на сервер…";
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                return false;
            }
        }
        if (!ready) {
            st.gfcasPhase = "СЕРВЕР: файл друга не появился за 4 минуты (или релей не развёрнут)";
            return false;
        }
        try {
            st.gfcasPhase = "СКАЧИВАНИЕ";
            // шифротекст качаем в файл с докачкой по Range — обрыв не страшен
            File encFile = new File(ctx.getCacheDir(), "relay_dl_" + session + ".enc");
            if (!downloadCipher(session, encFile)) return false;
            InputStream raw = new BufferedInputStream(new FileInputStream(encFile), 128 * 1024);
            InputStream plain = new DecryptStream(raw, Base64.decode(keyB64, Base64.DEFAULT));
            boolean ok = consume(ctx, plain, store, session);
            try {
                raw.close();
            } catch (Throwable ignored) {
            }
            if (ok) {
                encFile.delete();
                purgeServer(session);
            }
            return ok;
        } catch (Throwable t) {
            st.gfcasPhase = st.transferCancelled ? "ОТМЕНЕНО" : "СКАЧИВАНИЕ: " + t.getClass().getSimpleName();
            return false;
        }
    }

    /** Скачивание шифротекста с докачкой: Range + дозапись; пауза закрывает соединение и ждёт. */
    private static boolean downloadCipher(String session, File encFile) throws Exception {
        State st = State.get();
        long encTotal = meta(session);
        if (encTotal <= 0) throw new IOException("Недопустимый размер зашифрованного файла");
        while (true) {
            throwCancel(st);
            long have = encFile.exists() ? encFile.length() : 0;
            if (have == encTotal) return true;
            if (have > encTotal) throw new IOException("Локальная копия длиннее файла сервера");
            HttpURLConnection c = (HttpURLConnection) new URL(BASE + "/glink/dl/" + session).openConnection();
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
            int code = c.getResponseCode();
            boolean append = code == 206;
            if (!append && code != 200) {
                c.disconnect();
                st.gfcasPhase = "СКАЧИВАНИЕ: HTTP " + code;
                return false;
            }
            if (append && !DownloadRange.valid(c.getHeaderField("Content-Range"), have, encTotal, c.getContentLengthLong())) {
                c.disconnect(); throw new IOException("Некорректный диапазон сервера");
            }
            if (!append) {
                long size = c.getContentLengthLong();
                if (size >= 0 && size != encTotal) { c.disconnect(); throw new IOException("Размер ответа не совпадает"); }
                have = 0;
            }
            long lastReport = 0;
            try (InputStream in = new BufferedInputStream(c.getInputStream(), 128 * 1024);
                 OutputStream os = new BufferedOutputStream(
                         new FileOutputStream(encFile, append), 128 * 1024)) {
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = in.read(buf)) != -1) {
                    if (st.transferCancelled) throw new IOException("CANCELLED");
                    if (st.transferPaused) {
                        os.flush();
                        return downloadCipherPaused(session, encFile);
                    }
                    if (n > encTotal - have) throw new IOException("Сервер прислал лишние данные");
                    os.write(buf, 0, n);
                    have += n;
                    if (encTotal > 0) {
                        // без этих двух полей островок честно показывал 0% и 0 Б/с
                        st.total = encTotal;
                        st.transferred = have;
                        st.progress = (float) ((double) have / encTotal);
                    }
                    st.notifyChanged(true);
                    long now = System.currentTimeMillis();
                    if (now - lastReport > 700) {
                        lastReport = now;
                        final long g = have, tt = encTotal;
                        new Thread(() -> reportProgress(session, g, tt), "glink-prog").start();
                    }
                }
            } finally {
                c.disconnect();
            }
            if (encFile.length() == encTotal) return true;
            Thread.sleep(600); // обрыв до конца файла — цикл докачает остаток
        }
    }

    private static boolean downloadCipherPaused(String session, File encFile) throws Exception {
        State st = State.get();
        while (st.transferPaused && !st.transferCancelled) Thread.sleep(350);
        throwCancel(st);
        return downloadCipher(session, encFile);
    }

    private static void throwCancel(State st) throws IOException {
        if (st.transferCancelled) throw new IOException("CANCELLED");
    }

    private static long meta(String session) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(BASE + "/glink/meta/" + session).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(90000);
            if (c.getResponseCode() / 100 != 2) return -1;
            byte[] b = StreamCompat.readAll(c.getInputStream(), 4 * 1024 * 1024);
            return new JSONObject(new String(b, StandardCharsets.UTF_8)).optLong("size", -1);
        } catch (Throwable t) {
            return -1;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Разбор открытого потока: манифест + файлы -> ReceiveStore. */
    private static boolean consume(Context ctx, InputStream in, ReceiveStore store,
                                   String session) throws Exception {
        State st = State.get();
        DataInputStream d = new DataInputStream(in);
        int manLen = d.readInt();
        if (manLen < 2 || manLen > 4_000_000) throw new IOException("Манифест битый");
        byte[] manBytes = StreamCompat.readExactly(d, manLen);
        JSONObject man = new JSONObject(new String(manBytes, StandardCharsets.UTF_8));
        JSONArray files = man.optJSONArray("files");
        if (files == null) files = new JSONArray();
        long total = 0;
        for (int i = 0; i < files.length(); i++) {
            long sz = files.getJSONObject(i).optLong("s", -1);
            if (sz > 0) total += sz;
        }
        st.total = total;
        st.transferred = 0;
        st.filesTotal = files.length();
        st.filesDone = 0;
        String text = man.optString("text", "");
        if (!text.isEmpty()) {
            st.incomingText = text;
            store.saveText("Текст.txt", text);
        }
        String link = man.optString("link", "");
        if (!link.isEmpty()) {
            st.incomingLink = link;
            store.saveText("Ссылка.txt", link);
        }
        String fun = man.optString("fun", "");
        if (!fun.isEmpty()) st.incomingFun = fun;
        st.notifyChanged(true);

        byte[] buf = new byte[CHUNK];
        long lastProgReport = 0;
        for (int i = 0; i < files.length(); i++) {
            JSONObject f = files.getJSONObject(i);
            String path = f.optString("p", "file.bin");
            String mime = f.optString("m", "application/octet-stream");
            long size = d.readLong();
            if (size < 0 || size != f.optLong("s", -1)) throw new IOException("Размер файла не совпадает с манифестом");
            st.currentFile = path;
            st.notifyChanged(true);
            File pDir = new File(ctx.getCacheDir(), "relay_partial");
            pDir.mkdirs();
            File tmp = new File(pDir, "relay_" + i + ".part");
            CRC32 crc = new CRC32();
            try (OutputStream os = new BufferedOutputStream(new FileOutputStream(tmp), 64 * 1024)) {
                long left = size;
                while (left > 0) {
                    int n = d.read(buf, 0, (int) Math.min(buf.length, left));
                    if (n == -1) throw new IOException("Обрыв потока");
                    os.write(buf, 0, n);
                    crc.update(buf, 0, n);
                    left -= n;
                    st.transferred += n;
                    if (total > 0) {
                        st.progress = Math.min(1f, (float) ((double) st.transferred / total));
                    }
                    long nowMs = System.currentTimeMillis();
                    if (nowMs - lastProgReport > 700) {
                        lastProgReport = nowMs;
                        final long g = st.transferred, tt = total;
                        new Thread(() -> reportProgress(session, g, tt), "glink-prog").start();
                    }
                    st.notifyChanged(true);
                }
            }
            long wantCrc = d.readLong();
            if (wantCrc != crc.getValue()) throw new IOException("CRC не сошлась");
            ReceiveStore.Out pub = store.open(path, mime);
            try {
                try (InputStream fin = new FileInputStream(tmp); OutputStream output = pub.stream) {
                    int n;
                    while ((n = fin.read(buf)) != -1) output.write(buf, 0, n);
                }
                store.finish(pub.uri);
            } catch (Exception e) {
                try { pub.stream.close(); } catch (Throwable ignored) { }
                store.delete(pub.uri);
                throw e;
            }
            if (path.toLowerCase().endsWith(".apk")) st.receivedApkUri = pub.uri.toString();
            tmp.delete();
            synchronized (st.lastReceived) {
                st.lastReceived.add(path);
                st.lastReceivedUris.add(pub.uri.toString());
            }
            st.filesDone++;
            st.notifyChanged(true);
        }
        // Authenticate the terminal frame before acknowledging/deleting the relay copy.
        if (d.read() != -1) throw new IOException("Лишние данные после файлов");
        return true;
    }

    // ------------------------------------------------------------------
    // ШИФР: GrapeShift-стиль. Заголовок GSENC1 + соль; ключ = SHA-256(key||salt);
    // дальше кадры AES-GCM по 64 КБ.

    private static SecretKeySpec keyFor(byte[] keyRaw, byte[] salt) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(keyRaw);
        md.update(salt);
        return new SecretKeySpec(md.digest(), "AES");
    }

    private static final class EncryptSink implements AutoCloseable {
        private final OutputStream out;
        private final SecretKeySpec key;
        private final SecureRandom rnd = new SecureRandom();
        private final ByteArrayOutputStream pending = new ByteArrayOutputStream();

        EncryptSink(OutputStream out, byte[] keyRaw) throws Exception {
            this.out = out;
            byte[] salt = new byte[16];
            rnd.nextBytes(salt);
            this.key = keyFor(keyRaw, salt);
            out.write(MAGIC.getBytes(StandardCharsets.US_ASCII));
            out.write(salt);
        }

        void write(byte[] b, int off, int len) throws Exception {
            pending.write(b, off, len);
            while (pending.size() >= CHUNK) {
                byte[] all = pending.toByteArray();
                emit(all, 0, CHUNK);
                pending.reset();
                pending.write(all, CHUNK, all.length - CHUNK);
            }
        }

        void finish() throws Exception {
            byte[] rest = pending.toByteArray();
            if (rest.length > 0) emit(rest, 0, rest.length);
            pending.reset();
            // терминальный пустой кадр
            emit(new byte[0], 0, 0);
            out.flush();
            out.close();
        }

        @Override public void close() throws IOException { out.close(); }

        private void emit(byte[] b, int off, int len) throws Exception {
            byte[] iv = new byte[12];
            rnd.nextBytes(iv);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
            byte[] ct = c.doFinal(b, off, len);
            int frameLen = iv.length + ct.length;
            out.write((frameLen >> 24) & 0xFF);
            out.write((frameLen >> 16) & 0xFF);
            out.write((frameLen >> 8) & 0xFF);
            out.write(frameLen & 0xFF);
            out.write(iv);
            out.write(ct);
        }
    }

    private static final class DecryptStream extends InputStream {
        private final DataInputStream in;
        private final SecretKeySpec key;
        private byte[] plain = new byte[0];
        private int pos = 0;
        private boolean eof = false;

        DecryptStream(InputStream raw, byte[] keyRaw) throws Exception {
            this.in = new DataInputStream(raw);
            byte[] magic = StreamCompat.readExactly(in, 6);
            if (!MAGIC.equals(new String(magic, StandardCharsets.US_ASCII))) {
                throw new IOException("Не GSENC1");
            }
            byte[] salt = StreamCompat.readExactly(in, 16);
            this.key = keyFor(keyRaw, salt);
        }

        private boolean nextFrame() throws IOException {
            if (eof) return false;
            int len;
            try { len = in.readInt(); }
            catch (IOException e) { throw new IOException("Нет завершающего кадра GSENC1", e); }
            if (len < 28 || len > CHUNK + 64) throw new IOException("Кадр битый");
            byte[] frame = StreamCompat.readExactly(in, len);
            if (frame.length != len) throw new IOException("Обрыв кадра");
            byte[] iv = new byte[12];
            System.arraycopy(frame, 0, iv, 0, 12);
            try {
                Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
                plain = c.doFinal(frame, 12, frame.length - 12);
            } catch (Exception e) {
                throw new IOException("Расшифровка не удалась (ключ?)");
            }
            pos = 0;
            if (plain.length == 0) {
                if (in.read() != -1) throw new IOException("Лишние данные после GSENC1");
                eof = true;
                return false;
            }
            return true;
        }

        @Override
        public int read() throws IOException {
            byte[] one = new byte[1];
            int n = read(one, 0, 1);
            return n == -1 ? -1 : one[0] & 0xFF;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            while (pos >= plain.length) {
                if (!nextFrame()) return -1;
            }
            int n = Math.min(len, plain.length - pos);
            System.arraycopy(plain, pos, b, off, n);
            pos += n;
            return n;
        }
    }
}
