package com.prilozhi.app.identity;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;
import com.prilozhi.app.net.SealedOffer;
import com.prilozhi.app.net.StreamCompat;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;

/** ECDH transport key encrypted at rest by a non-exportable Android Keystore AES key. */
public final class TransportIdentity {
    private static final String ALIAS = "glink_wifi_transport_wrap_v2";
    private static final String FILE = "glink_wifi_transport_v2.json";
    private static KeyPair cached;
    private TransportIdentity() {}

    public static synchronized KeyPair get(Context ctx) throws Exception {
        if (cached != null) return cached;
        File path = new File(ctx.getNoBackupFilesDir(), FILE);
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        SecretKey master = (SecretKey) store.getKey(ALIAS, null);
        if (master == null) {
            if (path.exists()) throw new IllegalStateException("Ключ хранилища недоступен");
            KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            gen.init(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256).build());
            master = gen.generateKey();
        }
        if (path.exists()) {
            byte[] bytes;
            try (FileInputStream f = new FileInputStream(path)) { bytes = StreamCompat.readAll(f, 8192); }
            JSONObject o = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
            byte[] pub = SealedOffer.unb64(o.getString("pub"));
            byte[] iv = SealedOffer.unb64(o.getString("iv"));
            byte[] encrypted = SealedOffer.unb64(o.getString("enc"));
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, master, new GCMParameterSpec(128, iv));
            c.updateAAD(pub);
            byte[] privateDer = c.doFinal(encrypted);
            try {
                KeyFactory kf = KeyFactory.getInstance("EC");
                cached = new KeyPair(kf.generatePublic(new X509EncodedKeySpec(pub)),
                        kf.generatePrivate(new PKCS8EncodedKeySpec(privateDer)));
            } finally { java.util.Arrays.fill(privateDer, (byte) 0); }
            return cached;
        }
        KeyPair pair = SealedOffer.newTransportKey();
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, master);
        c.updateAAD(pair.getPublic().getEncoded());
        byte[] privateDer = pair.getPrivate().getEncoded();
        byte[] encrypted;
        try { encrypted = c.doFinal(privateDer); }
        finally { java.util.Arrays.fill(privateDer, (byte) 0); }
        JSONObject o = new JSONObject().put("v", 2).put("pub", SealedOffer.b64(pair.getPublic().getEncoded()))
                .put("iv", SealedOffer.b64(c.getIV())).put("enc", SealedOffer.b64(encrypted));
        AtomicFile file = new AtomicFile(path);
        FileOutputStream out = null;
        try {
            out = file.startWrite();
            out.write(o.toString().getBytes(StandardCharsets.UTF_8));
            file.finishWrite(out);
        } catch (Exception ex) {
            if (out != null) file.failWrite(out);
            throw ex;
        }
        cached = pair;
        return cached;
    }
}
