'use strict';
/* Optional direct TLS transport for networks where a normal ClientHello stalls.
   It only changes TLS record framing, never TLS validation, SNI or application
   data. A short initial record is followed by the rest of the same ClientHello;
   subsequent encrypted bytes are passed through unchanged. */
const { Duplex } = require('node:stream');
const net = require('node:net');
const tls = require('node:tls');
const https = require('node:https');

class HelloFragmentStream extends Duplex {
  constructor(socket, onFragment = () => {}) {
    super();
    this.socket = socket; this.onFragment = onFragment;
    this.first = Buffer.alloc(0); this.firstDone = false;
    this.partialTimer = null; this.delayTimer = null; this.pending = null;
    socket.on('data', chunk => { if (!this.push(chunk)) socket.pause(); });
    socket.on('end', () => this.push(null));
    socket.on('error', error => this.destroy(error));
    socket.on('close', () => { if (!this.destroyed) this.destroy(); });
    socket.on('connect', () => this.emit('connect'));
    socket.setNoDelay(true);
  }
  _read() { this.socket.resume(); }
  _flushPartialLater() {
    if (this.partialTimer) return;
    this.partialTimer = setTimeout(() => {
      this.partialTimer = null;
      if (this.firstDone || this.destroyed || !this.first.length) return;
      this.firstDone = true;
      const bytes = this.first; this.first = Buffer.alloc(0);
      this.socket.write(bytes);
    }, 60);
    this.partialTimer.unref();
  }
  _write(chunk, encoding, callback) {
    if (this.firstDone) return this.socket.write(chunk, encoding, callback);
    this.first = Buffer.concat([this.first, chunk]);
    if (this.first.length < 5) { this._flushPartialLater(); callback(); return; }
    const length = this.first.readUInt16BE(3);
    if (this.first[0] !== 22 || this.first[1] !== 3 || length < 8 || length > 16384 || this.first.length > 65536) {
      this.firstDone = true; clearTimeout(this.partialTimer); this.partialTimer = null;
      const bytes = this.first; this.first = Buffer.alloc(0);
      this.socket.write(bytes, callback); return;
    }
    if (this.first.length < 5 + length) { this._flushPartialLater(); callback(); return; }
    this.firstDone = true; clearTimeout(this.partialTimer); this.partialTimer = null;
    const original = this.first; this.first = Buffer.alloc(0);
    if (original[5] !== 1) { this.socket.write(original, callback); return; }
    const hello = original.subarray(5, 5 + length), tail = original.subarray(5 + length), split = 5;
    const firstHeader = Buffer.from(original.subarray(0, 5)), secondHeader = Buffer.from(firstHeader);
    firstHeader.writeUInt16BE(split, 3); secondHeader.writeUInt16BE(hello.length - split, 3);
    const first = Buffer.concat([firstHeader, hello.subarray(0, split)]);
    const rest = Buffer.concat([secondHeader, hello.subarray(split), tail]);
    let finished = false;
    const complete = error => {
      if (finished) return; finished = true;
      if (this.pending === complete) this.pending = null;
      callback(error);
    };
    this.pending = complete;
    this.socket.write(first, error => {
      if (finished) return;
      if (error) { complete(error); return; }
      try { this.onFragment(); } catch (_) { /* callback is diagnostic only */ }
      this.delayTimer = setTimeout(() => {
        this.delayTimer = null;
        if (this.destroyed) { complete(Error('transport_closed')); return; }
        this.socket.write(rest, complete);
      }, 15);
      this.delayTimer.unref();
    });
  }
  _final(callback) { this.socket.end(callback); }
  _destroy(error, callback) {
    clearTimeout(this.partialTimer); clearTimeout(this.delayTimer);
    this.partialTimer = null; this.delayTimer = null;
    if (this.pending) this.pending(error || Error('transport_closed'));
    this.socket.destroy(); callback(error);
  }
}

function fragmentedTlsAgent(onFragment) {
  const agent = new https.Agent({ keepAlive:false, maxSockets:1 });
  agent.createConnection = options => {
    const host = options.hostname || options.host;
    const raw = net.connect({ host, port:options.port || 443, lookup:options.lookup,
      family:options.family, localAddress:options.localAddress, autoSelectFamily:options.autoSelectFamily });
    const transport = new HelloFragmentStream(raw, onFragment);
    const servername = options.servername || (net.isIP(host) ? undefined : host);
    return tls.connect({ ...options, socket:transport, servername, rejectUnauthorized:true });
  };
  return agent;
}
module.exports = { HelloFragmentStream, fragmentedTlsAgent };
