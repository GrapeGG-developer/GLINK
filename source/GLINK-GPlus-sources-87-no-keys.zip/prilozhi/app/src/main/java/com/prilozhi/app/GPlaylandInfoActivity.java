package com.prilozhi.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Offline, honest availability page. There are deliberately no download URLs yet. */
public final class GPlaylandInfoActivity extends Activity {
    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable result = new GradientDrawable();
        result.setColor(color);
        result.setCornerRadius(dp(radius));
        return result;
    }

    private TextView text(String value, float size, int color) {
        TextView result = new TextView(this);
        result.setText(value);
        result.setTextSize(size);
        result.setTextColor(color);
        result.setGravity(Gravity.CENTER_VERTICAL);
        return result;
    }

    private void marginTop(LinearLayout parent, View child, int topDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(topDp);
        parent.addView(child, params);
    }

    private View platformCard(String platform, String tag) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        card.setBackground(rounded(Color.WHITE, 18));
        card.setTag(tag);
        card.setClickable(false);

        TextView title = text(platform, 19, 0xFF302B57);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.addView(title);
        TextView state = text("EXP · только телефон", 15, 0xFFE08A1A);
        state.setTag(tag + "_status");
        marginTop(card, state, 4);
        TextView explanation = text("Клиент Windows отменён. APK PLAYLAND в GLINK пока не вложен.", 13, 0xFF66617C);
        marginTop(card, explanation, 6);
        return card;
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window window = getWindow();
        window.setStatusBarColor(0xFF5046AD);
        window.setNavigationBarColor(0xFF5046AD);
        window.getDecorView().setSystemUiVisibility(0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFFF4F3FD);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(22), dp(24), dp(22), dp(28));
        scroll.addView(body, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.linker_gplayland);
        icon.setContentDescription(null);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(64), dp(64));
        body.addView(icon, iconParams);
        TextView title = text("gPLAYLANDg", 30, 0xFF38316D);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        marginTop(body, title, 14);
        TextView subtitle = text("PLAYLAND · игры и создание миров", 16, 0xFF6158B0);
        marginTop(body, subtitle, 5);

        TextView badge = text("EXP", 14, 0xFFFFFFFF);
        badge.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(14), dp(7), dp(14), dp(7));
        badge.setBackground(rounded(0xFFE08A1A, 15));
        badge.setTag("gplayland_status");
        LinearLayout.LayoutParams badgeParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        badgeParams.topMargin = dp(16);
        body.addView(badge, badgeParams);

        TextView intro = text("Хобби-EXP только для телефона, не выпуск. Клиента Windows нет и не будет.", 15, 0xFF514C69);
        marginTop(body, intro, 16);
        marginTop(body, platformCard("Android", "gplayland_android"), 18);
        TextView note = text("Установочный APK в эту плитку ещё не вложен — без выдуманной ссылки.", 13, 0xFF716C87);
        marginTop(body, note, 18);
        Button back = new Button(this);
        back.setText("Вернуться в GLINK");
        back.setTextColor(Color.WHITE);
        back.setAllCaps(false);
        back.setMinHeight(dp(48));
        back.setBackground(rounded(0xFF655BD5, 14));
        back.setTag("gplayland_back");
        back.setOnClickListener(v -> finish());
        marginTop(body, back, 22);
        setContentView(scroll);
    }
}
