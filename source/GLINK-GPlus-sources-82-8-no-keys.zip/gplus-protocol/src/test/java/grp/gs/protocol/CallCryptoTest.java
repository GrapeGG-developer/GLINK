package grp.gs.protocol;
import org.junit.Test;import java.security.KeyPair;import java.util.Arrays;import java.util.concurrent.*;import static org.junit.Assert.*;
public class CallCryptoTest {
 private static final String ALICE="abcd-efgh-ijkl-mnop",BOB="ABCD-EFGH-IJKL-MNOP",CALL="AAAAAAAAAAAAAAAAAAAAAA";
 @Test public void ephemeralPeersExchangeAndAuthenticateFrames()throws Exception{
  KeyPair a=CallCrypto.ephemeral(),b=CallCrypto.ephemeral();String chat=Protocol.directChat(ALICE,BOB);CallCrypto.Session x=CallCrypto.derive(a,b.getPublic().getEncoded(),true,chat,CALL,ALICE,BOB),y=CallCrypto.derive(b,a.getPublic().getEncoded(),false,chat,CALL,ALICE,BOB);
  try{byte[] audio={1,2,3,4},raw=x.seal(CallCrypto.AUDIO,123,audio);assertFalse(Arrays.equals(audio,raw));CallCrypto.Packet decoded=y.open(raw);assertEquals(CallCrypto.AUDIO,decoded.kind);assertEquals(123,decoded.timestamp);assertArrayEquals(audio,decoded.payload);try{y.open(raw);fail("replay accepted");}catch(SecurityException expected){}
   byte[] reply=y.seal(CallCrypto.VIDEO,456,new byte[]{7,8,9});assertArrayEquals(new byte[]{7,8,9},x.open(reply).payload);
   byte[] forged=x.seal(CallCrypto.AUDIO,124,new byte[]{5});byte[] changed=forged.clone();changed[changed.length-1]^=1;try{y.open(changed);fail("tampering accepted");}catch(Exception expected){}assertArrayEquals(new byte[]{5},y.open(forged).payload);
   byte[] wrongDirection=x.seal(CallCrypto.CONTROL,1,new byte[]{2});try{x.open(wrongDirection);fail("direction accepted");}catch(Exception expected){}
   try{CallCrypto.derive(a,b.getPublic().getEncoded(),true,chat,"BBBBBBBBBBBBBBBBBBBBBB",ALICE,ALICE);fail();}catch(SecurityException expected){}
  }finally{x.close();y.close();}try{x.seal(CallCrypto.AUDIO,1,new byte[0]);fail();}catch(SecurityException expected){}
 }
 @Test public void distinctSessionsAndCallContextsCannotDecryptEachOther()throws Exception{
  KeyPair a=CallCrypto.ephemeral(),b=CallCrypto.ephemeral(),c=CallCrypto.ephemeral();String chat=Protocol.directChat(ALICE,BOB);try(CallCrypto.Session sender=CallCrypto.derive(a,b.getPublic().getEncoded(),true,chat,CALL,ALICE,BOB);CallCrypto.Session other=CallCrypto.derive(c,a.getPublic().getEncoded(),false,chat,CALL,ALICE,BOB);CallCrypto.Session differentCall=CallCrypto.derive(b,a.getPublic().getEncoded(),false,chat,"BBBBBBBBBBBBBBBBBBBBBB",ALICE,BOB)){
   byte[] frame=sender.seal(CallCrypto.AUDIO,1,new byte[]{42});try{other.open(frame);fail();}catch(Exception expected){}try{differentCall.open(frame);fail();}catch(Exception expected){}
  }
 }
 @Test public void rejectsWrongCurveMalformedAndOversizedFrames()throws Exception{
  KeyPair a=CallCrypto.ephemeral(),b=CallCrypto.ephemeral();String chat=Protocol.directChat(ALICE,BOB);java.security.KeyPairGenerator generator=java.security.KeyPairGenerator.getInstance("EC");generator.initialize(new java.security.spec.ECGenParameterSpec("secp384r1"));KeyPair wrong=generator.generateKeyPair();
  try{CallCrypto.derive(a,wrong.getPublic().getEncoded(),true,chat,CALL,ALICE,BOB);fail();}catch(Exception expected){}try{CallCrypto.derive(a,new byte[90],true,chat,CALL,ALICE,BOB);fail();}catch(Exception expected){}
  try(CallCrypto.Session x=CallCrypto.derive(a,b.getPublic().getEncoded(),true,chat,CALL,ALICE,BOB);CallCrypto.Session y=CallCrypto.derive(b,a.getPublic().getEncoded(),false,chat,CALL,ALICE,BOB)){try{x.seal(CallCrypto.AUDIO,0,new byte[CallCrypto.MAX_PAYLOAD+1]);fail();}catch(SecurityException expected){}byte[] valid=x.seal(CallCrypto.AUDIO,0,new byte[10]);for(int length:new int[]{0,1,20,valid.length-1}){try{y.open(Arrays.copyOf(valid,length));fail();}catch(Exception expected){}}assertEquals(10,y.open(valid).payload.length);}
 }
 @Test public void concurrentSendersNeverReuseSequence()throws Exception{
  KeyPair a=CallCrypto.ephemeral(),b=CallCrypto.ephemeral();String chat=Protocol.directChat(ALICE,BOB);try(CallCrypto.Session s=CallCrypto.derive(a,b.getPublic().getEncoded(),true,chat,CALL,ALICE,BOB)){
   ExecutorService workers=Executors.newFixedThreadPool(4);try{java.util.Set<Long> seqs=java.util.concurrent.ConcurrentHashMap.newKeySet();java.util.List<Future<?>> jobs=new java.util.ArrayList<>();for(int i=0;i<100;i++)jobs.add(workers.submit(()->{try{byte[] x=s.seal(CallCrypto.AUDIO,0,new byte[1]);long sequence=java.nio.ByteBuffer.wrap(x,5,8).getLong();if(!seqs.add(sequence))throw new AssertionError("nonce reused");}catch(Exception e){throw new RuntimeException(e);}}));for(Future<?> f:jobs)f.get();assertEquals(100,seqs.size());}finally{workers.shutdownNow();}
  }
 }
}
