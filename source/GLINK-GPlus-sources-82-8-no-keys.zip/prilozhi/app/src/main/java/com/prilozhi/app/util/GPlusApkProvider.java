package com.prilozhi.app.util;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

/** Private, read-only URI granted to the system installer for a verified G+ APK. */
public final class GPlusApkProvider extends ContentProvider {
    @Override public boolean onCreate(){return true;}
    private File checked(Uri uri)throws FileNotFoundException{
        if(getContext()==null||uri==null||!"content".equals(uri.getScheme())||!(getContext().getPackageName()+".gplus-installer").equals(uri.getAuthority())
                ||uri.getQuery()!=null||uri.getFragment()!=null)throw new FileNotFoundException("Invalid APK URI");
        List<String> parts=uri.getPathSegments();if(parts.size()!=2||!"apk".equals(parts.get(0))||!GPlusDownload.validName(parts.get(1)))throw new FileNotFoundException("Invalid APK URI");
        File dir=GPlusDownload.directory(getContext()),file=new File(dir,parts.get(1));
        try{if(!dir.getCanonicalPath().equals(file.getCanonicalFile().getParent())||!file.isFile())throw new FileNotFoundException("APK missing");}
        catch(java.io.IOException e){throw new FileNotFoundException("APK unavailable");}return file;
    }
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{
        if(!"r".equals(mode))throw new FileNotFoundException("Read only");return ParcelFileDescriptor.open(checked(uri),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public String getType(Uri uri){try{checked(uri);return "application/vnd.android.package-archive";}catch(Exception e){return null;}}
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order){
        try{File f=checked(uri);String[] cols=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor c=new MatrixCursor(cols,1);Object[] row=new Object[cols.length];for(int i=0;i<cols.length;i++){
                if(OpenableColumns.DISPLAY_NAME.equals(cols[i]))row[i]=f.getName();else if(OpenableColumns.SIZE.equals(cols[i]))row[i]=f.length();
            }c.addRow(row);return c;
        }catch(Exception e){return null;}
    }
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException("Read only");}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] args){throw new UnsupportedOperationException("Read only");}
    @Override public int delete(Uri uri,String selection,String[] args){throw new UnsupportedOperationException("Read only");}
}
