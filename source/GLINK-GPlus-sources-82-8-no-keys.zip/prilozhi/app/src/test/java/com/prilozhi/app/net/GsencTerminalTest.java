package com.prilozhi.app.net;

import org.junit.Test;
import java.io.*;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import static org.junit.Assert.*;

public class GsencTerminalTest {
    private static byte[] encrypt(byte[] data,byte[] key) throws Exception {
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        Class<?> c=Class.forName("com.prilozhi.app.net.RelayTransfer$EncryptSink");
        Constructor<?> ctor=c.getDeclaredConstructor(OutputStream.class,byte[].class);ctor.setAccessible(true);
        Object sink=ctor.newInstance(out,key);
        Method write=c.getDeclaredMethod("write",byte[].class,int.class,int.class);write.setAccessible(true);
        Method finish=c.getDeclaredMethod("finish");finish.setAccessible(true);
        write.invoke(sink,data,0,data.length);finish.invoke(sink);return out.toByteArray();
    }
    private static InputStream decrypt(byte[] cipher,byte[] key) throws Exception {
        Class<?> c=Class.forName("com.prilozhi.app.net.RelayTransfer$DecryptStream");
        Constructor<?> ctor=c.getDeclaredConstructor(InputStream.class,byte[].class);ctor.setAccessible(true);
        return (InputStream)ctor.newInstance(new ByteArrayInputStream(cipher),key);
    }
    private static byte[] drain(InputStream in) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[1024];int n;
        while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();
    }
    private static void rejected(byte[] c,byte[] key) throws Exception {
        try { drain(decrypt(c,key));fail("corrupt GSENC1 accepted"); } catch(IOException expected) { }
    }
    @Test public void terminalIsRequiredAuthenticatedAndMustBeFinal() throws Exception {
        byte[] key=new byte[32];Arrays.fill(key,(byte)0x51);
        byte[] data="synthetic file payload".getBytes(StandardCharsets.UTF_8), c=encrypt(data,key);
        assertArrayEquals(data,drain(decrypt(c,key)));
        rejected(Arrays.copyOf(c,c.length-32),key); // complete data, missing terminal frame
        byte[] extra=Arrays.copyOf(c,c.length+1);extra[extra.length-1]=1;rejected(extra,key);
        byte[] tampered=c.clone();tampered[tampered.length-2]^=1;rejected(tampered,key);
        byte[] truncated=Arrays.copyOf(c,c.length-1);rejected(truncated,key);
    }
}
