'use strict';
const {createAuth}=require('./auth');const {createMessages}=require('./messages');const {createAssets}=require('./assets');const {createCallRelay}=require('./call-relay');
/** Mount before body parsers and SPA fallback. Single process only. */
function createGPlus({dataDir,maxStorageBytes=0,reserveBytes=0}={}){
 const auth=createAuth({dataDir});
 const messages=createMessages({dataDir,authenticate:auth.authenticate,lookup:auth.lookup});
 const assets=createAssets({dataDir,authenticate:auth.authenticate,isMember:messages.isMember,maxStorageBytes,reserveBytes});
 const calls=createCallRelay({authenticate:auth.authenticate,isDirectMember:messages.isDirectMember});
 // Only explicitly disappearing messages are expired; no cleanup of ordinary history/media.
 const sweep=setInterval(()=>{try{messages.purgeExpired();}catch(e){console.error('G+ expiry cleanup:',e.message);}},60000);sweep.unref();
 let activeOperations=0;
 const handler=function(req,res,next){
  activeOperations++;
  Promise.resolve().then(()=>assets(req,res,()=>messages(req,res,()=>auth(req,res,next)))).catch(e=>{
   console.error('G+ request error:',e.message);if(!res.headersSent){res.writeHead(500,{'content-type':'application/json'});res.end('{"error":"internal_error"}');}else res.destroy();
  }).finally(()=>{activeOperations--;});
 };
 handler.pendingOperations=()=>activeOperations+assets.pendingWrites();
 handler.handleUpgrade=calls.handleUpgrade;handler.closeCalls=()=>calls.close();
 handler.close=()=>{clearInterval(sweep);calls.close();assets.close();messages.close();};return handler;
}
module.exports={createGPlus};
