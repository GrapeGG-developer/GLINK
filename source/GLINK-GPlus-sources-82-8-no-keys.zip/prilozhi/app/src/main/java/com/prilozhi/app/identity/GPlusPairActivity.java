package com.prilozhi.app.identity;

import android.app.Activity;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.widget.Toast;
import com.prilozhi.app.MainActivity;
import com.prilozhi.app.util.State;

/** Only the same-signature G+ application may start this activity. */
public final class GPlusPairActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        NfcAdapter adapter=NfcAdapter.getDefaultAdapter(this);
        if(adapter==null || !adapter.isEnabled()) { Toast.makeText(this,"Включите NFC для знакомства G+",Toast.LENGTH_LONG).show();finish();return; }
        new Thread(() -> {
            try {
                if(GPlusNfcStore.own(getApplicationContext())==null)throw new IllegalStateException("missing contact card");
                GPlusNfcStore.begin();State.get().notifyChanged();
                runOnUiThread(() -> {
                    Toast.makeText(this,"Приложите телефоны для добавления контакта G+",Toast.LENGTH_LONG).show();
                    Intent i=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(i);finish();
                });
            } catch(Exception e) {runOnUiThread(() -> {Toast.makeText(this,"Сначала откройте G+ и подключите профиль",Toast.LENGTH_LONG).show();finish();});}
        },"gplus-nfc-start").start();
    }
}
