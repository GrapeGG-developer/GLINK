// ============================================================
// GLINK RELAY — временное файловое реле и Wi-Fi v2 для GLINK 2.8+.
// Подключить до JSON-parser и SPA catch-all: app.use(require('./glink-relay')).
// Рядом обязательны glink-device-v2.js, glink-send.html, glink-crypto-v2.js,
// glink-send-v2.js; см. README. Хранилище временное, это не история G+.
// Сервер v2 отклоняет открытые ключи старых Wi-Fi-клиентов.
// Без проверки публичного ключа пользователем доверие к обнаружению ограничено.
// ============================================================
const fs = require('fs');
const path = require('path');

const DIR = process.env.GLINK_RELAY_DIR || path.join(__dirname, 'glink-data');
const TTL_MS = 60 * 60 * 1000;
const ASSEMBLING = new Set(); // 1 час
let ACTIVE_WRITES = 0;
function trackWrite() { ACTIVE_WRITES++; let finished = false; return () => { if (!finished) { finished = true; ACTIVE_WRITES--; } }; }
try { fs.mkdirSync(DIR, { recursive: true }); } catch (e) {}

function setExpiry(file, hours) {
  const h = [1, 6, 24].includes(hours) ? hours : 1;
  try { fs.writeFileSync(file + '.ttl.json', JSON.stringify({ exp: Date.now() + h * 3600 * 1000 })); } catch (e) {}
}
function expiry(file) {
  try {
    const t = JSON.parse(fs.readFileSync(file + '.ttl.json', 'utf8'));
    return Number.isSafeInteger(t.exp) && t.exp > 0 ? t.exp : null;
  } catch (e) { return null; }
}
function isExpired(file) { const exp = expiry(file); return exp !== null && Date.now() > exp; }
function purge(file) {
  try { fs.unlinkSync(file); } catch (e) {}
  try { fs.unlinkSync(file + '.prog.json'); } catch (e) {}
  try { fs.unlinkSync(file + '.ttl.json'); } catch (e) {}
  try { fs.rmSync(file + '.parts', { recursive: true, force: true }); } catch (e) {}
}

function fileFor(token) {
  if (!/^[a-zA-Z0-9_-]{6,64}$/.test(token)) return null;
  return path.join(DIR, token + '.bin');
}

function sweep() {
  try {
    const now = Date.now();
    for (const name of fs.readdirSync(DIR)) {
      const p = path.join(DIR, name);
      try {
        // The durable encrypted offer queue is not a temporary file.
        if (name === 'wifi-offers-v2.json') continue;
        const st = fs.statSync(p);
        if (name.startsWith('wifi-offers-v2.json.tmp-')) { if (now - st.mtimeMs > TTL_MS) fs.rmSync(p, { force: true }); continue; }
        if (name.endsWith('.bin')) {
          const exp = expiry(p);
          if (!ACTIVE_WRITES && !ASSEMBLING.has(p) && ((exp !== null && now > exp) || (exp === null && now - st.mtimeMs > TTL_MS))) purge(p);
          continue;
        }
        // Metadata/parts follow their payload's configured TTL. Never clean an
        // active upload or assembly out from under its writer.
        const match = name.match(/^(.*\.bin)\.(?:parts|prog\.json|ttl\.json)$/);
        if (match) {
          const file = path.join(DIR, match[1]), exp = expiry(file);
          if (!ACTIVE_WRITES && !ASSEMBLING.has(file) && ((exp !== null && now > exp) || (exp === null && now - st.mtimeMs > TTL_MS))) purge(file);
          continue;
        }
        if (!ACTIVE_WRITES && now - st.mtimeMs > TTL_MS) fs.rmSync(p, { recursive: true, force: true });
      } catch (e) {}
    }
  } catch (e) {}
}
// GSERVER freezes the writer and suspends cleanup while a consistent snapshot is copied.
let relayFrozen = process.env.GSERVER_CONTROLLED === '1';
setInterval(() => { if (!relayFrozen) sweep(); }, 10 * 60 * 1000).unref();
if (!relayFrozen) sweep();

// Wi-Fi v2 accepts only encrypted offers and authenticates recipient polling.
const deviceV2 = require('./glink-device-v2');
const GLINK_SEND_PAGE = fs.readFileSync(path.join(__dirname, 'glink-send.html'), 'utf8');
const GLINK_CRYPTO_JS = fs.readFileSync(path.join(__dirname, 'glink-crypto-v2.js'), 'utf8');
const GLINK_SEND_JS = fs.readFileSync(path.join(__dirname, 'glink-send-v2.js'), 'utf8');

module.exports = function glinkRelay(req, res, next) {
  if (deviceV2.handle(req, res)) return;
  if (req.url === '/glink/crypto-v2.js' || req.url === '/glink/send-v2.js') {
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    return res.end(req.url === '/glink/crypto-v2.js' ? GLINK_CRYPTO_JS : GLINK_SEND_JS);
  }
  if (req.url === '/glink/send' || req.url.startsWith('/glink/send?')) {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    return res.end(GLINK_SEND_PAGE);
  }
  const m = req.url.match(/^\/glink\/(up|meta|dl|done|prog|chunk|chunks|get|ttl)\/([a-zA-Z0-9_-]{6,64})/);
  if (!m) return next();
  const op = m[1];
  const file = fileFor(m[2]);
  if (!file) { res.statusCode = 400; return res.end('bad token'); }

  if (op === 'get') {
    res.statusCode = 410;
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    return res.end('Public GLINK links were removed; use NFC or a v2 device offer.');
  }

  if (op === 'up' && req.method === 'POST') {
    const ttlH = parseInt(new URL(req.url, 'http://localhost').searchParams.get('ttl') || '1', 10);
    setExpiry(file, ttlH);
    const tmp = file + '.tmp';
    const done = trackWrite();
    const out = fs.createWriteStream(tmp);
    req.pipe(out);
    req.on('aborted', () => out.destroy(new Error('request aborted')));
    req.on('error', () => out.destroy(new Error('request error')));
    out.on('finish', () => {
      try { fs.renameSync(tmp, file); } catch (e) { done(); res.statusCode = 500; return res.end('write error'); }
      done();
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ ok: true }));
    });
    out.on('error', () => { try { fs.unlinkSync(tmp); } catch (e) {} done(); if (!res.destroyed) { res.statusCode = 500; res.end('write error'); } });
    return;
  }

  // --- Докачка загрузки: части по 4 МБ, сборка по готовности ---
  if (op === 'chunks') {
    const dir = file + '.parts';
    fs.readdir(dir, (err, names) => {
      const have = err ? [] : names.filter(n => /^\d+$/.test(n)).map(n => parseInt(n, 10));
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ have }));
    });
    return;
  }

  if (op === 'chunk' && req.method === 'POST') {
    const q = new URL(req.url, 'http://localhost').searchParams;
    if (q.get('ttl')) setExpiry(file, parseInt(q.get('ttl'), 10));
    const idx = parseInt(q.get('i') || '-1', 10);
    const count = parseInt(q.get('n') || '0', 10);
    if (idx < 0 || count <= 0 || idx >= count) { res.statusCode = 400; return res.end('bad chunk'); }
    const dir = file + '.parts';
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) {}
    // АТОМАРНО: пишем во временное имя, публикуем часть только rename'ом,
    // иначе параллельная сборка хватала недописанные части и файл был битым
    const part = path.join(dir, String(idx) + '.tmp-' + Math.random().toString(36).slice(2, 9));
    const done = trackWrite();
    const out = fs.createWriteStream(part);
    req.pipe(out);
    req.on('aborted', () => out.destroy(new Error('request aborted')));
    req.on('error', () => out.destroy(new Error('request error')));
    out.on('error', () => { try { fs.unlinkSync(part); } catch (e) {} done(); if (!res.destroyed) { res.statusCode = 500; res.end('write error'); } });
    out.on('finish', () => {
      try { fs.renameSync(part, path.join(dir, String(idx))); } catch (e) { done(); res.statusCode = 500; return res.end('write error'); }
      fs.readdir(dir, (err, names) => {
        const have = err ? [] : names.filter(n => /^\d+$/.test(n)).map(n => parseInt(n, 10));
        const allHere = have.length >= count
          && Array.from({ length: count }, (_, i) => i).every(i => have.includes(i));
        if (allHere && !ASSEMBLING.has(file)) {
          ASSEMBLING.add(file);
          // все части на месте — собираем файл по порядку
          const finalTmp = file + '.assemble';
          const ws = fs.createWriteStream(finalTmp);
          ws.on('error', () => { ASSEMBLING.delete(file); done(); if (!res.destroyed) { res.statusCode = 500; res.end('assembly error'); } });
          let cur = 0;
          const pump = () => {
            if (cur >= count) {
              ws.end(() => {
                ASSEMBLING.delete(file);
                try { fs.renameSync(finalTmp, file); } catch (e) { done(); res.statusCode = 500; return res.end('assembly error'); }
                try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) {}
                done();
                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify({ ok: true, assembled: true }));
              });
              return;
            }
            const rs = fs.createReadStream(path.join(dir, String(cur++)));
            rs.on('end', pump);
            rs.on('error', () => { ASSEMBLING.delete(file); ws.destroy(); done(); if (!res.destroyed) { res.statusCode = 500; res.end('read error'); } });
            rs.pipe(ws, { end: false });
          };
          pump();
        } else {
          done();
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ ok: true, have: have.length }));
        }
      });
    });
    return;
  }

  if (op === 'ttl' && req.method === 'POST') {
    const h = parseInt(new URL(req.url, 'http://localhost').searchParams.get('h') || '1', 10);
    setExpiry(file, h);
    res.setHeader('Content-Type', 'application/json');
    return res.end(JSON.stringify({ ok: true, hours: [1, 6, 24].includes(h) ? h : 1 }));
  }

  if ((op === 'meta' || op === 'dl' || op === 'get') && isExpired(file)) {
    purge(file);
    res.statusCode = 404;
    return res.end('expired');
  }

  if (op === 'meta') {
    fs.stat(file, (err, st) => {
      if (err) { res.statusCode = 404; return res.end('not ready'); }
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ size: st.size }));
    });
    return;
  }

  if (op === 'dl') {
    fs.stat(file, (err, st) => {
      if (err) { res.statusCode = 404; return res.end('not ready'); }
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('Accept-Ranges', 'bytes');
      const range = req.headers.range;
      const mm = range && range.match(/^bytes=(\d+)-(\d*)$/);
      if (mm) {
        const start = parseInt(mm[1], 10);
        const end = mm[2] ? Math.min(parseInt(mm[2], 10), st.size - 1) : st.size - 1;
        if (start > end) { res.statusCode = 416; return res.end(); }
        res.statusCode = 206;
        res.setHeader('Content-Range', `bytes ${start}-${end}/${st.size}`);
        res.setHeader('Content-Length', end - start + 1);
        fs.createReadStream(file, { start, end }).pipe(res);
      } else {
        res.setHeader('Content-Length', st.size);
        fs.createReadStream(file).pipe(res);
      }
    });
    return;
  }

  if (op === 'prog') {
    const progFile = file + '.prog.json';
    if (req.method === 'POST') {
      const q = new URL(req.url, 'http://localhost').searchParams;
      const got = Math.max(0, parseInt(q.get('got') || '0', 10) || 0);
      const total = Math.max(0, parseInt(q.get('total') || '0', 10) || 0);
      try { fs.writeFileSync(progFile, JSON.stringify({ got, total })); } catch (e) {}
      res.setHeader('Content-Type', 'application/json');
      return res.end(JSON.stringify({ ok: true }));
    }
    fs.readFile(progFile, (err, data) => {
      if (err) { res.statusCode = 404; return res.end('no progress'); }
      res.setHeader('Content-Type', 'application/json');
      res.end(data);
    });
    return;
  }

  if (op === 'done' && req.method === 'POST') {
    purge(file);
    res.setHeader('Content-Type', 'application/json');
    return res.end(JSON.stringify({ ok: true }));
  }

  return next();
};


// Only an authenticated GSERVER controller can call this in-process hook.
module.exports.setFrozen = function (value) { if (value) relayFrozen = true; deviceV2.setFrozen(!!value); if (!value) relayFrozen = false; };
module.exports.pendingWrites = function () { return ACTIVE_WRITES + ASSEMBLING.size; };
module.exports.sweepForTests = sweep;

// Direct public download links are disabled; Wi-Fi v2 delivers only encrypted offers.
