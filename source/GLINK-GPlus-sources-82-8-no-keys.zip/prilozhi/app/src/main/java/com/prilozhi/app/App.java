package com.prilozhi.app;

import android.app.Application;
import android.content.Context;

/** GLINK: обмен только через NFC, серверов и сети не требуется. */
public class App extends Application {
    private static App instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        // авто-очистка: вчерашние шифровки, недокачки и прочий рабочий кэш не копится
        new Thread(() -> {
            try {
                java.io.File[] files = getCacheDir().listFiles();
                if (files == null) return;
                long dayAgo = System.currentTimeMillis() - 24L * 3600 * 1000;
                for (java.io.File f : files) {
                    String n = f.getName();
                    boolean junk = n.startsWith("relay_up_") || n.startsWith("relay_dl_")
                            || n.startsWith("gfcas_") || n.equals("apk_preview.apk")
                            || n.startsWith("relay_") || f.isDirectory()
                            && (n.equals("gfcas_partial") || n.equals("relay_partial"));
                    if (junk && f.lastModified() < dayAgo) deleteRecursive(f);
                }
            } catch (Throwable ignored) {
            }
        }, "glink-cache-clean").start();
    }

    private static void deleteRecursive(java.io.File f) {
        if (f.isDirectory()) {
            java.io.File[] kids = f.listFiles();
            if (kids != null) for (java.io.File k : kids) deleteRecursive(k);
        }
        f.delete();
    }

    public static App get() {
        return instance;
    }

    public static Context ctx() {
        return instance;
    }
}
