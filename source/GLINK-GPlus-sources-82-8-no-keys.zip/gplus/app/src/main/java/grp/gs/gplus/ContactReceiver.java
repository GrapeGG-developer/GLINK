package grp.gs.gplus;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import grp.gs.protocol.Protocol;

/** Exported solely for the signature-permission-protected GLINK NFC bridge. */
public final class ContactReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if(intent==null||!"grp.gs.gplus.CONTACT_FROM_GLINK".equals(intent.getAction()))return;
        final byte[] card=intent.getByteArrayExtra("card");
        if(card==null||card.length>Protocol.MAX_CARD)return;
        PendingResult pending=goAsync();Context app=context.getApplicationContext();
        new Thread(() -> {
            try(GPlusStore store=new GPlusStore(app)){
                GlinkBridge bridge=new GlinkBridge(app);Protocol.Card saved=store.putContact(card,bridge.id());
                bridge.ackContact(saved.id);
                app.sendBroadcast(new Intent("grp.gs.gplus.CONTACTS_UPDATED").setPackage(app.getPackageName()));
            }catch(Exception ignored){}finally{pending.finish();}
        },"gplus-contact-import").start();
    }
}
