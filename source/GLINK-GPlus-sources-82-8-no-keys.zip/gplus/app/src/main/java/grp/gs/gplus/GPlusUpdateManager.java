package grp.gs.gplus;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Foreground-only mandatory updater. Android always asks the user to confirm installation. */
final class GPlusUpdateManager {
    static final String FEED = "https://raw.githubusercontent.com/GrapeGG-developer/GLINK/main/gplus-version.json";
    static final String APK = "https://raw.githubusercontent.com/GrapeGG-developer/GLINK/main/GPlus.apk";
    static final String VERSION_PATTERN = "[0-9]+\\.[0-9]+\\.GLINK-(RELEASE|BETA|PATCH|EXP|TEST)";
    private static final long MAX_SIZE = 200L * 1024 * 1024;
    private static final String KEEP = "upd_keep_name";
    private final Activity activity;
    private final Context context;
    private final SharedPreferences prefs;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private boolean checking, active, verifying, attemptedInstall, awaitingPermission, installerLaunched, closed;
    private Dialog panel;
    private ProgressBar bar;
    private TextView status;
    private Button button;
    private final Runnable loop = new Runnable() {
        @Override public void run() {
            if (!active || closed) return;
            check();
            main.postDelayed(this, 60_000);
        }
    };

    static final class Info {
        final int code;
        final String name, sha, notes;
        final long size;
        Info(int c, String n, String s, long z, String t) { code=c; name=n; sha=s; size=z; notes=t; }
    }

    GPlusUpdateManager(Activity a) {
        activity=a; context=a.getApplicationContext();
        prefs=context.getSharedPreferences("gplus_update", Context.MODE_PRIVATE);
    }

    static Info parse(String json, int current) throws Exception {
        JSONObject o = new JSONObject(json);
        int code = o.getInt("versionCode");
        if (code < 1) throw new SecurityException("Invalid update version");
        if (code <= current) return null; // A retired, older feed need not match today's schema.
        String name=o.getString("versionName"), url=o.getString("apk"), sha=o.getString("sha256");
        String notes=o.optString("notes", "Улучшения и исправления");
        long size=o.getLong("size");
        if (!name.matches(VERSION_PATTERN) || !APK.equals(url) || !sha.matches("[0-9a-f]{64}")
                || size<1 || size>MAX_SIZE || notes.length()>8192)
            throw new SecurityException("Invalid update feed");
        return new Info(code,name,sha,size,notes);
    }

    void onResume() {
        if (closed) return;
        active=true;
        main.removeCallbacks(loop);
        boolean returnedFromInstaller=installerLaunched;
        installerLaunched=false;
        if (awaitingPermission) {
            awaitingPermission=false;
            attemptedInstall=false;
            Info pending=pendingInfo();
            if (pending!=null) { showPanel(pending); installPending(); }
        } else if (returnedFromInstaller) {
            Info pending=pendingInfo();
            if (pending!=null) {
                showPanel(pending);
                setStatus("Подтвердите установку в Android", "Открыть установку", true,
                        () -> { attemptedInstall=false; installPending(); });
            }
        } else {
            Info pending=pendingInfo();
            if (pending!=null && file().isFile()) {
                showPanel(pending); attemptedInstall=false; installPending();
            } else check();
        }
        main.postDelayed(loop, 60_000);
    }
    void onPause() { active=false; main.removeCallbacks(loop); }
    void close() { active=false; closed=true; main.removeCallbacks(loop); worker.shutdownNow(); }

    private Info pendingInfo() {
        int code=prefs.getInt("code",0);
        if (code>0) {
            try {
                long installed=context.getPackageManager().getPackageInfo(context.getPackageName(),0).getLongVersionCode();
                if (code<=installed) { file().delete(); legacyCachedFile().delete(); prefs.edit().clear().apply(); return null; }
            } catch (Exception ignored) { return null; }
        }
        String name=prefs.getString("name",""), sha=prefs.getString("sha256","");
        long size=prefs.getLong("size",0);
        if(code<1 || name==null || !name.matches(VERSION_PATTERN) || sha==null
                || !sha.matches("[0-9a-f]{64}") || size<1 || size>MAX_SIZE) return null;
        return new Info(code,name,sha,size,prefs.getString("notes","Улучшения и исправления"));
    }

    private void check() {
        if (!active || closed || checking || (panel!=null && panel.isShowing())) return;
        checking=true;
        worker.execute(() -> {
            File dest=file(), temp=new File(dest.getParentFile(), "GPlus-update.part.apk");
            Info info=null;
            try {
                PackageInfo current=context.getPackageManager().getPackageInfo(context.getPackageName(),PackageManager.GET_SIGNING_CERTIFICATES);
                int currentCode=(int)current.getLongVersionCode();
                info=parse(fetchText(FEED),currentCode);
                if (info==null) {
                    // Only retire a pending file once this app version is installed. Never remove
                    // upd_keep_name while a newer APK might still be open in Android's installer.
                    if (prefs.getInt("code",0)<=currentCode) {
                        temp.delete(); dest.delete(); legacyCachedFile().delete(); prefs.edit().clear().apply();
                    }
                    return;
                }
                final Info offered=info;
                main.post(() -> { if (active&&!closed) showPanel(offered); });
                boolean exists=dest.isFile() && dest.length()==info.size && info.sha.equals(sha256(dest));
                if (!exists) {
                    temp.delete();
                    download(APK,temp,info.size,info.sha, (done,total) -> main.post(() -> showProgress(done,total)));
                    verifyPackage(temp,info,current);
                    if (dest.exists()&&!dest.delete()) throw new java.io.IOException("Cannot replace update");
                    if (!temp.renameTo(dest)) throw new java.io.IOException("Cannot retain update");
                } else verifyPackage(dest,info,current);
                boolean saved=prefs.edit().putInt("code",info.code).putString("name",info.name)
                        .putString("sha256",info.sha).putLong("size",info.size)
                        .putString("notes",info.notes).putString(KEEP,dest.getName()).commit();
                if(!saved)throw new java.io.IOException("Cannot retain update metadata");
                main.post(() -> {
                    if(active&&!closed) { showPanel(offered); attemptedInstall=false; installPending(); }
                });
            } catch(Exception e) {
                temp.delete();
                final boolean hadOffer=info!=null;
                main.post(() -> {
                    if (active&&hadOffer&&!closed) setStatus("Не удалось скачать или проверить обновление", "Повторить", true,
                            () -> { if(panel!=null) panel.dismiss(); panel=null; check(); });
                });
            } finally { main.post(() -> checking=false); }
        });
    }

    /** Kept package-visible so Robolectric can verify the mandatory UI without network access. */
    void showPanel(Info info) {
        if (!active || closed || activity.isFinishing() || activity.isDestroyed()) return;
        if(panel!=null&&panel.isShowing()) return;
        float d=activity.getResources().getDisplayMetrics().density;
        LinearLayout box=new LinearLayout(activity); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding((int)(20*d),(int)(20*d),(int)(20*d),(int)(20*d));
        GradientDrawable background=new GradientDrawable();background.setColor(0xF21A1429);
        background.setCornerRadius(22*d);background.setStroke(Math.max(1,(int)d),0x665DCE9A);box.setBackground(background);
        LinearLayout row=new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon=new ImageView(activity);icon.setImageResource(R.mipmap.ic_launcher);icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        icon.setOutlineProvider(new ViewOutlineProvider(){@Override public void getOutline(View v,Outline o){o.setRoundRect(0,0,v.getWidth(),v.getHeight(),12*d);}});
        icon.setClipToOutline(true);row.addView(icon,new LinearLayout.LayoutParams((int)(46*d),(int)(46*d)));
        LinearLayout titleBox=new LinearLayout(activity);titleBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1);tp.leftMargin=(int)(14*d);row.addView(titleBox,tp);
        titleBox.addView(label("доступно обновление G+",20,Color.WHITE));
        String current="";try{current=context.getPackageManager().getPackageInfo(context.getPackageName(),0).versionName;}catch(Exception ignored){}
        TextView versions=label(current+"  →  "+info.name,13,0xFF7DF1A6);titleBox.addView(versions);
        box.addView(row);
        TextView size=label(String.format(Locale.ROOT,"размер обновления: %.1f МБ",info.size/1048576f),12,0xFFBFB6CD);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=(int)(9*d);box.addView(size,sp);
        for(String part:info.notes.split("[;\\n]")) {
            String s=part.trim(); if(s.isEmpty())continue;
            TextView note=label("■  "+s,13,0xFFE3DEEB);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=(int)(5*d);box.addView(note,np);
        }
        bar=new ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(1000);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,(int)(6*d));bp.topMargin=(int)(16*d);box.addView(bar,bp);
        status=label("подготовка…",12,0xFFBFB6CD);LinearLayout.LayoutParams st=new LinearLayout.LayoutParams(-1,-2);st.topMargin=(int)(9*d);box.addView(status,st);
        button=new Button(activity,null,android.R.attr.borderlessButtonStyle);button.setTextColor(0xFF7DF1A6);button.setAllCaps(false);button.setText("скачивание…");button.setEnabled(false);button.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams b=new LinearLayout.LayoutParams(-1,(int)(48*d));b.topMargin=(int)(12*d);box.addView(button,b);
        Dialog dlg=new Dialog(activity);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);dlg.setContentView(box);
        dlg.setCancelable(false);dlg.setCanceledOnTouchOutside(false);panel=dlg;
        dlg.setOnDismissListener(x -> { if(panel==dlg)panel=null; });
        Window win=dlg.getWindow();if(win!=null){win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            if(Build.VERSION.SDK_INT>=31){try{win.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);WindowManager.LayoutParams a=win.getAttributes();a.setBlurBehindRadius(28);win.setAttributes(a);}catch(Throwable ignored){}}}
        dlg.show();if(win!=null)win.setLayout((int)(activity.getResources().getDisplayMetrics().widthPixels*.92f),WindowManager.LayoutParams.WRAP_CONTENT);
        box.setAlpha(0f);box.setTranslationY(40*d);box.animate().alpha(1f).translationY(0f).setDuration(300).start();
    }
    private TextView label(String s,float size,int color){TextView v=new TextView(activity);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL));return v;}
    private void setStatus(String text,String action,boolean enabled,Runnable click){
        if(panel==null||!panel.isShowing()||status==null||button==null)return;
        status.setText(text);button.setText(action);button.setEnabled(enabled);button.setOnClickListener(click==null?null:v->click.run());
    }
    private void showProgress(long done,long total){if(panel==null||!panel.isShowing()||bar==null||status==null)return;bar.setProgress((int)Math.min(1000,done*1000/Math.max(1,total)));status.setText((done*100/Math.max(1,total))+"% · скачивание и проверка");}

    private void installPending() {
        if(attemptedInstall||verifying||!active||closed||activity.isFinishing()||activity.isDestroyed())return;
        Info info=pendingInfo();if(info==null)return;verifying=true;
        worker.execute(() -> {
            boolean valid=false;File f=file();
            try {
                PackageInfo installed=context.getPackageManager().getPackageInfo(context.getPackageName(),PackageManager.GET_SIGNING_CERTIFICATES);
                if(f.isFile()&&info.code>installed.getLongVersionCode()&&info.size==f.length()&&info.sha.equals(sha256(f))){verifyPackage(f,info,installed);valid=true;}
                else if(info.code<=installed.getLongVersionCode()){f.delete();prefs.edit().clear().apply();}
            }catch(Exception ignored){}
            final boolean ok=valid;
            main.post(() -> {
                verifying=false;
                if(!ok){setStatus("Проверка APK не прошла", "Повторить", true, ()->{if(panel!=null)panel.dismiss();panel=null;check();});return;}
                if(!active||attemptedInstall||closed||activity.isFinishing()||activity.isDestroyed())return;
                if(!context.getPackageManager().canRequestPackageInstalls()){
                    setStatus("Разрешите G+ устанавливать обновления", "Открыть настройки", true, ()->{
                        awaitingPermission=true;
                        try{activity.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+context.getPackageName())));}
                        catch(Exception e){awaitingPermission=false;setStatus("Откройте разрешение установки вручную", "Повторить", true, this::installPending);}
                    });return;
                }
                try {
                    Uri uri=Uri.parse("content://"+context.getPackageName()+".updates/GPlus-update.apk");
                    Intent install=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    attemptedInstall=true;installerLaunched=true;
                    setStatus("Обновление проверено — открываю установку Android", "установка…", false, null);
                    activity.startActivity(install);
                }catch(Exception e){attemptedInstall=false;installerLaunched=false;setStatus("Не удалось открыть установщик", "Повторить", true,this::installPending);}
            });
        });
    }
    // Keep the verified APK in private durable storage; Android may evict cache
    // while its installer is still waiting for user confirmation.
    static File pendingFile(Context c){return new File(c.getFilesDir(),"GPlus-update.apk");}
    private File legacyCachedFile(){return new File(context.getCacheDir(),"GPlus-update.apk");}
    private File file(){return pendingFile(context);}
    private void verifyPackage(File apk,Info info,PackageInfo installed)throws Exception{
        PackageManager pm=context.getPackageManager();PackageInfo archive=pm.getPackageArchiveInfo(apk.getAbsolutePath(),PackageManager.GET_SIGNING_CERTIFICATES);
        if(archive==null||!context.getPackageName().equals(archive.packageName)||archive.getLongVersionCode()!=info.code||!info.name.equals(archive.versionName)||archive.signingInfo==null||installed.signingInfo==null)throw new SecurityException("Invalid APK");
        Signature[] a=archive.signingInfo.getApkContentsSigners(),b=installed.signingInfo.getApkContentsSigners();
        if(a==null||b==null||a.length!=b.length||a.length==0)throw new SecurityException("Different signer");
        for(Signature s:a){boolean found=false;for(Signature t:b)if(Arrays.equals(s.toByteArray(),t.toByteArray()))found=true;if(!found)throw new SecurityException("Different signer");}
    }
    private static String fetchText(String url)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();try{c.setInstanceFollowRedirects(false);c.setConnectTimeout(8000);c.setReadTimeout(12000);c.setUseCaches(false);if(c.getResponseCode()!=200)throw new java.io.IOException("Update feed unavailable");try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){if(out.size()+n>65536)throw new java.io.IOException("Feed too large");out.write(b,0,n);}return new String(out.toByteArray(),java.nio.charset.StandardCharsets.UTF_8);}}finally{c.disconnect();}
    }
    interface Progress {void update(long done,long total);}
    private static void download(String url,File target,long expected,String sha,Progress progress)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();try{c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(30000);c.setUseCaches(false);if(c.getResponseCode()!=200)throw new java.io.IOException("APK unavailable");long declared=c.getContentLengthLong();if(declared>0&&declared!=expected)throw new SecurityException("Invalid APK size");MessageDigest md=MessageDigest.getInstance("SHA-256");long total=0,last=0;try(InputStream in=c.getInputStream();FileOutputStream out=new FileOutputStream(target)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1){total+=n;if(total>expected)throw new SecurityException("APK too large");md.update(b,0,n);out.write(b,0,n);if(total-last>262144){progress.update(total,expected);last=total;}}out.getFD().sync();}if(total!=expected||!hex(md.digest()).equals(sha))throw new SecurityException("Invalid APK digest");progress.update(total,expected);}finally{c.disconnect();}
    }
    static String sha256(File f)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)md.update(b,0,n);}return hex(md.digest());}
    private static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte v:b)s.append(String.format(Locale.ROOT,"%02x",v&255));return s.toString();}
}
