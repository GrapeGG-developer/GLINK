package com.prilozhi.app.ui;

/** Density-independent island geometry and a frame-rate independent, non-overshooting transition. */
public final class IslandGeometry {
    public static final float COLLAPSED_DP = 58f;
    public static final float EXPANDED_DP = 588f;
    private static final float SNAP_DP = 0.12f;

    private IslandGeometry() {}

    public static float widthPx(float density) {
        return COLLAPSED_DP * density;
    }

    public static float targetHeightPx(boolean expanded, float density) {
        return (expanded ? EXPANDED_DP : COLLAPSED_DP) * density;
    }

    public static float nextHeightPx(float current, boolean expanded, float density, float dt) {
        final float min = COLLAPSED_DP * density;
        final float max = EXPANDED_DP * density;
        final float target = targetHeightPx(expanded, density);
        current = Math.max(min, Math.min(max, current));
        if (dt <= 0f) return current;
        float safeDt = Math.min(dt, 0.05f);
        float progress = 1f - (float) Math.exp(-15f * safeDt);
        float next = current + (target - current) * progress;
        return Math.abs(target - next) <= SNAP_DP * density ? target : next;
    }

    public static boolean animating(float current, boolean expanded, float density) {
        return Math.abs(targetHeightPx(expanded, density) - current) > SNAP_DP * density;
    }
}
