package grp.gs.gplus;

import grp.gs.protocol.Protocol;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.ByteBuffer;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

/** Direct-message client. Only sealed and signed envelopes enter the database or server. */
public final class ChatEngine {
    private final GlinkBridge bridge; private final GPlusApi api; private final GPlusStore store;
    public ChatEngine(GlinkBridge bridge,GPlusApi api,GPlusStore store){this.bridge=bridge;this.api=api;this.store=store;}
    public String chatId(Protocol.Card peer)throws Exception{return Protocol.directChat(bridge.id(),peer.id);}
    public void queue(Protocol.Card peer,JSONObject message)throws Exception{queue(peer,message,null,null,0);}
    void queueCallSignal(Protocol.Card peer,JSONObject message)throws Exception{String type=message.optString("type");if(!type.equals("call_offer")&&!type.equals("call_answer")&&!type.equals("call_end"))throw new SecurityException("Invalid call signal");queue(peer,message,null,null,120);}
    private void queue(Protocol.Card peer,JSONObject message,String asset,MediaCrypto.Prepared file,int ttlSeconds)throws Exception{
        String from=bridge.id(), chat=Protocol.directChat(from,peer.id);
        byte[] plain=message.toString().getBytes(StandardCharsets.UTF_8);
        if(plain.length==0||plain.length>64000)throw new IllegalArgumentException("Сообщение слишком большое");
        byte[] random=new byte[16];new SecureRandom().nextBytes(random);String event=Protocol.b64(random);
        JSONArray boxes=new JSONArray();String selfCipher=null,selfSignature=null;
        for(int i=0;i<2;i++){
            String to=i==0?from:peer.id;byte[] pub=i==0?bridge.encryptionPublic():peer.encryptionPublic;
            byte[] cipher=bridge.encrypt(pub,Protocol.boxContext(chat,event,from,to),plain);
            byte[] signature=bridge.signDigest(Protocol.messageDigest(chat,event,from,to,cipher));
            String c=Protocol.b64(cipher),s=Protocol.b64(signature);
            boxes.put(new JSONObject().put("to",to).put("ciphertext",c).put("signature",s));
            if(i==0){selfCipher=c;selfSignature=s;}
        }
        if(ttlSeconds<0||ttlSeconds>31536000)throw new IllegalArgumentException("Invalid TTL");
        JSONObject request=new JSONObject().put("id",event).put("boxes",boxes);if(ttlSeconds>0)request.put("ttl_seconds",ttlSeconds);
        store.upsertDirect(chat,peer);
        store.saveDraft(chat,event,from,selfCipher,selfSignature,request.toString(),System.currentTimeMillis(),asset,file);
    }
    public void queueFile(Protocol.Card peer,String asset,MediaCrypto.Prepared file,String name,String mime)throws Exception {queueFile(peer,asset,file,name,mime,false,false);}
    public void queueVoice(Protocol.Card peer,String asset,MediaCrypto.Prepared file)throws Exception {queueFile(peer,asset,file,"Голосовое сообщение.m4a","audio/mp4",true,false);}
    public void queueForwardedFile(Protocol.Card peer,String asset,MediaCrypto.Prepared file,String name,String mime,boolean voice)throws Exception {queueFile(peer,asset,file,name,mime,voice,true);}
    private void queueFile(Protocol.Card peer,String asset,MediaCrypto.Prepared file,String name,String mime,boolean voice,boolean forwarded)throws Exception {
        if(!Protocol.validEventId(asset)||file==null)throw new IllegalArgumentException("Invalid asset");
        String safe=name==null?"Файл":name.replaceAll("[/\\\\\\p{Cntrl}]","_").trim();if(safe.isEmpty())safe="Файл";if(safe.length()>180)safe=safe.substring(0,180);
        String type=mime!=null&&mime.matches("[A-Za-z0-9.+_-]{1,80}/[A-Za-z0-9.+_-]{1,80}")?mime:"application/octet-stream";
        try{JSONObject message=new JSONObject().put("v",1).put("type","file").put("asset",asset).put("name",safe).put("mime",type).put("key",Protocol.b64(file.keyset)).put("size",file.plainSize).put("cipher_size",file.cipherSize).put("sha256",file.sha256);if(voice)message.put("voice",true);if(forwarded)message.put("forwarded",true);queue(peer,message,asset,file,0);}
        finally{java.util.Arrays.fill(file.keyset,(byte)0);}
    }
    public void queueText(Protocol.Card peer,String text,String reply)throws Exception{queueText(peer,text,reply,0);}
    public void queueText(Protocol.Card peer,String text,String reply,int ttlSeconds)throws Exception{
        if(text==null||text.trim().isEmpty()||text.length()>16000)throw new IllegalArgumentException("Введите сообщение до 16000 символов");
        JSONObject obj=new JSONObject().put("v",1).put("type","text").put("text",text);
        if(reply!=null&&!reply.isEmpty())obj.put("reply",reply);queue(peer,obj,null,null,ttlSeconds);
    }
    /** Flushes pending ciphertext, retrieves only this device's ciphertext and persists it before ACK. */
    public void sync(Protocol.Card peer,boolean markRead)throws Exception{
        String self=bridge.id(), chat=Protocol.directChat(self,peer.id);
        JSONObject opened=api.openDirect(peer.id);if(!chat.equals(opened.optString("id")))throw new SecurityException("Неверный чат");
        store.upsertDirect(chat,peer);
        for(String[] pending:store.outbox(chat)){
            if(pending[2]!=null){String[] asset=store.localAsset(pending[2]);if(asset==null)throw new IllegalStateException("Локальный файл недоступен");if(!"1".equals(asset[3])){java.io.File f=new java.io.File(asset[0]);if(!f.isFile()||f.length()!=Long.parseLong(asset[1]))throw new IllegalStateException("Локальный файл недоступен");api.uploadAsset(chat,pending[2],f,asset[2]);store.markAssetUploaded(pending[2]);}}
            JSONObject body=new JSONObject(pending[1]),response=api.sendEvent(chat,body);long seq=response.getLong("seq"),created=response.getLong("created");
            // Keep the outbox entry until both the event and its media binding
            // are confirmed. Each step is safe to retry after a crash.
            if(pending[2]!=null)api.bindAsset(pending[2],pending[0]);
            JSONArray boxes=body.getJSONArray("boxes");boolean found=false;
            for(int i=0;i<boxes.length();i++){JSONObject b=boxes.getJSONObject(i);if(self.equals(b.getString("to"))){store.saveEnvelope(chat,pending[0],self,self,b.getString("ciphertext"),b.getString("signature"),seq,created,response.optLong("expires",0),"sent");found=true;break;}}
            if(!found)throw new SecurityException("Нет собственной копии");store.removeOutbox(pending[0]);
        }
        long cursor=store.cursor(chat);boolean more;
        do{
            JSONObject page=api.events(chat,cursor);JSONArray events=page.getJSONArray("events");
            for(int i=0;i<events.length();i++){
                JSONObject e=events.getJSONObject(i);String event=e.getString("id"),sender=e.getString("sender"),to=e.getString("recipient");long seq=e.getLong("seq");
                if(seq<=cursor||!self.equals(to)||(!sender.equals(self)&&!sender.equals(peer.id)))throw new SecurityException("Неверный конверт");
                byte[] pub=sender.equals(self)?bridge.publicKey():peer.identityPublic;
                byte[] cipher=IdentityUtil.unb64(e.getString("ciphertext")),sig=IdentityUtil.unb64(e.getString("signature"));
                if(!Protocol.verifySignature(pub,Protocol.messageDigest(chat,event,sender,to,cipher),sig))throw new SecurityException("Подпись сообщения неверна");
                // Verify authentication and format before acknowledging receipt.
                parse(bridge.decrypt(Protocol.boxContext(chat,event,sender,to),cipher));
                store.saveIncoming(chat,event,sender,to,e.getString("ciphertext"),e.getString("signature"),seq,e.getLong("created"),e.optLong("expires",0),sender.equals(self)?"sent":"received");cursor=seq;
            }
            more=page.optBoolean("has_more",false);
            if(more&&events.length()==0)throw new SecurityException("Пустая страница сервера");
        }while(more);
        if(cursor>0){try{api.ack(chat,cursor);if(markRead)api.readReceipt(chat,cursor);}catch(GPlusApi.ApiException e){if(e.status!=404)throw e;}}
        try{MediaReceipts.flush(api,store);}catch(Exception ignored){/* retained locally for retry */}
    }
    public static final class Message {
        public final String id,sender,state;public final long created,seq;public final JSONObject content;
        Message(String id,String sender,String state,long created,long seq,JSONObject content){this.id=id;this.sender=sender;this.state=state;this.created=created;this.seq=seq;this.content=content;}
    }
    public List<Message> messages(Protocol.Card peer)throws Exception{return messagesAfter(peer,-1);}
    public List<Message> messagesAfter(Protocol.Card peer,long after)throws Exception{
        String self=bridge.id(),chat=Protocol.directChat(self,peer.id);List<Message> out=new ArrayList<>();
        for(String[] e:store.envelopesAfter(chat,after)){
            String event=e[0],sender=e[1],to=e[2];if(!self.equals(to)||(!self.equals(sender)&&!peer.id.equals(sender)))continue;
            byte[] cipher=IdentityUtil.unb64(e[3]),sig=IdentityUtil.unb64(e[4]),pub=self.equals(sender)?bridge.publicKey():peer.identityPublic;
            if(!Protocol.verifySignature(pub,Protocol.messageDigest(chat,event,sender,to,cipher),sig))throw new SecurityException("Неверная подпись истории");
            JSONObject content=parse(bridge.decrypt(Protocol.boxContext(chat,event,sender,to),cipher));
            out.add(new Message(event,sender,e[7],Long.parseLong(e[6]),Long.parseLong(e[5]),content));
        }return out;
    }
    static JSONObject parse(byte[] bytes)throws Exception{
        if(bytes==null||bytes.length==0||bytes.length>64000)throw new SecurityException("Неверный размер сообщения");
        String text=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
        JSONObject obj=new JSONObject(text);if(obj.optInt("v")!=1||obj.optString("type").isEmpty())throw new SecurityException("Неверное сообщение");return obj;
    }
}
