package com.prilozhi.app.net;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.webkit.MimeTypeMap;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public final class ManifestBuilder {

    public interface Opener {
        InputStream open() throws IOException;
    }

    public static class SendFile {
        public final String path;
        public final long size;
        public final String mime;
        public final Opener opener;

        public SendFile(String path, long size, String mime, Opener opener) {
            this.path = path;
            this.size = size;
            this.mime = mime;
            this.opener = opener;
        }
    }

    public static class Built {
        public final List<SendFile> files = new ArrayList<>();
        public String text;
        public String link;
        /** Отдельный канал приколов: формат GLINKFUN/1 (не текст!). */
        public String fun;
        private final java.util.Set<String> usedPaths = new java.util.HashSet<>();

        /** Уникализирует путь внутри передачи: "a.txt" -> "a (1).txt". */
        public String unique(String path) {
            if (usedPaths.add(path.toLowerCase())) return path;
            int slash = path.lastIndexOf('/');
            String dir = slash >= 0 ? path.substring(0, slash + 1) : "";
            String name = slash >= 0 ? path.substring(slash + 1) : path;
            int dot = name.lastIndexOf('.');
            String stem = dot > 0 ? name.substring(0, dot) : name;
            String ext = dot > 0 ? name.substring(dot) : "";
            int n = 1;
            String cand;
            do {
                cand = dir + stem + " (" + (n++) + ")" + ext;
            } while (!usedPaths.add(cand.toLowerCase()));
            return cand;
        }
    }

    private static final int MAX_FILES = 4000;

    private ManifestBuilder() {
    }

    public static Built build(Context ctx, List<OutItem> items) throws IOException {
        Built built = new Built();
        for (OutItem item : items) {
            if (built.files.size() >= MAX_FILES && (item.kind == OutItem.KIND_FILE || item.kind == OutItem.KIND_TREE))
                throw new IOException("Слишком много файлов в передаче");
            switch (item.kind) {
                case OutItem.KIND_TEXT:
                    if (item.isLink) {
                        if (built.link == null) built.link = item.text;
                        else built.text = (built.text == null ? "" : built.text + "\n") + item.text;
                    } else {
                        built.text = (built.text == null ? "" : built.text + "\n\n") + item.text;
                    }
                    break;
                case OutItem.KIND_FUN:
                    if (built.fun == null) built.fun = item.text;
                    break;
                case OutItem.KIND_FILE:
                    addFile(ctx, built, item);
                    break;
                case OutItem.KIND_TREE:
                    walkTree(ctx, built, item.uri, "");
                    break;
            }
        }
        return built;
    }

    private static void addFile(final Context ctx, Built built, OutItem item) throws IOException {
        // Never silently omit a selected item when access was revoked.
        try (InputStream probe = ctx.getContentResolver().openInputStream(item.uri)) {
            if (probe == null) throw new IOException("Файл недоступен: " + item.label());
        } catch (Exception e) {
            throw new IOException("Файл недоступен: " + item.label(), e);
        }
        String name = sanitize(item.displayName != null ? item.displayName : "file.bin");
        long size = item.size;
        if (size < 0) size = querySize(ctx, item.uri);
        final Uri uri = item.uri;
        String mime = item.mime != null ? item.mime : "application/octet-stream";
        built.files.add(new SendFile(built.unique(name), size, mime, () -> {
            if ("file".equals(uri.getScheme())) {
                return new java.io.FileInputStream(new java.io.File(uri.getPath()));
            }
            InputStream in = ctx.getContentResolver().openInputStream(uri);
            if (in == null) throw new IOException("Не удалось открыть " + name);
            return in;
        }));
    }

    private static void walkTree(Context ctx, Built built, Uri treeUri, String base) throws IOException {
        if (built.files.size() >= MAX_FILES) throw new IOException("Слишком много файлов в передаче");
        String rootId;
        try {
            rootId = DocumentsContract.getTreeDocumentId(treeUri);
        } catch (Exception e) {
            throw new IOException("Некорректная папка");
        }
        String dirName = base;
        if (base.isEmpty()) {
            String nm = queryDisplayName(ctx, DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId));
            dirName = sanitize(nm != null ? nm : "Папка");
        }
        walkChildren(ctx, built, treeUri, rootId, dirName);
    }

    private static void walkChildren(Context ctx, Built built, Uri treeUri, String docId, String base) throws IOException {
        if (built.files.size() >= MAX_FILES) return;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId);
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(children, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE
            }, null, null, null);
            if (c == null) throw new IOException("Папка недоступна: " + base);
            while (c.moveToNext()) {
                if (built.files.size() >= MAX_FILES) throw new IOException("Слишком много файлов в передаче");
                String id = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                long size = c.isNull(3) ? -1 : c.getLong(3);
                if (name == null) name = "item";
                boolean isDir = DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);
                if (isDir) {
                    walkChildren(ctx, built, treeUri, id, base + "/" + sanitize(name));
                } else {
                    final Uri docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                    final String path = base + "/" + sanitize(name);
                    final String fmime = mime != null ? mime : guessMime(name);
                    built.files.add(new SendFile(built.unique(path), size, fmime, () -> {
                        InputStream in = ctx.getContentResolver().openInputStream(docUri);
                        if (in == null) throw new IOException("Не удалось открыть " + path);
                        return in;
                    }));
                }
            }
        } catch (Exception e) {
            throw new IOException("Не удалось полностью прочитать папку: " + base, e);
        } finally {
            if (c != null) c.close();
        }
    }

    public static long querySize(Context ctx, Uri uri) {
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(uri, new String[]{
                    DocumentsContract.Document.COLUMN_SIZE}, null, null, null);
            if (c != null && c.moveToFirst() && !c.isNull(0)) return c.getLong(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return -1;
    }

    private static String queryDisplayName(Context ctx, Uri uri) {
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(uri, new String[]{
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return null;
    }

    public static String sanitize(String name) {
        String s = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (s.isEmpty()) s = "file";
        return s;
    }

    public static String guessMime(String name) {
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            String ext = name.substring(dot + 1).toLowerCase();
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    public static long totalSize(List<OutItem> items) {
        long sum = 0;
        for (OutItem it : items) {
            if (it.size > 0) sum += it.size;
        }
        return sum;
    }

    public static boolean amInitiator(String myId, String peerId) {
        return myId.compareTo(peerId) <= 0;
    }
}
