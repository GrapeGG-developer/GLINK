package grp.gs.gplus;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** HTTPS auth, profile, encrypted-message and media API for the experimental G+ server. */
public final class GPlusApi {
    private final String base;
    private final GlinkBridge identity;
    private String token = "";

    public static final class ApiException extends IOException {
        public final int status;
        public final String error;
        ApiException(int status, String error) { super(error); this.status = status; this.error = error; }
    }

    public GPlusApi(String base, GlinkBridge identity) {
        if (base == null || !base.startsWith("https://")) throw new IllegalArgumentException("HTTPS required");
        this.base = base.replaceAll("/+$", ""); this.identity = identity;
    }
    public synchronized boolean isSignedIn() { return !token.isEmpty(); }
    synchronized String callToken(){if(token.isEmpty())throw new IllegalStateException("Требуется вход в G+");return token;}
    String callUrl(String chat,String call)throws Exception{if(!grp.gs.protocol.Protocol.validChatId(chat)||!grp.gs.protocol.Protocol.validEventId(call))throw new SecurityException("Неверный адрес звонка");return "wss://"+base.substring(8)+"/gplus/call-relay?chat="+java.net.URLEncoder.encode(chat,"UTF-8")+"&call="+java.net.URLEncoder.encode(call,"UTF-8");}

    public synchronized JSONObject login(String nickname) throws Exception {
        token = "";
        byte[] pub = identity.publicKey();
        JSONObject challenge = request("/gplus/auth/challenge", "POST", new JSONObject().put("public_key", IdentityUtil.b64(pub)), false);
        byte[] nonce = IdentityUtil.unb64(challenge.getString("nonce"));
        byte[] signature = identity.sign(nonce);
        JSONObject verify = new JSONObject().put("public_key", IdentityUtil.b64(pub))
                .put("nonce", IdentityUtil.b64(nonce)).put("signature", IdentityUtil.b64(signature));
        if (nickname != null && !nickname.isEmpty()) verify.put("nickname", nickname);
        JSONObject auth = request("/gplus/auth/verify", "POST", verify, false);
        if (!identity.id().equals(auth.optString("id")) || auth.optString("token").isEmpty()) {
            throw new SecurityException("Неверный ответ сервера G+");
        }
        token = auth.getString("token");
        try { return request("/gplus/me", "GET", null, true); }
        catch (Exception e) { token = ""; throw e; }
    }
    public synchronized JSONObject saveProfile(JSONObject profile) throws Exception {
        return request("/gplus/me/profile", "POST", profile, true);
    }

    public synchronized JSONObject me()throws Exception{return request("/gplus/me","GET",null,true);}
    public synchronized JSONObject createGroup(JSONObject state)throws Exception{return request("/gplus/chats/group","POST",state,true);}
    public synchronized JSONObject groupState(String chat)throws Exception{return request("/gplus/chats/"+chat+"/state","GET",null,true);}
    public synchronized JSONObject openDirect(String peer)throws Exception{return request("/gplus/chats/direct","POST",new JSONObject().put("peer",peer),true);}
    public synchronized JSONObject sendEvent(String chat,JSONObject event)throws Exception{return request("/gplus/chats/"+chat+"/events","POST",event,true);}
    public synchronized void bindAsset(String asset,String event)throws Exception{
        if(!grp.gs.protocol.Protocol.validEventId(asset)||!grp.gs.protocol.Protocol.validEventId(event))throw new SecurityException("Invalid asset binding");
        JSONObject r=request("/gplus/assets/"+asset+"/bind","POST",new JSONObject().put("event",event),true);
        if(!r.optBoolean("ok"))throw new SecurityException("Invalid asset binding response");
    }
    public synchronized void confirmAssetReceived(String asset,String event,String sha)throws Exception{
        if(!grp.gs.protocol.Protocol.validEventId(asset)||!grp.gs.protocol.Protocol.validEventId(event)||sha==null||!sha.matches("[0-9a-f]{64}"))throw new SecurityException("Invalid asset receipt");
        JSONObject r=request("/gplus/assets/"+asset+"/received","POST",new JSONObject().put("event",event).put("sha256",sha),true);
        if(!r.optBoolean("ok"))throw new SecurityException("Invalid asset receipt response");
    }
    public synchronized JSONObject events(String chat,long after)throws Exception{return request("/gplus/chats/"+chat+"/events?after="+after,"GET",null,true);}
    public synchronized JSONObject chats()throws Exception{return request("/gplus/chats","GET",null,true);}
    public synchronized JSONObject members(String chat)throws Exception{return request("/gplus/chats/"+chat+"/members","GET",null,true);}
    public synchronized void ack(String chat,long seq)throws Exception{request("/gplus/chats/"+chat+"/ack","POST",new JSONObject().put("seq",seq),true);}
    public synchronized void readReceipt(String chat,long seq)throws Exception{request("/gplus/chats/"+chat+"/read","POST",new JSONObject().put("seq",seq),true);}

    public synchronized void uploadAsset(String chat,String id,File file,String sha)throws Exception {
        if(!grp.gs.protocol.Protocol.validChatId(chat)||!grp.gs.protocol.Protocol.validEventId(id)||!sha.matches("[0-9a-f]{64}")||!file.isFile()||token.isEmpty())throw new IllegalArgumentException("Invalid asset");
        HttpURLConnection c=(HttpURLConnection)new URL(base+"/gplus/assets/"+id).openConnection();
        try{c.setInstanceFollowRedirects(false);c.setConnectTimeout(NetworkTimeouts.CONNECT_MS);c.setReadTimeout(NetworkTimeouts.mediaReadMs(file.length()));c.setRequestMethod("PUT");c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("X-Gplus-Chat",chat);c.setRequestProperty("X-Gplus-Sha256",sha);c.setRequestProperty("Content-Type","application/octet-stream");c.setDoOutput(true);c.setFixedLengthStreamingMode(file.length());
            try(InputStream in=new FileInputStream(file);OutputStream out=c.getOutputStream()){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
            int status=c.getResponseCode();if(status/100!=2){String error="upload_failed";try(InputStream in=c.getErrorStream()){if(in!=null)error=new JSONObject(new String(read(in),StandardCharsets.UTF_8)).optString("error",error);}catch(Exception ignored){}throw new ApiException(status,error);}
        }finally{c.disconnect();}
    }
    public synchronized void downloadAsset(String id,File destination,long expectedSize,String expectedSha)throws Exception {
        if(!grp.gs.protocol.Protocol.validEventId(id)||expectedSize<1||!expectedSha.matches("[0-9a-f]{64}")||token.isEmpty())throw new IllegalArgumentException("Invalid asset");
        HttpURLConnection c=(HttpURLConnection)new URL(base+"/gplus/assets/"+id).openConnection();File temp=new File(destination.getParentFile(),destination.getName()+".part");
        try{c.setInstanceFollowRedirects(false);c.setConnectTimeout(NetworkTimeouts.CONNECT_MS);c.setReadTimeout(NetworkTimeouts.mediaReadMs(expectedSize));c.setRequestMethod("GET");c.setRequestProperty("Authorization","Bearer "+token);int status=c.getResponseCode();if(status/100!=2)throw new ApiException(status,"download_failed");
            long declared=c.getContentLengthLong();if(declared!=expectedSize)throw new SecurityException("Размер файла не совпадает");MessageDigest md=MessageDigest.getInstance("SHA-256");long total=0;
            try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(temp)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1){total+=n;if(total>expectedSize)throw new SecurityException("Файл слишком большой");md.update(b,0,n);out.write(b,0,n);}}
            StringBuilder hex=new StringBuilder();for(byte x:md.digest())hex.append(String.format(java.util.Locale.ROOT,"%02x",x&255));if(total!=expectedSize||!expectedSha.equals(hex.toString()))throw new SecurityException("Проверка файла не прошла");
            try(RandomAccessFile f=new RandomAccessFile(temp,"rw")){f.getFD().sync();}if(destination.exists()&&!destination.delete())throw new IOException("Не удалось заменить файл");if(!temp.renameTo(destination))throw new IOException("Не удалось сохранить файл");
        }finally{c.disconnect();temp.delete();}
    }
    private static byte[] read(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[4096]; int n;
        while ((n = in.read(buf)) != -1) { if (out.size() + n > 4 * 1024 * 1024) throw new IOException("Ответ слишком большой"); out.write(buf, 0, n); }
        return out.toByteArray();
    }
    private JSONObject request(String path, String method, JSONObject body, boolean authorize) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(base + path).openConnection();
        try {
            c.setInstanceFollowRedirects(false); c.setUseCaches(false); c.setConnectTimeout(NetworkTimeouts.CONNECT_MS); c.setReadTimeout(NetworkTimeouts.API_READ_MS);
            c.setRequestMethod(method); c.setRequestProperty("Accept", "application/json");
            if (authorize) {
                if (token.isEmpty()) throw new ApiException(401, "authentication_required");
                c.setRequestProperty("Authorization", "Bearer " + token);
            }
            if (body != null) {
                c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                try (OutputStream out = c.getOutputStream()) { out.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
            }
            int status = c.getResponseCode();
            InputStream stream = status / 100 == 2 ? c.getInputStream() : c.getErrorStream();
            byte[] bytes; try (InputStream in = stream) { bytes = in == null ? new byte[0] : read(in); }
            JSONObject response;
            try { response = new JSONObject(new String(bytes, StandardCharsets.UTF_8)); }
            catch (Exception invalid) { throw new ApiException(status, "server_not_deployed"); }
            if (status / 100 != 2) throw new ApiException(status, response.optString("error", "server_error"));
            return response;
        } finally { c.disconnect(); }
    }
}
