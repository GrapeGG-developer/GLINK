package com.prilozhi.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

import com.prilozhi.app.util.State;

public class BackdropView extends View implements State.Listener {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Matrix matrix = new Matrix();
    private RadialGradient gPurple, gGreen, gViolet;
    private android.graphics.Bitmap blurredBackdrop;
    private int[] blurPixels, blurWork;
    private long lastBlurAt;
    private static final int BLUR_SCALE = 8;
    private long lastNs;
    private float t;
    private volatile boolean windowVisible = true;
    private boolean animRunning = false;

    private void startFrame() {
        if (animRunning) return;
        animRunning = true;
        lastNs = 0;
        postOnAnimation(frame);
    }
    private float energy = 0.35f;
    private float energyTgt = 0.35f;
    // настроение фона: скорость дрейфа пятен по состоянию + красная вспышка ошибки
    private float moodSpeed = 0.7f, moodSpeedTgt = 0.7f;
    private float tMove = 0f;
    private long errorFlashAt = 0;
    private boolean errorNow = false;
    private final Runnable frame = new Runnable() {
        @Override
        public void run() {
            long now = System.nanoTime();
            float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
            lastNs = now;
            if (!windowVisible) {
                animRunning = false;
                return;
            }
            t += dt;
            energy += (energyTgt - energy) * Math.min(1, dt * 2.5f);
            moodSpeed += (moodSpeedTgt - moodSpeed) * Math.min(1, dt * 1.8f);
            tMove += dt * moodSpeed;
            invalidate();
            // умная нагрузка: медленный дрейф не требует 60 fps
            postOnAnimationDelayed(this, 50);
        }
    };

    public BackdropView(Context context) {
        super(context);
    }

    public BackdropView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        State.get().addListener(this);
        applyState(State.get());
        startFrame();
    }

    @Override
    public void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        windowVisible = visibility == VISIBLE;
        if (visibility == VISIBLE && isAttachedToWindow()) {
            startFrame();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(frame);
        State.get().removeListener(this);
        super.onDetachedFromWindow();
    }

    @Override
    public void onStateChanged(State state) {
        applyState(state);
    }

    private void applyState(State s) {
        switch (s.mode) {
            case TRANSFER:
                energyTgt = 0.95f;
                moodSpeedTgt = 2.3f;
                break;
            case TAP:
            case SUCCESS:
                energyTgt = 0.95f;
                moodSpeedTgt = 1.6f;
                break;
            case CONNECTING:
                energyTgt = 0.7f;
                moodSpeedTgt = 1.2f;
                break;
            case ERROR:
                energyTgt = 0.45f;
                moodSpeedTgt = 0.5f;
                if (!errorNow) errorFlashAt = System.currentTimeMillis();
                break;
            case READY_SEND:
            case READY_RECV:
                energyTgt = 0.55f;
                moodSpeedTgt = 1.0f;
                break;
            default:
                energyTgt = 0.35f;
                moodSpeedTgt = 0.7f;
        }
        errorNow = s.mode == State.Mode.ERROR;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldW, int oldH) {
        super.onSizeChanged(w, h, oldW, oldH);
        gPurple = null;
        gGreen = null;
        gViolet = null;
        if (blurredBackdrop != null) blurredBackdrop.recycle();
        blurredBackdrop = null;
        blurPixels = null;
        blurWork = null;
        lastBlurAt = 0;
    }

    /** A shared, actually blurred snapshot of the backdrop (not of the text/icons). */
    public android.graphics.Bitmap getBlurredSnapshot() {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return null;
        long now = android.os.SystemClock.uptimeMillis();
        if (blurredBackdrop != null && now - lastBlurAt < 160) return blurredBackdrop;
        int sw = Math.max(1, (w + BLUR_SCALE - 1) / BLUR_SCALE);
        int sh = Math.max(1, (h + BLUR_SCALE - 1) / BLUR_SCALE);
        if (blurredBackdrop == null || blurredBackdrop.getWidth() != sw || blurredBackdrop.getHeight() != sh) {
            if (blurredBackdrop != null) blurredBackdrop.recycle();
            blurredBackdrop = android.graphics.Bitmap.createBitmap(sw, sh, android.graphics.Bitmap.Config.ARGB_8888);
            blurPixels = new int[sw * sh];
            blurWork = new int[sw * sh];
        }
        Canvas copy = new Canvas(blurredBackdrop);
        copy.scale((float) sw / w, (float) sh / h);
        draw(copy);
        blurSmallBitmap(blurredBackdrop, blurPixels, blurWork);
        lastBlurAt = now;
        return blurredBackdrop;
    }

    /** Separable box blur on a 1/8-resolution bitmap; shared by all visible tiles. */
    private static void blurSmallBitmap(android.graphics.Bitmap bitmap, int[] pixels, int[] work) {
        int w = bitmap.getWidth(), h = bitmap.getHeight();
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h);
        final int radius = 2;
        final int count = radius * 2 + 1;
        for (int y = 0; y < h; y++) {
            int r = 0, g = 0, b = 0;
            for (int k = -radius; k <= radius; k++) {
                int c = pixels[y * w + Math.max(0, Math.min(w - 1, k))];
                r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255;
            }
            for (int x = 0; x < w; x++) {
                work[y * w + x] = 0xFF000000 | (r / count << 16) | (g / count << 8) | b / count;
                int left = pixels[y * w + Math.max(0, x - radius)];
                int right = pixels[y * w + Math.min(w - 1, x + radius + 1)];
                r += ((right >> 16) & 255) - ((left >> 16) & 255);
                g += ((right >> 8) & 255) - ((left >> 8) & 255);
                b += (right & 255) - (left & 255);
            }
        }
        for (int x = 0; x < w; x++) {
            int r = 0, g = 0, b = 0;
            for (int k = -radius; k <= radius; k++) {
                int c = work[Math.max(0, Math.min(h - 1, k)) * w + x];
                r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255;
            }
            for (int y = 0; y < h; y++) {
                pixels[y * w + x] = 0xFF000000 | (r / count << 16) | (g / count << 8) | b / count;
                int top = work[Math.max(0, y - radius) * w + x];
                int bottom = work[Math.min(h - 1, y + radius + 1) * w + x];
                r += ((bottom >> 16) & 255) - ((top >> 16) & 255);
                g += ((bottom >> 8) & 255) - ((top >> 8) & 255);
                b += (bottom & 255) - (top & 255);
            }
        }
        bitmap.setPixels(pixels, 0, w, 0, 0, w, h);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w == 0 || h == 0) return;

        canvas.drawColor(0xFF000000);
        // чистый чёрный фон без сетки — только мягкие цветные пятна ниже
        paint.setShader(null);

        float r = Math.max(w, h) * 0.78f;
        if (gPurple == null) {
            gPurple = new RadialGradient(0, 0, r, new int[]{0x6B2A1450, 0x3D8B45E8, 0x000A0713},
                    new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
            gGreen = new RadialGradient(0, 0, r, new int[]{0x57300F57, 0x2E35F0AC, 0x000A0713},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
            gViolet = new RadialGradient(0, 0, r, new int[]{0x4D54259E, 0x24A875FF, 0x000A0713},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        }

        float x1 = w * 0.22f + (float) Math.sin(tMove * 0.46f) * w * 0.16f;
        float y1 = h * 0.16f + (float) Math.cos(tMove * 0.38f) * h * 0.10f;
        float x2 = w * 0.82f + (float) Math.cos(tMove * 0.42f) * w * 0.14f;
        float y2 = h * 0.78f + (float) Math.sin(tMove * 0.50f) * h * 0.11f;
        float x3 = w * 0.55f + (float) Math.sin(tMove * 0.30f + 2f) * w * 0.22f;
        float y3 = h * 0.45f + (float) Math.cos(tMove * 0.26f + 1f) * h * 0.14f;

        drawBlob(canvas, gPurple, x1, y1, r, 0.55f + 0.45f * energy);
        drawBlob(canvas, gGreen, x2, y2, r, 0.5f + 0.5f * energy);
        drawBlob(canvas, gViolet, x3, y3, r * 1.1f, 0.35f + 0.4f * energy);

        // Живые пылинки: медленный дрейф и мерцание (по чуть-чуть, без перегруза)
        paint.setShader(null);
        for (int i = 0; i < 22; i++) {
            float px = (float) ((i * 0.173f + Math.sin(t * 0.05f + i * 1.7f) * 0.012f) % 1f) * w;
            float py = (float) ((i * 0.291f + tMove * 0.004f * (0.5f + (i % 5) * 0.13f)) % 1f) * h;
            float tw = 0.25f + 0.55f * (0.5f + 0.5f * (float) Math.sin(t * (0.6f + (i % 4) * 0.21f) + i * 2.3f));
            paint.setColor((i % 3 == 0 ? 0xFF22E39A : 0xFF8B5CF6));
            paint.setAlpha((int) (70 * tw * (0.4f + energy * 0.6f)));
            canvas.drawCircle(px, py, 1.1f + (i % 3) * 0.7f, paint);
        }
        paint.setAlpha(255);

        // ошибка: красная вспышка по краям экрана, потом тихий красный кант
        if (errorNow) {
            long since = System.currentTimeMillis() - errorFlashAt;
            float decay = since < 2500 ? 1f - since / 2500f : 0f;
            int alpha = (int) (30 + 120 * decay * (0.6f + 0.4f * Math.sin(t * 6f)));
            paint.setShader(null);
            paint.setColor(0xFFFF2222);
            float band = 26f * getResources().getDisplayMetrics().density;
            paint.setAlpha(alpha);
            canvas.drawRect(0, 0, w, band, paint);
            canvas.drawRect(0, h - band, w, h, paint);
            canvas.drawRect(0, 0, band, h, paint);
            canvas.drawRect(w - band, 0, w, h, paint);
            paint.setAlpha(255);
        }
    }

    private void drawBlob(Canvas canvas, RadialGradient g, float x, float y, float r, float alpha) {
        matrix.reset();
        matrix.postTranslate(x, y);
        g.setLocalMatrix(matrix);
        paint.setShader(g);
        paint.setAlpha((int) (255 * Math.min(1f, alpha * 1.18f)));
        canvas.drawCircle(x, y, r, paint);
    }
}
