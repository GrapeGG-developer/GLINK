package com.prilozhi.app;

import com.prilozhi.app.identity.IdentityCodec;
import org.junit.Test;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import static org.junit.Assert.*;

public class IdentityCodecTest {
    @Test public void publicIdentityIsStableAndDifferentForDifferentKeys() {
        byte[] k1 = "public-key-1".getBytes(StandardCharsets.UTF_8);
        byte[] k2 = "public-key-2".getBytes(StandardCharsets.UTF_8);
        String id = IdentityCodec.idFromPublicKey(k1);
        assertEquals(id, IdentityCodec.idFromPublicKey(k1));
        assertNotEquals(id, IdentityCodec.idFromPublicKey(k2));
        assertEquals(19, id.length());
        assertEquals('-', id.charAt(4));
        assertEquals('-', id.charAt(9));
        assertEquals('-', id.charAt(14));
    }
    @Test public void idMatchesNodeServerForP256PublicKey() {
        String publicKey = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEHny7K-MKTdnKJl5NRI8_bMBw-Uv318i4Bm6juD2IEC6_OZYL7F0egtIjZPt3ikJROoyB1S4XLL2o7hvSvIqp6Q";
        byte[] der = java.util.Base64.getUrlDecoder().decode(publicKey);
        assertEquals("d3wu-riJk-0XkL-edEU", IdentityCodec.idFromPublicKey(der));
    }
    @Test public void authenticationChallengeIsDomainSeparated() {
        byte[] nonce = new byte[32];
        Arrays.fill(nonce, (byte) 5);
        byte[] msg = IdentityCodec.challengeMessage(nonce);
        assertTrue(msg.length > nonce.length);
        assertEquals("G+ AUTH v1\0", new String(msg, 0, msg.length - 32, StandardCharsets.UTF_8));
        assertArrayEquals(nonce, Arrays.copyOfRange(msg, msg.length - 32, msg.length));
    }
    @Test(expected = IllegalArgumentException.class)
    public void rejectShortChallenge() {
        IdentityCodec.challengeMessage(new byte[31]);
    }
}
