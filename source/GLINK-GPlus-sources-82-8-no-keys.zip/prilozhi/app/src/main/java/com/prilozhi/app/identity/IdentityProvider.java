package com.prilozhi.app.identity;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.Process;

/** Narrow, signature-protected bridge for a separately installed G+ signed by GrapeScript. */
public final class IdentityProvider extends ContentProvider {
    public static final String PERMISSION = "grp.gs.glink.permission.GPLUS_IDENTITY";

    @Override public boolean onCreate() { return true; }

    @Override public Bundle call(String method, String arg, Bundle extras) {
        if (Binder.getCallingUid() != Process.myUid()) {
            if (getContext() == null) throw new SecurityException("Context unavailable");
            getContext().enforceCallingPermission(PERMISSION, "G+ identity requires the GrapeScript signature");
        }
        try {
            Bundle result = new Bundle();
            if ("get_public_identity".equals(method)) {
                result.putString("id", InstallationIdentity.publicId());
                result.putByteArray("public_key", InstallationIdentity.publicKey());
            } else if ("sign_gplus_challenge".equals(method)) {
                byte[] nonce = extras == null ? null : extras.getByteArray("nonce");
                result.putByteArray("signature", InstallationIdentity.signChallenge(nonce));
            } else if ("sign_gplus_digest".equals(method)) {
                result.putByteArray("signature", InstallationIdentity.signGPlusDigest(
                        extras == null ? null : extras.getByteArray("digest")));
            } else if ("get_gplus_encryption_public".equals(method)) {
                result.putByteArray("public_keyset", GPlusCryptoIdentity.publicKeyset(getContext()));
            } else if ("open_gplus_envelope".equals(method)) {
                result.putByteArray("plaintext", GPlusCryptoIdentity.decrypt(getContext(),
                        extras == null ? null : extras.getByteArray("ciphertext"),
                        extras == null ? null : extras.getByteArray("context")));
            } else if ("set_gplus_contact_card".equals(method)) {
                GPlusNfcStore.setOwn(getContext(), extras == null ? null : extras.getByteArray("card"));
            } else if ("get_gplus_pending_contacts".equals(method)) {
                result.putStringArray("cards", GPlusNfcStore.pending(getContext()));
            } else if ("ack_gplus_contact".equals(method)) {
                GPlusNfcStore.ack(getContext(), extras == null ? null : extras.getString("id"));
            } else {
                throw new IllegalArgumentException("Unsupported identity operation");
            }
            return result;
        } catch (SecurityException | IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalStateException("GLINK identity is unavailable", e);
        }
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String order) {
        throw new UnsupportedOperationException();
    }
    @Override public String getType(Uri uri) { return null; }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String where, String[] args) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String where, String[] args) {
        throw new UnsupportedOperationException();
    }
}
