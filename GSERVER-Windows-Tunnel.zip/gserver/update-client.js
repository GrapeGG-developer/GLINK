'use strict';
/* Pinned and signed GSERVER updater. Updates are prepared automatically,
   but installation runs only after the server has stopped. No secret is passed
   in arguments; the verified old runner performs replacement. */
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const U = require('./update-core');
const PIN = '32fdf77aa29b2b054b5c0eebf0a495eb424f8e84ec0fe55afe35c95ea95cf852';
const sleep = ms => new Promise(r => setTimeout(r, ms));
function samePath(a,b) {
  let x=path.resolve(a), y=path.resolve(b);
  if(process.platform==='win32'){x=x.toLowerCase();y=y.toLowerCase();}
  return x===y;
}
function certificate(pem, expected=PIN) {
  const c=new crypto.X509Certificate(pem), fp=crypto.createHash('sha256').update(c.raw).digest('hex');
  if(fp!==expected)throw Error('untrusted_update_certificate');
  return pem;
}
async function readBounded(p,max) {
  const st=await fs.stat(p);if(!st.isFile()||st.size>max)throw Error('update_file_too_large');return fs.readFile(p);
}
async function canonicalPotentialPath(value) {
  if(!path.isAbsolute(value))throw Error('invalid_update_path');
  let base=path.resolve(value),tail=[];
  for(;;){
    try{return path.resolve(await fs.realpath(base),...tail);}
    catch(e){
      if(e.code!=='ENOENT')throw e;
      const parent=path.dirname(base);if(parent===base)throw Error('invalid_update_path');
      tail.unshift(path.basename(base));base=parent;
    }
  }
}
async function normalizePaths(root,data,work) {
  if(!path.isAbsolute(root)||!path.isAbsolute(data)||!path.isAbsolute(work))throw Error('invalid_update_path');
  root=await fs.realpath(root);data=await canonicalPotentialPath(data);work=await canonicalPotentialPath(work);
  if(U.childOf(data,work)||U.childOf(work,data))throw Error('protected_data_path');
  return {root,data,work};
}
async function safeWorkDir(work,segments) {
  let cursor=work;
  for(const part of segments){
    cursor=path.join(cursor,part);
    try{const st=await fs.lstat(cursor);if(st.isSymbolicLink()||!st.isDirectory())throw Error('unsafe_update_work_directory');}
    catch(e){if(e.code!=='ENOENT')throw e;await fs.mkdir(cursor);}
  }
  return cursor;
}
async function checkWorkFile(file) {
  try{const st=await fs.lstat(file);if(st.isSymbolicLink()||!st.isFile())throw Error('unsafe_update_work_file');}
  catch(e){if(e.code!=='ENOENT')throw e;}
}
async function copyRunner(work) {
  const runner=await safeWorkDir(work,['runner']);
  for(const name of ['update-client.js','update-core.js','update-cert.pem']){
    const dest=path.join(runner,name);await checkWorkFile(dest);
    await U.safeCopyAtomic(path.join(__dirname,name),dest);
  }
  for(const name of ['yauzl','pend','buffer-crc32']) {
    const src=path.dirname(require.resolve(name+'/package.json'));
    const dest=await safeWorkDir(work,['runner','node_modules',name]);
    for(const file of await fs.readdir(src,{withFileTypes:true})) {
      if(file.isFile()&&(/\.js$/.test(file.name)||file.name==='package.json')){
        const target=path.join(dest,file.name);await checkWorkFile(target);
        await U.safeCopyAtomic(path.join(src,file.name),target);
      }
    }
  }
}
async function prepare(root,data,work,current,options={}) {
  ({root,data,work}=await normalizePaths(root,data,work));
  try{await fs.access(path.join(work,'journal.json'));throw Error('unfinished_update_recovery_required');}
  catch(e){if(e.code!=='ENOENT')throw e;}
  const pub=certificate(options.pem||await readBounded(path.join(__dirname,'update-cert.pem'),16384),options.pin||PIN);
  const fetch=options.fetch||U.fetchBuffer;
  const raw=await fetch(U.MANIFEST_URL,16384),m=JSON.parse(raw.toString('utf8'));
  if(!U.verifyManifest(m,pub,current))return false;
  const archive=await fetch(U.ARTIFACT_URL,U.MAX_ARCHIVE);U.verifyArchive(archive,m);
  await fs.mkdir(work,{recursive:true});
  const token=crypto.randomBytes(8).toString('hex');
  const trial=path.join(work,'validate-'+token),candidate=path.join(work,'download-'+token+'.part');
  const zip=path.join(work,'download.zip'),ready=path.join(work,'ready.json');
  try {
    await fs.writeFile(candidate,archive,{mode:0o600,flag:'wx'});
    const files=await U.extractArchive(candidate,trial);
    for(const rel of files)await U.ensureSafeTarget(root,data,rel);
    await copyRunner(work);
    await checkWorkFile(zip);await checkWorkFile(ready);
    await fs.rename(candidate,zip);
    /* The marker is written last: interrupted preparation is never ready. */
    await U.atomicJson(ready,{schema:1,root,data,manifest:m});
    return true;
  } finally {await fs.rm(trial,{recursive:true,force:true});await fs.rm(candidate,{force:true});}
}
async function inspectReady(root,data,work,current,options={}) {
  ({root,data,work}=await normalizePaths(root,data,work));
  try{await fs.access(path.join(work,'journal.json'));throw Error('unfinished_update_recovery_required');}
  catch(e){if(e.code!=='ENOENT')throw e;}
  const ready=path.join(work,'ready.json'),zip=path.join(work,'download.zip');
  let item;
  try{await checkWorkFile(ready);item=JSON.parse((await readBounded(ready,32768)).toString('utf8'));}
  catch(e){if(e.code==='ENOENT')return false;throw e;}
  if(!item||item.schema!==1||typeof item.root!=='string'||!path.isAbsolute(item.root)||
     typeof item.data!=='string'||!path.isAbsolute(item.data)||!samePath(item.root,root)||!samePath(item.data,data))return false;
  const pub=certificate(options.pem||await readBounded(path.join(__dirname,'update-cert.pem'),16384),options.pin||PIN);
  if(!U.verifyManifest(item.manifest,pub,current))return false;
  await checkWorkFile(zip);const archive=await readBounded(zip,U.MAX_ARCHIVE);U.verifyArchive(archive,item.manifest);
  /* Refresh the detached runner from the installed copy only after validation. */
  await copyRunner(work);
  return true;
}
async function waitPid(pid,seconds=90) {
  if(!Number.isInteger(pid)||pid<1||pid===process.pid)throw Error('invalid_parent_pid');
  const end=Date.now()+seconds*1000;
  while(Date.now()<end){
    try{process.kill(pid,0);}catch(e){if(e.code==='ESRCH'||e.code==='EINVAL')return;if(e.code!=='EPERM')throw e;}
    await sleep(250);
  }
  throw Error('parent_did_not_exit');
}
async function waitForProbe(cp,work,token,version,timeout=30000) {
  let stopped=false,reason='';cp.once('exit',(code)=>{stopped=true;reason='probe_exited_'+code;});
  cp.once('error',()=>{stopped=true;reason='probe_launch_failed';});
  const ready=path.join(work,'probe-'+token+'.ok'),end=Date.now()+timeout;
  while(Date.now()<end){
    if(stopped)throw Error(reason);
    try{
      const contents=(await readBounded(ready,256)).toString('utf8').trim();
      if(contents!=='GSERVER-UPDATE-PROBE-1:'+version)throw Error('probe_wrong_version');
      return;
    }catch(e){if(e.code!=='ENOENT')throw e;}
    await sleep(250);
  }
  throw Error('probe_timeout');
}
async function terminateProbe(cp) {
  if(!cp||!cp.pid||cp.exitCode!==null||cp.signalCode!==null)return;
  await new Promise(resolve=>{
    const timer=setTimeout(resolve,10000);
    cp.once('exit',()=>{clearTimeout(timer);resolve();});
    try{cp.kill();}catch(_){clearTimeout(timer);resolve();}
  });
  if(cp.exitCode===null&&cp.signalCode===null)throw Error('probe_will_not_stop');
}
async function install(root,data,work,current,resume,options={}) {
  ({root,data,work}=await normalizePaths(root,data,work));
  await checkWorkFile(path.join(work,'ready.json'));await checkWorkFile(path.join(work,'download.zip'));
  const item=JSON.parse((await readBounded(path.join(work,'ready.json'),32768)).toString('utf8'));
  if(item.schema!==1||!samePath(item.root,root)||!samePath(item.data,data))throw Error('update_context_changed');
  const pub=certificate(options.pem||await readBounded(path.join(__dirname,'update-cert.pem'),16384),options.pin||PIN);
  if(!U.verifyManifest(item.manifest,pub,current))throw Error('update_no_longer_new');
  const archive=await readBounded(path.join(work,'download.zip'),U.MAX_ARCHIVE);U.verifyArchive(archive,item.manifest);
  const token=crypto.randomBytes(16).toString('hex'),stage=path.join(work,'stage-'+token);
  const zip=path.join(work,'download.zip'), probeFile=path.join(work,'probe.current');let cp=null;
  try {
    const files=await U.extractArchive(zip,stage);
    await U.applyFiles(root,data,work,stage,files,async()=>{
      await U.atomicJson(probeFile,{schema:1,token});
      cp=(options.spawn||spawn)(path.join(root,'GSERVER.exe'),['--update-probe='+token,...(resume?['--resume-after-update']:[])],
        {cwd:root,detached:true,stdio:'ignore',windowsHide:false});
      try{
        await waitForProbe(cp,work,token,item.manifest.versionCode,options.probeTimeout||30000);
        if(options.afterProbe)await options.afterProbe(); /* fault-injection hook for local tests only */
      }catch(e){await terminateProbe(cp);throw e;}
    });
    await fs.writeFile(path.join(work,'commit-'+token+'.ok'),'committed\n',{mode:0o600});
    if(cp)cp.unref();
    await fs.rm(probeFile,{force:true});
    await fs.rm(path.join(work,'ready.json'),{force:true});await fs.rm(zip,{force:true});
    return true;
  } finally {
    await fs.rm(stage,{recursive:true,force:true});
    const journalExists=await fs.access(path.join(work,'journal.json')).then(()=>true,()=>false);
    if(!journalExists){
      await fs.rm(probeFile,{force:true});
      await fs.rm(path.join(work,'probe-'+token+'.ok'),{force:true});
      await fs.rm(path.join(work,'abort-'+token+'.ok'),{force:true});
    }
  }
}
async function recoverAfterExit(root,work,pid,options={}) {
  await (options.waitPid||waitPid)(pid);root=await fs.realpath(root);work=await canonicalPotentialPath(work);
  const file=path.join(work,'journal.json');
  let j;try{await checkWorkFile(file);j=JSON.parse((await readBounded(file,1024*1024)).toString('utf8'));}
  catch(e){if(e.code==='ENOENT')return false;throw e;}
  if(!j||typeof j.root!=='string'||!path.isAbsolute(j.root)||!samePath(root,j.root)||!path.isAbsolute(j.dataRoot||''))throw Error('invalid_update_journal');
  const safe=await normalizePaths(root,j.dataRoot,work);
  if(!samePath(safe.data,j.dataRoot))throw Error('invalid_update_journal');
  root=safe.root;work=safe.work;
  try{
    const probe=path.join(work,'probe.current');await checkWorkFile(probe);
    const q=JSON.parse((await readBounded(probe,1024)).toString('utf8'));
    if(q.schema===1&&/^[a-f0-9]{32}$/.test(q.token)){
      const abort=path.join(work,'abort-'+q.token+'.ok');await checkWorkFile(abort);
      await fs.writeFile(abort,'abort\n',{flag:'wx'}).catch(e=>{if(e.code!=='EEXIST')throw e;});
      await sleep(options.probeStopDelay??1800);
    }
  }catch(e){if(e.code!=='ENOENT')throw e;}
  let failure;
  for(let i=0;i<20;i++){
    try{const rolledBack=await U.recover(root,j.dataRoot,work);await fs.rm(path.join(work,'probe.current'),{force:true});return rolledBack;}
    catch(e){failure=e;if(!['EBUSY','EPERM','EACCES'].includes(e.code))throw e;await sleep(1000);}
  }
  throw failure||Error('rollback_failed_keep_backups');
}
async function cli(){
  const [cmd,root,a,b,c,d,e]=process.argv.slice(2);
  if(!root||!path.isAbsolute(root))throw Error('invalid_update_path');
  if(cmd==='check')return (await prepare(root,a,b,Number(c)))?10:0;
  if(cmd==='inspect')return (await inspectReady(root,a,b,Number(c)))?10:0;
  if(cmd==='install'){
    await waitPid(Number(d));
    try{await install(root,a,b,Number(c),e==='1');return 0;}
    catch(error){
      let recovered=true;
      try{await recoverAfterExit(root,b,1,{waitPid:async()=>{}});}catch(_){recovered=false;}
      const args=[recovered?'--update-failed':'--recovery-failed'];
      try{const cp=spawn(path.join(root,'GSERVER.exe'),args,{cwd:root,detached:true,stdio:'ignore'});cp.unref();}catch(_){}
      throw error;
    }
  }
  if(cmd==='recover'){
    try{
      await recoverAfterExit(root,a,Number(b));
      const cp=spawn(path.join(root,'GSERVER.exe'),['--recovered'],{cwd:root,detached:true,stdio:'ignore'});cp.unref();return 0;
    }catch(error){
      try{const cp=spawn(path.join(root,'GSERVER.exe'),['--recovery-failed'],{cwd:root,detached:true,stdio:'ignore'});cp.unref();}catch(_){}
      throw error;
    }
  }
  throw Error('invalid_update_command');
}
if(require.main===module)cli().then(code=>{process.exitCode=code;}).catch(e=>{
  console.error('GSERVER update:',e&&e.message||'unknown_error');process.exitCode=1;
});
module.exports={samePath,certificate,canonicalPotentialPath,normalizePaths,prepare,inspectReady,waitPid,waitForProbe,terminateProbe,install,recoverAfterExit};
