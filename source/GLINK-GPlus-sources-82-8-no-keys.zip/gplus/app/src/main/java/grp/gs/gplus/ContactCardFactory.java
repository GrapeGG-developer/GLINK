package grp.gs.gplus;

import grp.gs.protocol.Protocol;
import org.json.JSONObject;

/** Create and sign a public NFC contact card with the GLINK-held keys. */
public final class ContactCardFactory {
    private ContactCardFactory() {}
    public static byte[] create(JSONObject profile,GlinkBridge bridge)throws Exception {
        if(profile==null)throw new IllegalStateException("Для знакомства нужен вход в G+");
        JSONObject fields=profile.optJSONObject("profile");if(fields==null)fields=new JSONObject();
        String id=bridge.id(), nick=Protocol.nickname(profile.optString("nickname"));
        if(nick==null)throw new IllegalStateException("Нужен уникальный @ник");
        String display=profile.optString("display_name",nick);
        byte[] identity=bridge.publicKey(), encryption=bridge.encryptionPublic();
        Protocol.Card unsigned=new Protocol.Card(id,nick,display,fields.optString("bio",""),fields.optString("city",""),fields.optString("website",""),identity,encryption,null);
        byte[] sig=bridge.signDigest(unsigned.digest());
        Protocol.Card signed=new Protocol.Card(id,nick,display,unsigned.bio,unsigned.city,unsigned.website,identity,encryption,sig);
        return Protocol.encodeCard(signed);
    }
}
