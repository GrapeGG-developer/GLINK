package grp.gs.protocol;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.ECPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.text.Normalizer;
import java.util.Arrays;
import java.util.Base64;
import java.util.Locale;

/** Canonical, domain-separated formats shared by G+ and GLINK. No secrets or Android APIs here. */
public final class Protocol {
    public static final byte[] SIGN_DOMAIN = "G+ SIGNATURE v1\0".getBytes(StandardCharsets.UTF_8);
    private static final byte[] CONTACT_DOMAIN = "G+ CONTACT v1\0".getBytes(StandardCharsets.UTF_8);
    private static final byte[] MESSAGE_DOMAIN = "G+ MESSAGE v1\0".getBytes(StandardCharsets.UTF_8);
    private static final byte[] BOX_DOMAIN = "G+ BOX v1\0".getBytes(StandardCharsets.UTF_8);
    private static final byte[] DIRECT_DOMAIN = "G+ DIRECT v1\0".getBytes(StandardCharsets.UTF_8);
    private static final byte[] NFC_DOMAIN = "G+ NFC PROOF v1\0".getBytes(StandardCharsets.UTF_8);
    private static final byte[] MEDIA_DOMAIN = "G+ MEDIA v1\0".getBytes(StandardCharsets.UTF_8);
    private static final byte[] GROUP_DOMAIN = "G+ GROUP v1\0".getBytes(StandardCharsets.UTF_8);
    private static final byte[] MAGIC = new byte[]{'G','P','C','1'};
    private static final BigInteger P256_ORDER = new BigInteger("FFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551",16);
    public static final int MAX_CARD = 8192;
    private Protocol() {}

    public static String b64(byte[] bytes) { return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes); }
    public static byte[] unb64(String value) { return Base64.getUrlDecoder().decode(value); }
    public static byte[] sha256(byte[] bytes) throws Exception { return MessageDigest.getInstance("SHA-256").digest(bytes); }
    public static String identityId(byte[] publicKey) throws Exception {
        String s = b64(Arrays.copyOf(sha256(publicKey),12));
        return s.substring(0,4)+"-"+s.substring(4,8)+"-"+s.substring(8,12)+"-"+s.substring(12,16);
    }
    public static String nickname(String s) {
        if (s==null) return null;
        String n=s.trim(); if(n.startsWith("@")) n=n.substring(1);
        n=Normalizer.normalize(n,Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);
        return n.matches("[\\p{L}\\p{N}_]{3,32}") ? n : null;
    }
    public static boolean validId(String id) { return id!=null && id.matches("[A-Za-z0-9_-]{4}-[A-Za-z0-9_-]{4}-[A-Za-z0-9_-]{4}-[A-Za-z0-9_-]{4}"); }
    public static boolean validChatId(String id) { return id!=null && id.matches("[dgc]_[A-Za-z0-9_-]{22,43}"); }
    public static boolean validEventId(String id) { return id!=null && id.matches("[A-Za-z0-9_-]{22}"); }
    private static byte[] utf8(String value) { return value.getBytes(StandardCharsets.UTF_8); }
    private static String text(byte[] bytes) throws CharacterCodingException {
        return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
    }
    private static void field(DataOutputStream out,byte[] value) throws IOException { out.writeInt(value.length); out.write(value); }
    private static byte[] packed(byte[] domain,byte[]... fields) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(domain);
        DataOutputStream d=new DataOutputStream(out);for(byte[] value:fields)field(d,value);d.flush();return out.toByteArray();
    }
    private static byte[] readField(DataInputStream in,int maximum) throws IOException {
        int n=in.readInt();if(n<0 || n>maximum || n>in.available())throw new IOException("Invalid contact field");
        byte[] b=new byte[n];in.readFully(b);return b;
    }
    private static boolean clean(String s,int max) {
        if(s==null || s.length()>max) return false;
        for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c<32 && c!='\n' && c!='\t')return false;}
        return true;
    }

    /** Public signed profile transmitted only by the NFC contact flow in our clients. */
    public static final class Card {
        public final String id,nick,display,bio,city,website;
        public final byte[] identityPublic,encryptionPublic,signature;
        public Card(String id,String nick,String display,String bio,String city,String website,byte[] sign,byte[] enc,byte[] signature) {
            this.id=id;this.nick=nick;this.display=display;this.bio=bio;this.city=city;this.website=website;
            this.identityPublic=sign==null?null:sign.clone();this.encryptionPublic=enc==null?null:enc.clone();
            this.signature=signature==null?null:signature.clone();
        }
        public byte[] digest() throws Exception {
            validateFields();
            return sha256(packed(CONTACT_DOMAIN,utf8(id),utf8(nick),utf8(display),utf8(bio),utf8(city),utf8(website),identityPublic,encryptionPublic));
        }
        private void validateFields() throws Exception {
            if(!validId(id)||identityPublic==null||!id.equals(identityId(identityPublic)))throw new SecurityException("Invalid identity");
            String canonical=nickname(nick);if(canonical==null || !canonical.equals(nick))throw new SecurityException("Invalid nickname");
            if(!clean(display,80)||display.trim().isEmpty()||!clean(bio,500)||!clean(city,80)||!clean(website,256)
                    ||(!website.isEmpty()&&!website.matches("(?i)https://[^\\s]+"))) throw new SecurityException("Invalid profile");
            if(identityPublic.length<80||identityPublic.length>160||encryptionPublic==null||encryptionPublic.length<50||encryptionPublic.length>2048)
                throw new SecurityException("Invalid contact keys");
            parseP256(identityPublic);
        }
        public void verify() throws Exception {
            if(signature==null || signature.length<8 || signature.length>160 || !verifySignature(identityPublic,digest(),signature))
                throw new SecurityException("Invalid contact signature");
        }
    }
    public static byte[] encodeCard(Card c) throws Exception {
        c.verify();ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream d=new DataOutputStream(bytes);
        d.write(MAGIC);field(d,utf8(c.id));field(d,utf8(c.nick));field(d,utf8(c.display));field(d,utf8(c.bio));field(d,utf8(c.city));field(d,utf8(c.website));
        field(d,c.identityPublic);field(d,c.encryptionPublic);field(d,c.signature);d.flush();
        byte[] out=bytes.toByteArray();if(out.length>MAX_CARD)throw new IOException("Contact too large");return out;
    }
    public static Card decodeCard(byte[] bytes) throws Exception {
        if(bytes==null||bytes.length>MAX_CARD||bytes.length<4)throw new IOException("Invalid contact");
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes));byte[] magic=new byte[4];in.readFully(magic);
        if(!Arrays.equals(magic,MAGIC))throw new IOException("Unknown contact format");
        String id=text(readField(in,80)),nick=text(readField(in,160)),display=text(readField(in,400));
        String bio=text(readField(in,2400)),city=text(readField(in,400)),website=text(readField(in,1024));
        byte[] sign=readField(in,160), enc=readField(in,2048), sig=readField(in,160);
        if(in.available()!=0)throw new IOException("Contact trailing bytes");
        Card card=new Card(id,nick,display,bio,city,website,sign,enc,sig);card.verify();return card;
    }
    private static PublicKey parseP256(byte[] bytes) throws Exception {
        PublicKey p=KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(bytes));
        if(!(p instanceof ECPublicKey)||!((ECPublicKey)p).getParams().getOrder().equals(P256_ORDER))throw new SecurityException("Wrong signing curve");return p;
    }
    public static boolean verifySignature(byte[] pub,byte[] digest,byte[] sig) throws Exception {
        if(digest==null||digest.length!=32||sig==null||sig.length>160)return false;
        Signature s=Signature.getInstance("SHA256withECDSA");s.initVerify(parseP256(pub));s.update(SIGN_DOMAIN);s.update(digest);return s.verify(sig);
    }
    public static byte[] boxContext(String chat,String event,String from,String to) throws Exception {
        if(!validChatId(chat)||!validEventId(event)||!validId(from)||!validId(to))throw new IllegalArgumentException("Invalid message context");
        return packed(BOX_DOMAIN,utf8(chat),utf8(event),utf8(from),utf8(to));
    }
    public static byte[] messageDigest(String chat,String event,String from,String to,byte[] ciphertext) throws Exception {
        if(ciphertext==null||ciphertext.length<20||ciphertext.length>131072)throw new IllegalArgumentException("Invalid ciphertext");
        return sha256(packed(MESSAGE_DOMAIN,boxContext(chat,event,from,to),ciphertext));
    }
    /** Owner-signed, immutable membership. Cards must be in strictly increasing ID order. */
    public static byte[] groupDigest(String chat,String kind,String title,String owner,java.util.List<byte[]> cards)throws Exception {
        if(!validChatId(chat)||!("group".equals(kind)&&chat.startsWith("g_")||"channel".equals(kind)&&chat.startsWith("c_"))||!validId(owner)||!clean(title,80)||title.trim().isEmpty()||cards==null||cards.size()<2||cards.size()>50)throw new IllegalArgumentException("Invalid group");
        java.util.List<byte[]> fields=new java.util.ArrayList<>();fields.add(utf8(chat));fields.add(utf8(kind));fields.add(utf8(title));fields.add(utf8(owner));
        String previous="";boolean hasOwner=false;for(byte[] raw:cards){Card c=decodeCard(raw);if(c.id.compareTo(previous)<=0)throw new SecurityException("Group members not canonical");previous=c.id;if(c.id.equals(owner))hasOwner=true;fields.add(raw);}
        if(!hasOwner)throw new SecurityException("Group owner is not a member");return sha256(packed(GROUP_DOMAIN,fields.toArray(new byte[0][])));
    }
    public static byte[] mediaContext(String chat,String asset)throws Exception {if(!validChatId(chat)||!validEventId(asset))throw new IllegalArgumentException("Invalid media context");return packed(MEDIA_DOMAIN,utf8(chat),utf8(asset));}
    public static byte[] nfcProof(byte[] readerCard,byte[] hceCard,byte[] readerNonce,byte[] hceNonce,String role)throws Exception {
        if(readerCard==null||hceCard==null||readerCard.length>MAX_CARD||hceCard.length>MAX_CARD||readerNonce==null||readerNonce.length!=32||hceNonce==null||hceNonce.length!=32||(!"reader".equals(role)&&!"hce".equals(role)))throw new IllegalArgumentException("Invalid NFC proof");
        return sha256(packed(NFC_DOMAIN,readerCard,hceCard,readerNonce,hceNonce,utf8(role)));
    }
    public static String directChat(String a,String b) throws Exception {
        if(!validId(a)||!validId(b)||a.equals(b))throw new IllegalArgumentException("Invalid direct members");
        String x=a.compareTo(b)<0?a:b, y=a.compareTo(b)<0?b:a;
        return "d_"+b64(Arrays.copyOf(sha256(packed(DIRECT_DOMAIN,utf8(x),utf8(y))),16));
    }
}
