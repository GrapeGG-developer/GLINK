package com.prilozhi.app.identity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MotionEvent;

/** Explicit, domain-separated gPLAYLANDg proof. The private key remains in GLINK. */
public class GPlaySignInActivity extends Activity {
    public static final String EXTRA_NONCE = "gplay_nonce";
    public static final String EXTRA_PUBLIC_KEY = "gplay_public_key";
    public static final String EXTRA_SIGNATURE = "gplay_signature";
    private byte[] nonce;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setResult(RESULT_CANCELED);
        if (!authorizedCaller()) { finish(); return; }
        try {
            nonce = getIntent() == null ? null : getIntent().getByteArrayExtra(EXTRA_NONCE);
        } catch (RuntimeException badIntent) {
            nonce = null;
        }
        if (nonce == null || nonce.length != 32) { nonce = null; finish(); return; }
        nonce = nonce.clone();
        getWindow().getDecorView().setFilterTouchesWhenObscured(true);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Вход в gPLAYLANDg")
                .setMessage("Разрешить вход через GLINK на этом устройстве? "
                        + "gPLAYLANDg получит открытый идентификатор и подтверждение входа. "
                        + "Закрытый ключ останется в GLINK.")
                .setPositiveButton("Разрешить", (d, which) -> approve())
                .setNegativeButton("Отмена", (d, which) -> finish())
                .setOnCancelListener(d -> finish())
                .create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setFilterTouchesWhenObscured(true);
    }

    /** Manifest permission is the primary gate; reject launches without a result recipient too. */
    protected boolean authorizedCaller() {
        String caller = getCallingPackage();
        if (caller == null) return false;
        try {
            return getPackageManager().checkSignatures(getPackageName(), caller) == PackageManager.SIGNATURE_MATCH;
        } catch (RuntimeException unavailable) {
            return false;
        }
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        int blocked = MotionEvent.FLAG_WINDOW_IS_OBSCURED | MotionEvent.FLAG_WINDOW_IS_PARTIALLY_OBSCURED;
        if ((event.getFlags() & blocked) != 0) return true;
        return super.dispatchTouchEvent(event);
    }

    protected byte[] publicKey() throws Exception { return InstallationIdentity.publicKey(); }
    protected byte[] sign(byte[] challenge) throws Exception { return InstallationIdentity.signGplayChallenge(challenge); }

    private void approve() {
        byte[] challenge = nonce;
        nonce = null;
        if (challenge == null) return;
        try {
            byte[] key = publicKey();
            byte[] signature = sign(challenge);
            Intent result = new Intent();
            result.putExtra(EXTRA_PUBLIC_KEY, key);
            result.putExtra(EXTRA_SIGNATURE, signature);
            setResult(RESULT_OK, result);
        } catch (Exception unavailable) {
            setResult(RESULT_CANCELED);
        } finally {
            finish();
        }
    }

    @Override protected void onDestroy() {
        nonce = null;
        super.onDestroy();
    }
}
