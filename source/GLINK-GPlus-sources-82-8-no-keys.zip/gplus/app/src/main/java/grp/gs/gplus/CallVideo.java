package grp.gs.gplus;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.util.Size;
import android.view.Surface;
import java.nio.ByteBuffer;
import java.util.Collections;

/** Best-effort low-rate front-camera JPEG frames, always inside the encrypted call session. */
final class CallVideo implements AutoCloseable {
    interface Sink {void send(byte[] jpeg,int rotation);void failed();}
    private final Context context;private final Sink sink;private final int displayRotation;
    private HandlerThread thread;private Handler handler;private ImageReader reader;private CameraDevice device;private CameraCaptureSession session;
    private volatile boolean closed;private long lastFrame;private int imageRotation;
    CallVideo(Context c,Sink s,int rotation){context=c.getApplicationContext();sink=s;displayRotation=rotation;}
    @SuppressLint("MissingPermission") void start()throws Exception{
        if(context.checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)throw new SecurityException("Нужен доступ к камере");
        CameraManager manager=(CameraManager)context.getSystemService(Context.CAMERA_SERVICE);String id=null;CameraCharacteristics chars=null;
        for(String candidate:manager.getCameraIdList()){CameraCharacteristics c=manager.getCameraCharacteristics(candidate);Integer lens=c.get(CameraCharacteristics.LENS_FACING);if(lens!=null&&lens==CameraCharacteristics.LENS_FACING_FRONT){id=candidate;chars=c;break;}}
        if(id==null)throw new IllegalStateException("Фронтальная камера недоступна");
        StreamConfigurationMap map=chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);Size[] sizes=map==null?null:map.getOutputSizes(ImageFormat.JPEG);if(sizes==null||sizes.length==0)throw new IllegalStateException("Видео недоступно");
        Size chosen=sizes[0];long best=Long.MAX_VALUE;for(Size size:sizes){if(size.getWidth()>1280||size.getHeight()>1280)continue;long score=Math.abs(size.getWidth()-320L)+Math.abs(size.getHeight()-240L);if(score<best){best=score;chosen=size;}}if(best==Long.MAX_VALUE)throw new IllegalStateException("Нет подходящего размера камеры");
        Integer orientation=chars.get(CameraCharacteristics.SENSOR_ORIENTATION);int rotationDegrees=displayRotation==Surface.ROTATION_90?90:displayRotation==Surface.ROTATION_180?180:displayRotation==Surface.ROTATION_270?270:0;imageRotation=((orientation==null?0:orientation)-rotationDegrees+360)%360;
        thread=new HandlerThread("GPlusCallCamera");thread.start();handler=new Handler(thread.getLooper());reader=ImageReader.newInstance(chosen.getWidth(),chosen.getHeight(),ImageFormat.JPEG,2);
        reader.setOnImageAvailableListener(source->{Image image=null;try{image=source.acquireLatestImage();long now=SystemClock.elapsedRealtime();if(image==null||closed||now-lastFrame<200)return;lastFrame=now;ByteBuffer data=image.getPlanes()[0].getBuffer();if(data.remaining()>grp.gs.protocol.CallCrypto.MAX_PAYLOAD-1)return;byte[] jpeg=new byte[data.remaining()];data.get(jpeg);sink.send(jpeg,imageRotation);}catch(Exception ignored){}finally{if(image!=null)image.close();}},handler);
        manager.openCamera(id,new CameraDevice.StateCallback(){
            @Override public void onOpened(CameraDevice camera){if(closed){camera.close();return;}device=camera;try{camera.createCaptureSession(Collections.singletonList(reader.getSurface()),new CameraCaptureSession.StateCallback(){
                @Override public void onConfigured(CameraCaptureSession configured){if(closed){configured.close();return;}session=configured;try{CaptureRequest.Builder request=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);request.addTarget(reader.getSurface());request.set(CaptureRequest.CONTROL_MODE,CaptureRequest.CONTROL_MODE_AUTO);request.set(CaptureRequest.JPEG_QUALITY,(byte)60);request.set(CaptureRequest.JPEG_ORIENTATION,0);configured.setRepeatingRequest(request.build(),null,handler);}catch(Exception e){sink.failed();}}
                @Override public void onConfigureFailed(CameraCaptureSession failed){if(!closed)sink.failed();}
            },handler);}catch(Exception e){if(!closed)sink.failed();}}
            @Override public void onDisconnected(CameraDevice camera){camera.close();if(!closed)sink.failed();}
            @Override public void onError(CameraDevice camera,int error){camera.close();if(!closed)sink.failed();}
        },handler);
    }
    @Override public synchronized void close(){closed=true;if(session!=null){try{session.close();}catch(Exception ignored){}session=null;}if(device!=null){try{device.close();}catch(Exception ignored){}device=null;}if(reader!=null){try{reader.close();}catch(Exception ignored){}reader=null;}if(thread!=null){thread.quitSafely();thread=null;}}
}
