package com.prilozhi.app.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.webkit.WebView;

/** An animation surface, never a touch target: the parent handles logo taps. */
public final class PassiveLogoWebView extends WebView {
    public PassiveLogoWebView(Context c, AttributeSet a) { super(c, a); setFocusable(false); setClickable(false); }
    @Override public boolean dispatchTouchEvent(MotionEvent event) { return false; }
}
