package grp.gs.gplus;

import grp.gs.protocol.Protocol;
import org.json.JSONObject;
import java.security.KeyPair;
import java.security.SecureRandom;

/** Validation of call signaling AFTER ChatEngine has verified the sender and decrypted the envelope. */
final class CallSignal {
    private static final long MAX_AGE=120_000,MAX_FUTURE=15_000;
    static final class Offer {final String call;final byte[] key;final boolean video;Offer(String c,byte[] k,boolean v){call=c;key=k;video=v;}}
    static String newId(){byte[] b=new byte[16];new SecureRandom().nextBytes(b);return Protocol.b64(b);}
    static JSONObject offer(String id,KeyPair ephemeral,boolean video)throws Exception{return signal("call_offer",id).put("key",Protocol.b64(ephemeral.getPublic().getEncoded())).put("video",video);}
    static JSONObject answer(String id,KeyPair ephemeral)throws Exception{return signal("call_answer",id).put("key",Protocol.b64(ephemeral.getPublic().getEncoded()));}
    static JSONObject end(String id)throws Exception{return signal("call_end",id);}
    private static JSONObject signal(String type,String call)throws Exception{if(!Protocol.validEventId(call))throw new SecurityException("Invalid call");return new JSONObject().put("v",1).put("type",type).put("call",call).put("at",System.currentTimeMillis());}
    static boolean fresh(JSONObject obj,long now){long at=obj.optLong("at",0);return at>0&&at<=now+MAX_FUTURE&&at>=now-MAX_AGE;}
    private static byte[] key(JSONObject obj){try{String encoded=obj.optString("key","");if(encoded.length()<100||encoded.length()>220)return null;byte[] key=Protocol.unb64(encoded);return key.length>=80&&key.length<=160?key:null;}catch(Exception e){return null;}}
    static Offer parseOffer(ChatEngine.Message m,String peer,long now){if(m==null||!peer.equals(m.sender)||!"call_offer".equals(m.content.optString("type"))||!fresh(m.content,now))return null;String id=m.content.optString("call","");byte[] key=key(m.content);if(!Protocol.validEventId(id)||key==null||!m.content.has("video")||!(m.content.opt("video") instanceof Boolean))return null;return new Offer(id,key,m.content.optBoolean("video"));}
    static byte[] parseAnswer(ChatEngine.Message m,String peer,String call,long now){return m!=null&&peer.equals(m.sender)&&"call_answer".equals(m.content.optString("type"))&&call.equals(m.content.optString("call"))&&fresh(m.content,now)?key(m.content):null;}
    static boolean isEnd(ChatEngine.Message m,String peer,String call,long now){return m!=null&&peer.equals(m.sender)&&"call_end".equals(m.content.optString("type"))&&call.equals(m.content.optString("call"))&&fresh(m.content,now);}
}
