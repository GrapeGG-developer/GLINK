'use strict';
/* Read-only, unauthenticated diagnostic for the configured HTTPS coordinator.
   Its bounded key/value output contains no URL, IP address, body, path, proxy
   setting, credential or arbitrary error text. The Windows parent checks every
   field again before offering the user a copy. */
const { dnsProbe, httpsProbe, upgradeProbe } = require('./deep-diagnose');
const { fragmentedTlsAgent } = require('../tls-handshake-fallback');

function parseOrigin(value) {
  if (typeof value !== 'string' || value.length > 2048 || /[\x00-\x20\x7f?#\\]/.test(value)) throw Error('invalid_origin');
  const u = new URL(value);
  if (u.protocol !== 'https:' || !u.hostname || u.username || u.password || u.pathname !== '/') throw Error('invalid_origin');
  const port = u.port ? Number(u.port) : 443;
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw Error('invalid_origin');
  // URL.hostname includes brackets for IPv6 literals, but net/tls expect none.
  const host = u.hostname.startsWith('[') && u.hostname.endsWith(']') ? u.hostname.slice(1, -1) : u.hostname;
  return { host, port };
}
function ms(value) {
  return String(Math.min(180000, Math.max(0, Number.isFinite(value) ? Math.floor(value) : 0)));
}
async function collect(value, dependencies = {}) {
  const origin = parseOrigin(value);
  const dns = dependencies.dnsProbe || dnsProbe;
  const get = dependencies.httpsProbe || httpsProbe;
  const ws = dependencies.upgradeProbe || upgradeProbe;
  const dnsResult = await dns({ host: origin.host, timeout: 5000 });
  const result = { dns4: dnsResult.error ? 'ERROR_' + dnsResult.error : dnsResult.v4 ? 'YES' : 'NO',
    dns6: dnsResult.error ? 'ERROR_' + dnsResult.error : dnsResult.v6 ? 'YES' : 'NO', families: {} };
  async function familyCheck(family, hasAddress) {
    if (!hasAddress && !dnsResult.error) {
      result.families[family] = { https: { result: 'SKIPPED', ms: 0 }, fragmented: { result: 'SKIPPED', ms: 0 },
        wss: { steps: { dns: 'SKIPPED', tcp: 'SKIPPED', tls: 'SKIPPED', upgrade: 'SKIPPED' }, ms: 0 } };
      return;
    }
    const options = { host: origin.host, port: origin.port, family, timeout: 9000 };
    // Two direct HTTPS paths are useful when a normal TLS ClientHello stalls.
    // The second changes record framing only; it still verifies certificates.
    const [normal, fragmented, wss] = await Promise.all([
      get(options), get({ ...options, agentFactory: fragmentedTlsAgent }), ws(options)
    ]);
    result.families[family] = { https: normal, fragmented, wss };
  }
  await Promise.all([familyCheck(4, dnsResult.v4), familyCheck(6, dnsResult.v6)]);
  return result;
}
function render(value) {
  const lines = ['DIAG_VERSION=1', 'DNS4=' + value.dns4, 'DNS6=' + value.dns6];
  for (const family of [4, 6]) {
    const f = value.families[family];
    lines.push('HTTPS' + family + '=' + f.https.result, 'HTTPS' + family + '_MS=' + ms(f.https.ms));
    lines.push('FRAG' + family + '=' + f.fragmented.result, 'FRAG' + family + '_MS=' + ms(f.fragmented.ms));
    for (const step of ['dns', 'tcp', 'tls', 'upgrade'])
      lines.push('WSS' + family + '_' + (step === 'upgrade' ? 'UP' : step.toUpperCase()) + '=' + f.wss.steps[step]);
    lines.push('WSS' + family + '_MS=' + ms(f.wss.ms));
  }
  lines.push('END=OK');
  return lines.join('\n') + '\n';
}
async function main() {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = '1';
  const report = await collect(process.argv[2]);
  process.stdout.write(render(report));
}
if (require.main === module) main().catch(() => {
  // Never print an exception, argument, URL or arbitrary Node error text.
  process.stdout.write('DIAG_VERSION=1\nEND=ERROR\n');
  process.exitCode = 1;
});
module.exports = { parseOrigin, collect, render };
