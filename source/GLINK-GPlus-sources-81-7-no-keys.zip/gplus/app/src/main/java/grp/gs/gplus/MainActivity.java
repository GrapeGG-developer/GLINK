package grp.gs.gplus;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.ComponentName;
import android.os.Build;
import grp.gs.protocol.Protocol;
import java.util.ArrayList;
import java.util.List;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** G+ development build: actual GLINK identity login and profile, no simulated messenger. */
public class MainActivity extends Activity {
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private GlinkBridge identity;
    private GPlusApi api;
    private JSONObject me;
    private String deviceId = "", connection = "Проверяем GLINK…";
    private boolean working, missingGlink, retryShown;
    private FrameLayout frame, drawer;
    private TextView status, identityLine, serverBadge;
    private String serverLabel="Сервер · проверка";
    private boolean serverStatusChecking;
    private final Runnable serverStatusLoop=new Runnable(){@Override public void run(){
        if(!resumed)return;
        if(!serverStatusChecking){serverStatusChecking=true;new Thread(()->{
            String result=ServerIndicator.check(BuildConfig.GPLUS_API_BASE);
            main.post(()->{serverStatusChecking=false;if(resumed&&!isFinishing()&&!isDestroyed()){serverLabel=result;if(serverBadge!=null)serverBadge.setText(result);}});
        },"gplus-server-status").start();}
        main.postDelayed(this,60000);
    }};
    private ThemeColors t;
    private GPlusStore store;
    private ChatEngine chatEngine;
    private GroupEngine groupEngine;
    private GPlusUpdateManager updater;
    private VoiceUi voiceUi;private VoicePlayback voicePlayback;
    private List<Protocol.Card> contacts=new ArrayList<>();
    private List<SignedGroup> groups=new ArrayList<>();
    private Protocol.Card activePeer;
    private LinearLayout messageColumn;
    private ScrollView messageScroll;
    private EditText messageInput;
    private TextView chatStatus;
    private boolean syncBusy, resumed, showArchive, incomingDialog;
    private long peerRead;
    private String searchQuery="";
    private String replyTo="", requestedPeer="";
    private static final int PICK_MEDIA=4710,SAVE_MEDIA=4711;
    private Timeline.Item selectedMedia;private Protocol.Card mediaPeer;
    private final BroadcastReceiver contactUpdates=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){refreshContacts();}};
    private final Runnable pollChat=new Runnable(){@Override public void run(){if(resumed&&activePeer!=null){syncChat(true);main.postDelayed(this,10000);}}};

    private static final class ThemeColors {
        final int bg, panel, stroke, text, secondary, accent, accentInk, iconSurface;
        final boolean light;
        ThemeColors(int bg, int panel, int stroke, int text, int secondary, int accent, int accentInk, int iconSurface, boolean light) {
            this.bg=bg; this.panel=panel; this.stroke=stroke; this.text=text; this.secondary=secondary;
            this.accent=accent; this.accentInk=accentInk; this.iconSurface=iconSurface; this.light=light;
        }
    }
    private ThemeColors colors() {
        switch (prefs.getString("theme", "navy")) {
            case "yellow": return new ThemeColors(0xff10100e,0xff1c1c18,0xff38382f,0xfffffcef,0xffaaa797,0xffffd83d,0xff191509,0xff2a291e,false);
            case "white": return new ThemeColors(0xfff8f6fc,0xffffffff,0xffe8e2f1,0xff211a31,0xff787083,0xff7c45e7,0xffffffff,0xfff1eafb,true);
            default: return new ThemeColors(0xff0a1423,0xff111f32,0xff293c54,0xfff4f7fc,0xff9aacc1,0xffa18dff,0xff141026,0xff1c2e45,false);
        }
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("gplus_settings", MODE_PRIVATE);
        identity = new GlinkBridge(this); api = new GPlusApi(BuildConfig.GPLUS_API_BASE, identity);
        store=new GPlusStore(this);chatEngine=new ChatEngine(identity,api,store);groupEngine=new GroupEngine(identity,api,store);updater=new GPlusUpdateManager(this);voiceUi=new VoiceUi(this,this::queueVoice);voicePlayback=new VoicePlayback(this,api,store,prefs,io);VoiceUi.clearStale(this);
        requestedPeer=getIntent()==null?"":getIntent().getStringExtra("peer_id");if(requestedPeer==null)requestedPeer="";
        IntentFilter f=new IntentFilter("grp.gs.gplus.CONTACTS_UPDATED");
        if(Build.VERSION.SDK_INT>=33)registerReceiver(contactUpdates,f,Context.RECEIVER_NOT_EXPORTED);else registerLegacyContactUpdates(f);
        render(); refreshContacts();
        if(prefs.getBoolean("key_loss_notice_ack",false))connect();else showKeyLossNotice();
    }
    private void showKeyLossNotice(){
        if(isFinishing()||isDestroyed())return;
        new AlertDialog.Builder(this).setTitle("Важно: доступ к аккаунту")
            .setMessage("G+ использует ключ GLINK, который хранится на этом устройстве. Если потерять телефон, удалить GLINK или потерять его ключ, восстановить прежний аккаунт и доступ к зашифрованной переписке нельзя. Номер телефона и секретная фраза не используются.")
            .setCancelable(false).setPositiveButton("Понятно",(d,w)->{prefs.edit().putBoolean("key_loss_notice_ack",true).apply();connect();}).show();
    }
    // API 29–32 has no RECEIVER_NOT_EXPORTED overload. Restrict sender to our signature permission.
    @android.annotation.SuppressLint("UnspecifiedRegisterReceiverFlag")
    private void registerLegacyContactUpdates(IntentFilter filter){registerReceiver(contactUpdates,filter,"grp.gs.glink.permission.GPLUS_IDENTITY",null);}
    @Override protected void onResume() {
        super.onResume();
        resumed=true;if(updater!=null)updater.onResume();refreshContacts();refreshGroups();
        main.removeCallbacks(serverStatusLoop);main.post(serverStatusLoop);
        if (retryShown && missingGlink && !working) connect();
        retryShown = true;
        if(activePeer!=null){setVisibleChat(activePeer);main.removeCallbacks(pollChat);main.post(pollChat);}
    }
    @Override protected void onPause(){resumed=false;if(updater!=null)updater.onPause();if(voiceUi!=null)voiceUi.cancel();if(voicePlayback!=null)voicePlayback.stop();AppPresence.visibleChat="";main.removeCallbacks(pollChat);main.removeCallbacks(serverStatusLoop);super.onPause();}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);String id=intent.getStringExtra("peer_id");if(id!=null){requestedPeer=id;refreshContacts();}}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(voiceUi!=null)voiceUi.permissionResult(request,results);}
    @Override protected void onDestroy() { try{unregisterReceiver(contactUpdates);}catch(Exception ignored){}if(updater!=null)updater.close();io.shutdown();super.onDestroy(); }
    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private GradientDrawable shape(int fill, int radius, int border) {
        GradientDrawable d = new GradientDrawable(); d.setColor(fill); d.setCornerRadius(dp(radius));
        if (border != 0) d.setStroke(dp(1), border); return d;
    }
    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        v.setIncludeFontPadding(false); return v;
    }
    private LinearLayout vertical() { LinearLayout x = new LinearLayout(this); x.setOrientation(LinearLayout.VERTICAL); return x; }
    private LinearLayout horizontal() { LinearLayout x = new LinearLayout(this); x.setGravity(Gravity.CENTER_VERTICAL); return x; }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private View gap(int h) { View v = new View(this); v.setLayoutParams(lp(1,h)); return v; }
    private TextView button(String label, Runnable click) {
        TextView v = text(label, 14, t.accentInk, true); v.setGravity(Gravity.CENTER);
        v.setBackground(shape(t.accent,14,0)); v.setPadding(dp(18),0,dp(18),0);
        v.setMinHeight(dp(50)); v.setOnClickListener(x -> click.run()); return v;
    }
    private FrameLayout iconButton(String glyph, String description, Runnable click) {
        FrameLayout b = new FrameLayout(this); b.setBackground(shape(t.panel,15,t.stroke));
        Glyph icon = new Glyph(glyph,t.text); FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(dp(22),dp(22),Gravity.CENTER); b.addView(icon,p);
        b.setContentDescription(description); b.setOnClickListener(v -> click.run()); return b;
    }
    private void bars() {
        Window w=getWindow(); w.setStatusBarColor(t.bg); w.setNavigationBarColor(t.bg);
        int flags=t.light ? View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0;
        w.getDecorView().setSystemUiVisibility(flags);
    }
    private void render() {
        t=colors(); bars();
        frame = new FrameLayout(this); frame.setBackgroundColor(t.bg); frame.setFitsSystemWindows(true);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        LinearLayout column = vertical(); column.setPadding(dp(22),dp(16),dp(22),dp(24));
        scroll.addView(column); frame.addView(scroll,new FrameLayout.LayoutParams(-1,-1)); setContentView(frame);

        LinearLayout header=horizontal();
        header.addView(iconButton("menu","Меню",this::openDrawer),lp(48,48));
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.gplus_wordmark); logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoLp=lp(94,48); logoLp.leftMargin=dp(17); header.addView(logo,logoLp);
        View flex=new View(this); header.addView(flex,new LinearLayout.LayoutParams(0,1,1));
        header.addView(iconButton("search","Поиск",this::searchChats),lp(48,48));
        LinearLayout.LayoutParams pp=lp(48,48);pp.leftMargin=dp(8);header.addView(iconButton("person","Профиль",this::showProfile),pp);
        column.addView(header,lp(-1,48)); column.addView(gap(38));

        TextView eyebrow=text("ВАШЕ ПРОСТРАНСТВО",11,t.accent,true); eyebrow.setLetterSpacing(.12f); column.addView(eyebrow);
        column.addView(gap(9)); column.addView(text(showArchive?"Архив":"Чаты",34,t.text,true)); column.addView(gap(8));
        column.addView(text("Общение начинается здесь",15,t.secondary,false)); column.addView(gap(25));

        LinearLayout net=horizontal(); net.setPadding(dp(15),dp(13),dp(15),dp(13)); net.setBackground(shape(t.panel,16,t.stroke));
        View dot=new View(this); dot.setBackground(shape(me!=null ? 0xff26dc49 : t.secondary,9,0)); net.addView(dot,lp(8,8));
        status=text(connection,13,t.text,true); LinearLayout.LayoutParams statusLp=new LinearLayout.LayoutParams(0,-2,1); statusLp.leftMargin=dp(11); net.addView(status,statusLp);
        Glyph refresh=new Glyph("refresh",t.secondary); net.addView(refresh,lp(19,19));
        net.setContentDescription("Состояние подключения. Нажмите, чтобы повторить."); net.setOnClickListener(v -> { if (missingGlink) missingDialog(); else connect(); });
        column.addView(net,lp(-1,-2));
        serverBadge=text(serverLabel,11,t.secondary,false);LinearLayout.LayoutParams badgeLp=lp(-1,-2);badgeLp.topMargin=dp(7);badgeLp.leftMargin=dp(4);column.addView(serverBadge,badgeLp);
        column.addView(gap(18));

        List<Protocol.Card> visible=new ArrayList<>();String query=searchQuery.trim().toLowerCase(java.util.Locale.ROOT);
        for(Protocol.Card p:contacts)if(prefs.getBoolean("archive_"+p.id,false)==showArchive&&(query.isEmpty()||p.display.toLowerCase(java.util.Locale.ROOT).contains(query)||p.nick.toLowerCase(java.util.Locale.ROOT).contains(query)))visible.add(p);
        visible.sort((a,b)->{boolean x=prefs.getBoolean("pin_"+a.id,false),y=prefs.getBoolean("pin_"+b.id,false);return x==y?a.display.compareToIgnoreCase(b.display):x?-1:1;});
        List<SignedGroup> visibleGroups=new ArrayList<>();for(SignedGroup g:groups)if(prefs.getBoolean("archive_"+g.id,false)==showArchive&&(query.isEmpty()||g.title.toLowerCase(java.util.Locale.ROOT).contains(query)))visibleGroups.add(g);visibleGroups.sort((a,b)->{boolean x=prefs.getBoolean("pin_"+a.id,false),y=prefs.getBoolean("pin_"+b.id,false);return x==y?a.title.compareToIgnoreCase(b.title):x?-1:1;});
        if(!query.isEmpty()){TextView clear=text("Поиск: "+searchQuery+"  ·  очистить",13,t.accent,true);clear.setOnClickListener(v->{searchQuery="";render();});column.addView(clear);column.addView(gap(12));}
        if(visible.isEmpty()&&visibleGroups.isEmpty()){
            LinearLayout card=vertical(); card.setGravity(Gravity.CENTER_HORIZONTAL); card.setPadding(dp(22),dp(28),dp(22),dp(24)); card.setBackground(shape(t.panel,24,t.stroke));
            FrameLayout iconCircle = new FrameLayout(this); iconCircle.setBackground(shape(t.iconSurface,40,0));
            iconCircle.addView(new Glyph("chat",t.accent),new FrameLayout.LayoutParams(dp(35),dp(35),Gravity.CENTER)); card.addView(iconCircle,lp(72,72));
            card.addView(gap(22)); TextView empty=text(showArchive?"Архив пуст":!searchQuery.isEmpty()?"Ничего не найдено":"Здесь появятся ваши чаты",18,t.text,true); empty.setGravity(Gravity.CENTER); card.addView(empty);
            card.addView(gap(10)); TextView explain=text("Добавляйте контакты через GLINK по NFC.",14,t.secondary,false); explain.setGravity(Gravity.CENTER); explain.setLineSpacing(dp(3),1f); card.addView(explain);
            card.addView(gap(23));card.addView(button("Добавить контакт",this::explainNfc),lp(-1,50));column.addView(card,lp(-1,-2));
        }else{
            for(SignedGroup group:visibleGroups){LinearLayout row=horizontal();row.setPadding(dp(14),dp(12),dp(14),dp(12));row.setBackground(shape(t.panel,18,t.stroke));TextView avatar=text(group.title.substring(0,group.title.offsetByCodePoints(0,1)).toUpperCase(java.util.Locale.getDefault()),20,t.accent,true);avatar.setGravity(Gravity.CENTER);avatar.setBackground(shape(t.iconSurface,30,0));row.addView(avatar,lp(48,48));LinearLayout labels=vertical();LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,-2,1);q.leftMargin=dp(14);row.addView(labels,q);labels.addView(text(group.title,16,t.text,true));labels.addView(gap(5));labels.addView(text(("channel".equals(group.kind)?"Канал":"Группа")+" · "+group.members.size()+" участников"+(prefs.getBoolean("pin_"+group.id,false)?" · закреплён":""),13,t.secondary,false));row.setOnClickListener(v->openGroup(group));row.setOnLongClickListener(v->{groupListActions(group);return true;});column.addView(row,lp(-1,-2));column.addView(gap(9));}
            for(Protocol.Card person:visible){
                LinearLayout row=horizontal();row.setPadding(dp(14),dp(12),dp(14),dp(12));row.setBackground(shape(t.panel,18,t.stroke));
                TextView avatar=text(person.display.substring(0,person.display.offsetByCodePoints(0,1)).toUpperCase(java.util.Locale.getDefault()),20,t.accent,true);avatar.setGravity(Gravity.CENTER);avatar.setBackground(shape(t.iconSurface,30,0));row.addView(avatar,lp(48,48));
                LinearLayout labels=vertical();LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,-2,1);q.leftMargin=dp(14);row.addView(labels,q);labels.addView(text(person.display,16,t.text,true));labels.addView(gap(5));labels.addView(text("@"+person.nick+(prefs.getBoolean("pin_"+person.id,false)?" · закреплён":""),13,t.secondary,false));
                row.setOnClickListener(v -> openChat(person));row.setOnLongClickListener(v->{chatListActions(person);return true;});column.addView(row,lp(-1,-2));column.addView(gap(9));
            }
            column.addView(gap(7));column.addView(button("Добавить контакт",this::explainNfc),lp(-1,50));
        }
        if(!showArchive){column.addView(gap(9));column.addView(button("Создать группу или канал",this::createGroupChoice),lp(-1,50));}
        column.addView(gap(20));
        identityLine=text(deviceId.isEmpty()?"GLINK ID появится после подключения":"GLINK ID · открыть по отпечатку",12,t.secondary,false);
        if(!deviceId.isEmpty()){identityLine.setOnClickListener(v -> openPublicId());identityLine.setContentDescription("Открыть публичный GLINK ID по отпечатку");}
        column.addView(identityLine);
        column.addView(gap(12)); TextView disclaimer=text("Разработка: для обмена нужен обновлённый GLINK и сервер G+. Возможности ещё проверяются.",12,t.secondary,false); disclaimer.setLineSpacing(dp(2),1f); column.addView(disclaimer);
    }
    private void refreshStatus() {
        if (isFinishing() || isDestroyed()) return;
        if(activePeer==null)render();else if(chatStatus!=null)chatStatus.setText(connection);
    }
    private void connect() {
        if (working || !prefs.getBoolean("key_loss_notice_ack",false)) return;
        working=true; connection="Подключаемся…"; refreshStatus();
        io.execute(() -> {
            try {
                identity.load(); final String id=identity.id();
                JSONObject account=api.login(prefs.getString("nickname", ""));
                boolean ready;try{identity.setContactCard(ContactCardFactory.create(account,identity));ready=true;}catch(Exception e){ready=false;}
                final boolean pairingReady=ready;
                main.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    working=false; missingGlink=false; deviceId=id; me=account;
                    prefs.edit().putString("nickname",account.optString("nickname", "")).apply();
                    connection=pairingReady?"Подключено · @"+account.optString("nickname"):"Нужен новый GLINK для чатов"; refreshStatus();
                    refreshContacts();refreshGroups();if(pairingReady)startMessageService();if(activePeer!=null)syncChat(true);
                });
            } catch (Exception e) {
                String id=""; boolean missing=false;
                try { id=identity.id(); } catch (Exception ignored) { missing=true; }
                final String knownId=id; final boolean noGlink=missing;
                final String error=(e instanceof GPlusApi.ApiException) ? ((GPlusApi.ApiException)e).error : "";
                main.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    working=false; me=null; deviceId=knownId; missingGlink=noGlink;
                    connection=noGlink ? "Нужен актуальный GLINK" : "Сервер G+ пока недоступен";
                    refreshStatus();
                    if (!noGlink && (error.equals("nickname_required_or_invalid") || error.equals("nickname_taken"))) {
                        connection="Выберите уникальный @ник"; refreshStatus(); nicknameDialog(error.equals("nickname_taken"));
                    }
                });
            }
        });
    }
    private void startMessageService(){
        if(!prefs.getBoolean("background_messages",true))return;
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED&&!prefs.getBoolean("notifications_asked",false)){
            prefs.edit().putBoolean("notifications_asked",true).apply();requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},4702);
        }
        try{startForegroundService(new Intent(this,MessageService.class));}catch(Exception ignored){}
    }
    private void chooseBackground(){
        boolean enabled=prefs.getBoolean("background_messages",true);
        new AlertDialog.Builder(this).setTitle("Фоновые уведомления").setMessage("G+ проверяет сообщения без Google через фоновую службу с постоянным уведомлением. Android и энергосбережение могут приостанавливать её, поэтому мгновенная доставка не гарантируется.")
            .setPositiveButton(enabled?"Выключить":"Включить",(d,w)->{prefs.edit().putBoolean("background_messages",!enabled).apply();if(enabled)stopService(new Intent(this,MessageService.class));else if(me!=null)startMessageService();})
            .setNegativeButton("Закрыть",null).show();
    }
    private void nicknameDialog(boolean taken) {
        EditText input=new EditText(this); input.setSingleLine(true); input.setText(prefs.getString("nickname","")); input.setHint("Например, grapescript");
        int pad=dp(20); LinearLayout wrap=vertical(); wrap.setPadding(pad,0,pad,0); wrap.addView(input);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(taken?"Этот ник уже занят":"Ваш @ник")
                .setMessage("От 3 до 32 букв, цифр или подчёркиваний. Номер телефона и пароль не нужны.")
                .setView(wrap).setNegativeButton("Отмена",null).setPositiveButton("Продолжить",null).create();
        d.setOnShowListener(ignored -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String nick=IdentityUtil.nickname(input.getText().toString());
            if (nick==null) { input.setError("От 3 до 32 букв, цифр или _"); return; }
            prefs.edit().putString("nickname",nick).apply(); d.dismiss(); connect();
        })); d.show();
    }
    private void missingDialog() {
        new AlertDialog.Builder(this).setTitle("Для G+ нужен GLINK")
            .setMessage("Установите версию GLINK с GLINK ID, подписанную тем же ключом разработчика. Публичный ID не является паролем. Пока обновление не опубликовано, установите проверенную локальную сборку GLINK.")
            .setPositiveButton("Открыть сайт GLINK",(d,w) -> startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://GrapeGG-developer.github.io/GLINK/"))))
            .setNegativeButton("Закрыть",null).show();
    }
    private void refreshContacts(){
        io.execute(() -> {try{
            try{String self=identity.id();for(String encoded:identity.pendingContacts()){try{Protocol.Card c=store.putContact(Protocol.unb64(encoded),self);identity.ackContact(c.id);}catch(Exception ignored){}}}catch(Exception ignored){}
            List<Protocol.Card> found=store.contacts();main.post(() -> {contacts=found;if(!requestedPeer.isEmpty()){String id=requestedPeer;requestedPeer="";for(Protocol.Card c:found)if(c.id.equals(id)){openChat(c);return;}}if(activePeer==null)refreshStatus();});
        }catch(Exception ignored){}});
    }
    private void refreshGroups(){
        io.execute(()->{try{List<SignedGroup> found=new ArrayList<>();if(api.isSignedIn()){try{found=groupEngine.discover();}catch(Exception ignored){}}if(found.isEmpty())for(String s:store.groupStates())try{found.add(groupEngine.parse(new JSONObject(s)));}catch(Exception ignored){}final List<SignedGroup> loaded=found;main.post(()->{if(isFinishing()||isDestroyed())return;groups=loaded;if(activePeer==null)render();});}catch(Exception ignored){}});
    }
    private void openGroup(SignedGroup group){startActivity(new Intent(this,GroupActivity.class).putExtra("group_id",group.id));}
    private void groupListActions(SignedGroup group){boolean pinned=prefs.getBoolean("pin_"+group.id,false),archived=prefs.getBoolean("archive_"+group.id,false);String[] actions={pinned?"Открепить":"Закрепить",archived?"Вернуть из архива":"В архив"};new AlertDialog.Builder(this).setTitle(group.title).setItems(actions,(d,n)->{prefs.edit().putBoolean((n==0?"pin_":"archive_")+group.id,n==0?!pinned:!archived).apply();render();}).show();}
    private void createGroupChoice(){String[] choices={"Группа","Канал"};new AlertDialog.Builder(this).setTitle("Создать").setItems(choices,(d,n)->createGroup(n==0?"group":"channel")).setNegativeButton("Отмена",null).show();}
    private void createGroup(String kind){
        if(me==null){Toast.makeText(this,"Сначала подключите профиль G+",Toast.LENGTH_LONG).show();return;}if(contacts.isEmpty()){Toast.makeText(this,"Сначала добавьте контакт через NFC",Toast.LENGTH_LONG).show();return;}
        List<Protocol.Card> available=new ArrayList<>(contacts);LinearLayout form=vertical();form.setPadding(dp(20),dp(4),dp(20),0);EditText title=field("Название", "",true);title.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(80)});form.addView(title);List<android.widget.CheckBox> checks=new ArrayList<>();for(Protocol.Card person:available){android.widget.CheckBox c=new android.widget.CheckBox(this);c.setText(person.display+"  @"+person.nick);form.addView(c);checks.add(c);}ScrollView scroll=new ScrollView(this);scroll.addView(form);AlertDialog dialog=new AlertDialog.Builder(this).setTitle("group".equals(kind)?"Новая группа":"Новый канал").setMessage("Выберите контакты, добавленные через NFC. Состав пока нельзя изменить; в канале пишет только создатель.").setView(scroll).setNegativeButton("Отмена",null).setPositiveButton("Создать",null).create();dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String name=title.getText().toString().trim();if(name.isEmpty()){title.setError("Введите название");return;}List<Protocol.Card> selected=new ArrayList<>();for(int i=0;i<checks.size();i++)if(checks.get(i).isChecked())selected.add(available.get(i));if(selected.isEmpty()||selected.size()>49){Toast.makeText(this,"Выберите от 1 до 49 контактов",Toast.LENGTH_LONG).show();return;}dialog.dismiss();Toast.makeText(this,"Создаём…",Toast.LENGTH_SHORT).show();io.execute(()->{try{if(!api.isSignedIn())api.login(prefs.getString("nickname",""));SignedGroup created=groupEngine.create(kind,name,selected);main.post(()->{refreshGroups();openGroup(created);});}catch(Exception e){main.post(()->Toast.makeText(this,"Не удалось создать. Проверьте сервер и контакты.",Toast.LENGTH_LONG).show());}});}));dialog.show();
    }
    private void explainNfc() {
        if(me==null){Toast.makeText(this,"Сначала подключите профиль G+",Toast.LENGTH_LONG).show();return;}
        JSONObject profile=me;
        io.execute(() -> {try{
            identity.setContactCard(ContactCardFactory.create(profile,identity));
            main.post(() -> {try{
                Intent i=new Intent();i.setComponent(new ComponentName("grp.gs.glink","com.prilozhi.app.identity.GPlusPairActivity"));startActivity(i);
            }catch(Exception e){Toast.makeText(this,"Нужен GLINK с поддержкой G+",Toast.LENGTH_LONG).show();}});
        }catch(Exception e){main.post(() -> Toast.makeText(this,"Не удалось подготовить знакомство. Обновите GLINK.",Toast.LENGTH_LONG).show());}});
    }
    private void openPublicId() {
        try {
            android.content.pm.PackageInfo glink=getPackageManager().getPackageInfo("grp.gs.glink",0);
            if(glink.getLongVersionCode()<76 || getPackageManager().checkSignatures(getPackageName(),"grp.gs.glink")!=android.content.pm.PackageManager.SIGNATURE_MATCH)
                throw new IllegalStateException("Trusted GLINK update required");
            Intent intent=new Intent("grp.gs.glink.action.SHOW_PUBLIC_ID");
            intent.setComponent(new ComponentName("grp.gs.glink","com.prilozhi.app.MainActivity"));
            startActivity(intent);
        } catch(Exception e) { Toast.makeText(this,"Обновите GLINK, чтобы открыть ID по отпечатку",Toast.LENGTH_LONG).show(); }
    }
    private void showProfile() {
        if (me == null) {
            new AlertDialog.Builder(this).setTitle("Профиль G+")
                .setMessage(deviceId.isEmpty()?"Сначала подключите актуальный GLINK и сервер G+.":"Профиль станет доступен после подключения сервера G+. Свой ID можно открыть в GLINK по отпечатку.")
                .setPositiveButton("Понятно",null).show(); return;
        }
        JSONObject p=me.optJSONObject("profile"); if (p==null) p=new JSONObject();
        LinearLayout form=vertical(); form.setPadding(dp(22),dp(4),dp(22),0);
        EditText name=field("Имя",me.optString("display_name",""),true);
        EditText bio=field("О себе",p.optString("bio",""),false);
        EditText city=field("Город",p.optString("city",""),true);
        EditText website=field("Сайт (https://)",p.optString("website",""),true);
        form.addView(name);form.addView(bio);form.addView(city);form.addView(website);
        form.addView(gap(10));form.addView(button("Открыть GLINK ID по отпечатку",this::openPublicId));
        ScrollView scroll=new ScrollView(this);scroll.addView(form);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Профиль · @"+me.optString("nickname"))
            .setMessage("GLINK ID доступен после подтверждения отпечатка. При потере устройства или ключа GLINK восстановить прежний аккаунт невозможно.").setView(scroll).setNegativeButton("Отмена",null)
            .setPositiveButton("Сохранить",null).create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n=name.getText().toString().trim(), b=bio.getText().toString().trim(), c=city.getText().toString().trim(), w=website.getText().toString().trim();
            if(n.isEmpty()||n.length()>80){name.setError("Введите имя до 80 символов");return;}
            if(b.length()>500){bio.setError("До 500 символов");return;}
            if(c.length()>80){city.setError("До 80 символов");return;}
            if(!w.isEmpty() && (!w.startsWith("https://") || w.length()>256)){website.setError("Нужен адрес https://");return;}
            dialog.dismiss(); connection="Сохраняем профиль…";refreshStatus();
            io.execute(() -> { try {
                JSONObject obj=new JSONObject().put("display_name",n).put("bio",b).put("city",c).put("website",w);
                JSONObject saved=api.saveProfile(obj);
                boolean ready;try{identity.setContactCard(ContactCardFactory.create(saved,identity));ready=true;}catch(Exception e){ready=false;}
                final boolean cardReady=ready;
                main.post(() -> {me=saved;connection=cardReady?"Подключено · @"+saved.optString("nickname"):"Нужен новый GLINK для чатов";refreshStatus();Toast.makeText(this,"Профиль сохранён",Toast.LENGTH_SHORT).show();});
            } catch(Exception e) {main.post(() -> {connection="Не удалось сохранить профиль";refreshStatus();Toast.makeText(this,"Проверьте подключение к серверу G+",Toast.LENGTH_LONG).show();});} });
        })); dialog.show();
    }
    private void openChat(Protocol.Card peer){
        activePeer=peer;replyTo="";peerRead=0;setVisibleChat(peer);renderChat();loadMessages(peer);main.removeCallbacks(pollChat);main.post(pollChat);
    }
    private void renderChat(){
        t=colors();bars();frame=new FrameLayout(this);frame.setBackgroundColor(t.bg);frame.setFitsSystemWindows(true);
        LinearLayout root=vertical();root.setPadding(dp(16),dp(12),dp(16),dp(12));frame.addView(root,new FrameLayout.LayoutParams(-1,-1));setContentView(frame);
        LinearLayout header=horizontal();header.addView(iconButton("back","Назад",this::leaveChat),lp(48,48));
        LinearLayout labels=vertical();LinearLayout.LayoutParams hl=new LinearLayout.LayoutParams(0,-2,1);hl.leftMargin=dp(14);header.addView(labels,hl);
        labels.addView(text(activePeer.display,18,t.text,true));chatStatus=text("@"+activePeer.nick,12,t.secondary,false);labels.addView(chatStatus);
        header.addView(iconButton("info","Настройки чата",this::chatSettings),lp(48,48));root.addView(header,lp(-1,52));root.addView(gap(10));
        messageScroll=new ScrollView(this);messageScroll.setFillViewport(false);messageColumn=vertical();messageColumn.setPadding(0,dp(8),0,dp(8));messageScroll.addView(messageColumn);root.addView(messageScroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout compose=horizontal();LinearLayout.LayoutParams attach=lp(48,50);attach.rightMargin=dp(8);compose.addView(iconButton("attach","Вложения и опросы",this::composeExtras),attach);messageInput=new EditText(this);messageInput.setSingleLine(false);messageInput.setMaxLines(4);messageInput.setHint("Сообщение");messageInput.setTextColor(t.text);messageInput.setHintTextColor(t.secondary);messageInput.setTextSize(15);messageInput.setPadding(dp(14),dp(10),dp(14),dp(10));messageInput.setBackground(shape(t.panel,15,t.stroke));
        compose.addView(messageInput,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams send=lp(54,50);send.leftMargin=dp(8);compose.addView(iconButton("send","Отправить",this::sendText),send);root.addView(compose,lp(-1,-2));
    }
    private void setVisibleChat(Protocol.Card peer){io.execute(()->{try{String id=chatEngine.chatId(peer);main.post(()->{if(resumed&&activePeer!=null&&activePeer.id.equals(peer.id))AppPresence.visibleChat=id;});}catch(Exception ignored){}});}
    private void searchChats(){EditText input=field("Имя или @ник",searchQuery,true);new AlertDialog.Builder(this).setTitle("Поиск чатов").setView(input).setNegativeButton("Отмена",null).setPositiveButton("Найти",(d,w)->{searchQuery=input.getText().toString();render();}).show();}
    private void chatListActions(Protocol.Card person){boolean pinned=prefs.getBoolean("pin_"+person.id,false),archived=prefs.getBoolean("archive_"+person.id,false);String[] actions={pinned?"Открепить":"Закрепить",archived?"Вернуть из архива":"В архив"};new AlertDialog.Builder(this).setTitle(person.display).setItems(actions,(d,n)->{prefs.edit().putBoolean((n==0?"pin_":"archive_")+person.id,n==0?!pinned:!archived).apply();render();}).show();}
    private void chatSettings(){if(activePeer==null)return;Protocol.Card peer=activePeer;String[] options={"Обновить","Исчезающие сообщения","Аудиозвонок","Видеозвонок"};new AlertDialog.Builder(this).setTitle(peer.display).setItems(options,(d,n)->{if(n==0)syncChat(true);else if(n==1)chooseExpiry();else startActivity(new Intent(this,CallActivity.class).putExtra("peer_id",peer.id).putExtra("outgoing",true).putExtra("video",n==3));}).show();}
    private void chooseExpiry(){if(activePeer==null)return;Protocol.Card peer=activePeer;String[] labels={"Выключено","1 минута","1 час","1 день","1 неделя"};int[] values={0,60,3600,86400,604800};new AlertDialog.Builder(this).setTitle("Исчезающие сообщения").setMessage("Настройка действует только для новых текстов. Вложения не исчезают. Отсчёт начинается на сервере; собеседник может сохранить копию.").setItems(labels,(d,n)->{prefs.edit().putInt("ttl_"+peer.id,values[n]).apply();Toast.makeText(this,"Срок: "+labels[n],Toast.LENGTH_SHORT).show();}).setNegativeButton("Отмена",null).show();}
    private void leaveChat(){AppPresence.visibleChat="";activePeer=null;messageColumn=null;messageScroll=null;messageInput=null;chatStatus=null;replyTo="";main.removeCallbacks(pollChat);render();}
    private void loadMessages(Protocol.Card peer){io.execute(() -> {try{List<ChatEngine.Message> all=chatEngine.messages(peer);String meId=identity.id();main.post(() -> {if(activePeer!=null&&activePeer.id.equals(peer.id)){showMessages(Timeline.apply(all),meId);showIncomingCall(peer,all);}});}catch(Exception e){main.post(() -> {if(activePeer!=null&&activePeer.id.equals(peer.id)&&chatStatus!=null)chatStatus.setText("История недоступна: проверьте GLINK");});}});}
    private void showIncomingCall(Protocol.Card peer,List<ChatEngine.Message> messages){
        if(!resumed||incomingDialog||isFinishing()||isDestroyed())return;long seen=prefs.getLong("call_seen_"+peer.id,0),latest=seen;ChatEngine.Message chosen=null;CallSignal.Offer offer=null;long now=System.currentTimeMillis();
        for(ChatEngine.Message m:messages){if(m.seq<=seen||!peer.id.equals(m.sender)||!"call_offer".equals(m.content.optString("type")))continue;latest=Math.max(latest,m.seq);CallSignal.Offer candidate=CallSignal.parseOffer(m,peer.id,now);if(candidate!=null){boolean ended=false;for(ChatEngine.Message later:messages)if(later.seq>m.seq&&"call_end".equals(later.content.optString("type"))&&candidate.call.equals(later.content.optString("call"))){ended=true;break;}if(!ended&&(chosen==null||m.seq>chosen.seq)){chosen=m;offer=candidate;}}}
        if(latest>seen)prefs.edit().putLong("call_seen_"+peer.id,latest).apply();if(chosen==null)return;final ChatEngine.Message event=chosen;final CallSignal.Offer valid=offer;incomingDialog=true;
        new AlertDialog.Builder(this).setTitle(valid.video?"Входящий видеозвонок":"Входящий аудиозвонок").setMessage(peer.display+" звонит вам. Микрофон и камера включаются только после ответа и разрешения.").setCancelable(false).setNegativeButton("Отклонить",(d,w)->{incomingDialog=false;io.execute(()->{try{if(!api.isSignedIn())api.login(prefs.getString("nickname",""));chatEngine.queueCallSignal(peer,CallSignal.end(valid.call));chatEngine.sync(peer,false);}catch(Exception ignored){}});}).setPositiveButton("Ответить",(d,w)->{incomingDialog=false;startActivity(new Intent(this,CallActivity.class).putExtra("peer_id",peer.id).putExtra("outgoing",false).putExtra("video",valid.video).putExtra("offer_id",event.id));}).show();
    }
    private void showMessages(List<Timeline.Item> all,String self){
        if(messageColumn==null)return;messageColumn.removeAllViews();
        if(all.isEmpty()){TextView hint=text("Напишите первое сообщение",14,t.secondary,false);hint.setGravity(Gravity.CENTER);messageColumn.addView(hint,lp(-1,70));return;}
        for(Timeline.Item item:all){boolean mine=self.equals(item.sender);LinearLayout wrap=vertical();wrap.setPadding(dp(14),dp(10),dp(14),dp(10));wrap.setBackground(shape(mine?t.iconSurface:t.panel,16,t.stroke));
            if(!item.reply.isEmpty()){TextView reply=text("Ответ на сообщение",11,t.accent,true);wrap.addView(reply);wrap.addView(gap(4));}
            if(item.forwarded){wrap.addView(text("Переслано",11,t.accent,true));wrap.addView(gap(4));}
            if("sticker".equals(item.content.optString("type"))&&!item.deleted)wrap.addView(new StickerView(this,item.content.optString("sticker")),lp(112,112));else{TextView body=text(PollUi.display(item),15,t.text,false);wrap.addView(body);}
            StringBuilder meta=new StringBuilder();if(item.edited)meta.append("изменено  ");if(!item.reactions.isEmpty()){for(String r:item.reactions.values())meta.append(r).append(' ');}
            if(mine)meta.append("pending".equals(item.state)?"· в очереди":item.seq>0&&peerRead>=item.seq?"· прочитано":"· отправлено");
            if(meta.length()>0){wrap.addView(gap(5));wrap.addView(text(meta.toString(),11,t.secondary,false));}
            LinearLayout.LayoutParams p=lp(-2,-2);p.gravity=mine?Gravity.END:Gravity.START;p.topMargin=dp(7);p.rightMargin=mine?0:dp(35);p.leftMargin=mine?dp(35):0;messageColumn.addView(wrap,p);
            if(!item.deleted){if("file".equals(item.content.optString("type")))wrap.setOnClickListener(v->{if(item.content.optBoolean("voice")&&activePeer!=null){Protocol.Card audioPeer=activePeer;io.execute(()->{try{String chat=chatEngine.chatId(audioPeer);main.post(()->{if(activePeer!=null&&activePeer.id.equals(audioPeer.id))voicePlayback.play(chat,item.id,item.content);});}catch(Exception ignored){}});}else saveMedia(item);});else if(!item.pollOptions.isEmpty())wrap.setOnClickListener(v->PollUi.vote(this,item,this::queueAction));wrap.setOnLongClickListener(v -> {messageActions(item,mine);return true;});}
        }
        messageScroll.post(() -> {if(messageScroll!=null)messageScroll.fullScroll(View.FOCUS_DOWN);});
    }
    private void sendText(){
        if(activePeer==null||messageInput==null)return;String text=messageInput.getText().toString();if(text.trim().isEmpty())return;
        Protocol.Card peer=activePeer;String reply=replyTo;int ttl=prefs.getInt("ttl_"+peer.id,0);replyTo="";messageInput.setText("");
        io.execute(() -> {try{chatEngine.queueText(peer,text,reply,ttl);main.post(() -> {if(activePeer!=null&&activePeer.id.equals(peer.id)){loadMessages(peer);syncChat(true);}});}
        catch(Exception e){main.post(() -> {if(activePeer!=null&&activePeer.id.equals(peer.id)&&messageInput!=null&&messageInput.length()==0)messageInput.setText(text);Toast.makeText(this,"Не удалось подготовить сообщение. Проверьте GLINK.",Toast.LENGTH_LONG).show();});}});
    }
    private void syncChat(boolean markRead){
        if(syncBusy||activePeer==null)return;Protocol.Card peer=activePeer;
        if(!api.isSignedIn()){loadMessages(peer);if(chatStatus!=null)chatStatus.setText("Нет связи · сообщения сохраняются в очереди");return;}
        syncBusy=true;
        io.execute(() -> {String online="";long read=0;Exception failure=null;try{
                try{chatEngine.sync(peer,markRead);}catch(GPlusApi.ApiException e){if(e.status!=401)throw e;JSONObject account=api.login(prefs.getString("nickname",""));try{identity.setContactCard(ContactCardFactory.create(account,identity));}catch(Exception ignored){}chatEngine.sync(peer,markRead);main.post(()->me=account);}
                org.json.JSONArray members=api.members(chatEngine.chatId(peer)).getJSONArray("members");for(int i=0;i<members.length();i++){JSONObject m=members.getJSONObject(i);if(peer.id.equals(m.optString("user_id"))){online=m.optBoolean("online")?"в сети":"не в сети";read=m.optLong("last_read",0);}}}
            catch(Exception e){failure=e;}final Exception error=failure;final String state=online;final long readSeq=read;
            main.post(() -> {syncBusy=false;if(activePeer!=null&&activePeer.id.equals(peer.id)){if(chatStatus!=null)chatStatus.setText(error==null?state:"Нет связи · очередь сохранена");if(error==null)peerRead=readSeq;loadMessages(peer);} });
        });
    }
    private void messageActions(Timeline.Item item,boolean mine){
        boolean file="file".equals(item.content.optString("type")),poll=!item.pollOptions.isEmpty(),sticker="sticker".equals(item.content.optString("type"));
        String[] choices=sticker?(mine?new String[]{"Ответить","Удалить","Реакция","Переслать"}:new String[]{"Ответить","Реакция","Переслать"}):file?(mine?new String[]{"Сохранить файл","Ответить","Удалить","Реакция","Переслать"}:new String[]{"Сохранить файл","Ответить","Реакция","Переслать"}):poll?(mine?new String[]{"Голосовать","Ответить","Удалить","Реакция","Переслать"}:new String[]{"Голосовать","Ответить","Реакция","Переслать"}):(mine?new String[]{"Ответить","Изменить","Удалить","Реакция","Переслать"}:new String[]{"Ответить","Реакция","Переслать"});
        new AlertDialog.Builder(this).setTitle("Сообщение").setItems(choices,(d,n) -> {String action=choices[n];
            if(action.equals("Сохранить файл")){saveMedia(item);}
            else if(action.equals("Голосовать")){PollUi.vote(this,item,this::queueAction);}
            else if(action.equals("Ответить")){replyTo=item.id;if(chatStatus!=null)chatStatus.setText("Ответ на сообщение");if(messageInput!=null)messageInput.requestFocus();}
            else if(action.equals("Изменить")){EditText input=field("Сообщение",item.text,false);new AlertDialog.Builder(this).setTitle("Изменить сообщение").setView(input).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(x,y)->{try{queueAction(new JSONObject().put("v",1).put("type","edit").put("target",item.id).put("text",input.getText().toString()));}catch(Exception ignored){}}).show();}
            else if(action.equals("Удалить")){new AlertDialog.Builder(this).setTitle("Удалить сообщение?").setMessage("Сейчас удаление скрывает сообщение в клиентах; ранее сохранённые копии могут остаться.").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(x,y)->{try{queueAction(new JSONObject().put("v",1).put("type","delete").put("target",item.id));}catch(Exception ignored){}}).show();}
            else if(action.equals("Реакция")){String[] r={"❤️","👍","😂","😮","Убрать"};new AlertDialog.Builder(this).setTitle("Реакция").setItems(r,(x,y)->{try{queueAction(new JSONObject().put("v",1).put("type","reaction").put("target",item.id).put("reaction",y==4?"":r[y]));}catch(Exception ignored){}}).show();}
            else if(action.equals("Переслать")){Protocol.Card source=activePeer;if(source!=null)io.execute(()->{try{String chat=chatEngine.chatId(source);main.post(()->{if(!isFinishing()&&!isDestroyed())Forwarder.choose(this,io,identity,api,store,prefs,chat,item,()->{if(activePeer!=null){loadMessages(activePeer);syncChat(true);}});});}catch(Exception ignored){}});}

        }).setNegativeButton("Отмена",null).show();
    }
    private void queueAction(JSONObject action){if(activePeer==null)return;Protocol.Card peer=activePeer;io.execute(() -> {try{chatEngine.queue(peer,action);main.post(() -> {if(activePeer!=null&&activePeer.id.equals(peer.id)){loadMessages(peer);syncChat(true);}});}catch(Exception e){main.post(() -> Toast.makeText(this,"Не удалось подготовить действие",Toast.LENGTH_SHORT).show());}});}
    private void composeExtras(){String[] choices={"Файл, фото или видео","Опрос","Стикер","Голосовое сообщение"};new AlertDialog.Builder(this).setTitle("Добавить").setItems(choices,(d,n)->{if(n==0)pickMedia();else if(n==1)PollUi.create(this,this::queueAction);else if(n==2)StickerUi.choose(this,this::queueAction);else voiceUi.request();}).setNegativeButton("Отмена",null).show();}
    private void queueVoice(java.io.File source){
        if(activePeer==null){source.delete();return;}Protocol.Card peer=activePeer;io.execute(()->{MediaCrypto.Prepared prepared=null;boolean queued=false;try{byte[] random=new byte[16];new java.security.SecureRandom().nextBytes(random);String asset=Protocol.b64(random),chat=chatEngine.chatId(peer);java.io.File dir=new java.io.File(getNoBackupFilesDir(),"encrypted_media");if(!dir.exists()&&!dir.mkdirs())throw new java.io.IOException("Нет места");prepared=MediaCrypto.encrypt(new java.io.FileInputStream(source),new java.io.File(dir,asset+".bin"),chat,asset);chatEngine.queueVoice(peer,asset,prepared);queued=true;main.post(()->{if(activePeer!=null&&activePeer.id.equals(peer.id)){loadMessages(peer);syncChat(true);}Toast.makeText(this,"Голосовое добавлено в очередь",Toast.LENGTH_SHORT).show();});}catch(Exception e){if(prepared!=null&&!queued)prepared.file.delete();main.post(()->Toast.makeText(this,"Не удалось подготовить голосовое",Toast.LENGTH_LONG).show());}finally{source.delete();}});
    }
    private void pickMedia(){
        if(activePeer==null)return;Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("*/*");pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);try{startActivityForResult(pick,PICK_MEDIA);}catch(Exception e){Toast.makeText(this,"Не удалось открыть выбор файла",Toast.LENGTH_LONG).show();}
    }
    private void saveMedia(Timeline.Item item){
        if(activePeer==null)return;selectedMedia=item;mediaPeer=activePeer;JSONObject file=item.content;
        String name=file.optString("name","Файл"),mime=file.optString("mime","application/octet-stream");
        if(!mime.matches("[A-Za-z0-9.+_-]{1,80}/[A-Za-z0-9.+_-]{1,80}"))mime="application/octet-stream";
        Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);save.addCategory(Intent.CATEGORY_OPENABLE);save.setType(mime);save.putExtra(Intent.EXTRA_TITLE,name);
        try{startActivityForResult(save,SAVE_MEDIA);}catch(Exception e){Toast.makeText(this,"Не удалось выбрать место сохранения",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();
        if(request==PICK_MEDIA&&activePeer!=null){
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            Protocol.Card peer=activePeer;Toast.makeText(this,"Шифруем файл без изменения качества…",Toast.LENGTH_SHORT).show();
            io.execute(() -> {MediaCrypto.Prepared prepared=null;boolean queued=false;try{
                String name="Файл",mime=getContentResolver().getType(uri);
                try(android.database.Cursor c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst()&&!c.isNull(0))name=c.getString(0);}catch(Exception ignored){}
                String chat=chatEngine.chatId(peer);byte[] random=new byte[16];new java.security.SecureRandom().nextBytes(random);String asset=Protocol.b64(random);
                java.io.File dir=new java.io.File(getNoBackupFilesDir(),"encrypted_media");if(!dir.exists()&&!dir.mkdirs())throw new java.io.IOException("Нет места для файла");
                prepared=MediaCrypto.encrypt(getContentResolver().openInputStream(uri),new java.io.File(dir,asset+".bin"),chat,asset);
                chatEngine.queueFile(peer,asset,prepared,name,mime);queued=true;
                main.post(() -> {if(activePeer!=null&&activePeer.id.equals(peer.id)){loadMessages(peer);syncChat(true);}Toast.makeText(this,"Файл добавлен в очередь",Toast.LENGTH_SHORT).show();});
            }catch(Exception e){if(prepared!=null&&!queued)prepared.file.delete();main.post(() -> Toast.makeText(this,"Не удалось подготовить файл",Toast.LENGTH_LONG).show());}});
        }else if(request==SAVE_MEDIA&&selectedMedia!=null&&mediaPeer!=null){
            Timeline.Item chosen=selectedMedia;JSONObject file=chosen.content;String mediaEvent=chosen.id;Protocol.Card peer=mediaPeer;selectedMedia=null;mediaPeer=null;
            io.execute(()->{try{
                String asset=file.getString("asset"),sha=file.getString("sha256"),chat=chatEngine.chatId(peer);long size=file.getLong("size"),cipherSize=file.getLong("cipher_size");
                if(!Protocol.validEventId(asset)||size<0||cipherSize<1||!sha.matches("[0-9a-f]{64}"))throw new SecurityException("Некорректный файл");
                java.io.File dir=new java.io.File(getNoBackupFilesDir(),"encrypted_media");if(!dir.exists()&&!dir.mkdirs())throw new java.io.IOException("Нет места для файла");java.io.File local=new java.io.File(dir,asset+".bin");
                if(!mediaMatches(local,cipherSize,sha)){
                    if(dir.getUsableSpace()<cipherSize+20L*1024*1024)throw new java.io.IOException("Недостаточно места");
                    if(!api.isSignedIn())api.login(prefs.getString("nickname",""));
                    try{api.downloadAsset(asset,local,cipherSize,sha);}catch(GPlusApi.ApiException e){if(e.status!=401)throw e;api.login(prefs.getString("nickname",""));api.downloadAsset(asset,local,cipherSize,sha);}
                }
                byte[] key=Protocol.unb64(file.getString("key"));try{
                    // Authenticate the whole file before touching the user's destination.
                    MediaCrypto.decrypt(new java.io.FileInputStream(local),new java.io.OutputStream(){@Override public void write(int b){}@Override public void write(byte[] b,int off,int len){}},key,chat,asset,size);
                    java.io.OutputStream out=getContentResolver().openOutputStream(uri,"w");if(out==null)throw new java.io.IOException("Нет доступа к файлу");MediaCrypto.decrypt(new java.io.FileInputStream(local),out,key,chat,asset,size);
                }finally{java.util.Arrays.fill(key,(byte)0);}
                try{MediaReceipts.verified(store,asset,mediaEvent,sha);}catch(Exception ignored){/* never delete server media without a receipt */}
                main.post(()->Toast.makeText(this,"Файл сохранён без изменения качества",Toast.LENGTH_LONG).show());
            }catch(Exception e){main.post(()->Toast.makeText(this,"Не удалось проверить или сохранить файл; проверьте созданный документ",Toast.LENGTH_LONG).show());}});
        }
    }
    static boolean mediaMatches(java.io.File f,long size,String expected){
        if(!f.isFile()||f.length()!=size)return false;try(java.io.InputStream in=new java.io.FileInputStream(f)){java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)md.update(b,0,n);StringBuilder s=new StringBuilder();for(byte x:md.digest())s.append(String.format(java.util.Locale.ROOT,"%02x",x&255));return expected.equals(s.toString());}catch(Exception e){return false;}
    }
    private EditText field(String hint,String value,boolean single) { EditText f=new EditText(this); f.setHint(hint); f.setText(value); f.setSingleLine(single); f.setTextSize(15); return f; }
    private void openDrawer() {
        if (drawer!=null) return;
        drawer=new FrameLayout(this); drawer.setBackgroundColor(0x99000000); frame.addView(drawer,new FrameLayout.LayoutParams(-1,-1));
        drawer.setOnClickListener(v -> closeDrawer());
        LinearLayout panel=vertical(); panel.setPadding(dp(22),dp(24),dp(22),dp(25)); panel.setBackground(shape(t.panel,0,0)); panel.setClickable(true);
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(Math.min(dp(300),getResources().getDisplayMetrics().widthPixels-dp(55)),-1,Gravity.START); drawer.addView(panel,p);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.gplus_wordmark);logo.setScaleType(ImageView.ScaleType.FIT_START);panel.addView(logo,lp(88,55)); panel.addView(gap(28));
        panel.addView(text("G+",22,t.text,true)); panel.addView(gap(8)); panel.addView(text(me==null?"Предварительная сборка":"@"+me.optString("nickname"),14,t.secondary,false)); panel.addView(gap(24));
        menuRow(panel,"chat","Чаты",() -> {closeDrawer();showArchive=false;render();});
        menuRow(panel,"chat","Архив",() -> {closeDrawer();showArchive=true;render();});
        menuRow(panel,"person","Профиль",() -> {closeDrawer();showProfile();});
        menuRow(panel,"palette","Темы",() -> {closeDrawer();chooseTheme();});
        menuRow(panel,"info","Уведомления",() -> {closeDrawer();chooseBackground();});
        menuRow(panel,"refresh","Подключение",() -> {closeDrawer();connect();});
        menuRow(panel,"info","О сборке",() -> {closeDrawer();new AlertDialog.Builder(this).setTitle("G+ в разработке")
            .setMessage("Экспериментальная сборка: чаты, файлы и звонки требуют совместимого сервера и проверки на настоящих устройствах. Звонки пока тестируются.\n\nМедиа хранится на сервере 30 суток после подтверждения последним получателем. Недоставленные файлы по этому сроку не удаляются; сохранённые копии остаются на устройстве.\n\nПотерянный ключ GLINK и прежний аккаунт восстановить нельзя.").setPositiveButton("Понятно",null).show();});
        View flex=new View(this); panel.addView(flex,new LinearLayout.LayoutParams(1,0,1));
        panel.addView(text("GRAPESCRIPT  ·  G+",11,t.secondary,true));
        panel.setTranslationX(-p.width); panel.animate().translationX(0).setDuration(220).start();
    }
    private void menuRow(LinearLayout parent,String glyph,String label,Runnable click) {
        LinearLayout row=horizontal(); row.setPadding(dp(12),0,dp(12),0); row.setBackground(shape(t.panel,12,0));
        row.addView(new Glyph(glyph,t.secondary),lp(22,22)); TextView name=text(label,15,t.text,true); LinearLayout.LayoutParams p=lp(-1,-2);p.leftMargin=dp(16);row.addView(name,p);
        row.setOnClickListener(v -> click.run()); parent.addView(row,lp(-1,50));
    }
    private void closeDrawer() { if(drawer!=null){frame.removeView(drawer);drawer=null;} }
    private void chooseTheme() {
        String[] labels={"Жёлто-чёрная","Бело-фиолетовая","Тёмно-синяя"}, ids={"yellow","white","navy"};
        new AlertDialog.Builder(this).setTitle("Тема оформления").setItems(labels,(d,n) -> {prefs.edit().putString("theme",ids[n]).apply();render();}).setNegativeButton("Отмена",null).show();
    }
    @Override public void onBackPressed() { if(drawer!=null) closeDrawer(); else if(activePeer!=null)leaveChat(); else if(showArchive){showArchive=false;render();}else super.onBackPressed(); }

    private final class Glyph extends View {
        final String glyph; final Paint p=new Paint(3);
        Glyph(String glyph,int color){ super(MainActivity.this);this.glyph=glyph;p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1.8f));p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND); }
        @Override protected void onDraw(Canvas raw) {
            super.onDraw(raw); Canvas c=raw; c.save(); c.scale(getWidth()/24f,getHeight()/24f);
            p.setStrokeWidth(1.8f);
            switch(glyph){
                case "search": c.drawCircle(10,10,6,p);c.drawLine(14.5f,14.5f,20,20,p);break;
                case "attach": {Path a=new Path();a.moveTo(8,13);a.lineTo(14,7);a.cubicTo(16,5,19,5,20,7);a.cubicTo(21,9,21,11,19,13);a.lineTo(11,21);a.cubicTo(8,24,3,21,3,18);a.cubicTo(3,17,3.5f,16,4.5f,15);a.lineTo(13,6.5f);c.drawPath(a,p);break;}
                case "back": c.drawLine(20,12,4,12,p);c.drawLine(4,12,10,6,p);c.drawLine(4,12,10,18,p);break;
                case "send": {Path a=new Path();a.moveTo(3,4);a.lineTo(21,12);a.lineTo(3,20);a.lineTo(7,12);a.close();c.drawPath(a,p);c.drawLine(7,12,21,12,p);break;}
                case "menu": c.drawLine(3,6,21,6,p);c.drawLine(3,12,21,12,p);c.drawLine(3,18,16,18,p);break;
                case "person": c.drawCircle(12,7,3.4f,p);c.drawRoundRect(5.5f,13,18.5f,21,4.5f,4.5f,p);break;
                case "chat": {Path a=new Path();a.moveTo(5,4);a.lineTo(19,4);a.quadTo(22,4,22,7);a.lineTo(22,15);a.quadTo(22,18,19,18);a.lineTo(12,18);a.lineTo(7,21);a.lineTo(7,18);a.lineTo(5,18);a.quadTo(2,18,2,15);a.lineTo(2,7);a.quadTo(2,4,5,4);c.drawPath(a,p);c.drawLine(7,9,17,9,p);c.drawLine(7,13,14,13,p);break;}
                case "refresh": { c.drawArc(4,4,20,20,45,275,false,p);c.drawLine(18,3,20,7,p);c.drawLine(20,7,16,7,p);break; }
                case "palette": c.drawCircle(12,12,9,p);c.drawCircle(8,9,1,p);c.drawCircle(13,7,1,p);c.drawCircle(17,11,1,p);c.drawArc(10,13,18,21,125,150,false,p);break;
                case "info": c.drawCircle(12,12,9,p);c.drawPoint(12,7,p);c.drawLine(12,11,12,17,p);break;
            }
            c.restore();
        }
    }
}
