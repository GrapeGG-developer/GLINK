'use strict';
// Encrypted binary object storage for development. No automatic delivered-media cleanup.
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const {Transform,pipeline}=require('node:stream');const {promisify}=require('node:util');const pipe=promisify(pipeline);
const Database=require('better-sqlite3');const P=require('./protocol');
function reply(res,status,body){if(res.destroyed||res.writableEnded)return;const b=Buffer.from(JSON.stringify(body));res.writeHead(status,{'Content-Type':'application/json','Content-Length':b.length,'Cache-Control':'no-store'});res.end(b);}
function createAssets({dataDir,authenticate,isMember,maxStorageBytes=0,reserveBytes=0,now=Date.now}){
 if(!path.isAbsolute(dataDir)||typeof authenticate!=='function'||typeof isMember!=='function')throw Error('invalid asset configuration');
 if(!Number.isSafeInteger(maxStorageBytes)||maxStorageBytes<0||!Number.isSafeInteger(reserveBytes)||reserveBytes<0)throw Error('invalid asset limits');
 const dir=path.join(dataDir,'encrypted-assets');fs.mkdirSync(dir,{recursive:true,mode:0o700});
 const db=new Database(path.join(dataDir,'gplus-assets.sqlite3'));db.pragma('journal_mode = WAL');db.pragma('synchronous = FULL');
 let activeUploads=0;
 db.exec('CREATE TABLE IF NOT EXISTS assets(id TEXT PRIMARY KEY,chat TEXT NOT NULL,owner TEXT NOT NULL,size INTEGER NOT NULL,sha TEXT NOT NULL,state TEXT NOT NULL,created INTEGER NOT NULL)');
 // Interrupted writes are not delivered media; clean only their temporary files/rows.
 for(const a of db.prepare("SELECT id FROM assets WHERE state='uploading'").all()){
  try{fs.unlinkSync(path.join(dir,a.id+'.tmp'));}catch{}try{fs.unlinkSync(path.join(dir,a.id+'.bin'));}catch{}
 }
 db.prepare("DELETE FROM assets WHERE state='uploading'").run();
 const reserve=db.transaction((id,chat,owner,size,sha)=>{
  const old=db.prepare('SELECT * FROM assets WHERE id=?').get(id);
  if(old){if(old.state==='complete'&&old.chat===chat&&old.owner===owner&&old.size===size&&old.sha===sha)return 'already';return 'conflict';}
  const used=db.prepare('SELECT COALESCE(SUM(size),0) AS n FROM assets').get().n;
  if(maxStorageBytes===0||used+size>maxStorageBytes)return 'full';
  const stat=fs.statfsSync(dir);if(Number(stat.bavail)*Number(stat.bsize)<size+reserveBytes)return 'full';
  db.prepare("INSERT INTO assets(id,chat,owner,size,sha,state,created) VALUES(?,?,?,?,?,'uploading',?)").run(id,chat,owner,size,sha,now());return 'new';
 });
 const api=async function(req,res,next=()=>reply(res,404,{error:'not_found'})){
  const pathname=(req.url||'').split('?')[0];if(!pathname.startsWith('/gplus/assets/'))return next();
  const match=pathname.match(/^\/gplus\/assets\/([A-Za-z0-9_-]{22})$/);if(!match)return reply(res,404,{error:'not_found'});
  const id=match[1],who=authenticate(req);if(!who)return reply(res,401,{error:'unauthorized'});
  if(req.method==='GET'){
   const item=db.prepare("SELECT * FROM assets WHERE id=? AND state='complete'").get(id);
   if(!item||!isMember(item.chat,who.id))return reply(res,404,{error:'asset_not_found'});
   const file=path.join(dir,id+'.bin');try{const stat=await fsp.stat(file);if(stat.size!==item.size)return reply(res,503,{error:'storage_unavailable'});
    res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Length':item.size,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    const stream=fs.createReadStream(file);stream.on('error',()=>res.destroy());stream.pipe(res);return;
   }catch{return reply(res,503,{error:'storage_unavailable'});}
  }
  if(req.method!=='PUT')return reply(res,405,{error:'method_not_allowed'});
  const chat=req.headers['x-gplus-chat'],sha=req.headers['x-gplus-sha256'],raw=req.headers['content-length'];
  const size=Number(raw);
  if(!P.validChat(chat)||!P.validEvent(id)||!/^\d+$/.test(raw||'')||!Number.isSafeInteger(size)||size<1||!(/^[0-9a-f]{64}$/.test(sha||'')))return reply(res,400,{error:'bad_upload'});
  if(!isMember(chat,who.id))return reply(res,404,{error:'chat_not_found'});
  let result;try{result=reserve(id,chat,who.id,size,sha);}catch{return reply(res,503,{error:'storage_unavailable'});}
  if(result==='already'){req.resume();return reply(res,200,{id,size,duplicate:true});}
  if(result==='conflict'){req.resume();return reply(res,409,{error:'asset_conflict'});}
  if(result==='full'){req.resume();return reply(res,507,{error:'storage_full'});}
  const temp=path.join(dir,id+'.tmp'),final=path.join(dir,id+'.bin'),hash=crypto.createHash('sha256');let count=0;
  activeUploads++;
  const meter=new Transform({transform(chunk,encoding,cb){count+=chunk.length;if(count>size)return cb(Error('too_large'));hash.update(chunk);cb(null,chunk);}});
  try{
   await pipe(req,meter,fs.createWriteStream(temp,{flags:'wx',mode:0o600}));
   if(count!==size||hash.digest('hex')!==sha)throw Error('bad_upload');
   const fd=await fsp.open(temp,'r+');try{await fd.sync();}finally{await fd.close();}
   await fsp.rename(temp,final);try{const d=await fsp.open(dir,'r');try{await d.sync();}finally{await d.close();}}catch{}
   db.prepare("UPDATE assets SET state='complete' WHERE id=? AND state='uploading'").run(id);
   return reply(res,201,{id,size,duplicate:false});
  }catch(e){try{await fsp.unlink(temp);}catch{}try{await fsp.unlink(final);}catch{}db.prepare("DELETE FROM assets WHERE id=? AND state='uploading'").run(id);return reply(res,400,{error:e.message==='bad_upload'?'invalid_digest':'upload_failed'});}
  finally{activeUploads--;}
 };
 api.pendingWrites=()=>activeUploads;
 api.close=()=>db.close();return api;
}
module.exports={createAssets};
