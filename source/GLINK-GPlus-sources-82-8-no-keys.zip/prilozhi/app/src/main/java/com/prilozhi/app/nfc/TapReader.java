package com.prilozhi.app.nfc;

import android.content.Context;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.util.Log;

import com.prilozhi.app.net.ReceiveStore;
import com.prilozhi.app.util.State;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Касание NFC в GLINK — только рукопожатие:
 * SELECT, hello (имя + токен GFCAS), дальше телефоны можно разносить.
 * Единственный транспорт файлов — серверный релей (см. net/RelayTransfer). Если канал
 * канал не встал, передача честно заканчивается ошибкой с фазой срыва —
 * устаревшего NFC-канала для файлов больше нет.
 */
public final class TapReader implements NfcAdapter.ReaderCallback {

    public interface Listener {
        void onTransferStarted(String peerName);

        void onNfcTransfer(boolean ok, String message);
    }

    private static final String TAG = "GlinkNfc";
    private static final int PAGE = 180;

    private final Context ctx;
    private final Listener listener;
    private volatile boolean busy = false;

    public TapReader(Context ctx, Listener listener) {
        this.ctx = ctx.getApplicationContext();
        this.listener = listener;
    }

    public static int readerFlags() {
        return NfcAdapter.FLAG_READER_NFC_A
                | NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK;
    }

    @Override
    public void onTagDiscovered(Tag tag) {
        com.prilozhi.app.util.State.get().nfcNearAt = System.currentTimeMillis(); // радар: телефон рядом
        if (busy) return;
        if (System.currentTimeMillis() < State.get().cooldownUntil) return;
        IsoDep iso = IsoDep.get(tag);
        if (iso == null) return; // чужая карта/метка — молча пропускаем
        busy = true;
        final State st = State.get();
        boolean ok = false;
        boolean gplusJob = false;
        String msg;
        try {
            iso.connect();
            try {
                iso.setTimeout(7000);
            } catch (Exception ignored) {
            }

            // SELECT AID (до 3 попыток: поле при касании капризно)
            byte[] sel = new byte[5 + CardService.AID.length + 1];
            sel[0] = 0x00;
            sel[1] = (byte) 0xA4;
            sel[2] = 0x04;
            sel[3] = 0x00;
            sel[4] = (byte) CardService.AID.length;
            System.arraycopy(CardService.AID, 0, sel, 5, CardService.AID.length);
            sel[sel.length - 1] = 0x00;
            byte[] resp = null;
            for (int attempt = 0; attempt < 3; attempt++) {
                try {
                    resp = iso.transceive(sel);
                } catch (Exception e) {
                    resp = null;
                }
                if (isOk(resp)) break;
                sleep(90);
            }
            if (!isOk(resp)) return; // не GLINK — молчим

            // If this side initiated G+, avoid reading any unrelated file-transfer session.
            if (com.prilozhi.app.identity.GPlusNfcStore.active()) {
                gplusJob = true; st.sessionActive = true; exchangeGPlusContact(iso);
                st.cooldownUntil = System.currentTimeMillis() + 5000; ok = true; return;
            }
            JSONObject hello = new JSONObject(readPaged(iso, 0xCA));
            if (hello.optInt("gplus", 0) == 1) {
                gplusJob = true;
                st.sessionActive = true;
                exchangeGPlusContact(iso);
                st.cooldownUntil = System.currentTimeMillis() + 5000;
                ok = true;
                return;
            }
            String peerName = hello.optString("name", "Телефон");
            st.peerName = peerName;
            if (hello.optInt("has", 0) != 1) {
                msg = hello.optInt("pending", 0) == 1 ? "Отправитель ещё подготавливает передачу — повторите касание"
                        : "На втором телефоне ничего не выбрано для отправки";
                listener.onNfcTransfer(false, msg);
                return;
            }
            String session = hello.optString("s", "");
            String keyB64 = hello.optString("k", "");
            if (session.isEmpty() || keyB64.isEmpty()) {
                msg = "Второй телефон не дал сессию сервера — обновите GLINK на нём";
                st.setMode(State.Mode.ERROR, "Старая версия у друга", msg);
                listener.onNfcTransfer(false, msg);
                return;
            }

            st.sessionActive = true;
            st.tapDoneAt = System.currentTimeMillis();
            st.setMode(State.Mode.TAP, "Касание!", "Есть контакт!");
            listener.onTransferStarted(peerName);
            try {
                iso.close(); // NFC свою работу сделал — дальше только GFCAS
            } catch (Exception ignored) {
            }

            // ЕДИНСТВЕННЫЙ ТРАНСПОРТ: серверный релей (ключ получен по NFC)
            st.setMode(State.Mode.TRANSFER, "Передача: подключение…",
                    "Скачиваю с сервера GrapeScript");
            synchronized (st.lastReceived) {
                st.lastReceived.clear();
                st.lastReceivedUris.clear();
            }
            ReceiveStore store = new ReceiveStore(ctx);
            boolean done = com.prilozhi.app.net.RelayTransfer.receive(ctx, session, keyB64, store);
            if (!done) {
                msg = "Не удалось получить: " + st.gfcasPhase;
                st.setMode(State.Mode.ERROR, "Не удалось передать", msg);
                listener.onNfcTransfer(false, msg);
                return;
            }

            st.progress = 1f;
            st.cooldownUntil = System.currentTimeMillis() + 5000;
            st.setMode(State.Mode.SUCCESS, "Готово!", "Получено от " + peerName);
            ok = true;
            msg = "Передача завершена";
            listener.onNfcTransfer(true, msg);
        } catch (Throwable t) {
            Log.w(TAG, "tap fail", t);
            if (gplusJob) {
                listener.onNfcTransfer(false, "Не удалось добавить контакт G+: " + (t.getMessage() == null ? "ошибка NFC" : t.getMessage()));
            } else if (st.mode == State.Mode.TRANSFER || st.mode == State.Mode.TAP
                    || st.mode == State.Mode.CONNECTING) {
                String det = t.getMessage();
                msg = "Обрыв касания: " + (det != null ? det : t.getClass().getSimpleName());
                st.setMode(State.Mode.ERROR, "Ошибка касания", msg);
                listener.onNfcTransfer(false, msg);
            }
        } finally {
            if (ok) st.cooldownUntil = System.currentTimeMillis() + 5000;
            st.sessionActive = false;
            st.notifyChanged();
            try {
                iso.close();
            } catch (Exception ignored) {
            }
            busy = false;
        }
    }

    private void exchangeGPlusContact(IsoDep iso) throws Exception {
        byte[] own = com.prilozhi.app.identity.GPlusNfcStore.own(ctx);
        if (own == null) throw new Exception("Откройте G+ и подключите профиль на обоих телефонах");
        byte[] readerNonce=new byte[32];new java.security.SecureRandom().nextBytes(readerNonce);
        byte[] start=new byte[37];start[1]=(byte)0xD9;start[4]=32;System.arraycopy(readerNonce,0,start,5,32);
        byte[] hello=transceiveRetry(iso,start);
        if(!isOk(hello)||hello.length!=34)throw new Exception("Второму телефону нужно обновление GLINK");
        byte[] hceNonce=java.util.Arrays.copyOf(hello,32);
        for (int offset=0, index=0; offset<own.length; index++) {
            int n=Math.min(PAGE,own.length-offset); boolean last=offset+n==own.length;
            byte[] command=new byte[5+n];command[0]=0;command[1]=(byte)0xDA;command[2]=(byte)index;
            command[3]=(byte)(last?1:0);command[4]=(byte)n;System.arraycopy(own,offset,command,5,n);
            if (!isOk(transceiveRetry(iso,command))) throw new Exception("Второй телефон не готов к знакомству G+");
            offset+=n;
        }
        byte[] peer=readPagedBytes(iso,0xCB);
        grp.gs.protocol.Protocol.Card other=grp.gs.protocol.Protocol.decodeCard(peer);
        grp.gs.protocol.Protocol.Card self=grp.gs.protocol.Protocol.decodeCard(own);
        if (self.id.equals(other.id)) throw new Exception("Это тот же GLINK ID");
        byte[] response=transceiveRetry(iso,new byte[]{0x00,(byte)0xCD,0x00,0x00,0x00});
        if(!isOk(response)||response.length<10||response.length>162)throw new Exception("Второй телефон не подтвердил ключ");
        byte[] sig=java.util.Arrays.copyOf(response,response.length-2);
        byte[] proof=grp.gs.protocol.Protocol.nfcProof(own,peer,readerNonce,hceNonce,"hce");
        if(!grp.gs.protocol.Protocol.verifySignature(other.identityPublic,proof,sig))throw new SecurityException("Подпись второго телефона неверна");
        byte[] readerProof=grp.gs.protocol.Protocol.nfcProof(own,peer,readerNonce,hceNonce,"reader");
        byte[] readerSig=com.prilozhi.app.identity.InstallationIdentity.signGPlusDigest(readerProof);
        byte[] commit=new byte[5+readerSig.length];commit[1]=(byte)0xDC;commit[4]=(byte)readerSig.length;System.arraycopy(readerSig,0,commit,5,readerSig.length);
        if (!isOk(transceiveRetry(iso,commit))) throw new Exception("Контакт G+ не сохранён на втором устройстве");
        com.prilozhi.app.identity.GPlusNfcStore.accept(ctx,peer);
    }

    private String readPaged(IsoDep iso, int ins) throws Exception {
        return new String(readPagedBytes(iso,ins), StandardCharsets.UTF_8);
    }

    private byte[] readPagedBytes(IsoDep iso, int ins) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        for (int page = 0; page < 400; page++) {
            byte[] r = transceiveRetry(iso, new byte[]{0x00, (byte) ins, (byte) page, 0x00, 0x00});
            if (!isOk(r)) throw new Exception("Ошибка чтения hello");
            int n = r.length - 2;
            if (n <= 0) break;
            bos.write(r, 0, n);
            if (n < PAGE) break;
        }
        return bos.toByteArray();
    }

    private byte[] transceiveRetry(IsoDep iso, byte[] apdu) throws Exception {
        Exception err = null;
        for (int att = 0; att < 3; att++) {
            try {
                return iso.transceive(apdu);
            } catch (Exception e) {
                err = e;
                sleep(120);
            }
        }
        throw err != null ? err : new Exception("NFC не отвечает");
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }

    private static boolean isOk(byte[] r) {
        return r != null && r.length >= 2
                && (r[r.length - 2] & 0xFF) == 0x90 && (r[r.length - 1] & 0xFF) == 0x00;
    }
}
