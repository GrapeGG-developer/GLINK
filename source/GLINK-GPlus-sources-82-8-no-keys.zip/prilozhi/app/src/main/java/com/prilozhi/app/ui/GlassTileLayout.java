package com.prilozhi.app.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.RippleDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.LinearLayout;

import com.prilozhi.app.R;

/**
 * A rounded project/fun tile. The animated backdrop is sampled and blurred independently
 * of the children, so text and icons remain sharp. No system overlay permission is used.
 */
public class GlassTileLayout extends LinearLayout {
    private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint colorPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final RectF bounds = new RectF();
    private final int[] tileLocation = new int[2];
    private final int[] backdropLocation = new int[2];
    private float radius;
    private int overlayColor = 0xC825193D;

    public GlassTileLayout(Context c) { super(c); init(); }
    public GlassTileLayout(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        radius = 14f * getResources().getDisplayMetrics().density;
        setWillNotDraw(false);
        setOrientation(HORIZONTAL);
        setGravity(android.view.Gravity.CENTER_VERTICAL);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline outline) {
                outline.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius);
            }
        });
        setClipToOutline(true);
        setForeground(new RippleDrawable(ColorStateList.valueOf(0x38FFFFFF), null, null));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(Math.max(1f, getResources().getDisplayMetrics().density * .7f));
        borderPaint.setColor(0x40FFFFFF);
    }

    /** Maintain the same icon-derived darkened palette used by the project tiles. */
    public void setAccentColor(int accent) {
        overlayColor = Color.argb(206,
                Math.round(Color.red(accent) * .42f),
                Math.round(Color.green(accent) * .42f),
                Math.round(Color.blue(accent) * .42f));
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        bounds.set(0, 0, getWidth(), getHeight());
        clip.reset();
        clip.addRoundRect(bounds, radius, radius, Path.Direction.CW);
        int save = canvas.save();
        canvas.clipPath(clip);
        View root = getRootView();
        View background = root == null ? null : root.findViewById(R.id.backdrop);
        if (background instanceof BackdropView) {
            BackdropView backdrop = (BackdropView) background;
            Bitmap bitmap = backdrop.getBlurredSnapshot();
            if (bitmap != null && backdrop.getWidth() > 0 && backdrop.getHeight() > 0) {
                getLocationOnScreen(tileLocation);
                backdrop.getLocationOnScreen(backdropLocation);
                canvas.save();
                canvas.translate(backdropLocation[0] - tileLocation[0],
                        backdropLocation[1] - tileLocation[1]);
                canvas.scale((float) backdrop.getWidth() / bitmap.getWidth(),
                        (float) backdrop.getHeight() / bitmap.getHeight());
                canvas.drawBitmap(bitmap, 0, 0, bitmapPaint);
                canvas.restore();
            }
        }
        colorPaint.setColor(overlayColor);
        canvas.drawRect(bounds, colorPaint);
        canvas.restoreToCount(save);
        float half = borderPaint.getStrokeWidth() / 2f;
        canvas.drawRoundRect(half, half, getWidth() - half, getHeight() - half,
                radius, radius, borderPaint);
        // Keep the blurred portion aligned with the gently moving backdrop without 60fps work.
        if (isShown()) postInvalidateDelayed(160);
    }
}
