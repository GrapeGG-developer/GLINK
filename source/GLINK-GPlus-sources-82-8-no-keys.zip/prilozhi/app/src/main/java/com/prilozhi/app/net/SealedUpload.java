package com.prilozhi.app.net;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** An in-process resume may only reuse exactly the ciphertext which was sealed. */
final class SealedUpload {
    private final long length;
    private final byte[] digest;
    SealedUpload(long length, byte[] digest) {
        if (length <= 0 || digest == null || digest.length != 32) throw new IllegalArgumentException("invalid_seal");
        this.length=length;this.digest=digest.clone();
    }
    static MessageDigest sha256() {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }
    boolean matches(File file) throws IOException {
        if (!file.isFile() || file.length()!=length) return false;
        MessageDigest hash=sha256();long read=0;
        try(FileInputStream in=new FileInputStream(file)) {
            byte[] b=new byte[128*1024];int n;
            while((n=in.read(b))!=-1){hash.update(b,0,n);read+=n;}
        }
        return read==length && file.length()==length && MessageDigest.isEqual(digest,hash.digest());
    }
}
