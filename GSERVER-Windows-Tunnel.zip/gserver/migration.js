'use strict';
// Cold-snapshot migration for the *single* writer model. The caller MUST freeze
// requests, drain uploads, close both SQLite databases and suspend relay sweeps.
// No data is deleted: the target's previous root is retained beside it.
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const {Transform,pipeline}=require('node:stream');const {promisify}=require('node:util');const pipe=promisify(pipeline);
const Database=require('better-sqlite3');
const MAX_FILES=200000,MAX_MANIFEST=32*1024*1024;
function validTx(t){return typeof t==='string'&&/^[a-f0-9]{32}$/.test(t);}
function validPath(p){
 if(typeof p!=='string'||p.length>700||p.includes('\\')||p.startsWith('/')||p.endsWith('/'))return false;
 const parts=p.split('/');if(parts.length<2||!['gplus','glink'].includes(parts[0]))return false;
 return parts.every(x=>x!=='.'&&x!=='..'&&/^[A-Za-z0-9._-]{1,180}$/.test(x));
}
function verifyManifest(m){
 if(!m||m.version!==1||!validTx(m.tx)||!Array.isArray(m.files)||m.files.length>MAX_FILES||!Number.isSafeInteger(m.total)||m.total<0)throw Error('invalid_manifest');
 let total=0,prev='';for(const e of m.files){
  if(!e||!validPath(e.path)||e.path<=prev||!Number.isSafeInteger(e.size)||e.size<0||!/^[0-9a-f]{64}$/.test(e.sha256||''))throw Error('invalid_manifest_entry');
  prev=e.path;total+=e.size;if(!Number.isSafeInteger(total))throw Error('invalid_manifest_size');
 }
 if(total!==m.total||Buffer.byteLength(JSON.stringify(m))>MAX_MANIFEST)throw Error('invalid_manifest_size');return m;
}
function inside(root,rel){if(!validPath(rel))throw Error('invalid_path');const p=path.resolve(root,...rel.split('/'));if(!p.startsWith(path.resolve(root)+path.sep))throw Error('invalid_path');return p;}
function findEntry(m,rel){let lo=0,hi=m.files.length-1;while(lo<=hi){const mid=(lo+hi)>>1,e=m.files[mid];if(e.path===rel)return e;if(e.path<rel)lo=mid+1;else hi=mid-1;}return null;}
async function safeParent(stage,rel){let p=stage;const root=await fsp.lstat(p);if(!root.isDirectory()||root.isSymbolicLink())throw Error('unsafe_stage');for(const part of rel.split('/').slice(0,-1)){p=path.join(p,part);try{await fsp.mkdir(p,{mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}const st=await fsp.lstat(p);if(!st.isDirectory()||st.isSymbolicLink())throw Error('unsafe_stage');}}
async function hashFile(file){return new Promise((resolve,reject)=>{const h=crypto.createHash('sha256'),r=fs.createReadStream(file);r.on('error',reject);r.on('data',b=>h.update(b));r.on('end',()=>resolve(h.digest('hex')));});}
async function list(root,dir,prefix,out){
 let names;try{names=await fsp.readdir(dir,{withFileTypes:true});}catch(e){if(e.code==='ENOENT')return;throw e;}
 for(const entry of names){const rel=prefix+'/'+entry.name;if(!validPath(rel))throw Error('unsafe_storage_name');const name=path.join(dir,entry.name),st=await fsp.lstat(name);
  if(st.isSymbolicLink())throw Error('storage_symlink');
  if(st.isDirectory())await list(root,name,rel,out);
  else if(st.isFile()){if(!Number.isSafeInteger(st.size))throw Error('file_too_large');out.push({path:rel,size:st.size,sha256:await hashFile(name)});if(out.length>MAX_FILES)throw Error('too_many_files');}
  else throw Error('unsafe_storage_entry');
 }
}
async function snapshot(root,tx){
 if(!path.isAbsolute(root)||!validTx(tx))throw Error('invalid_snapshot');
 const top=await fsp.readdir(root,{withFileTypes:true});if(top.some(e=>!['gplus','glink'].includes(e.name)||!e.isDirectory()||e.isSymbolicLink()))throw Error('dedicated_storage_required');
 const all=[];await list(root,path.join(root,'gplus'),'gplus',all);await list(root,path.join(root,'glink'),'glink',all);all.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
 let total=0;for(const e of all)total+=e.size;return verifyManifest({version:1,tx,total,files:all});
}
function stagePath(root,tx){if(!path.isAbsolute(root)||!validTx(tx))throw Error('invalid_stage');return path.join(path.dirname(root),'.'+path.basename(root)+'-stage-'+tx);}
function manifestPath(root,tx){return stagePath(root,tx)+'.manifest.json';}
function backupPath(root,tx){return path.join(path.dirname(root),path.basename(root)+'-backup-'+tx);}
function freeBytes(dir){let s=fs.statfsSync(dir);const n=Number(s.bavail)*Number(s.bsize);if(!Number.isFinite(n)||n<0)throw Error('cannot_check_disk');return n;}
async function syncFile(file){const f=await fsp.open(file,'r+');try{await f.sync();}finally{await f.close();}}
async function syncDir(dir){try{const f=await fsp.open(dir,'r');try{await f.sync();}finally{await f.close();}}catch{/* Windows does not support fsync on directories. */}}
async function prepare(root,m,reserveBytes=0){
 verifyManifest(m);if(!Number.isSafeInteger(reserveBytes)||reserveBytes<0)throw Error('invalid_reserve');
 const parent=path.dirname(root);await fsp.mkdir(parent,{recursive:true});
 if(freeBytes(parent)<m.total+reserveBytes)throw Error('not_enough_space');
 const stage=stagePath(root,m.tx),mp=manifestPath(root,m.tx),backup=backupPath(root,m.tx);
 if(fs.existsSync(stage)||fs.existsSync(mp)||fs.existsSync(backup))throw Error('transaction_exists');
 await fsp.mkdir(stage,{recursive:false,mode:0o700});
 try{await fsp.mkdir(path.join(stage,'gplus'));await fsp.mkdir(path.join(stage,'glink'));await fsp.writeFile(mp,JSON.stringify(m),{flag:'wx',mode:0o600});await syncFile(mp);await syncDir(parent);}
 catch(e){/* retain incomplete stage for inspection; never silently erase it */throw e;}
 return stage;
}
function loadManifest(root,tx){const p=manifestPath(root,tx);const s=fs.statSync(p);if(s.size>MAX_MANIFEST)throw Error('manifest_too_large');return verifyManifest(JSON.parse(fs.readFileSync(p,'utf8')));}
async function receive(root,tx,rel,stream,declared){
 const m=loadManifest(root,tx),entry=findEntry(m,rel);if(!entry||declared!==entry.size)throw Error('unexpected_file');
 const stage=stagePath(root,tx),dest=inside(stage,rel),tmp=dest+'.uploading';
 await safeParent(stage,rel);
 if(fs.existsSync(dest)){const st=await fsp.stat(dest);if(st.size===entry.size&&await hashFile(dest)===entry.sha256){stream.resume();return;}throw Error('file_conflict');}
 if(fs.existsSync(tmp))throw Error('partial_upload_exists');
 let n=0;const hash=crypto.createHash('sha256');const meter=new Transform({transform(chunk,enc,cb){n+=chunk.length;if(n>entry.size)return cb(Error('file_too_large'));hash.update(chunk);cb(null,chunk);}});
 try{await pipe(stream,meter,fs.createWriteStream(tmp,{flags:'wx',mode:0o600}));if(n!==entry.size||hash.digest('hex')!==entry.sha256)throw Error('digest_mismatch');await syncFile(tmp);await fsp.rename(tmp,dest);await syncDir(path.dirname(dest));}
 catch(e){try{await fsp.unlink(tmp);}catch{}throw e;}
}
async function verifyTree(root,m){
 verifyManifest(m);for(const e of m.files){const file=inside(root,e.path),st=await fsp.lstat(file);if(!st.isFile()||st.isSymbolicLink()||st.size!==e.size||await hashFile(file)!==e.sha256)throw Error('snapshot_verification_failed');}
 const actual=[];await list(root,path.join(root,'gplus'),'gplus',actual);await list(root,path.join(root,'glink'),'glink',actual);actual.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
 if(actual.length!==m.files.length||actual.some((e,i)=>e.path!==m.files[i].path||e.size!==m.files[i].size||e.sha256!==m.files[i].sha256))throw Error('unexpected_snapshot_files');
 const account=path.join(root,'gplus','accounts-v1.json');if(fs.existsSync(account)){let a=JSON.parse(fs.readFileSync(account,'utf8'));if(a.version!==1||!a.accounts||typeof a.accounts!=='object'||Array.isArray(a.accounts))throw Error('invalid_accounts');}
 for(const dbName of ['gplus-messages.sqlite3','gplus-assets.sqlite3']){
  const file=path.join(root,'gplus',dbName);if(!fs.existsSync(file))continue;
  const db=new Database(file,{readonly:true,fileMustExist:true});try{
   if(db.pragma('integrity_check',{simple:true})!=='ok'||db.pragma('foreign_key_check').length)throw Error('sqlite_integrity_failed');
   if(dbName==='gplus-assets.sqlite3'){
    for(const a of db.prepare('SELECT id,size,sha,state FROM assets').all()){
     if(a.state!=='complete'||!/^[A-Za-z0-9_-]{22}$/.test(a.id)||!/^[0-9a-f]{64}$/.test(a.sha)||!Number.isSafeInteger(a.size))throw Error('invalid_asset_row');
     const entry=findEntry(m,'gplus/encrypted-assets/'+a.id+'.bin');if(!entry||entry.size!==a.size||entry.sha256!==a.sha)throw Error('asset_missing_or_damaged');
    }
   }
  }finally{db.close();}
 }
}
async function commit(root,tx){
 const m=loadManifest(root,tx),stage=stagePath(root,tx),backup=backupPath(root,tx);
 if(fs.existsSync(stage)){
  await verifyTree(stage,m);
  if(!fs.existsSync(backup)){if(!fs.existsSync(root))throw Error('target_root_missing');await fsp.rename(root,backup);await syncDir(path.dirname(root));}
  if(fs.existsSync(root))throw Error('ambiguous_target_state');
  await fsp.rename(stage,root);await syncDir(path.dirname(root));
 } else {
  // A process may have stopped between the final rename and acknowledging it.
  if(!fs.existsSync(backup)||!fs.existsSync(root))throw Error('transaction_not_ready');
  await verifyTree(root,m);
 }
 return {tx,backup,files:m.files.length,total:m.total};
}
module.exports={MAX_MANIFEST,validPath,validTx,verifyManifest,inside,hashFile,snapshot,prepare,receive,commit,verifyTree,stagePath,backupPath,loadManifest};
