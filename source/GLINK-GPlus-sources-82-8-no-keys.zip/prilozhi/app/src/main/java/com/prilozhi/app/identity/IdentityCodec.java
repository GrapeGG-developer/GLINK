package com.prilozhi.app.identity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

/** Public IDs are derived from public keys; the private key is never displayed. */
public final class IdentityCodec {
    private static final byte[] AUTH_DOMAIN = "G+ AUTH v1\0".getBytes(StandardCharsets.UTF_8);
    private IdentityCodec() {}

    public static String idFromPublicKey(byte[] key) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(key);
            byte[] shortHash = new byte[12];
            System.arraycopy(hash, 0, shortHash, 0, shortHash.length);
            String id = Base64.getUrlEncoder().withoutPadding().encodeToString(shortHash);
            return id.substring(0, 4) + "-" + id.substring(4, 8) + "-"
                    + id.substring(8, 12) + "-" + id.substring(12, 16);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public static byte[] challengeMessage(byte[] nonce) {
        if (nonce == null || nonce.length != 32) throw new IllegalArgumentException("Expected a 32-byte challenge");
        byte[] message = new byte[AUTH_DOMAIN.length + nonce.length];
        System.arraycopy(AUTH_DOMAIN, 0, message, 0, AUTH_DOMAIN.length);
        System.arraycopy(nonce, 0, message, AUTH_DOMAIN.length, nonce.length);
        return message;
    }
}
