package com.prilozhi.app.net;

import android.net.Uri;

public class OutItem {
    public static final int KIND_FILE = 0;
    public static final int KIND_TREE = 1;
    public static final int KIND_TEXT = 2;
    public static final int KIND_FUN = 3;

    public final int kind;
    public final Uri uri;
    /** Distinguishes a newly selected item from an older item with the same name/size. */
    public final String selectionId = java.util.UUID.randomUUID().toString();
    public String displayName;
    public String mime;
    public long size;
    public String text;
    public boolean isLink;

    private OutItem(int kind, Uri uri) {
        this.kind = kind;
        this.uri = uri;
        this.size = -1;
    }

    public static OutItem file(Uri uri, String name, String mime, long size) {
        OutItem it = new OutItem(KIND_FILE, uri);
        it.displayName = name;
        it.mime = mime;
        it.size = size;
        return it;
    }

    public static OutItem tree(Uri uri, String name) {
        OutItem it = new OutItem(KIND_TREE, uri);
        it.displayName = name;
        it.mime = "vnd.android.document/directory";
        return it;
    }

    public static OutItem text(String text, boolean isLink) {
        OutItem it = new OutItem(KIND_TEXT, null);
        it.text = text;
        it.isLink = isLink;
        it.displayName = isLink ? "Ссылка" : "Текст";
        it.mime = isLink ? "text/uri-list" : "text/plain";
        it.size = text != null ? text.length() : 0;
        return it;
    }

    /** Прикол: едет отдельным форматом GLINKFUN/1, не текстом и не файлом. */
    public static OutItem fun(String cmd) {
        OutItem it = new OutItem(KIND_FUN, null);
        it.text = cmd;
        it.displayName = "Прикол: " + cmd;
        it.mime = "application/x-glink-fun";
        it.size = 0;
        return it;
    }

    public OutItem copyForResend() {
        OutItem copy = new OutItem(kind, uri);
        copy.displayName = displayName;copy.mime = mime;copy.size = size;copy.text = text;copy.isLink = isLink;
        return copy;
    }

    public String label() {
        if (kind == KIND_FUN) return "Прикол: " + text;
        if (kind == KIND_TEXT) {
            String t = text == null ? "" : text.trim();
            if (t.length() > 40) t = t.substring(0, 40) + "…";
            return t;
        }
        return displayName != null ? displayName : "—";
    }

    public String typeLabel() {
        switch (kind) {
            case KIND_TREE:
                return "Папка";
            case KIND_TEXT:
                return isLink ? "Ссылка" : "Текст";
            case KIND_FUN:
                return "Прикол";
            default:
                return "Файл";
        }
    }
}
