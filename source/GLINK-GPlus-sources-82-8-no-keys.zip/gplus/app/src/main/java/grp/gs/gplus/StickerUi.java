package grp.gs.gplus;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import java.util.function.Consumer;

final class StickerUi {
    private StickerUi(){}
    static void choose(Activity activity,Consumer<JSONObject> send){
        String[] ids={"berry","spark","leaf","orbit"};float density=activity.getResources().getDisplayMetrics().density;LinearLayout grid=new LinearLayout(activity);grid.setOrientation(LinearLayout.VERTICAL);int pad=Math.round(16*density);grid.setPadding(pad,pad,pad,pad);AlertDialog dialog=new AlertDialog.Builder(activity).setTitle("Стикеры G+").setView(grid).setNegativeButton("Отмена",null).create();for(int row=0;row<2;row++){LinearLayout line=new LinearLayout(activity);for(int col=0;col<2;col++){String id=ids[row*2+col];LinearLayout cell=new LinearLayout(activity);cell.setOrientation(LinearLayout.VERTICAL);cell.setGravity(Gravity.CENTER);StickerView sticker=new StickerView(activity,id);cell.addView(sticker,new LinearLayout.LayoutParams(Math.round(90*density),Math.round(90*density)));TextView title=new TextView(activity);title.setText(StickerView.title(id));title.setTypeface(Typeface.DEFAULT_BOLD);title.setGravity(Gravity.CENTER);cell.addView(title);cell.setPadding(pad,pad,pad,pad);cell.setOnClickListener(v->{try{JSONObject m=new JSONObject().put("v",1).put("type","sticker").put("sticker",id);dialog.dismiss();send.accept(m);}catch(Exception ignored){}});line.addView(cell,new LinearLayout.LayoutParams(0,-2,1));}grid.addView(line);}dialog.show();
    }
}
