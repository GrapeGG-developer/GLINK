package com.prilozhi.app;

import com.prilozhi.app.net.ManifestBuilder;
import com.prilozhi.app.net.OutItem;
import com.prilozhi.app.util.Fmt;
import com.prilozhi.app.util.State;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/** Базовые юнит-тесты GLINK (стабы): чистая логика без Android-окружения. */
public class GlinkUnitTest {

    @Test
    public void fmt_sizeBoundaries() {
        assertEquals("—", Fmt.size(-1));
        assertEquals("512 Б", Fmt.size(512));
        assertTrue(Fmt.size(2048).contains("КБ"));
        assertTrue(Fmt.size(5L * 1024 * 1024).contains("МБ"));
        assertTrue(Fmt.size(3L * 1024 * 1024 * 1024).contains("ГБ"));
    }

    @Test
    public void fmt_speedSuffix() {
        assertTrue(Fmt.speed(1024).endsWith("/с"));
    }

    @Test
    public void manifest_sanitizeRemovesBadChars() {
        assertEquals("a_b_c_d.txt", ManifestBuilder.sanitize("a/b:c*d.txt"));
        assertEquals("file", ManifestBuilder.sanitize("   "));
        assertEquals("ок.txt", ManifestBuilder.sanitize("ок.txt"));
    }

    @Test
    public void manifest_uniquePaths() {
        ManifestBuilder.Built b = new ManifestBuilder.Built();
        assertEquals("a.txt", b.unique("a.txt"));
        assertEquals("a (1).txt", b.unique("a.txt"));
        assertEquals("a (2).txt", b.unique("a.txt"));
        assertEquals("dir/a.txt", b.unique("dir/a.txt"));
    }

    @Test
    public void funItem_isSeparateFormat() {
        OutItem it = OutItem.fun("DISCO");
        assertEquals(OutItem.KIND_FUN, it.kind);
        assertEquals("Прикол", it.typeLabel());
        assertEquals("Прикол: DISCO", it.label());
        assertEquals("application/x-glink-fun", it.mime);
        assertEquals(0, it.size);
    }

    @Test
    public void modes_coverTransferStates() {
        assertTrue(State.Mode.valueOf("TRANSFER") != null);
        assertTrue(State.Mode.valueOf("READY_SEND") != null);
        assertTrue(State.Mode.valueOf("SUCCESS") != null);
        assertTrue(State.Mode.valueOf("ERROR") != null);
    }

    @Test
    public void state_tokenShape() {
        String t = State.newToken();
        assertEquals(6, t.length());
        for (char c : t.toCharArray()) {
            assertTrue("ABCDEFGHJKLMNPQRSTUVWXYZ23456789".indexOf(c) >= 0);
        }
    }

    @Test
    public void fun_onlyOnePerTransfer() throws Exception {
        java.util.List<com.prilozhi.app.net.OutItem> items = new java.util.ArrayList<>();
        items.add(com.prilozhi.app.net.OutItem.fun("RAIN"));
        items.add(com.prilozhi.app.net.OutItem.fun("DISCO"));
        com.prilozhi.app.net.ManifestBuilder.Built b =
                com.prilozhi.app.net.ManifestBuilder.build(null, items);
        // в передачу уходит только первый прикол, файлов приколы не создают
        assertEquals("RAIN", b.fun);
        assertTrue(b.files.isEmpty());
    }

    @Test
    public void manifest_textAndLinkGoToSeparateFields() throws Exception {
        java.util.List<com.prilozhi.app.net.OutItem> items = new java.util.ArrayList<>();
        items.add(com.prilozhi.app.net.OutItem.text("привет от друга", false));
        items.add(com.prilozhi.app.net.OutItem.text("https://example.com", true));
        com.prilozhi.app.net.ManifestBuilder.Built b =
                com.prilozhi.app.net.ManifestBuilder.build(null, items);
        assertEquals("https://example.com", b.link);
        assertTrue(b.text != null && b.text.contains("привет"));
        assertTrue(b.files.isEmpty());
    }

    @Test
    public void outItem_labelsAndTypes() {
        assertEquals("Текст", com.prilozhi.app.net.OutItem.text("abc", false).typeLabel());
        assertEquals("Ссылка", com.prilozhi.app.net.OutItem.text("https://x", true).typeLabel());
        assertEquals("Прикол", com.prilozhi.app.net.OutItem.fun("RAIN").typeLabel());
        assertTrue(com.prilozhi.app.net.OutItem.fun("RAIN").label().contains("RAIN"));
    }

    @Test
    public void manifest_sanitizeKeepsNormalNames() {
        assertEquals("photo_1.jpg", com.prilozhi.app.net.ManifestBuilder.sanitize("photo_1.jpg"));
    }
}
