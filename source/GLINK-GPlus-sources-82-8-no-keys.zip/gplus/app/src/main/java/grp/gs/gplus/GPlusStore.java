package grp.gs.gplus;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import grp.gs.protocol.Protocol;
import java.util.ArrayList;
import java.util.List;

/** Local contacts and encrypted message envelopes. Private message plaintext is not stored here. */
public final class GPlusStore extends SQLiteOpenHelper {
    private static final String DB="gplus-local-v1.db";
    public GPlusStore(Context ctx){this(ctx,DB);}
    GPlusStore(Context ctx,String name){super(ctx.getApplicationContext(),name,null,3);setWriteAheadLoggingEnabled(true);}
    @Override public void onConfigure(SQLiteDatabase db){super.onConfigure(db);try(Cursor c=db.rawQuery("PRAGMA secure_delete=ON",null)){c.moveToFirst();}}
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE contacts (id TEXT PRIMARY KEY, nickname TEXT NOT NULL, display TEXT NOT NULL, card BLOB NOT NULL, added INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE conversations (id TEXT PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL DEFAULT '', peer_id TEXT, pinned INTEGER NOT NULL DEFAULT 0, archived INTEGER NOT NULL DEFAULT 0, updated INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE envelopes (event_id TEXT NOT NULL, chat_id TEXT NOT NULL, sender TEXT NOT NULL, recipient TEXT NOT NULL, ciphertext TEXT NOT NULL, signature TEXT NOT NULL, server_seq INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL DEFAULT 0, expires INTEGER NOT NULL DEFAULT 0, state TEXT NOT NULL DEFAULT 'sent', PRIMARY KEY(event_id,recipient))");
        db.execSQL("CREATE INDEX envelopes_chat ON envelopes(chat_id,server_seq,created)");
        db.execSQL("CREATE TABLE outbox (event_id TEXT PRIMARY KEY, chat_id TEXT NOT NULL, payload TEXT NOT NULL, asset_id TEXT, created INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE local_assets (id TEXT PRIMARY KEY, chat_id TEXT NOT NULL, filename TEXT NOT NULL, size INTEGER NOT NULL, sha TEXT NOT NULL, uploaded INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE sync_cursors (chat_id TEXT PRIMARY KEY, seq INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE notified (chat_id TEXT PRIMARY KEY, seq INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE groups (id TEXT PRIMARY KEY, state TEXT NOT NULL, updated INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE pending_media_receipts (asset_id TEXT NOT NULL, event_id TEXT NOT NULL, sha TEXT NOT NULL, created INTEGER NOT NULL, attempted INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(asset_id,event_id))");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV){
        if(oldV<2&&newV>=2){
            db.execSQL("CREATE TABLE IF NOT EXISTS groups (id TEXT PRIMARY KEY, state TEXT NOT NULL, updated INTEGER NOT NULL)");
            db.execSQL("CREATE TABLE IF NOT EXISTS notified (chat_id TEXT PRIMARY KEY, seq INTEGER NOT NULL)");
            db.execSQL("CREATE TABLE IF NOT EXISTS sync_cursors (chat_id TEXT PRIMARY KEY, seq INTEGER NOT NULL)");
            db.execSQL("CREATE TABLE IF NOT EXISTS local_assets (id TEXT PRIMARY KEY, chat_id TEXT NOT NULL, filename TEXT NOT NULL, size INTEGER NOT NULL, sha TEXT NOT NULL, uploaded INTEGER NOT NULL DEFAULT 0)");
            db.execSQL("CREATE TABLE IF NOT EXISTS outbox (event_id TEXT PRIMARY KEY, chat_id TEXT NOT NULL, payload TEXT NOT NULL, asset_id TEXT, created INTEGER NOT NULL)");
            if(!column(db,"envelopes","expires"))db.execSQL("ALTER TABLE envelopes ADD COLUMN expires INTEGER NOT NULL DEFAULT 0");
            if(!column(db,"outbox","asset_id"))db.execSQL("ALTER TABLE outbox ADD COLUMN asset_id TEXT");
        }
        if(oldV<3&&newV>=3)db.execSQL("CREATE TABLE IF NOT EXISTS pending_media_receipts (asset_id TEXT NOT NULL, event_id TEXT NOT NULL, sha TEXT NOT NULL, created INTEGER NOT NULL, attempted INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(asset_id,event_id))");
        if(newV>3)throw new IllegalStateException("Migration required");
    }
    private static boolean column(SQLiteDatabase db,String table,String name){try(Cursor c=db.rawQuery("PRAGMA table_info("+table+")",null)){int i=c.getColumnIndex("name");while(c.moveToNext())if(name.equals(c.getString(i)))return true;return false;}}
    public synchronized Protocol.Card putContact(byte[] bytes,String ownId)throws Exception{
        Protocol.Card card=Protocol.decodeCard(bytes);
        if(card.id.equals(ownId))throw new SecurityException("Cannot add your own device");
        ContentValues v=new ContentValues();v.put("id",card.id);v.put("nickname",card.nick);v.put("display",card.display);v.put("card",bytes);v.put("added",System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("contacts",null,v,SQLiteDatabase.CONFLICT_REPLACE);return card;
    }
    public Protocol.Card contact(String id)throws Exception{
        try(Cursor c=getReadableDatabase().query("contacts",new String[]{"card"},"id=?",new String[]{id},null,null,null)){
            return c.moveToFirst()?Protocol.decodeCard(c.getBlob(0)):null;
        }
    }
    public List<Protocol.Card> contacts()throws Exception{
        List<Protocol.Card> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().query("contacts",new String[]{"card"},null,null,null,null,"display COLLATE NOCASE")){
            while(c.moveToNext())out.add(Protocol.decodeCard(c.getBlob(0)));
        } return out;
    }
    public synchronized void putGroup(SignedGroup group)throws Exception{
        org.json.JSONObject incoming=group.json();String existing=groupState(group.id);
        if(existing!=null){org.json.JSONObject old=new org.json.JSONObject(existing);for(String k:new String[]{"id","kind","title","owner"})if(!old.getString(k).equals(incoming.getString(k)))throw new SecurityException("Group state changed");if(!old.getJSONArray("cards").toString().equals(incoming.getJSONArray("cards").toString()))throw new SecurityException("Group membership changed");}
        ContentValues v=new ContentValues();v.put("id",group.id);v.put("state",incoming.toString());v.put("updated",System.currentTimeMillis());getWritableDatabase().insertWithOnConflict("groups",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public String groupState(String id){try(Cursor c=getReadableDatabase().query("groups",new String[]{"state"},"id=?",new String[]{id},null,null,null)){return c.moveToFirst()?c.getString(0):null;}}
    public List<String> groupStates(){List<String> out=new ArrayList<>();try(Cursor c=getReadableDatabase().query("groups",new String[]{"state"},null,null,null,null,"updated DESC")){while(c.moveToNext())out.add(c.getString(0));}return out;}
    public void upsertDirect(String id,Protocol.Card peer){
        ContentValues v=new ContentValues();v.put("id",id);v.put("kind","direct");v.put("title",peer.display);v.put("peer_id",peer.id);v.put("updated",System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("conversations",null,v,SQLiteDatabase.CONFLICT_IGNORE);
    }
    public void saveEnvelope(String chat,String event,String sender,String recipient,String ciphertext,String signature,long seq,long created,long expires,String state){
        ContentValues v=new ContentValues();v.put("chat_id",chat);v.put("event_id",event);v.put("sender",sender);v.put("recipient",recipient);v.put("ciphertext",ciphertext);v.put("signature",signature);v.put("server_seq",seq);v.put("created",created);v.put("expires",expires);v.put("state",state);
        getWritableDatabase().insertWithOnConflict("envelopes",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public synchronized void saveDraft(String chat,String event,String owner,String cipher,String sig,String payload,long created,String asset,MediaCrypto.Prepared file){
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            saveEnvelope(chat,event,owner,owner,cipher,sig,0,created,0,"pending");
            ContentValues v=new ContentValues();v.put("event_id",event);v.put("chat_id",chat);v.put("payload",payload);if(asset!=null)v.put("asset_id",asset);v.put("created",created);db.insertWithOnConflict("outbox",null,v,SQLiteDatabase.CONFLICT_IGNORE);
            if(asset!=null&&file!=null){ContentValues a=new ContentValues();a.put("id",asset);a.put("chat_id",chat);a.put("filename",file.file.getAbsolutePath());a.put("size",file.cipherSize);a.put("sha",file.sha256);a.put("uploaded",0);db.insertOrThrow("local_assets",null,a);}
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    public String[] localAsset(String id){try(Cursor c=getReadableDatabase().query("local_assets",new String[]{"filename","size","sha","uploaded"},"id=?",new String[]{id},null,null,null)){return c.moveToFirst()?new String[]{c.getString(0),c.getString(1),c.getString(2),c.getString(3)}:null;}}
    public void markAssetUploaded(String id){ContentValues v=new ContentValues();v.put("uploaded",1);getWritableDatabase().update("local_assets",v,"id=?",new String[]{id});}
    /** Queue only after the encrypted file is durable and fully authenticated. */
    public synchronized void queueMediaReceipt(String asset,String event,String sha){
        if(!Protocol.validEventId(asset)||!Protocol.validEventId(event)||sha==null||!sha.matches("[0-9a-f]{64}"))throw new IllegalArgumentException("Invalid media receipt");
        SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("asset_id",asset);v.put("event_id",event);v.put("sha",sha);v.put("created",System.currentTimeMillis());
        if(db.insertWithOnConflict("pending_media_receipts",null,v,SQLiteDatabase.CONFLICT_IGNORE)==-1){
            try(Cursor c=db.query("pending_media_receipts",new String[]{"sha"},"asset_id=? AND event_id=?",new String[]{asset,event},null,null,null)){if(!c.moveToFirst()||!sha.equals(c.getString(0)))throw new SecurityException("Conflicting media receipt");}
        }
    }
    public List<String[]> pendingMediaReceipts(){List<String[]> result=new ArrayList<>();try(Cursor c=getReadableDatabase().query("pending_media_receipts",new String[]{"asset_id","event_id","sha"},null,null,null,null,"attempted ASC,created ASC","8")){while(c.moveToNext())result.add(new String[]{c.getString(0),c.getString(1),c.getString(2)});}return result;}
    public void markMediaReceiptAttempt(String asset,String event,String sha){ContentValues v=new ContentValues();v.put("attempted",Math.max(1,System.currentTimeMillis()));getWritableDatabase().update("pending_media_receipts",v,"asset_id=? AND event_id=? AND sha=?",new String[]{asset,event,sha});}
    public void removeMediaReceipt(String asset,String event,String sha){getWritableDatabase().delete("pending_media_receipts","asset_id=? AND event_id=? AND sha=?",new String[]{asset,event,sha});}
    public void removeOutbox(String event){getWritableDatabase().delete("outbox","event_id=?",new String[]{event});}
    public List<String[]> outbox(String chat){
        List<String[]> result=new ArrayList<>();try(Cursor c=getReadableDatabase().query("outbox",new String[]{"event_id","payload","asset_id"},"chat_id=?",new String[]{chat},null,null,"created ASC")){while(c.moveToNext())result.add(new String[]{c.getString(0),c.getString(1),c.getString(2)});}return result;
    }
    public long notified(String chat){try(Cursor c=getReadableDatabase().rawQuery("SELECT seq FROM notified WHERE chat_id=?",new String[]{chat})){return c.moveToFirst()?c.getLong(0):0;}}
    public synchronized void markNotified(String chat,long seq){SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("chat_id",chat);v.put("seq",seq);db.insertWithOnConflict("notified",null,v,SQLiteDatabase.CONFLICT_IGNORE);db.execSQL("UPDATE notified SET seq=MAX(seq,?) WHERE chat_id=?",new Object[]{seq,chat});}
    public long cursor(String chat){try(Cursor c=getReadableDatabase().rawQuery("SELECT seq FROM sync_cursors WHERE chat_id=?",new String[]{chat})){return c.moveToFirst()?c.getLong(0):0;}}
    public synchronized void saveIncoming(String chat,String event,String sender,String recipient,String cipher,String sig,long seq,long created,long expires,String state){
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{saveEnvelope(chat,event,sender,recipient,cipher,sig,seq,created,expires,state);ContentValues v=new ContentValues();v.put("chat_id",chat);v.put("seq",seq);db.insertWithOnConflict("sync_cursors",null,v,SQLiteDatabase.CONFLICT_IGNORE);db.execSQL("UPDATE sync_cursors SET seq=MAX(seq,?) WHERE chat_id=?",new Object[]{seq,chat});db.setTransactionSuccessful();}finally{db.endTransaction();}
    }
    public List<String[]> envelopes(String chat){return envelopesAfter(chat,-1);}
    public List<String[]> envelopesAfter(String chat,long seq){
        getWritableDatabase().delete("envelopes","expires>0 AND expires<=?",new String[]{Long.toString(System.currentTimeMillis())});
        List<String[]> result=new ArrayList<>();
        String where=seq<0?"chat_id=?":"chat_id=? AND server_seq>?";String[] args=seq<0?new String[]{chat}:new String[]{chat,Long.toString(seq)};
        try(Cursor c=getReadableDatabase().query("envelopes",new String[]{"event_id","sender","recipient","ciphertext","signature","server_seq","created","state"},where,args,null,null,"created ASC, server_seq ASC")){
            while(c.moveToNext())result.add(new String[]{c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7)});
        }return result;
    }
}
