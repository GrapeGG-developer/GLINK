package com.prilozhi.app.net;
import org.junit.Test;
import static org.junit.Assert.*;
public class DownloadRangeTest {
    @Test public void acceptsOnlyExpectedSessionRange() {
        assertTrue(DownloadRange.valid("bytes 10-99/100",10,100,90));
        assertTrue(DownloadRange.valid("bytes 10-19/100",10,100,-1));
        assertFalse(DownloadRange.valid("bytes 0-99/100",10,100,100));
        assertFalse(DownloadRange.valid("bytes 10-99/101",10,100,90));
        assertFalse(DownloadRange.valid("bytes 10-100/100",10,100,91));
        assertFalse(DownloadRange.valid("bytes 10-99/100",10,100,89));
        assertFalse(DownloadRange.valid("bytes 10-99/*",10,100,-1));
        assertFalse(DownloadRange.valid("bytes 999999999999999999999-99/100",10,100,-1));
        assertFalse(DownloadRange.valid(null,0,100,-1));
    }
}
