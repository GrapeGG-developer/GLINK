package grp.gs.gplus;

import grp.gs.protocol.Protocol;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

/** Multi-recipient HPKE envelopes; membership is signed and message bodies remain encrypted. */
public final class GroupEngine {
    private final GlinkBridge bridge;private final GPlusApi api;private final GPlusStore store;
    public GroupEngine(GlinkBridge bridge,GPlusApi api,GPlusStore store){this.bridge=bridge;this.api=api;this.store=store;}
    public SignedGroup parse(JSONObject state)throws Exception{return SignedGroup.parse(state,bridge.id(),bridge.publicKey(),bridge.encryptionPublic());}
    public SignedGroup load(String id)throws Exception{String state=store.groupState(id);if(state==null)throw new IllegalArgumentException("Группа недоступна");return parse(new JSONObject(state));}
    public SignedGroup create(String kind,String title,List<Protocol.Card> contacts)throws Exception{
        JSONObject me=api.me();if(me.optString("nickname").isEmpty()||me.optString("display_name").isEmpty())throw new IllegalStateException("Нужен профиль");
        SignedGroup group=SignedGroup.create(kind,title,ContactCardFactory.create(me,bridge),contacts,bridge);
        SignedGroup confirmed=parse(api.createGroup(group.json()).getJSONObject("state"));if(!confirmed.id.equals(group.id))throw new SecurityException("Неверный ID группы");store.putGroup(confirmed);return confirmed;
    }
    public List<SignedGroup> discover()throws Exception{
        JSONArray chats=api.chats().getJSONArray("chats");for(int i=0;i<chats.length();i++){JSONObject c=chats.getJSONObject(i);String kind=c.optString("kind"),id=c.optString("id");if(!"group".equals(kind)&&!"channel".equals(kind))continue;SignedGroup group=parse(api.groupState(id).getJSONObject("state"));if(!id.equals(group.id)||!kind.equals(group.kind))throw new SecurityException("Неверное состояние группы");store.putGroup(group);}
        List<SignedGroup> out=new ArrayList<>();for(String s:store.groupStates())out.add(parse(new JSONObject(s)));return out;
    }
    public void queue(SignedGroup group,JSONObject message)throws Exception{queue(group,message,null,null,0);}
    private void queue(SignedGroup group,JSONObject message,String asset,MediaCrypto.Prepared file,int ttlSeconds)throws Exception{
        String self=bridge.id(),type=message.optString("type");boolean subscriber=!group.canPost(self);if(subscriber&&!"vote".equals(type)&&!"reaction".equals(type))throw new SecurityException("В канале может писать только владелец");
        byte[] plain=message.toString().getBytes(StandardCharsets.UTF_8);if(plain.length==0||plain.length>64000)throw new IllegalArgumentException("Сообщение слишком большое");
        if(ttlSeconds<0||ttlSeconds>31536000)throw new IllegalArgumentException("Неверный срок");byte[] random=new byte[16];new SecureRandom().nextBytes(random);String event=Protocol.b64(random),selfCipher=null,selfSignature=null;JSONArray boxes=new JSONArray();
        for(Protocol.Card recipient:group.members){String to=recipient.id;byte[] cipher=bridge.encrypt(recipient.encryptionPublic,Protocol.boxContext(group.id,event,self,to),plain);byte[] signature=bridge.signDigest(Protocol.messageDigest(group.id,event,self,to,cipher));String c=Protocol.b64(cipher),s=Protocol.b64(signature);boxes.put(new JSONObject().put("to",to).put("ciphertext",c).put("signature",s));if(to.equals(self)){selfCipher=c;selfSignature=s;}}
        if(selfCipher==null)throw new SecurityException("Нет собственного конверта");JSONObject request=new JSONObject().put("id",event).put("boxes",boxes);if(subscriber)request.put("operation",type);if(ttlSeconds>0)request.put("ttl_seconds",ttlSeconds);store.saveDraft(group.id,event,self,selfCipher,selfSignature,request.toString(),System.currentTimeMillis(),asset,file);
    }
    public void queueText(SignedGroup group,String text,String reply,int ttlSeconds)throws Exception{
        if(text==null||text.trim().isEmpty()||text.length()>16000)throw new IllegalArgumentException("Введите сообщение до 16000 символов");JSONObject message=new JSONObject().put("v",1).put("type","text").put("text",text);if(reply!=null&&!reply.isEmpty())message.put("reply",reply);queue(group,message,null,null,ttlSeconds);
    }
    public void queueFile(SignedGroup group,String asset,MediaCrypto.Prepared file,String name,String mime)throws Exception{queueFile(group,asset,file,name,mime,false,false);}
    public void queueVoice(SignedGroup group,String asset,MediaCrypto.Prepared file)throws Exception{queueFile(group,asset,file,"Голосовое сообщение.m4a","audio/mp4",true,false);}
    public void queueForwardedFile(SignedGroup group,String asset,MediaCrypto.Prepared file,String name,String mime,boolean voice)throws Exception{queueFile(group,asset,file,name,mime,voice,true);}
    private void queueFile(SignedGroup group,String asset,MediaCrypto.Prepared file,String name,String mime,boolean voice,boolean forwarded)throws Exception{
        if(!Protocol.validEventId(asset)||file==null)throw new IllegalArgumentException("Invalid asset");String safe=name==null?"Файл":name.replaceAll("[/\\\\\\p{Cntrl}]","_").trim();if(safe.isEmpty())safe="Файл";if(safe.length()>180)safe=safe.substring(0,180);String type=mime!=null&&mime.matches("[A-Za-z0-9.+_-]{1,80}/[A-Za-z0-9.+_-]{1,80}")?mime:"application/octet-stream";
        try{JSONObject message=new JSONObject().put("v",1).put("type","file").put("asset",asset).put("name",safe).put("mime",type).put("key",Protocol.b64(file.keyset)).put("size",file.plainSize).put("cipher_size",file.cipherSize).put("sha256",file.sha256);if(voice)message.put("voice",true);if(forwarded)message.put("forwarded",true);queue(group,message,asset,file,0);}finally{java.util.Arrays.fill(file.keyset,(byte)0);}
    }
    /** Persist before acknowledgement; all membership and per-recipient signatures are checked. */
    public void sync(SignedGroup local,boolean markRead)throws Exception{
        SignedGroup group=parse(api.groupState(local.id).getJSONObject("state"));if(!group.id.equals(local.id))throw new SecurityException("Неверная группа");store.putGroup(group);String self=bridge.id();
        for(String[] pending:store.outbox(group.id)){
            if(pending[2]!=null){String[] asset=store.localAsset(pending[2]);if(asset==null)throw new IllegalStateException("Локальный файл недоступен");if(!"1".equals(asset[3])){File f=new File(asset[0]);if(!f.isFile()||f.length()!=Long.parseLong(asset[1]))throw new IllegalStateException("Локальный файл недоступен");api.uploadAsset(group.id,pending[2],f,asset[2]);store.markAssetUploaded(pending[2]);}}
            JSONObject body=new JSONObject(pending[1]),response=api.sendEvent(group.id,body);long seq=response.getLong("seq"),created=response.getLong("created");if(pending[2]!=null)api.bindAsset(pending[2],pending[0]);JSONArray boxes=body.getJSONArray("boxes");boolean found=false;for(int i=0;i<boxes.length();i++){JSONObject b=boxes.getJSONObject(i);if(self.equals(b.getString("to"))){store.saveEnvelope(group.id,pending[0],self,self,b.getString("ciphertext"),b.getString("signature"),seq,created,response.optLong("expires",0),"sent");found=true;break;}}if(!found)throw new SecurityException("Нет собственного конверта");store.removeOutbox(pending[0]);
        }
        long cursor=store.cursor(group.id);boolean more;do{JSONObject page=api.events(group.id,cursor);JSONArray events=page.getJSONArray("events");for(int i=0;i<events.length();i++){
            JSONObject e=events.getJSONObject(i);String event=e.getString("id"),sender=e.getString("sender"),to=e.getString("recipient");long seq=e.getLong("seq");Protocol.Card author=group.member(sender);if(seq<=cursor||!self.equals(to)||author==null)throw new SecurityException("Неверный конверт группы");byte[] cipher=IdentityUtil.unb64(e.getString("ciphertext")),sig=IdentityUtil.unb64(e.getString("signature"));if(!Protocol.verifySignature(author.identityPublic,Protocol.messageDigest(group.id,event,sender,to,cipher),sig))throw new SecurityException("Подпись сообщения неверна");ChatEngine.parse(bridge.decrypt(Protocol.boxContext(group.id,event,sender,to),cipher));store.saveIncoming(group.id,event,sender,to,e.getString("ciphertext"),e.getString("signature"),seq,e.getLong("created"),e.optLong("expires",0),sender.equals(self)?"sent":"received");cursor=seq;
        }more=page.optBoolean("has_more",false);if(more&&events.length()==0)throw new SecurityException("Пустая страница сервера");}while(more);if(cursor>0){try{api.ack(group.id,cursor);if(markRead)api.readReceipt(group.id,cursor);}catch(GPlusApi.ApiException e){if(e.status!=404)throw e;}}
        try{MediaReceipts.flush(api,store);}catch(Exception ignored){/* retained locally for retry */}
    }
    public List<ChatEngine.Message> messages(SignedGroup group)throws Exception{return messagesAfter(group,-1);}
    public List<ChatEngine.Message> messagesAfter(SignedGroup group,long after)throws Exception{
        String self=bridge.id();List<ChatEngine.Message> out=new ArrayList<>();for(String[] e:store.envelopesAfter(group.id,after)){String event=e[0],sender=e[1],to=e[2];Protocol.Card author=group.member(sender);if(!self.equals(to)||author==null)throw new SecurityException("Неизвестный отправитель");byte[] cipher=IdentityUtil.unb64(e[3]),sig=IdentityUtil.unb64(e[4]);if(!Protocol.verifySignature(author.identityPublic,Protocol.messageDigest(group.id,event,sender,to,cipher),sig))throw new SecurityException("Неверная подпись истории");JSONObject content=ChatEngine.parse(bridge.decrypt(Protocol.boxContext(group.id,event,sender,to),cipher));String type=content.optString("type");if(!group.canPost(sender)&&!"vote".equals(type)&&!"reaction".equals(type))continue;out.add(new ChatEngine.Message(event,sender,e[7],Long.parseLong(e[6]),Long.parseLong(e[5]),content));}return out;
    }
}
