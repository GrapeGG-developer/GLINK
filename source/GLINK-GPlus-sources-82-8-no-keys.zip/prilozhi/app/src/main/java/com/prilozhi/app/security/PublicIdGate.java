package com.prilozhi.app.security;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.prilozhi.app.identity.InstallationIdentity;

import java.util.concurrent.Executor;
import java.util.function.BooleanSupplier;

/**
 * Local display/copy gate for the public ID only; it does not make that ID
 * secret, change the existing Keystore identity, or expose its private key.
 * FingerprintManager is intentionally used because BiometricPrompt may accept
 * another biometric modality. Android retains the enrolled fingerprint data.
 */
@SuppressWarnings("deprecation")
public final class PublicIdGate {
    interface IdentitySource { String read() throws Exception; }
    private static final String PREFS = "glink_public_id_gate";
    private static final String SETUP_SEEN = "fingerprint_setup_seen";
    private final Activity activity;
    private final TextView row;
    private final BooleanSupplier canOfferSetup;
    private final IdentitySource identity;
    private final Executor worker;
    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean resumed;
    private long generation;
    private CancellationSignal cancellation;
    private AlertDialog fingerprintDialog, idDialog, setupDialog;
    private final Runnable setupTask = this::offerSetup;

    public PublicIdGate(Activity activity, TextView row, BooleanSupplier canOfferSetup) {
        this(activity, row, canOfferSetup, InstallationIdentity::publicId,
                task -> new Thread(task, "glink-public-id").start());
    }
    PublicIdGate(Activity activity, TextView row, BooleanSupplier canOfferSetup,
                 IdentitySource identity, Executor worker) {
        this.activity = activity; this.row = row; this.canOfferSetup = canOfferSetup;
        this.identity = identity; this.worker = worker;
        row.setText("GLINK ID · открыть по отпечатку");
        row.setContentDescription("Открыть и скопировать публичный GLINK ID после подтверждения отпечатка пальца");
        row.setOnClickListener(v -> requestId());
        row.setFocusable(true);
    }
    public void onResume() {
        resumed = true;
        scheduleSetup();
    }
    public void scheduleSetup() {
        main.removeCallbacks(setupTask);
        if (resumed) main.postDelayed(setupTask, 1300);
    }
    public void onPause() {
        resumed = false;
        main.removeCallbacks(setupTask);
        cancelAuthentication();
        if (idDialog != null) { idDialog.dismiss(); idDialog = null; }
        if (setupDialog != null) { setupDialog.dismiss(); setupDialog = null; }
    }
    private boolean usableActivity() {
        return resumed && !activity.isFinishing() && !activity.isDestroyed();
    }
    private FingerprintManager manager() {
        try { return (FingerprintManager) activity.getSystemService(Context.FINGERPRINT_SERVICE); }
        catch (RuntimeException ignored) { return null; }
    }
    private boolean hasHardware(FingerprintManager fm) {
        try { return fm != null && fm.isHardwareDetected(); }
        catch (RuntimeException ignored) { return false; }
    }
    private boolean enrolled(FingerprintManager fm) {
        try { return fm != null && fm.hasEnrolledFingerprints(); }
        catch (RuntimeException ignored) { return false; }
    }
    private void offerSetup() {
        if (!usableActivity() || !canOfferSetup.getAsBoolean() || setupDialog != null || fingerprintDialog != null || idDialog != null
                || activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(SETUP_SEEN, false)) return;
        setupDialog = new AlertDialog.Builder(activity)
                .setTitle("GLINK ID и отпечаток")
                .setMessage("Показ и копирование GLINK ID на этом телефоне защищены отпечатком пальца. "
                        + "ID остаётся публичным для контактов и G+. Отпечатки хранит Android, GLINK их не получает. "
                        + "Если отпечаток ещё не добавлен, его можно настроить в системе.")
                .setPositiveButton("Настроить", (d, w) -> {
                    activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(SETUP_SEEN, true).apply();
                    requestId();
                })
                .setNegativeButton("Закрыть", (d, w) -> activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .edit().putBoolean(SETUP_SEEN, true).apply())
                .create();
        AlertDialog current = setupDialog;
        current.setOnDismissListener(d -> { if (setupDialog == current) setupDialog = null; });
        current.show();
    }
    private void enrollment() {
        try {
            Intent intent;
            if (Build.VERSION.SDK_INT >= 30) {
                intent = new Intent(Settings.ACTION_BIOMETRIC_ENROLL);
                intent.putExtra(Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
                        android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_STRONG);
            } else intent = new Intent(Settings.ACTION_FINGERPRINT_ENROLL);
            if (intent.resolveActivity(activity.getPackageManager()) == null)
                intent = new Intent(Settings.ACTION_SECURITY_SETTINGS);
            activity.startActivity(intent);
        } catch (RuntimeException e) {
            Toast.makeText(activity, "Откройте настройки телефона и добавьте отпечаток пальца", Toast.LENGTH_LONG).show();
        }
    }
    public void openPublicId() { requestId(); }
    private void requestId() {
        if (!usableActivity() || fingerprintDialog != null || idDialog != null) return;
        FingerprintManager fm = manager();
        if (!hasHardware(fm)) {
            new AlertDialog.Builder(activity).setTitle("Датчик недоступен")
                    .setMessage("Чтобы открыть ID здесь, нужен доступный датчик отпечатка пальца. Сам ID публичен для контактов.")
                    .setPositiveButton("Понятно", null).show(); return;
        }
        if (!enrolled(fm)) {
            new AlertDialog.Builder(activity).setTitle("Добавьте отпечаток")
                    .setMessage("Добавьте отпечаток пальца в настройках Android и вернитесь к GLINK ID. Приложение не хранит отпечатки.")
                    .setPositiveButton("Настройки", (d, w) -> enrollment())
                    .setNegativeButton("Отмена", null).show(); return;
        }
        long request = ++generation;
        TextView status = new TextView(activity);
        float density = activity.getResources().getDisplayMetrics().density;
        int pad = Math.round(24 * density); status.setPadding(pad, Math.round(12 * density), pad, Math.round(8 * density));
        status.setText("Коснитесь датчика отпечатка пальца на телефоне.");
        AlertDialog dialog = new AlertDialog.Builder(activity).setTitle("Открыть GLINK ID")
                .setView(status).setNegativeButton("Отмена", (d, w) -> cancelAuthentication()).create();
        fingerprintDialog = dialog;
        dialog.setOnDismissListener(d -> { if (fingerprintDialog == dialog) cancelAuthentication(); });
        dialog.show();
        cancellation = new CancellationSignal();
        try {
            fm.authenticate(null, cancellation, 0, new FingerprintManager.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
                    if (request != generation || !usableActivity()) return;
                    cancelAuthentication();
                    long reveal = generation;
                    worker.execute(() -> {
                        String value = null; try { value = identity.read(); } catch (Exception ignored) { }
                        final String id = value;
                        main.post(() -> {
                            if (reveal != generation || !usableActivity()) return;
                            if (id == null || id.isEmpty()) {
                                Toast.makeText(activity, "GLINK ID недоступен", Toast.LENGTH_SHORT).show(); return;
                            }
                            showId(id);
                        });
                    });
                }
                @Override public void onAuthenticationFailed() {
                    if (request == generation && usableActivity()) status.setText("Не распознано. Попробуйте ещё раз.");
                }
                @Override public void onAuthenticationError(int error, CharSequence message) {
                    if (request != generation || !usableActivity()) return;
                    cancelAuthentication();
                    new AlertDialog.Builder(activity).setTitle("Отпечаток недоступен")
                            .setMessage(message == null ? "Попробуйте ещё раз позже." : message)
                            .setPositiveButton("Понятно", null).show();
                }
            }, main);
        } catch (RuntimeException e) {
            cancelAuthentication();
            new AlertDialog.Builder(activity).setTitle("Отпечаток недоступен")
                    .setMessage("Не удалось запустить датчик. Проверьте системные настройки и попробуйте ещё раз.")
                    .setPositiveButton("Понятно", null).show();
        }
    }
    private void showId(String id) {
        if (!usableActivity()) return;
        idDialog = new AlertDialog.Builder(activity).setTitle("GLINK ID")
                .setMessage(id + "\n\nЭто публичный ID: его могут видеть ваши контакты и G+.")
                .setPositiveButton("Копировать", (d, w) -> {
                    if (!usableActivity()) return;
                    ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                    if (clipboard != null) {
                        clipboard.setPrimaryClip(ClipData.newPlainText("GLINK ID", id));
                        Toast.makeText(activity, "GLINK ID скопирован", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("Закрыть", null).create();
        AlertDialog current = idDialog;
        current.setOnDismissListener(d -> { if (idDialog == current) idDialog = null; });
        current.show();
    }
    private void cancelAuthentication() {
        ++generation;
        CancellationSignal current = cancellation; cancellation = null;
        AlertDialog dialog = fingerprintDialog; fingerprintDialog = null;
        if (current != null && !current.isCanceled()) current.cancel();
        if (dialog != null && dialog.isShowing()) dialog.dismiss();
    }
}
