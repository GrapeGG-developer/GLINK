package com.prilozhi.app.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Fetch and verify the official G+ APK privately before handing it to Android. */
public final class GPlusDownload {
    public static final String FEED="https://raw.githubusercontent.com/GrapeGG-developer/GLINK/main/gplus-version.json";
    public static final String APK="https://raw.githubusercontent.com/GrapeGG-developer/GLINK/main/GPlus.apk";
    static final String DIRECTORY="gplus-installer", PREFS="gplus_install", KEEP="upd_keep_name";
    private static final long MAX_SIZE=200L*1024*1024;
    private static final AtomicBoolean DOWNLOADING=new AtomicBoolean();
    private GPlusDownload(){}

    public static final class Info {
        public final int code; public final String name,sha; public final long size;
        Info(int code,String name,String sha,long size){this.code=code;this.name=name;this.sha=sha;this.size=size;}
    }
    public interface Callback { void onProgress(long done,long total); void onDone(Uri uri,String error); }
    static Info parseInfo(String text)throws Exception{
        JSONObject o=new JSONObject(text);long size=o.getLong("size");int code=o.getInt("versionCode");
        String version=o.getString("versionName"),hash=o.getString("sha256");
        if(code<1||!version.matches("[0-9]+\\.[0-9]+\\.GLINK-(RELEASE|BETA|PATCH|EXP|TEST)")
                ||!APK.equals(o.getString("apk"))||!hash.matches("[0-9a-f]{64}")||size<1||size>MAX_SIZE)
            throw new SecurityException("Invalid G+ feed");
        return new Info(code,version,hash,size);
    }
    public static long parse(String text)throws Exception{return parseInfo(text).size;}
    private static HttpURLConnection connect(String url,int read)throws Exception{
        URL u=new URL(url);if(!"https".equalsIgnoreCase(u.getProtocol()))throw new SecurityException("HTTPS required");
        HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setInstanceFollowRedirects(false);c.setUseCaches(false);
        c.setConnectTimeout(8000);c.setReadTimeout(read);c.setRequestProperty("User-Agent","GLINK-Android");return c;
    }
    /** Network I/O: call off the main thread. Returns null if the release is unavailable. */
    public static Info fetch(){HttpURLConnection feed=null,apk=null;try{
        feed=connect(FEED,8000);if(feed.getResponseCode()!=200)return null;String body;
        try(InputStream in=feed.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){if(out.size()+n>65536)return null;out.write(b,0,n);}body=new String(out.toByteArray(),StandardCharsets.UTF_8);
        }
        Info info=parseInfo(body);apk=connect(APK,8000);apk.setRequestMethod("HEAD");if(apk.getResponseCode()!=200)return null;
        String type=apk.getContentType();if(type!=null&&type.toLowerCase(Locale.ROOT).startsWith("text/html"))return null;
        long length=apk.getContentLengthLong();return length<=0||length==info.size?info:null;
    }catch(Exception e){return null;}finally{if(feed!=null)feed.disconnect();if(apk!=null)apk.disconnect();}}
    public static boolean available(){return fetch()!=null;}

    @SuppressWarnings("deprecation")
    static void verifyPackageInfo(PackageInfo candidate,PackageInfo own,Info info){
        if(candidate==null||own==null||info==null||!"grp.gs.gplus".equals(candidate.packageName)
                ||candidate.getLongVersionCode()!=info.code||!info.name.equals(candidate.versionName))throw new SecurityException("Неверный пакет G+");
        Signature[] a=candidate.signingInfo!=null?candidate.signingInfo.getApkContentsSigners():candidate.signatures;
        Signature[] b=own.signingInfo!=null?own.signingInfo.getApkContentsSigners():own.signatures;
        if(a==null||b==null||a.length==0||a.length!=b.length)throw new SecurityException("Нет подписи G+");
        boolean[] matched=new boolean[b.length];
        for(Signature s:a){boolean match=false;for(int i=0;i<b.length;i++)if(!matched[i]&&Arrays.equals(s.toByteArray(),b[i].toByteArray())){matched[i]=true;match=true;break;}
            if(!match)throw new SecurityException("Подпись G+ не совпадает с GLINK");}
    }
    private static void verifyPackage(Context c,File file,Info info)throws Exception{
        PackageManager pm=c.getPackageManager();int flags=PackageManager.GET_SIGNING_CERTIFICATES|PackageManager.GET_SIGNATURES;
        verifyPackageInfo(pm.getPackageArchiveInfo(file.getAbsolutePath(),flags),pm.getPackageInfo(c.getPackageName(),flags),info);
    }
    static File directory(Context c){return new File(c.getFilesDir(),DIRECTORY);}
    static boolean validName(String s){return s!=null&&s.matches("GPlus-install-[1-9][0-9]{0,9}-[a-f0-9]{24}\\.apk");}
    static Uri uri(Context c,String name){if(!validName(name))throw new SecurityException("Invalid APK name");
        return new Uri.Builder().scheme("content").authority(c.getPackageName()+".gplus-installer").appendPath("apk").appendPath(name).build();}
    private static String nonce(){byte[] b=new byte[12];new SecureRandom().nextBytes(b);StringBuilder s=new StringBuilder(24);for(byte x:b)s.append(String.format(Locale.ROOT,"%02x",x&255));return s.toString();}
    private static Info pendingInfo(SharedPreferences p){try{
        JSONObject o=new JSONObject().put("versionCode",p.getInt("code",0)).put("versionName",p.getString("name","")).put("sha256",p.getString("sha",""))
                .put("size",p.getLong("size",0)).put("apk",APK);return parseInfo(o.toString());
    }catch(Exception e){return null;}}
    /** Recheck retained APK on a worker thread; never delete the pending file on failure. */
    public static Uri verifiedPending(Context context){
        Context c=context.getApplicationContext();SharedPreferences p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);String name=p.getString(KEEP,"");Info info=pendingInfo(p);
        if(!validName(name)||info==null)return null;File file=new File(directory(c),name);
        try{if(!file.isFile()||file.length()!=info.size)return null;try(InputStream in=new FileInputStream(file)){UpdateManager.copyAndVerify(in,null,info.size,info.sha,null);}verifyPackage(c,file,info);return uri(c,name);}
        catch(Exception e){return null;}
    }
    public static boolean hasPending(Context context){return context.getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE).contains(KEEP);}
    /** Retire only old G+ installer files after the expected signed app is installed. */
    public static void cleanupAfterInstalled(Context context){
        if(!DOWNLOADING.compareAndSet(false,true))return;
        try{
            Context c=context.getApplicationContext();SharedPreferences p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);Info pending=pendingInfo(p);
            if(pending==null)return;PackageManager pm=c.getPackageManager();int flags=PackageManager.GET_SIGNING_CERTIFICATES|PackageManager.GET_SIGNATURES;
            PackageInfo installed=pm.getPackageInfo("grp.gs.gplus",flags),own=pm.getPackageInfo(c.getPackageName(),flags);
            long installedCode=installed.getLongVersionCode();if(installedCode<pending.code||installedCode>Integer.MAX_VALUE||installed.versionName==null)return;
            verifyPackageInfo(installed,own,new Info((int)installedCode,installed.versionName,"",1));
            File[] files=directory(c).listFiles();boolean removed=true;if(files!=null)for(File f:files)if(validName(f.getName())&&!f.delete())removed=false;
            if(removed)p.edit().clear().commit();
        }catch(Exception ignored){}finally{DOWNLOADING.set(false);}
    }
    /** Size, SHA-256, package ID, exact version and GLINK signing certificate are mandatory. */
    public static void download(Context context,Info info,Callback cb){
        Context c=context.getApplicationContext();Handler main=new Handler(Looper.getMainLooper());
        if(!DOWNLOADING.compareAndSet(false,true)){main.post(()->cb.onDone(null,"Загрузка уже выполняется"));return;}
        new Thread(()->{HttpURLConnection con=null;File temp=null,retained=null;try{
            if(info==null||info.code<1||info.size<1||info.size>MAX_SIZE||!info.sha.matches("[0-9a-f]{64}")
                    ||!info.name.matches("[0-9]+\\.[0-9]+\\.GLINK-(RELEASE|BETA|PATCH|EXP|TEST)"))throw new SecurityException("Неверные сведения о G+");
            File dir=directory(c);if(!dir.isDirectory()&&!dir.mkdirs())throw new java.io.IOException("Нет места для загрузки");
            con=connect(APK,15000);if(con.getResponseCode()!=200)throw new java.io.IOException("Сервер загрузки недоступен");
            long declared=con.getContentLengthLong();if(declared>0&&declared!=info.size)throw new SecurityException("Размер APK не совпадает");
            temp=File.createTempFile("gplus-check-",".part",dir);final long[] last={0};
            try(InputStream in=con.getInputStream();FileOutputStream out=new FileOutputStream(temp)){
                UpdateManager.copyAndVerify(in,out,info.size,info.sha,done->{if(System.currentTimeMillis()-last[0]>150){last[0]=System.currentTimeMillis();main.post(()->cb.onProgress(done,info.size));}});out.getFD().sync();
            }
            verifyPackage(c,temp,info);String name="GPlus-install-"+info.code+"-"+nonce()+".apk";retained=new File(dir,name);
            if(retained.exists()||!temp.renameTo(retained))throw new java.io.IOException("Не удалось сохранить G+");temp=null;
            boolean saved=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(KEEP,name).putInt("code",info.code).putString("name",info.name)
                    .putString("sha",info.sha).putLong("size",info.size).commit();
            if(!saved)throw new java.io.IOException("Не удалось сохранить сведения о загрузке");
            Uri result=uri(c,name);retained=null;main.post(()->cb.onDone(result,null));
        }catch(Exception e){main.post(()->cb.onDone(null,"Не удалось скачать или проверить G+"));}
        finally{if(con!=null)con.disconnect();if(temp!=null)temp.delete();if(retained!=null)retained.delete();DOWNLOADING.set(false);}
        },"glink-gplus-download").start();
    }
}
