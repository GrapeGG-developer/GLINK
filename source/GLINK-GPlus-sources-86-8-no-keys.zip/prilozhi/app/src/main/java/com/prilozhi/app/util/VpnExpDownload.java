package com.prilozhi.app.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public final class VpnExpDownload {
    private static final String DIRECTORY = "yourvpn-exp-installer";
    private static final AtomicBoolean DOWNLOADING = new AtomicBoolean();

    public interface Callback {
        void onProgress(long done, long total);
        void onDone(Uri uri, String error);
    }

    interface ConnectionFactory { HttpURLConnection open(URL url) throws Exception; }
    interface ArchiveVerifier { void verify(Context context, File apk) throws Exception; }

    private VpnExpDownload() { }

    static File directory(Context c) {
        return new File(c.getFilesDir(), DIRECTORY);
    }

    static Uri uri(Context c) {
        return new Uri.Builder().scheme("content").authority(c.getPackageName() + ".vpn-installer")
                .appendPath("apk").appendPath(VpnExpPolicy.FILE_NAME).build();
    }

    @SuppressWarnings("deprecation")
    static void verifyPackage(Context c, File apk) throws Exception {
        int flags = PackageManager.GET_SIGNING_CERTIFICATES | PackageManager.GET_SIGNATURES;
        PackageInfo info = c.getPackageManager().getPackageArchiveInfo(apk.getAbsolutePath(), flags);
        if (info == null) throw new SecurityException("Не удалось прочитать APK");
        Signature[] found = info.signingInfo != null ? info.signingInfo.getApkContentsSigners() : info.signatures;
        if (found == null) throw new SecurityException("Нет подписи APK");
        byte[][] signatures = new byte[found.length][];
        for (int i = 0; i < found.length; i++) signatures[i] = found[i] == null ? null : found[i].toByteArray();
        VpnExpPolicy.verifyCandidate(info.packageName, info.getLongVersionCode(), info.versionName, signatures);
    }

    static Uri verifiedPending(Context context, ArchiveVerifier verifier) {
        Context c = context.getApplicationContext();
        File apk = new File(directory(c), VpnExpPolicy.FILE_NAME);
        try {
            if (!apk.isFile() || apk.length() != VpnExpPolicy.APK_SIZE) return null;
            try (InputStream in = new FileInputStream(apk)) {
                UpdateManager.copyAndVerify(in, null, VpnExpPolicy.APK_SIZE, VpnExpPolicy.APK_SHA256, null);
            }
            verifier.verify(c, apk);
            return uri(c);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static void download(Context context, Callback callback) {
        download(context, callback, url -> (HttpURLConnection) url.openConnection(), VpnExpDownload::verifyPackage);
    }

    static void download(Context context, Callback callback, ConnectionFactory factory, ArchiveVerifier verifier) {
        Context c = context.getApplicationContext();
        Handler main = new Handler(Looper.getMainLooper());
        if (!DOWNLOADING.compareAndSet(false, true)) {
            main.post(() -> callback.onDone(null, "Загрузка уже выполняется"));
            return;
        }
        new Thread(() -> {
            HttpURLConnection con = null;
            File temp = null;
            try {
                Uri pending = verifiedPending(c, verifier);
                if (pending != null) {
                    main.post(() -> callback.onDone(pending, null));
                    return;
                }
                File dir = directory(c);
                if (!dir.isDirectory() && !dir.mkdirs()) throw new java.io.IOException("Нет места для загрузки");
                URL url = new URL(VpnExpPolicy.APK_URL);
                if (!"https".equalsIgnoreCase(url.getProtocol())) throw new SecurityException("Нужен HTTPS");
                con = factory.open(url);
                con.setInstanceFollowRedirects(false);
                con.setUseCaches(false);
                con.setConnectTimeout(8000);
                con.setReadTimeout(30000);
                con.setRequestProperty("User-Agent", "GLINK-Android");
                con.setRequestProperty("Accept-Encoding", "identity");
                if (con.getResponseCode() != 200) throw new java.io.IOException("Сервер загрузки недоступен");
                String type = con.getContentType();
                if (type != null && type.toLowerCase(Locale.ROOT).startsWith("text/html")) throw new SecurityException("Неверный ответ сервера");
                long length = con.getContentLengthLong();
                if (length > 0 && length != VpnExpPolicy.APK_SIZE) throw new SecurityException("Размер APK не совпадает");
                temp = File.createTempFile("yourvpn-exp-check-", ".apk", dir);
                final long[] last = {0};
                try (InputStream in = con.getInputStream(); FileOutputStream out = new FileOutputStream(temp)) {
                    UpdateManager.copyAndVerify(in, out, VpnExpPolicy.APK_SIZE, VpnExpPolicy.APK_SHA256, done -> {
                        long now = System.currentTimeMillis();
                        if (now - last[0] >= 150 || done == VpnExpPolicy.APK_SIZE) {
                            last[0] = now;
                            main.post(() -> callback.onProgress(done, VpnExpPolicy.APK_SIZE));
                        }
                    });
                    out.getFD().sync();
                }
                verifier.verify(c, temp);
                File target = new File(dir, VpnExpPolicy.FILE_NAME);
                if (target.exists() && !target.delete()) throw new java.io.IOException("Не удалось заменить локальную копию");
                if (!temp.renameTo(target)) throw new java.io.IOException("Не удалось сохранить APK");
                temp = null;
                Uri result = uri(c);
                main.post(() -> callback.onDone(result, null));
            } catch (Exception ignored) {
                main.post(() -> callback.onDone(null, "Не удалось скачать или проверить приложение. Проверьте интернет."));
            } finally {
                if (con != null) con.disconnect();
                if (temp != null) temp.delete();
                DOWNLOADING.set(false);
            }
        }, "glink-vpn-exp-download").start();
    }
}
