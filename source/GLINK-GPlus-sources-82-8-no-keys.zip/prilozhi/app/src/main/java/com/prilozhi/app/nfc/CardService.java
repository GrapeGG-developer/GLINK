package com.prilozhi.app.nfc;

import android.nfc.cardemulation.HostApduService;
import android.os.Bundle;

import com.prilozhi.app.util.State;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * HCE-карта GLINK. NFC больше НЕ передаёт файлы (устаревший канал GFC удалён):
 * касание — это только рукопожатие. Карта отвечает на SELECT и отдаёт hello:
 * имя, флаг «есть что отправить» и токен GFCAS, по которому партнёр найдёт
 * этот телефон в BLE-эфире. Дальше всё (манифест, файлы, текст, приколы)
 * едет единственным транспортом — GFCAS.
 *
 *  00 A4 04 00 ..  SELECT AID   -> 9000
 *  00 CA [page]    hello (JSON) -> страница + 9000
 */
public class CardService extends HostApduService {

    public static final byte[] AID = hex("F05052494C4F5A4849");
    static final int PAGE = 180;

    private byte[] handshakeCache;
    private final grp.gs.protocol.NfcSession contacts = new grp.gs.protocol.NfcSession(new grp.gs.protocol.NfcSession.Host() {
        @Override public byte[] ownCard() throws Exception { return com.prilozhi.app.identity.GPlusNfcStore.own(CardService.this); }
        @Override public byte[] signDigest(byte[] digest) throws Exception { return com.prilozhi.app.identity.InstallationIdentity.signGPlusDigest(digest); }
        @Override public void acceptCard(byte[] card) throws Exception { com.prilozhi.app.identity.GPlusNfcStore.accept(CardService.this,card); }
        @Override public void setContactActive(boolean active) { State.get().sessionActive=active;State.get().notifyChanged(); }
    });

    private static byte[] hex(String s) {
        int n = s.length() / 2;
        byte[] out = new byte[n];
        for (int i = 0; i < n; i++) {
            out[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        }
        return out;
    }

    private byte[] handshake() {
        if (handshakeCache != null) return handshakeCache;
        try {
            State st = State.get();
            JSONObject o = new JSONObject();
            o.put("v", 3);
            boolean pairing=com.prilozhi.app.identity.GPlusNfcStore.active();
            o.put("gplus", pairing ? 1 : 0);
            o.put("id", st.deviceId);
            o.put("name", st.deviceName);
            String[] transfer = com.prilozhi.app.net.RelayTransfer.nfcSessionSnapshot();
            boolean ready = !pairing && st.hasOutbound() && transfer != null;
            o.put("has", ready ? 1 : 0);
            o.put("pending", !pairing && st.hasOutbound() && !ready ? 1 : 0);
            o.put("bt", st.deviceId); // legacy hello field
            o.put("s", ready ? transfer[0] : "");
            o.put("k", ready ? transfer[1] : "");
            handshakeCache = o.toString().getBytes(StandardCharsets.UTF_8);
        } catch (Throwable t) {
            handshakeCache = "{\"v\":3,\"has\":0}".getBytes(StandardCharsets.UTF_8);
        }
        return handshakeCache;
    }

    private static byte[] page(byte[] payload, int page) {
        int from = page * PAGE;
        if (from >= payload.length) return sw(0x9000);
        int to = Math.min(payload.length, from + PAGE);
        ByteArrayOutputStream bos = new ByteArrayOutputStream(to - from + 2);
        bos.write(payload, from, to - from);
        bos.write(0x90);
        bos.write(0x00);
        return bos.toByteArray();
    }

    @Override
    public synchronized byte[] processCommandApdu(byte[] cmd, Bundle extras) {
        com.prilozhi.app.util.State.get().nfcNearAt = System.currentTimeMillis(); // радар: телефон рядом
        try {
            if (cmd == null || cmd.length < 2) return sw(0x6F00);
            int ins = cmd[1] & 0xFF;
            switch (ins) {
                case 0xA4: // SELECT
                    handshakeCache = null;
                    return contacts.process(cmd);
                case 0xCA: // normal GLINK handshake
                    return page(handshake(), cmd.length > 2 ? cmd[2] & 0xFF : 0);
                case 0xD9: case 0xDA: case 0xCB: case 0xCD: case 0xDC:
                    return contacts.process(cmd);
                default:
                    return sw(0x6D00);
            }
        } catch (Throwable t) {
            return sw(0x6F00);
        }
    }

    private static byte[] sw(int code) {
        return new byte[]{(byte) ((code >> 8) & 0xFF), (byte) (code & 0xFF)};
    }

    @Override
    public void onDeactivated(int reason) {
        // Касание закончилось — дальше работает GFCAS, тут делать нечего.
        handshakeCache = null;
        contacts.reset();
    }
}
