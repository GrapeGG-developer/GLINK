package com.prilozhi.app;
import com.prilozhi.app.net.StreamCompat;
import org.junit.Test;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import static org.junit.Assert.*;
public class StreamCompatTest {
 @Test public void exactAndBoundedReadsWork() throws Exception {
  byte[] input = {1,2,3,4,5};
  assertArrayEquals(new byte[]{1,2,3}, StreamCompat.readExactly(new ByteArrayInputStream(input), 3));
  assertArrayEquals(input, StreamCompat.readAll(new ByteArrayInputStream(input), 5));
  assertArrayEquals(new byte[0], StreamCompat.readExactly(new ByteArrayInputStream(input), 0));
 }
 @Test(expected=EOFException.class) public void truncatedIsRejected() throws Exception {
  StreamCompat.readExactly(new ByteArrayInputStream(new byte[]{1}), 2);
 }
 @Test(expected=IOException.class) public void oversizedResponseIsRejected() throws Exception {
  StreamCompat.readAll(new ByteArrayInputStream(new byte[]{1,2,3}), 2);
 }
}
