package grp.gs.gplus;

/** Free Render may need a cold start; media is committed before its response. */
final class NetworkTimeouts {
    static final int CONNECT_MS = 20_000;
    static final int API_READ_MS = 90_000;
    private static final long MIB = 1024L * 1024L;
    private NetworkTimeouts() {}

    /** Give durable, block-by-block storage longer than a short API call.
     * It remains bounded so a failed request does not wait forever. */
    static int mediaReadMs(long bytes) {
        if (bytes < 0) throw new IllegalArgumentException("Invalid media size");
        long mib = bytes / MIB + (bytes % MIB == 0 ? 0 : 1);
        long estimate = 120_000L + Math.min(mib, 280L) * 6_000L;
        return (int) Math.max(180_000L, Math.min(1_800_000L, estimate));
    }
}
