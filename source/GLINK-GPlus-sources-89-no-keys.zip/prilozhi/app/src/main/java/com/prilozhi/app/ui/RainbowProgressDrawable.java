package com.prilozhi.app.ui;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

/** Determinate download bar: rainbow fill that keeps sliding while the panel is open. */
public final class RainbowProgressDrawable extends Drawable implements Animatable {
    private static final int[] RAINBOW = {
            0xFFFF1744, 0xFFFF9100, 0xFFFFEA00, 0xFF00E676,
            0xFF00E5FF, 0xFF2979FF, 0xFFD500F9, 0xFFFF1744
    };
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float shift;
    private boolean running;
    private int lastWidth;
    private Shader rainbow;

    public RainbowProgressDrawable() {
        track.setColor(0xFF1E1E1E);
        sheen.setColor(0x66FFFFFF);
    }

    @Override protected boolean onLevelChange(int level) {
        invalidateSelf();
        return true;
    }

    @Override public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;
        float radius = b.height() / 2f;
        rect.set(b);
        canvas.drawRoundRect(rect, radius, radius, track);
        float fraction = Math.max(0f, Math.min(1f, getLevel() / 10000f));
        if (fraction <= 0f) return;
        if (rainbow == null || lastWidth != b.width()) {
            lastWidth = b.width();
            rebuild(b.width());
        }
        int saved = canvas.save();
        canvas.clipRect(b.left, b.top, b.left + b.width() * fraction, b.bottom);
        fill.setShader(rainbow);
        canvas.drawRoundRect(rect, radius, radius, fill);
        float sheenX = b.left + ((shift * 1.7f) % (b.width() + 48f)) - 24f;
        canvas.drawRoundRect(sheenX, b.top, sheenX + 18f, b.bottom, radius, radius, sheen);
        canvas.restoreToCount(saved);
    }

    private void rebuild(int width) {
        float span = Math.max(160f, width * 1.35f);
        rainbow = new LinearGradient(-shift, 0f, -shift + span, 0f, RAINBOW, null, Shader.TileMode.REPEAT);
    }

    private final Runnable frame = new Runnable() {
        @Override public void run() {
            if (!running) return;
            shift = (shift + 7.5f) % 4096f;
            rainbow = null;
            invalidateSelf();
            scheduleSelf(this, SystemClock.uptimeMillis() + 16);
        }
    };

    @Override public void start() {
        if (running) return;
        running = true;
        scheduleSelf(frame, SystemClock.uptimeMillis() + 16);
        invalidateSelf();
    }

    @Override public void stop() {
        running = false;
        unscheduleSelf(frame);
    }

    @Override public boolean isRunning() { return running; }
    @Override public void setAlpha(int alpha) { fill.setAlpha(alpha); }
    @Override public void setColorFilter(ColorFilter filter) { fill.setColorFilter(filter); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    @Override public int getIntrinsicHeight() { return -1; }
}
