package grp.gs.gplus;

import com.google.crypto.tink.BinaryKeysetReader;
import com.google.crypto.tink.BinaryKeysetWriter;
import com.google.crypto.tink.CleartextKeysetHandle;
import com.google.crypto.tink.KeyTemplates;
import com.google.crypto.tink.KeysetHandle;
import com.google.crypto.tink.StreamingAead;
import com.google.crypto.tink.streamingaead.StreamingAeadConfig;
import grp.gs.protocol.Protocol;
import java.io.*;
import java.security.DigestOutputStream;
import java.security.MessageDigest;

/** Tink streaming encryption preserves source bytes. The key is only placed inside an E2E envelope. */
public final class MediaCrypto {
    private MediaCrypto(){}
    public static final class Prepared {
        public final File file;public final byte[] keyset;public final long plainSize,cipherSize;public final String sha256;
        Prepared(File f,byte[] k,long p,long c,String h){file=f;keyset=k;plainSize=p;cipherSize=c;sha256=h;}
    }
    public static Prepared encrypt(InputStream source,File finalFile,String chat,String asset)throws Exception{
        if(source==null||finalFile==null||finalFile.exists())throw new IllegalArgumentException("Invalid media destination");
        StreamingAeadConfig.register();KeysetHandle key=KeysetHandle.generateNew(KeyTemplates.get("AES256_GCM_HKDF_1MB"));
        ByteArrayOutputStream secret=new ByteArrayOutputStream();CleartextKeysetHandle.write(key,BinaryKeysetWriter.withOutputStream(secret));
        File parent=finalFile.getParentFile();if(!parent.exists()&&!parent.mkdirs())throw new IOException("Local media storage unavailable");
        File temp=new File(parent,finalFile.getName()+".tmp");if(temp.exists()||!temp.createNewFile())throw new IOException("Media file already exists");
        MessageDigest hash=MessageDigest.getInstance("SHA-256");long plain=0;
        try{
            try(InputStream in=source;OutputStream raw=new DigestOutputStream(new FileOutputStream(temp),hash);
                OutputStream encrypted=key.getPrimitive(StreamingAead.class).newEncryptingStream(raw,Protocol.mediaContext(chat,asset))){
                byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1){if(n==0)continue;encrypted.write(buf,0,n);plain+=n;if(plain<0)throw new IOException("Media too large");}
            }
            try(RandomAccessFile sync=new RandomAccessFile(temp,"rw")){sync.getFD().sync();}
            if(!temp.renameTo(finalFile))throw new IOException("Cannot store encrypted media");
            byte[] digest=hash.digest();StringBuilder hex=new StringBuilder();for(byte b:digest)hex.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
            return new Prepared(finalFile,secret.toByteArray(),plain,finalFile.length(),hex.toString());
        }catch(Exception e){temp.delete();throw e;}
    }
    /** Stream plaintext directly from one authenticated envelope into another, without a plaintext file. */
    public static Prepared reencrypt(File source,File destination,byte[] keyset,String oldChat,String oldAsset,long expectedPlain,String newChat,String newAsset)throws Exception{
        if(source==null||!source.isFile()||keyset==null||keyset.length<20||keyset.length>4096||expectedPlain<0)throw new SecurityException("Invalid media source");
        StreamingAeadConfig.register();KeysetHandle key=CleartextKeysetHandle.read(BinaryKeysetReader.withBytes(keyset));InputStream input=null;
        try{
            InputStream encrypted=new FileInputStream(source);try{input=key.getPrimitive(StreamingAead.class).newDecryptingStream(encrypted,Protocol.mediaContext(oldChat,oldAsset));}catch(Exception e){encrypted.close();throw e;}
            final InputStream stream=input;InputStream bounded=new FilterInputStream(stream){long total;boolean checked;private void verify()throws IOException{if(!checked){checked=true;if(total!=expectedPlain)throw new IOException("Media size mismatch");}}@Override public int read()throws IOException{int value=super.read();if(value<0)verify();else if(++total>expectedPlain)throw new IOException("Media too large");return value;}@Override public int read(byte[] b,int off,int len)throws IOException{int n=super.read(b,off,len);if(n<0)verify();else{total+=n;if(total>expectedPlain)throw new IOException("Media too large");}return n;}};
            Prepared result=encrypt(bounded,destination,newChat,newAsset);input=null;return result;
        }finally{if(input!=null)try{input.close();}catch(Exception ignored){}}
    }
    public static void decrypt(InputStream source,OutputStream destination,byte[] keyset,String chat,String asset,long expectedPlain)throws Exception{
        if(keyset==null||keyset.length<20||keyset.length>4096||expectedPlain<0)throw new SecurityException("Invalid media key");
        StreamingAeadConfig.register();KeysetHandle key=CleartextKeysetHandle.read(BinaryKeysetReader.withBytes(keyset));long total=0;
        try(InputStream encrypted=source;InputStream clear=key.getPrimitive(StreamingAead.class).newDecryptingStream(encrypted,Protocol.mediaContext(chat,asset));OutputStream out=destination){
            byte[] buf=new byte[65536];int n;while((n=clear.read(buf))!=-1){if(n==0)continue;total+=n;if(total>expectedPlain)throw new SecurityException("Media size mismatch");out.write(buf,0,n);}out.flush();
        }
        if(total!=expectedPlain)throw new SecurityException("Truncated media");
    }
}
