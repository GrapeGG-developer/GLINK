'use strict';
// Coordinates an explicit, cold two-server migration. Never fall back silently.
// The control secret is read from the process environment and is never printed
// or stored in the progress file. HTTPS certificate validation remains enabled.
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),http=require('node:http'),https=require('node:https'),crypto=require('node:crypto');
const secret=process.env.GSERVER_CONTROL_SECRET||'';
if(!/^[A-Za-z0-9_-]{32,128}$/.test(secret))throw Error('Missing GSERVER_CONTROL_SECRET');
if(process.env.NODE_TLS_REJECT_UNAUTHORIZED==='0')throw Error('TLS certificate verification must remain enabled');
function origin(s){const u=new URL(s),test=process.env.GSERVER_TEST_HTTP==='1';if((u.protocol!=='https:'&&!(test&&u.protocol==='http:'))||u.username||u.password||u.pathname!=='/'||u.search||u.hash)throw Error('HTTPS origin required');return u.origin;}
function req(base,route,method='GET',data=null,limit=32*1024*1024){return new Promise((resolve,reject)=>{
 const u=new URL(route,origin(base)),client=u.protocol==='https:'?https:http,b=data==null?null:Buffer.from(JSON.stringify(data));
 const r=client.request(u,{method,headers:{'X-Gserver-Admin':secret,...(b?{'Content-Type':'application/json','Content-Length':b.length}:{})},timeout:7200000},res=>{let n=0,parts=[];res.on('data',x=>{n+=x.length;if(n<=limit)parts.push(x);});res.on('end',()=>{try{if(n>limit)throw Error('response_too_large');let j=JSON.parse(Buffer.concat(parts).toString('utf8'));if(res.statusCode<200||res.statusCode>=300)throw Error(j.error||'request_failed');resolve(j);}catch(e){reject(e);}});res.on('error',reject);});r.on('timeout',()=>r.destroy(Error('timeout')));r.on('error',reject);if(b)r.write(b);r.end();
 });}
function copyFile(from,to,tx,entry){return new Promise((resolve,reject)=>{
 const q='?tx='+encodeURIComponent(tx)+'&path='+encodeURIComponent(entry.path),src=new URL('/gserver-admin/file'+q,origin(from)),dst=new URL('/gserver-admin/import/file'+q,origin(to));
 let done=false;function finish(e){if(done)return;done=true;if(e)reject(e);else resolve();}
 const get=(src.protocol==='https:'?https:http).request(src,{headers:{'X-Gserver-Admin':secret},timeout:120000},input=>{
  if(input.statusCode!==200||Number(input.headers['content-length'])!==entry.size){input.resume();return finish(Error('source_file_unavailable'));}
  const put=(dst.protocol==='https:'?https:http).request(dst,{method:'PUT',headers:{'X-Gserver-Admin':secret,'Content-Type':'application/octet-stream','Content-Length':entry.size},timeout:120000},res=>{
   let n=0,chunks=[];res.on('data',x=>{n+=x.length;if(n<=65536)chunks.push(x);});res.on('end',()=>{try{let j=JSON.parse(Buffer.concat(chunks).toString('utf8'));if(res.statusCode!==200)throw Error(j.error||'upload_failed');finish();}catch(e){finish(e);}});res.on('error',finish);
  });
  put.on('timeout',()=>put.destroy(Error('upload_timeout')));put.on('error',e=>{input.destroy();finish(e);});input.on('error',e=>{put.destroy();finish(e);});input.pipe(put);
 });get.on('timeout',()=>get.destroy(Error('download_timeout')));get.on('error',finish);get.end();
 });}
async function writeProgress(file,value){if(!file)return;await fsp.mkdir(path.dirname(file),{recursive:true});const tmp=file+'.tmp';await fsp.writeFile(tmp,JSON.stringify(value),{mode:0o600});await fsp.rename(tmp,file);}
async function switchServer({coordinator,peer,target,progressFile=null,onProgress=()=>{}}){
 coordinator=origin(coordinator);peer=origin(peer);if(coordinator===peer||!['GLINK-S','GSERVER'].includes(target))throw Error('invalid_switch');
 let saved=null;if(progressFile&&fs.existsSync(progressFile)){saved=JSON.parse(await fsp.readFile(progressFile,'utf8'));if(saved.coordinator!==coordinator||saved.peer!==peer||saved.target!==target||!/^[a-f0-9]{32}$/.test(saved.tx))throw Error('different_pending_transaction');}
 let c=await req(coordinator,'/gserver-admin/status'),p=await req(peer,'/gserver-admin/status');
 if(c.role!=='coordinator'||p.role!=='storage'||(c.mode==='GSERVER'&&c.peer!==peer))throw Error('unexpected_server_pair');
 const tx=saved?saved.tx:crypto.randomBytes(16).toString('hex');
 if(!saved&&c.mode===target&&!c.frozen)throw Error('already_using_selected_server');
 if(!saved){saved={version:1,tx,coordinator,peer,target,from:c.mode,phase:'begin'};await writeProgress(progressFile,saved);}
 const step=async(s)=>{saved.phase=s;await writeProgress(progressFile,saved);onProgress(s);};
 // If cutover was persisted before a crash, resume only this same transaction.
 if(c.mode===target&&saved.from!==target){
  const imported=target==='GSERVER'?p.lastImportedTx:c.lastImportedTx;
  if(imported!==tx)throw Error('cutover_transaction_mismatch');
  if(c.frozen){await step('unfreeze');await req(coordinator,'/gserver-admin/unfreeze','POST',{});}
  await step('complete');if(progressFile)await fsp.unlink(progressFile);return {tx,target,resumed:true};
 }
 if(c.mode!==saved.from)throw Error('coordinator_state_changed');
 await step('freezing');
 if(!c.frozen)await req(coordinator,'/gserver-admin/freeze','POST',{});else if(c.pending)await req(coordinator,'/gserver-admin/freeze','POST',{});
 p=await req(peer,'/gserver-admin/status');if(!p.frozen)await req(peer,'/gserver-admin/freeze','POST',{});else if(p.pending)await req(peer,'/gserver-admin/freeze','POST',{});
 const source=saved.from==='GLINK-S'?coordinator:peer,destination=target==='GLINK-S'?coordinator:peer;
 let d=await req(destination,'/gserver-admin/status');
 if(d.importTx===tx&&d.importRenamed){await step('verifying');await req(destination,'/gserver-admin/import/commit','POST',{tx});d=await req(destination,'/gserver-admin/status');}
 if(d.lastImportedTx!==tx){
  await step('snapshot');const manifest=await req(source,'/gserver-admin/snapshot','POST',{tx});
  if(manifest.tx!==tx||!Array.isArray(manifest.files))throw Error('invalid_manifest');
  await step('copying');await req(destination,'/gserver-admin/import/prepare','POST',{manifest});
  let copied=0;for(const e of manifest.files){await copyFile(source,destination,tx,e);copied+=e.size;onProgress('copying '+copied+'/'+manifest.total);}
  await step('verifying');await req(destination,'/gserver-admin/import/commit','POST',{tx});
 }
 if(target==='GSERVER'){
  p=await req(peer,'/gserver-admin/status');if(p.frozen)await req(peer,'/gserver-admin/unfreeze','POST',{});
 }
 await step('cutover');await req(coordinator,'/gserver-admin/switch','POST',{tx,mode:target,peer});
 await step('unfreeze');await req(coordinator,'/gserver-admin/unfreeze','POST',{});
 await step('complete');if(progressFile)await fsp.unlink(progressFile);
 return {tx,target};
}
if(require.main===module){
 const args=process.argv.slice(2);if(args.length!==4){console.error('Usage: switch-server.js COORDINATOR_HTTPS GSERVER_HTTPS GLINK-S|GSERVER PROGRESS_FILE');process.exit(2);}
 switchServer({coordinator:args[0],peer:args[1],target:args[2],progressFile:args[3],onProgress:s=>console.log('GSERVER: '+s)}).then(r=>{console.log('GSERVER: complete '+r.target);}).catch(e=>{console.error('GSERVER: stopped safely: '+e.message+'; keep both servers frozen and resume the same transaction.');process.exitCode=1;});
}
module.exports={switchServer,req,copyFile,origin};
