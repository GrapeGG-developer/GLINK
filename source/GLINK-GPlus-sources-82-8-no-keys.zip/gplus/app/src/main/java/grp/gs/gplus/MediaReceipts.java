package grp.gs.gplus;

/** Durable, idempotent receipts; a message ACK alone is never a media receipt. */
final class MediaReceipts {
    private MediaReceipts(){}

    // Call only after the complete ciphertext was saved and its digest, AEAD and
    // plaintext size were verified. The sender may not have bound the event yet.
    static void verified(GPlusStore store,String asset,String event,String sha){store.queueMediaReceipt(asset,event,sha);}

    static void flush(GPlusApi api,GPlusStore store)throws Exception{
        for(String[] receipt:store.pendingMediaReceipts()){
            store.markMediaReceiptAttempt(receipt[0],receipt[1],receipt[2]);
            try{
                api.confirmAssetReceived(receipt[0],receipt[1],receipt[2]);
                store.removeMediaReceipt(receipt[0],receipt[1],receipt[2]);
            }catch(GPlusApi.ApiException e){
                // Viewing one's own attachment is not a delivery to a recipient.
                if(e.status==404&&"recipient_not_found".equals(e.error))store.removeMediaReceipt(receipt[0],receipt[1],receipt[2]);
                else if(e.status==401)throw e;
                // A not-yet-bound event or temporary server issue is retried later.
            }
        }
    }
}
