package grp.gs.gplus;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Only reports an explicitly confirmed coordinator status; never infers a failover. */
public final class ServerIndicator {
    private ServerIndicator() {}
    public static String parse(String json) throws Exception {
        JSONObject o = new JSONObject(json);
        String mode=o.getString("mode"), state=o.getString("state");
        if (!"GLINK-S".equals(mode) && !"GSERVER".equals(mode)) throw new SecurityException("Unknown server");
        switch (state) {
            case "online": return mode + " · на связи";
            case "maintenance": return mode + " · перенос данных";
            case "unavailable": return mode + " · недоступен";
            default: throw new SecurityException("Unknown server status");
        }
    }
    public static String check(String base) {
        HttpURLConnection c=null;
        try {
            URL u=new URL(base.replaceAll("/+$", "")+"/gserver/status");
            if (!"https".equalsIgnoreCase(u.getProtocol())) throw new SecurityException("HTTPS required");
            c=(HttpURLConnection)u.openConnection();c.setInstanceFollowRedirects(false);c.setUseCaches(false);c.setConnectTimeout(NetworkTimeouts.CONNECT_MS);c.setReadTimeout(NetworkTimeouts.API_READ_MS);c.setRequestProperty("Accept","application/json");
            if(c.getResponseCode()!=200)throw new java.io.IOException("status unavailable");
            try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] b=new byte[1024];int n;while((n=in.read(b))!=-1){if(out.size()+n>4096)throw new java.io.IOException("status too large");out.write(b,0,n);}return parse(new String(out.toByteArray(),StandardCharsets.UTF_8));
            }
        } catch(Exception e){return "Сервер · нет данных";} finally{if(c!=null)c.disconnect();}
    }
}
