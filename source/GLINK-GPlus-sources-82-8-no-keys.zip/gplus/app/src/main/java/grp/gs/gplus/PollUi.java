package grp.gs.gplus;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputFilter;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Small, encrypted single-choice poll composer; no server-side poll plaintext. */
final class PollUi {
    private PollUi(){}
    static void create(Activity activity,Consumer<JSONObject> send){
        LinearLayout form=new LinearLayout(activity);form.setOrientation(LinearLayout.VERTICAL);int p=Math.round(20*activity.getResources().getDisplayMetrics().density);form.setPadding(p,0,p,0);EditText question=new EditText(activity);question.setHint("Вопрос");question.setFilters(new InputFilter[]{new InputFilter.LengthFilter(500)});form.addView(question,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));List<EditText> options=new ArrayList<>();for(int i=0;i<4;i++){EditText field=new EditText(activity);field.setSingleLine(true);field.setHint("Вариант "+(i+1)+(i>=2?" (необязательно)":""));field.setFilters(new InputFilter[]{new InputFilter.LengthFilter(120)});options.add(field);form.addView(field);}ScrollView scroll=new ScrollView(activity);scroll.addView(form);AlertDialog dialog=new AlertDialog.Builder(activity).setTitle("Новый опрос").setMessage("Один вариант на участника; голос можно изменить.").setView(scroll).setNegativeButton("Отмена",null).setPositiveButton("Отправить",null).create();dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String q=question.getText().toString().trim();if(q.isEmpty()){question.setError("Введите вопрос");return;}JSONArray choices=new JSONArray();for(EditText f:options){String option=f.getText().toString().trim();if(!option.isEmpty())choices.put(option);}if(choices.length()<2){options.get(1).setError("Нужно минимум два варианта");return;}try{JSONObject m=new JSONObject().put("v",1).put("type","poll").put("question",q).put("options",choices);dialog.dismiss();send.accept(m);}catch(Exception ignored){}}));dialog.show();
    }
    static void vote(Activity activity,Timeline.Item item,Consumer<JSONObject> send){
        if(item.deleted||item.pollOptions.isEmpty())return;String[] choices=new String[item.pollOptions.size()+1];for(int i=0;i<item.pollOptions.size();i++)choices[i]=item.pollOptions.get(i);choices[choices.length-1]="Убрать голос";new AlertDialog.Builder(activity).setTitle("Ваш голос").setItems(choices,(d,n)->{try{send.accept(new JSONObject().put("v",1).put("type","vote").put("target",item.id).put("option",n==choices.length-1?-1:n));}catch(Exception ignored){}}).setNegativeButton("Отмена",null).show();
    }
    static String display(Timeline.Item item){if(item.deleted||item.pollOptions.isEmpty())return item.text;int[] counts=new int[item.pollOptions.size()];for(Integer n:item.pollVotes.values())if(n!=null&&n>=0&&n<counts.length)counts[n]++;StringBuilder s=new StringBuilder(item.text);for(int i=0;i<counts.length;i++)s.append('\n').append("• ").append(item.pollOptions.get(i)).append(" — ").append(counts[i]);s.append("\nНажмите, чтобы проголосовать");return s.toString();}
}
