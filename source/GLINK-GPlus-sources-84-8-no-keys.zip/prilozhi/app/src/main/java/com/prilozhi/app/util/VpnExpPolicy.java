package com.prilozhi.app.util;

import java.security.MessageDigest;
import java.util.Locale;

public final class VpnExpPolicy {
    public static final String APK_URL = "https://raw.githubusercontent.com/GrapeGG-developer/GLINK/main/JustGrape-EXP-DEMO.apk";
    public static final long APK_SIZE = 7226394L;
    public static final String APK_SHA256 = "5c5f6a00131124e32ac296712e8f929d810529c338502704f3b9a00efae1e0f1";
    public static final String PACKAGE = "app.justgrape.yourvpn.preview";
    public static final long VERSION_CODE = 1L;
    public static final String VERSION_NAME = "0.1.0-preview";
    public static final String CERT_SHA256 = "7aecd2c018b6471440c45fda6372c648bef48b8d02562083d24c7529c48dc86b";
    public static final String FILE_NAME = "YourVPN-EXP-" + APK_SHA256.substring(0, 24) + ".apk";

    private VpnExpPolicy() { }

    static boolean validName(String value) {
        return FILE_NAME.equals(value);
    }

    static void verifyCandidate(String packageName, long versionCode, String versionName, byte[][] signatures) throws Exception {
        if (!PACKAGE.equals(packageName) || versionCode != VERSION_CODE || !VERSION_NAME.equals(versionName)
                || signatures == null || signatures.length != 1 || signatures[0] == null) {
            throw new SecurityException("Неверный APK демо");
        }
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(signatures[0]);
        StringBuilder hex = new StringBuilder(64);
        for (byte b : hash) hex.append(String.format(Locale.ROOT, "%02x", b & 255));
        if (!CERT_SHA256.equals(hex.toString())) throw new SecurityException("Неверная подпись демо");
    }
}
