package com.prilozhi.app.util;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import com.prilozhi.app.net.OutItem;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

public final class State {

    public enum Mode {
        IDLE, READY_SEND, READY_RECV, TAP, CONNECTING, TRANSFER, SUCCESS, ERROR
    }

    public static class HistoryEntry {
        public final String title;
        public final String subtitle;
        public final boolean ok;
        public final long time;

        public HistoryEntry(String title, String subtitle, boolean ok) {
            this.title = title;
            this.subtitle = subtitle;
            this.ok = ok;
            this.time = System.currentTimeMillis();
        }
    }

    public interface Listener {
        void onStateChanged(State state);
    }

    private static State instance;

    public static State get() {
        if (instance == null) {
            synchronized (State.class) {
                if (instance == null) instance = new State();
            }
        }
        return instance;
    }

    public final String deviceId = UUID.randomUUID().toString().replace("-", "").substring(0, 8);
    public String deviceName = (Build.MANUFACTURER + " " + Build.MODEL).trim();
    public int port = 47821;
    public volatile String token = newToken();

    public volatile Mode mode = Mode.IDLE;
    public volatile String title = "";
    public volatile String subtitle = "";

    public volatile float progress = 0f;
    public volatile float speed = 0f;
    public volatile long transferred = 0;
    public volatile long total = 0;
    public volatile int filesDone = 0;
    public volatile int filesTotal = 0;
    public volatile String currentFile = "";

    public final List<OutItem> outbound = new ArrayList<>();
    public final List<HistoryEntry> history = new ArrayList<>();

    public volatile String incomingText;
    public volatile String incomingFun;
    /** Радар сближения: когда последний раз NFC реально видел второй телефон. */
    public volatile long nfcNearAt = 0;
    // Result of a signature-protected G+ NFC contact exchange, consumed by the foreground UI.
    public volatile String gplusContactDone;
    // Wi-Fi передача: выбранное устройство и входящее предложение
    public volatile String wifiTargetId;
    public volatile String wifiTargetName;
    public volatile String wifiTargetKey;
    public volatile String wifiStatus = "";
    public volatile String offerFrom;
    public volatile String offerSession;
    public volatile String offerKey;
    /** Диагностика GFCAS: последняя фаза канала (видна в интерфейсе при сбое). */
    public volatile String gfcasPhase = "";
    /** Одноразовое сообщение о срыве быстрого канала — MainActivity покажет тостом. */
    public volatile String gfcasToast;
    /** Момент, когда NFC-касание завершилось и телефоны можно разносить. */
    public volatile long tapDoneAt = 0;
    // Серверный релей (транспорт 1.5): сессия, ключ (только через NFC), состояние заливки.
    public volatile String relaySession = "";
    public volatile String relayKeyB64 = "";
    public volatile String relaySig = "";
    public volatile String relayPhase = "";
    public volatile boolean relayUploaded = false;
    /** Срок хранения зашифрованной передачи на реле; по умолчанию один час. */
    public volatile int linkTtlHours = 1;
    public volatile boolean relayUploading = false;
    /** Сколько уже скачал получатель (0..1), отправитель опрашивает сервер. -1 = ещё не начал. */
    public volatile float peerProgress = -1f;
    public volatile boolean peerWatch = false;
    /** Пауза/отмена текущей передачи (кнопки в уведомлении). */
    public volatile boolean transferPaused = false;
    public volatile boolean transferCancelled = false;
    public volatile String incomingLink;
    public volatile String receivedApkUri;
    public volatile long cooldownUntil = 0;
    public final java.util.List<String> lastReceived = new java.util.ArrayList<>();
    public final java.util.List<String> lastReceivedUris = new java.util.ArrayList<>();
    public volatile java.util.List<com.prilozhi.app.net.OutItem> lastSentItems = new java.util.ArrayList<>();
    public volatile String lastReceivedDir = "";
    private long lastSpeedAt = 0;
    private long lastSpeedBytes = 0;

    public volatile String peerName;
    public volatile String peerId;
    public volatile boolean sessionActive = false;
    public volatile int lastSentCount = 0;
    public volatile boolean serverRunning = false;

    private final List<Listener> listeners = new CopyOnWriteArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private long lastNotify = 0;

    public static String newToken() {
        String alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        StringBuilder sb = new StringBuilder();
        java.util.Random r = new java.util.Random();
        for (int i = 0; i < 6; i++) sb.append(alphabet.charAt(r.nextInt(alphabet.length())));
        return sb.toString();
    }

    public void addListener(Listener l) {
        listeners.add(l);
    }

    public void removeListener(Listener l) {
        listeners.remove(l);
    }

    public void notifyChanged() {
        notifyChanged(false);
    }

    public void notifyChanged(boolean throttle) {
        long now = System.currentTimeMillis();
        if (throttle && now - lastNotify < 100) return;
        lastNotify = now;
        // скорость передачи: сглаженная по окну ~0.5 с
        if (mode == Mode.TRANSFER) {
            if (lastSpeedAt == 0) {
                lastSpeedAt = now;
                lastSpeedBytes = transferred;
            } else if (now - lastSpeedAt >= 400) {
                float inst = (transferred - lastSpeedBytes) * 1000f / (now - lastSpeedAt);
                speed = speed <= 0 ? inst : speed * 0.55f + inst * 0.45f;
                lastSpeedAt = now;
                lastSpeedBytes = transferred;
            }
        } else if (mode != Mode.SUCCESS) {
            speed = 0;
            lastSpeedAt = 0;
        }
        main.post(() -> {
            for (Listener l : listeners) {
                try {
                    l.onStateChanged(State.this);
                } catch (Throwable ignored) {
                }
            }
        });
    }

    public void setMode(Mode m, String title, String subtitle) {
        this.mode = m;
        this.title = title == null ? "" : title;
        this.subtitle = subtitle == null ? "" : subtitle;
        if (m == Mode.READY_RECV || m == Mode.READY_SEND || m == Mode.IDLE) {
            this.progress = 0;
            this.speed = 0;
            this.transferred = 0;
            this.total = 0;
            this.filesDone = 0;
            this.filesTotal = 0;
            this.currentFile = "";
        }
        notifyChanged();
    }

    public boolean hasOutbound() {
        synchronized (outbound) {
            return !outbound.isEmpty();
        }
    }

    public void addHistory(String title, String subtitle, boolean ok) {
        synchronized (history) {
            history.add(0, new HistoryEntry(title, subtitle, ok));
            while (history.size() > 12) history.remove(history.size() - 1);
        }
    }

    public int historySize() {
        synchronized (history) {
            return history.size();
        }
    }

    public java.util.List<HistoryEntry> historySnapshot() {
        synchronized (history) {
            return new ArrayList<>(history);
        }
    }

    public void clearOutbound() {
        synchronized (outbound) {
            outbound.clear();
        }
        notifyChanged();
    }
}
