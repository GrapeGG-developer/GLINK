'use strict';
// GSERVER / GLINK-S experimental single-writer backend and HTTPS coordinator.
// It must not be exposed without TLS, a strong shared admin/proxy key, backups,
// and an explicit production deployment review. No silent failover is allowed.
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const http=require('node:http'),https=require('node:https');
const M=require('./migration');
const {createGPlus}=require('../gplus-server');
const root=process.env.GSERVER_DATA_ROOT;
const role=process.env.GSERVER_ROLE||'storage';
const secret=process.env.GSERVER_CONTROL_SECRET||'';
// Per-process, random GUI status token; never persisted, logged or reused as
// the server control key. The status endpoint is loopback-only.
const rawGuiToken=process.env.GSERVER_GUI_STATUS_TOKEN||'';
const guiToken=/^[a-f0-9]{64}$/.test(rawGuiToken)?rawGuiToken:'';
delete process.env.GSERVER_GUI_STATUS_TOKEN;
let tunnelState=process.env.GSERVER_TUNNEL_ORIGIN?'connecting':'disabled';
if(!root||!path.isAbsolute(root)||path.parse(root).root===root)throw Error('GSERVER_DATA_ROOT must be an absolute dedicated directory');
if(!['storage','coordinator'].includes(role))throw Error('Invalid GSERVER_ROLE');
if(!/^[A-Za-z0-9_-]{32,128}$/.test(secret))throw Error('GSERVER_CONTROL_SECRET must be 32-128 random URL-safe characters');
if(process.env.NODE_TLS_REJECT_UNAUTHORIZED==='0')throw Error('TLS certificate verification must remain enabled');
const maxBytes=Number(process.env.GPLUS_MAX_ASSET_BYTES||8796093022208);
const reserve=Number(process.env.GPLUS_DISK_RESERVE_BYTES||2147483648);
if(!Number.isSafeInteger(maxBytes)||maxBytes<1||!Number.isSafeInteger(reserve)||reserve<0)throw Error('Invalid storage limit');
const controlFile=process.env.GSERVER_CONTROL_FILE||root+'.control.json';
let state={v:1,role,mode:role==='coordinator'?'GLINK-S':'GSERVER',frozen:false,peer:'',lastImportedTx:'',lastExportTx:'',importTx:''};
if(fs.existsSync(controlFile)){
 const s=JSON.parse(fs.readFileSync(controlFile,'utf8'));
 if(s.v!==1||s.role!==role||typeof s.frozen!=='boolean'||!['GLINK-S','GSERVER'].includes(s.mode))throw Error('Invalid control state');
 state=Object.assign(state,s);
}
// Crash between the two atomic renames: restore the old root before reopening.
// The verified staging copy remains intact and can be committed on resume.
if(!fs.existsSync(root)&&M.validTx(state.importTx)&&fs.existsSync(M.backupPath(root,state.importTx))&&fs.existsSync(M.stagePath(root,state.importTx)))
 fs.renameSync(M.backupPath(root,state.importTx),root);
if(fs.existsSync(controlFile)&&!fs.existsSync(root))throw Error('Storage root missing; refusing to create an empty replacement');
fs.mkdirSync(root,{recursive:true});fs.mkdirSync(path.join(root,'gplus'),{recursive:true});fs.mkdirSync(path.join(root,'glink'),{recursive:true});
process.env.GLINK_RELAY_DIR=path.join(root,'glink');process.env.GSERVER_CONTROLLED='1';
const glink=require('../glink-relay/glink-relay');
function save(){
 fs.mkdirSync(path.dirname(controlFile),{recursive:true});const temp=controlFile+'.tmp-'+crypto.randomBytes(8).toString('hex');let fd;
 try{fd=fs.openSync(temp,'wx',0o600);fs.writeFileSync(fd,JSON.stringify(state));fs.fsyncSync(fd);fs.closeSync(fd);fd=null;fs.renameSync(temp,controlFile);try{const d=fs.openSync(path.dirname(controlFile),'r');try{fs.fsyncSync(d);}finally{fs.closeSync(d);}}catch{}}
 finally{if(fd!==undefined&&fd!==null)try{fs.closeSync(fd);}catch{}try{fs.unlinkSync(temp);}catch{}}
}
if(!fs.existsSync(controlFile))save();
let app=null,inflight=0,working=false,uploads=0,exportReads=0;const sockets=new Set();
function openLocal(){if(app){glink.setFrozen(false);return;}const next=createGPlus({dataDir:path.join(root,'gplus'),maxStorageBytes:maxBytes,reserveBytes:reserve});try{glink.setFrozen(false);app=next;}catch(e){next.close();throw e;}}
function closeLocal(){glink.setFrozen(true);if(app){app.close();app=null;}}
if(!state.frozen&&(role==='storage'||state.mode==='GLINK-S'))openLocal();else glink.setFrozen(true);
function eq(a,b){if(typeof a!=='string'||a.length!==b.length)return false;return crypto.timingSafeEqual(Buffer.from(a),Buffer.from(b));}
function admin(req){return eq(req.headers['x-gserver-admin'],secret);}
function proxyAuth(req){return eq(req.headers['x-gserver-proxy-key'],secret);}
function json(res,code,data){if(res.destroyed||res.writableEnded)return;const b=Buffer.from(JSON.stringify(data));res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Content-Length':b.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(b);}
function body(req,max=64*1024){return new Promise((resolve,reject)=>{let n=0,parts=[];req.on('data',b=>{n+=b.length;if(n<=max)parts.push(b);});req.on('end',()=>{try{if(n>max)throw Error('body_too_large');resolve(JSON.parse(Buffer.concat(parts).toString('utf8')||'{}'));}catch(e){reject(e);}});req.on('error',reject);req.on('aborted',()=>reject(Error('request_aborted')));});}
function cleanUrl(value){let u;try{u=new URL(value);}catch{throw Error('invalid_peer_url');}const test=process.env.GSERVER_TEST_HTTP==='1';if((u.protocol!=='https:'&&!(test&&u.protocol==='http:'))||u.username||u.password||u.pathname!=='/'||u.search||u.hash)throw Error('peer_requires_https_origin');if(!u.hostname)throw Error('invalid_peer_url');return u.origin;}
function requestJson(base,route,method='GET',data=null){return new Promise((resolve,reject)=>{
 const u=new URL(route,cleanUrl(base)),client=u.protocol==='https:'?https:http,b=data===null?null:Buffer.from(JSON.stringify(data));
 const req=client.request(u,{method,headers:{'X-Gserver-Admin':secret,...(b?{'Content-Type':'application/json','Content-Length':b.length}:{})},timeout:15000},res=>{let n=0,buf=[];res.on('data',x=>{n+=x.length;if(n<=1024*1024)buf.push(x);});res.on('end',()=>{if(n>1024*1024)return reject(Error('response_too_large'));try{const j=JSON.parse(Buffer.concat(buf).toString('utf8'));if(res.statusCode<200||res.statusCode>=300)throw Error(j.error||'peer_error');resolve(j);}catch(e){reject(e);}});});req.on('timeout',()=>req.destroy(Error('peer_timeout')));req.on('error',reject);if(b)req.write(b);req.end();
 });}
function normalStart(res){inflight++;let done=false;const finish=()=>{if(!done){done=true;inflight--;}};res.once('finish',finish);res.once('close',finish);}
function pending(){return inflight+(app?app.pendingOperations():0)+glink.pendingWrites()+uploads+exportReads;}
async function waitDrained(){const deadline=Date.now()+60000;while(pending()>0&&Date.now()<deadline)await new Promise(r=>setTimeout(r,100));if(pending()>0)throw Error('busy_wait_for_active_transfers');}
function terminateSockets(){for(const s of sockets)try{s.destroy();}catch{}sockets.clear();if(app)app.closeCalls();}
function exportFile(tx){return controlFile+'.export-'+tx+'.json';}
function readExport(tx){if(!state.frozen||state.lastExportTx!==tx||!M.validTx(tx))throw Error('snapshot_not_active');const p=exportFile(tx);if(fs.statSync(p).size>M.MAX_MANIFEST)throw Error('manifest_too_large');return M.verifyManifest(JSON.parse(fs.readFileSync(p,'utf8')));}
async function atomicWrite(file,text){const tmp=file+'.tmp-'+crypto.randomBytes(8).toString('hex');await fsp.writeFile(tmp,text,{flag:'wx',mode:0o600});const h=await fsp.open(tmp,'r+');try{await h.sync();}finally{await h.close();}await fsp.rename(tmp,file);}
async function adminRoute(req,res,u){
 if(!admin(req))return json(res,401,{error:'unauthorized'});
 const route=u.pathname;
 if(req.method==='GET'&&route==='/gserver-admin/status')return json(res,200,{role,mode:state.mode,frozen:state.frozen,peer:state.peer,lastImportedTx:state.lastImportedTx,lastExportTx:state.lastExportTx,importTx:state.importTx,importRenamed:!!state.importTx&&!fs.existsSync(M.stagePath(root,state.importTx))&&fs.existsSync(M.backupPath(root,state.importTx)),pending:pending(),working});
 if(req.method==='POST'&&route==='/gserver-admin/freeze'){
  if(working)return json(res,409,{error:'operation_in_progress'});
  state.frozen=true;state.lastExportTx='';save();glink.setFrozen(true);terminateSockets();
  try{await waitDrained();closeLocal();return json(res,200,{ok:true,frozen:true});}catch(e){return json(res,409,{error:e.message,frozen:true});}
 }
 if(req.method==='POST'&&route==='/gserver-admin/snapshot'){
  if(!state.frozen||pending()||working||app)return json(res,409,{error:'freeze_and_drain_required'});
  const b=await body(req);if(!M.validTx(b.tx))return json(res,400,{error:'invalid_tx'});
  working=true;try{const manifest=await M.snapshot(root,b.tx);await atomicWrite(exportFile(b.tx),JSON.stringify(manifest));state.lastExportTx=b.tx;save();return json(res,200,manifest);}finally{working=false;}
 }
 if(req.method==='GET'&&route==='/gserver-admin/file'){
  const tx=u.searchParams.get('tx'),rel=u.searchParams.get('path'),m=readExport(tx),e=m.files.find(x=>x.path===rel);if(!e)return json(res,404,{error:'file_not_in_snapshot'});
  const file=M.inside(root,rel),st=await fsp.lstat(file);if(!st.isFile()||st.isSymbolicLink()||st.size!==e.size)return json(res,409,{error:'snapshot_changed'});
  exportReads++;let done=false;const finish=()=>{if(!done){done=true;exportReads--;}};
  res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Length':e.size,'Cache-Control':'no-store'});const stream=fs.createReadStream(file);stream.on('error',()=>res.destroy());stream.on('close',finish);res.on('close',()=>{stream.destroy();finish();});stream.pipe(res);return;
 }
 if(req.method==='POST'&&route==='/gserver-admin/import/prepare'){
  if(!state.frozen||pending()||working||app)return json(res,409,{error:'freeze_and_drain_required'});
  const b=await body(req,M.MAX_MANIFEST);const m=M.verifyManifest(b.manifest);
  if(state.importTx){
   if(state.importTx===m.tx&&JSON.stringify(M.loadManifest(root,m.tx))===JSON.stringify(m)&&fs.existsSync(M.stagePath(root,m.tx)))return json(res,200,{ok:true,tx:m.tx,resumed:true});
   return json(res,409,{error:'another_import_pending'});
  }
  // A crash may occur after preparing the verified stage but before saving state.
  if(fs.existsSync(M.stagePath(root,m.tx))){
   if(JSON.stringify(M.loadManifest(root,m.tx))!==JSON.stringify(m))return json(res,409,{error:'prepared_manifest_changed'});
   state.importTx=m.tx;state.lastExportTx='';save();return json(res,200,{ok:true,tx:m.tx,resumed:true});
  }
  working=true;
  try{await M.prepare(root,m,reserve);state.importTx=m.tx;state.lastExportTx='';save();return json(res,200,{ok:true,tx:m.tx});}finally{working=false;}
 }
 if(req.method==='PUT'&&route==='/gserver-admin/import/file'){
  if(!state.frozen||working||app)return json(res,409,{error:'freeze_and_drain_required'});
  const tx=u.searchParams.get('tx'),rel=u.searchParams.get('path'),raw=req.headers['content-length'];
  if(!M.validTx(tx)||state.importTx!==tx||!/^\d+$/.test(raw||'')||!Number.isSafeInteger(Number(raw)))return json(res,400,{error:'bad_import'});
  uploads++;try{await M.receive(root,tx,rel,req,Number(raw));return json(res,200,{ok:true});}finally{uploads--;}
 }
 if(req.method==='POST'&&route==='/gserver-admin/import/commit'){
  if(!state.frozen||pending()||working||app)return json(res,409,{error:'freeze_and_drain_required'});
  const b=await body(req),tx=b.tx;if(!M.validTx(tx)||state.importTx!==tx)return json(res,409,{error:'transaction_not_prepared'});
  working=true;try{const result=await M.commit(root,tx);state.importTx='';state.lastImportedTx=tx;save();return json(res,200,{ok:true,tx,files:result.files,total:result.total,backupRetained:true});}finally{working=false;}
 }
 if(req.method==='POST'&&route==='/gserver-admin/switch'){
  if(role!=='coordinator'||!state.frozen||pending()||working||app)return json(res,409,{error:'coordinator_freeze_required'});
  const b=await body(req);if(!M.validTx(b.tx)||!['GLINK-S','GSERVER'].includes(b.mode))return json(res,400,{error:'invalid_switch'});
  const oldMode=state.mode,oldPeer=state.peer,oldExport=state.lastExportTx;
  if(b.mode==='GSERVER'){
   const peer=cleanUrl(b.peer);const remote=await requestJson(peer,'/gserver-admin/status');
   if(remote.role!=='storage'||remote.frozen||remote.lastImportedTx!==b.tx||remote.working||remote.importTx)return json(res,409,{error:'peer_not_ready_or_not_imported'});
   state.peer=peer;
  } else if(state.lastImportedTx!==b.tx)return json(res,409,{error:'local_snapshot_not_imported'});
  state.mode=b.mode;state.lastExportTx='';
  try{save();}catch(e){state.mode=oldMode;state.peer=oldPeer;state.lastExportTx=oldExport;throw e;}
  return json(res,200,{ok:true,mode:state.mode,frozen:true});
 }
 if(req.method==='POST'&&route==='/gserver-admin/unfreeze'){
  if(!state.frozen||pending()||working||state.importTx)return json(res,409,{error:'not_ready'});
  if(role==='coordinator'&&state.mode==='GSERVER'){
   const remote=await requestJson(state.peer,'/gserver-admin/status');if(remote.frozen||remote.role!=='storage')return json(res,409,{error:'peer_not_ready'});
  } else openLocal();
  const oldExport=state.lastExportTx;
  state.frozen=false;state.lastExportTx='';
  try{save();}catch(e){state.frozen=true;state.lastExportTx=oldExport;closeLocal();throw e;}
  return json(res,200,{ok:true,mode:state.mode});
 }
 return json(res,404,{error:'not_found'});
}
function proxyTarget(raw){
 if(typeof raw!=='string'||!raw.startsWith('/')||raw.startsWith('//')||/[\r\n]/.test(raw))throw Error('invalid_proxy_path');
 const origin=cleanUrl(state.peer),u=new URL(raw,origin);if(u.origin!==origin)throw Error('invalid_proxy_path');return u;
}
function proxyRequest(req,res){
 let target;try{target=proxyTarget(req.url);}catch{return json(res,503,{error:'gserver_unavailable'});}
 const client=target.protocol==='https:'?https:http;const headers={...req.headers,host:target.host,'x-gserver-proxy-key':secret};delete headers['x-gserver-admin'];
 const up=client.request(target,{method:req.method,headers,timeout:60000},upres=>{res.writeHead(upres.statusCode,upres.headers);upres.on('error',()=>res.destroy());upres.pipe(res);});
 up.on('timeout',()=>up.destroy(Error('upstream_timeout')));up.on('error',()=>{if(!res.headersSent)json(res,503,{error:'gserver_unavailable'});else res.destroy();});req.on('aborted',()=>up.destroy());req.pipe(up);
}
function local(req,res){if(!app)return json(res,503,{error:'server_not_ready'});const notFound=()=>json(res,404,{error:'not_found'});app(req,res,()=>glink(req,res,notFound));}
function managedPath(raw){try{const p=new URL(raw,'http://local').pathname;return p==='/glink'||p.startsWith('/glink/')||p==='/gplus'||p.startsWith('/gplus/')||p==='/gserver'||p.startsWith('/gserver/')||p==='/gserver-admin'||p.startsWith('/gserver-admin/');}catch{return false;}}
function handler(req,res,next){
 let u;try{u=new URL(req.url,'http://local');}catch{return json(res,400,{error:'bad_url'});}
 if(!managedPath(req.url)){if(typeof next==='function')return next();return json(res,404,{error:'not_found'});}
 if(u.pathname==='/gserver/local-status'&&req.method==='GET'){
  const address=req.socket.remoteAddress,provided=req.headers['x-gserver-gui-status'];
  const valid=guiToken&&['127.0.0.1','::1','::ffff:127.0.0.1'].includes(address)&&
   typeof provided==='string'&&/^[a-f0-9]{64}$/.test(provided)&&
   crypto.timingSafeEqual(Buffer.from(provided,'ascii'),Buffer.from(guiToken,'ascii'));
  if(!valid)return json(res,404,{error:'not_found'});
  return json(res,200,{tunnel:tunnelState});
 }
 if(u.pathname==='/gserver/status'&&req.method==='GET'){
  if(role==='coordinator'&&state.mode==='GSERVER'&&!state.frozen){return requestJson(state.peer,'/gserver-admin/status').then(s=>json(res,200,{mode:'GSERVER',state:s.frozen?'maintenance':'online'})).catch(()=>json(res,200,{mode:'GSERVER',state:'unavailable'}));}
  return json(res,200,{mode:state.mode,state:state.frozen?'maintenance':'online'});
 }
 if(u.pathname.startsWith('/gserver-admin/'))return adminRoute(req,res,u).catch(e=>json(res,409,{error:e.message||'operation_failed'}));
 if(role==='storage'&&!proxyAuth(req))return json(res,403,{error:'coordinator_required'});
 if(state.frozen)return json(res,503,{error:'maintenance',retry_after:30});
 normalStart(res);
 if(role==='coordinator'&&state.mode==='GSERVER')return proxyRequest(req,res);
 return local(req,res);
}
function rejectUpgrade(socket,status='503 Service Unavailable'){if(!socket.destroyed){socket.write('HTTP/1.1 '+status+'\r\nConnection: close\r\nContent-Length: 0\r\n\r\n');socket.destroy();}}
function trackSocket(socket){sockets.add(socket);socket.once('close',()=>sockets.delete(socket));}
function upgrade(req,socket,head){
 let pathname='';try{pathname=new URL(req.url,'http://local').pathname;}catch{}
 if(pathname!=='/gplus/call-relay')return false;
 if(state.frozen||(role==='storage'&&!proxyAuth(req))){rejectUpgrade(socket,role==='storage'&&!proxyAuth(req)?'403 Forbidden':'503 Service Unavailable');return true;}
 trackSocket(socket);
 if(role==='coordinator'&&state.mode==='GSERVER'){
  let target;try{target=proxyTarget(req.url);}catch{rejectUpgrade(socket);return true;}
  const client=target.protocol==='https:'?https:http,headers={...req.headers,host:target.host,'x-gserver-proxy-key':secret};delete headers['x-gserver-admin'];
  const up=client.request(target,{headers,timeout:15000});up.on('upgrade',(response,remote,remoteHead)=>{
   let line='HTTP/1.1 '+response.statusCode+' '+response.statusMessage+'\r\n';for(let i=0;i<response.rawHeaders.length;i+=2)line+=response.rawHeaders[i]+': '+response.rawHeaders[i+1]+'\r\n';socket.write(line+'\r\n');if(remoteHead.length)socket.write(remoteHead);if(head.length)remote.write(head);socket.pipe(remote).pipe(socket);remote.on('error',()=>socket.destroy());socket.on('error',()=>remote.destroy());
  });up.on('response',()=>rejectUpgrade(socket));up.on('timeout',()=>up.destroy());up.on('error',()=>rejectUpgrade(socket));up.end();return true;
 }
 if(!app||!app.handleUpgrade(req,socket,head))rejectUpgrade(socket,'404 Not Found');
 return true;
}
let stopping=false;
async function dispose(){
 if(stopping)return;stopping=true;state.frozen=true;terminateSockets();glink.setFrozen(true);
 while(pending()>0)await new Promise(r=>setTimeout(r,100));closeLocal();
}
module.exports={handler,handleUpgrade:upgrade,managedPath,dispose};
if(require.main===module){
 const cert=process.env.GSERVER_TLS_CERT,key=process.env.GSERVER_TLS_KEY;
 let server;if(cert&&key)server=https.createServer({cert:fs.readFileSync(cert),key:fs.readFileSync(key),minVersion:'TLSv1.2'},handler);
 else if(process.env.GSERVER_ALLOW_INTERNAL_HTTP==='1'||process.env.GSERVER_TEST_HTTP==='1')server=http.createServer(handler);
 else throw Error('HTTPS certificate and private key required; plaintext is allowed only behind a trusted TLS proxy');
 server.on('upgrade',(req,socket,head)=>{if(!upgrade(req,socket,head))rejectUpgrade(socket,'404 Not Found');});
 server.requestTimeout=0; // Large transfers may legitimately take longer than five minutes.
 server.headersTimeout=15000;
 server.timeout=120000; // Close a genuinely idle connection, not an active upload.
 const port=Number(process.env.PORT||8443),host=process.env.GSERVER_BIND||((cert&&key)||process.env.GSERVER_ALLOW_INTERNAL_HTTP==='1'?'0.0.0.0':'127.0.0.1');
 const tunnelOrigin=process.env.GSERVER_TUNNEL_ORIGIN||'';
 if(tunnelOrigin&&(role!=='storage'||host!=='127.0.0.1'||cert||key||process.env.GSERVER_ALLOW_INTERNAL_HTTP!=='1'))throw Error('Tunnel storage must be plaintext loopback only; the remote link is TLS protected');
 let tunnel=null;
 server.listen(port,host,()=>{
  console.log('GSERVER '+role+' listening on '+host+':'+port);
  if(tunnelOrigin){const {startTunnel}=require('./tunnel-client');tunnel=startTunnel({coordinator:tunnelOrigin,secret,port,onState:s=>{tunnelState=s;console.log('GSERVER tunnel '+s);},onDiagnostic:d=>console.warn('GSERVER tunnel diagnostic '+d)});}
 });
 let stopRequested=false;
 function stop(){if(stopRequested)return;stopRequested=true;tunnelState='offline';state.frozen=true;terminateSockets();glink.setFrozen(true);if(tunnel)tunnel.close();server.close(async()=>{await dispose();process.exit(0);});}
 process.on('SIGINT',stop);process.on('SIGTERM',stop);
 // The native Windows controller owns this private stdin pipe. Closing the GUI
 // stops the server cleanly; no network shutdown endpoint is exposed.
 if(process.env.GSERVER_PARENT_STDIN==='1'){
  let input='';process.stdin.setEncoding('utf8');process.stdin.on('data',chunk=>{input+=chunk;if(input.length>64)input='';if(input.includes('stop\n'))stop();});
  process.stdin.on('end',stop);process.stdin.resume();
 }
}
