'use strict';
// Read-only, direct network probes. No keys, proxy values, IP addresses, paths,
// server bodies or arbitrary error messages are printed. TLS stays verified.
const dns = require('node:dns');
const net = require('node:net');
const tls = require('node:tls');
const https = require('node:https');
const crypto = require('node:crypto');

const HOST = 'loltube-v8.onrender.com';
const SAFE_CODES = new Set([
  'ECONNRESET','ECONNREFUSED','ETIMEDOUT','EHOSTUNREACH','ENETUNREACH',
  'EADDRNOTAVAIL','EAFNOSUPPORT','ENOTFOUND','EAI_AGAIN','EPROTO',
  'ERR_SSL_WRONG_VERSION_NUMBER','ERR_TLS_HANDSHAKE_TIMEOUT',
  'ERR_SOCKET_CONNECTION_TIMEOUT','UNABLE_TO_GET_ISSUER_CERT_LOCALLY',
  'UNABLE_TO_VERIFY_LEAF_SIGNATURE','SELF_SIGNED_CERT_IN_CHAIN',
  'DEPTH_ZERO_SELF_SIGNED_CERT','CERT_HAS_EXPIRED','CERT_NOT_YET_VALID',
  'ERR_TLS_CERT_ALTNAME_INVALID'
]);
function safeCode(error) {
  const seen = new WeakSet();
  function visit(e) {
    if (!e || typeof e !== 'object' || seen.has(e)) return '';
    seen.add(e);
    if (typeof e.code === 'string' && SAFE_CODES.has(e.code)) return e.code;
    if (Array.isArray(e.errors)) for (const inner of e.errors.slice(0, 8)) {
      const result = visit(inner); if (result) return result;
    }
    return visit(e.cause);
  }
  return visit(error) || 'OTHER';
}
function dnsProbe({ host = HOST, timeout = 5000, lookup = dns.lookup } = {}) {
  return new Promise(resolve => {
    let done = false;
    const timer = setTimeout(() => finish({ error: 'TIMEOUT' }), timeout);
    function finish(value) { if (done) return; done = true; clearTimeout(timer); resolve(value); }
    try {
      lookup(host, { all: true, verbatim: true }, (err, addresses) => {
        if (err) return finish({ error: safeCode(err) });
        const list = Array.isArray(addresses) ? addresses : [];
        finish({ v4: list.some(item => item && item.family === 4), v6: list.some(item => item && item.family === 6) });
      });
    } catch (e) { finish({ error: safeCode(e) }); }
  });
}
function httpsProbe({ host = HOST, port = 443, family = 4, ca, timeout = 15000, agentFactory } = {}) {
  return new Promise(resolve => {
    const start = Date.now(); let finished = false, request;
    // A custom agent without proxyEnv tests a direct connection; it does not
    // read or modify WinINet/WinHTTP proxy settings.
    const agent = agentFactory ? agentFactory() : new https.Agent({ keepAlive: false });
    const timer = setTimeout(() => finish('TIMEOUT'), timeout);
    function finish(result) {
      if (finished) return; finished = true; clearTimeout(timer);
      if (request) request.destroy(); agent.destroy();
      resolve({ result, ms: Date.now() - start });
    }
    try {
      const options = { hostname: host, port, family, path: '/gserver/status', method: 'GET', agent,
        rejectUnauthorized: true, headers: { 'User-Agent': 'GSERVER-readonly-network-check/1.0', Connection: 'close' } };
      if (ca) options.ca = ca;
      request = https.request(options, response => {
        const status = Number(response.statusCode);
        response.on('error', () => {}); response.destroy();
        finish(Number.isInteger(status) && status >= 100 && status <= 599 ? 'HTTP_' + status : 'INVALID_HTTP');
      });
      request.on('error', error => finish('ERROR_' + safeCode(error)));
      request.end();
    } catch (error) { finish('ERROR_' + safeCode(error)); }
  });
}
function upgradeProbe({ host = HOST, port = 443, family = 4, ca, timeout = 15000 } = {}) {
  return new Promise(resolve => {
    const start = Date.now(), key = crypto.randomBytes(16).toString('base64');
    const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
    const steps = { dns: net.isIP(host) ? 'IP' : 'WAIT', tcp: 'WAIT', tls: 'WAIT', upgrade: 'WAIT' };
    let socket, finished = false, header = Buffer.alloc(0);
    const timer = setTimeout(() => fail('TIMEOUT'), timeout);
    function stage() { return steps.tls === 'OK' ? 'UPGRADE' : steps.tcp === 'OK' ? 'TLS' : steps.dns === 'OK' || steps.dns === 'IP' ? 'TCP' : 'DNS_OR_TCP'; }
    function finish() {
      if (finished) return; finished = true; clearTimeout(timer);
      if (socket) socket.destroy();
      resolve({ steps: { ...steps }, ms: Date.now() - start });
    }
    function fail(code) { if (!finished) { steps.upgrade = stage() + '_' + code; finish(); } }
    try {
      const options = { host, port, family, rejectUnauthorized: true };
      if (!net.isIP(host)) options.servername = host;
      if (ca) options.ca = ca;
      socket = tls.connect(options);
      socket.on('lookup', error => { steps.dns = error ? 'ERROR_' + safeCode(error) : 'OK'; });
      socket.on('connect', () => { steps.tcp = 'OK'; });
      socket.on('secureConnect', () => {
        if (!socket.authorized) return fail('UNVERIFIED_TLS');
        steps.tls = 'OK';
        const hostHeader = (net.isIP(host) === 6 ? '[' + host + ']' : host) + (port === 443 ? '' : ':' + port);
        socket.write('GET /gserver/tunnel HTTP/1.1\r\nHost: ' + hostHeader + '\r\n' +
          'Connection: Upgrade\r\nUpgrade: websocket\r\nSec-WebSocket-Version: 13\r\n' +
          'Sec-WebSocket-Key: ' + key + '\r\n\r\n');
      });
      socket.on('data', chunk => {
        if (finished) return;
        if (header.length + chunk.length > 8192) return fail('HEADER_TOO_LARGE');
        header = Buffer.concat([header, chunk]);
        const end = header.indexOf('\r\n\r\n'); if (end < 0) return;
        const rows = header.subarray(0, end).toString('latin1').split('\r\n');
        const first = /^HTTP\/1\.[01] ([1-5][0-9]{2})(?: |$)/.exec(rows.shift() || '');
        if (!first) return fail('INVALID_HTTP');
        const status = Number(first[1]);
        if (status !== 101) { steps.upgrade = 'HTTP_' + status; return finish(); }
        const headers = Object.create(null);
        for (const row of rows) {
          const i = row.indexOf(':'); if (i < 1) continue;
          const name = row.slice(0, i).trim().toLowerCase();
          headers[name] = (headers[name] ? headers[name] + ',' : '') + row.slice(i + 1).trim();
        }
        const ok = String(headers.upgrade || '').toLowerCase() === 'websocket' &&
          String(headers.connection || '').toLowerCase().split(',').some(x => x.trim() === 'upgrade') &&
          headers['sec-websocket-accept'] === accept;
        steps.upgrade = ok ? 'HTTP_101_VALID' : 'HTTP_101_INVALID';
        finish();
      });
      socket.on('error', error => fail('ERROR_' + safeCode(error)));
      socket.on('end', () => fail('CLOSED'));
      socket.on('close', () => fail('CLOSED'));
    } catch (error) { fail('ERROR_' + safeCode(error)); }
  });
}
function formatUpgrade(result) {
  const s = result.steps;
  return 'DNS_' + s.dns + ' TCP_' + s.tcp + ' TLS_' + s.tls + ' ' + s.upgrade + ' MS_' + Math.max(0, Math.floor(result.ms));
}
async function run() {
  // Reject invalid certificates even if the parent has disabled validation.
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = '1';
  console.log('CHECK=GSERVER_DIRECT_NETWORK_NO_AUTH');
  const d = await dnsProbe();
  if (d.error) console.log('DNS=ERROR_' + d.error);
  else {
    console.log('DNS_IPV4=' + (d.v4 ? 'present' : 'absent'));
    console.log('DNS_IPV6=' + (d.v6 ? 'present' : 'absent'));
  }
  async function familyTest(family, present) {
    if (present === false) { console.log('IPV' + family + '=SKIPPED_NO_DNS_ADDRESS'); return; }
    const h = await httpsProbe({ family });
    console.log('HTTPS_IPV' + family + '=' + h.result + ' MS_' + Math.max(0, Math.floor(h.ms)));
    for (let attempt = 1; attempt <= 2; attempt++) {
      const w = await upgradeProbe({ family });
      console.log('WSS_IPV' + family + '_' + attempt + '=' + formatUpgrade(w));
    }
  }
  await Promise.all([familyTest(4, d.error ? undefined : d.v4), familyTest(6, d.error ? undefined : d.v6)]);
  console.log('NOTE=DIRECT_TESTS_NO_KEY_OR_AUTH; HTTP_101_ONLY_CHECKS_NETWORK');
  console.log('CHECK=FINISHED');
}
if (require.main === module) run().catch(() => { console.log('CHECK=ERROR_OTHER'); process.exitCode = 1; });
module.exports = { safeCode, dnsProbe, httpsProbe, upgradeProbe, formatUpgrade };
