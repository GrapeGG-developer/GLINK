package grp.gs.gplus;

import android.annotation.SuppressLint;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Low-latency mono PCM voice; the caller owns runtime microphone permission and lifetime. */
final class CallAudio implements AutoCloseable {
    interface Sink {void send(byte[] pcm);void failed();}
    private final Sink sink;private final ArrayBlockingQueue<byte[]> incoming=new ArrayBlockingQueue<>(20);
    private volatile boolean running;private AudioRecord record;private AudioTrack track;private android.media.audiofx.AcousticEchoCanceler echo;private android.media.audiofx.NoiseSuppressor noise;private Thread capture,play;
    CallAudio(Sink sink){this.sink=sink;}
    @SuppressLint("MissingPermission") synchronized void start()throws Exception{
        if(running)return;final int rate=16000, frame=640;
        int recMin=AudioRecord.getMinBufferSize(rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT),playMin=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
        if(recMin<=0||playMin<=0)throw new IllegalStateException("Аудио недоступно");
        try{
            record=new AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION,rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(recMin,frame*4));
            track=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()).setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()).setBufferSizeInBytes(Math.max(playMin,frame*4)).setTransferMode(AudioTrack.MODE_STREAM).build();
            if(record.getState()!=AudioRecord.STATE_INITIALIZED||track.getState()!=AudioTrack.STATE_INITIALIZED)throw new IllegalStateException("Аудио не запущено");
            try{if(android.media.audiofx.AcousticEchoCanceler.isAvailable()){echo=android.media.audiofx.AcousticEchoCanceler.create(record.getAudioSessionId());if(echo!=null)echo.setEnabled(true);}if(android.media.audiofx.NoiseSuppressor.isAvailable()){noise=android.media.audiofx.NoiseSuppressor.create(record.getAudioSessionId());if(noise!=null)noise.setEnabled(true);}}catch(Exception ignored){}
            record.startRecording();track.play();running=true;
            capture=new Thread(()->{try{while(running){byte[] pcm=new byte[frame];int pos=0;while(running&&pos<pcm.length){int n=record.read(pcm,pos,pcm.length-pos);if(n<=0)throw new IllegalStateException("Микрофон остановлен");pos+=n;}if(running)sink.send(pcm);}}catch(Exception e){if(running)sink.failed();}},"GPlusCallCapture");
            play=new Thread(()->{try{while(running){byte[] pcm=incoming.poll(1,TimeUnit.SECONDS);if(pcm!=null){int pos=0;while(running&&pos<pcm.length){int n=track.write(pcm,pos,pcm.length-pos,AudioTrack.WRITE_BLOCKING);if(n<=0)throw new IllegalStateException("Аудиовывод остановлен");pos+=n;}}}}catch(Exception e){if(running)sink.failed();}},"GPlusCallPlayback");capture.start();play.start();
        }catch(Exception e){close();throw e;}
    }
    void receive(byte[] pcm){if(!running||pcm==null||pcm.length!=640)return;if(!incoming.offer(pcm)){incoming.poll();incoming.offer(pcm);}}
    @Override public synchronized void close(){running=false;incoming.clear();if(echo!=null){try{echo.release();}catch(Exception ignored){}echo=null;}if(noise!=null){try{noise.release();}catch(Exception ignored){}noise=null;}if(record!=null){try{record.stop();}catch(Exception ignored){}try{record.release();}catch(Exception ignored){}record=null;}if(track!=null){try{track.stop();}catch(Exception ignored){}try{track.release();}catch(Exception ignored){}track=null;}if(capture!=null)capture.interrupt();if(play!=null)play.interrupt();}
}
