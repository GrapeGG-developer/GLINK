package grp.gs.gplus;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.KeyFactory;
import java.security.spec.X509EncodedKeySpec;
import java.text.Normalizer;
import java.util.Base64;
import java.util.Locale;

/** Pure helpers for public identity and automatic proof verification. */
public final class IdentityUtil {
    private static final byte[] DOMAIN = "G+ AUTH v1\0".getBytes(StandardCharsets.UTF_8);
    private IdentityUtil() {}

    public static String id(byte[] pub) throws Exception {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(pub);
        byte[] first = java.util.Arrays.copyOf(digest, 12);
        String shortId = Base64.getUrlEncoder().withoutPadding().encodeToString(first);
        return shortId.substring(0, 4) + "-" + shortId.substring(4, 8) + "-"
                + shortId.substring(8, 12) + "-" + shortId.substring(12, 16);
    }

    public static String nickname(String s) {
        if (s == null) return null;
        String n = s.trim(); if (n.startsWith("@")) n = n.substring(1);
        n = Normalizer.normalize(n, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);
        return n.matches("[\\p{L}\\p{N}_]{3,32}") ? n : null;
    }

    public static String b64(byte[] bytes) { return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes); }
    public static byte[] unb64(String text) { return Base64.getUrlDecoder().decode(text); }

    public static boolean verify(byte[] pub, byte[] nonce, byte[] sig) throws Exception {
        if (nonce == null || nonce.length != 32) throw new IllegalArgumentException("Invalid challenge");
        PublicKey key = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(pub));
        Signature verifier = Signature.getInstance("SHA256withECDSA");
        verifier.initVerify(key); verifier.update(DOMAIN); verifier.update(nonce); return verifier.verify(sig);
    }
}
