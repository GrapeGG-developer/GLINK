@echo off
start "" "%~dp0..\GSERVER.exe" --ui-preview
