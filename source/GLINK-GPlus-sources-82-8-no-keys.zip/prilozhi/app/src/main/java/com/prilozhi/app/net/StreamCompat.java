package com.prilozhi.app.net;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

/** Stream operations compatible with Android 10–12 (without Java 9 InputStream methods). */
public final class StreamCompat {
    private StreamCompat() {}

    public static byte[] readAll(InputStream in, int maxBytes) throws IOException {
        if (maxBytes < 0) throw new IllegalArgumentException("negative limit");
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(maxBytes, 8192));
        byte[] buf = new byte[8192];
        int read;
        while ((read = in.read(buf)) != -1) {
            if (read == 0) continue;
            if (out.size() > maxBytes - read) throw new IOException("Response is too large");
            out.write(buf, 0, read);
        }
        return out.toByteArray();
    }

    public static byte[] readExactly(InputStream in, int length) throws IOException {
        if (length < 0) throw new IllegalArgumentException("negative length");
        byte[] output = new byte[length];
        int offset = 0;
        while (offset < length) {
            int count = in.read(output, offset, length - offset);
            if (count < 0) throw new EOFException("Unexpected end of stream");
            if (count == 0) continue;
            offset += count;
        }
        return output;
    }
}
