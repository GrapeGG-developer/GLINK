package com.prilozhi.app.identity;
import com.google.crypto.tink.*;
import com.google.crypto.tink.aead.AeadConfig;
import com.google.crypto.tink.hybrid.HybridConfig;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import org.junit.Test;
import static org.junit.Assert.*;
public class GPlusTinkTest {
 @Test public void hpkeRoundTripTamperAndEncryptedKeyset() throws Exception {
  HybridConfig.register(); AeadConfig.register();
  KeysetHandle key=KeysetHandle.generateNew(KeyTemplates.get("DHKEM_P256_HKDF_SHA256_HKDF_SHA256_AES_128_GCM"));
  Aead master=KeysetHandle.generateNew(KeyTemplates.get("AES256_GCM")).getPrimitive(Aead.class);
  byte[] associated="G+ KEYSET v1\0".getBytes(StandardCharsets.UTF_8);
  ByteArrayOutputStream encrypted=new ByteArrayOutputStream();key.writeWithAssociatedData(BinaryKeysetWriter.withOutputStream(encrypted),master,associated);
  KeysetHandle restored=KeysetHandle.readWithAssociatedData(BinaryKeysetReader.withBytes(encrypted.toByteArray()),master,associated);
  ByteArrayOutputStream pub=new ByteArrayOutputStream();restored.getPublicKeysetHandle().writeNoSecret(BinaryKeysetWriter.withOutputStream(pub));
  KeysetHandle publicKey=KeysetHandle.readNoSecret(BinaryKeysetReader.withBytes(pub.toByteArray()));
  byte[] context="conversation/event/recipient".getBytes(StandardCharsets.UTF_8), text="Привет, G+".getBytes(StandardCharsets.UTF_8);
  byte[] ciphertext=publicKey.getPrimitive(HybridEncrypt.class).encrypt(text,context);
  assertArrayEquals(text,restored.getPrimitive(HybridDecrypt.class).decrypt(ciphertext,context));
  try {restored.getPrimitive(HybridDecrypt.class).decrypt(ciphertext,"other".getBytes(StandardCharsets.UTF_8));fail();}catch(java.security.GeneralSecurityException expected){}
  ciphertext[ciphertext.length-1]^=1;
  try {restored.getPrimitive(HybridDecrypt.class).decrypt(ciphertext,context);fail();}catch(java.security.GeneralSecurityException expected){}
 }
}
