package com.prilozhi.app.identity;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.Signature;
import java.security.spec.ECGenParameterSpec;

/** Device identity: public fingerprint plus a non-exportable signing key in Android Keystore. */
public final class InstallationIdentity {
    private static final String STORE = "AndroidKeyStore";
    private static final String ALIAS = "glink_gplus_identity_v1";
    private InstallationIdentity() {}

    private static synchronized KeyStore.PrivateKeyEntry entry() throws Exception {
        KeyStore store = KeyStore.getInstance(STORE);
        store.load(null);
        KeyStore.Entry entry = store.getEntry(ALIAS, null);
        if (entry == null) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, STORE);
            generator.initialize(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                    .setAlgorithmParameterSpec(new ECGenParameterSpec("secp256r1"))
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setUserAuthenticationRequired(false)
                    .build());
            generator.generateKeyPair();
            entry = store.getEntry(ALIAS, null);
        }
        if (!(entry instanceof KeyStore.PrivateKeyEntry)) throw new IllegalStateException("Identity unavailable");
        return (KeyStore.PrivateKeyEntry) entry;
    }

    public static byte[] publicKey() throws Exception {
        return entry().getCertificate().getPublicKey().getEncoded();
    }

    public static String publicId() throws Exception {
        return IdentityCodec.idFromPublicKey(publicKey());
    }

    /** Domain-separated signature for a G+ contact or message digest, never raw arbitrary data. */
    public static byte[] signGPlusDigest(byte[] digest) throws Exception {
        if (digest == null || digest.length != 32) throw new IllegalArgumentException("Expected SHA-256 digest");
        Signature signature = Signature.getInstance("SHA256withECDSA");
        signature.initSign(entry().getPrivateKey());
        signature.update(grp.gs.protocol.Protocol.SIGN_DOMAIN);
        signature.update(digest);
        return signature.sign();
    }

    /** Sign a one-time relay challenge and bind it to the independent transport public key. */
    public static byte[] signWifiChallenge(byte[] nonce, byte[] transportPublic) throws Exception {
        if (nonce == null || nonce.length != 32 || transportPublic == null
                || transportPublic.length < 80 || transportPublic.length > 150) {
            throw new IllegalArgumentException("Invalid Wi-Fi challenge");
        }
        Signature signature = Signature.getInstance("SHA256withECDSA");
        signature.initSign(entry().getPrivateKey());
        signature.update("GLINK-WIFI-AUTH-2\0".getBytes(java.nio.charset.StandardCharsets.UTF_8));
        signature.update(nonce);
        signature.update(transportPublic);
        return signature.sign();
    }

    /** Sign only the domain-separated G+ server challenge, never arbitrary caller-supplied data. */
    public static byte[] signChallenge(byte[] nonce) throws Exception {
        byte[] message = IdentityCodec.challengeMessage(nonce);
        Signature signature = Signature.getInstance("SHA256withECDSA");
        signature.initSign(entry().getPrivateKey());
        signature.update(message);
        return signature.sign();
    }
}
