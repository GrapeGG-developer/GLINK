package com.prilozhi.app.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;

/** A small gold/orange EXP flag. It animates only while visible and animations are enabled. */
public final class ExperimentalBadgeView extends View {
    private static final String LABEL = "EXP";
    private static final int[] GOLD = {
            0xFFDA8D1C, 0xFFF8AC32, 0xFFFFD25C, 0xFFFFF1AE, 0xFFE8A53D, 0xFFDA8D1C
    };
    private static final long CYCLE_MS = 2600L;
    private static final long FRAME_MS = 80L;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final Path flag = new Path();
    private final Matrix shift = new Matrix();
    private final Rect visibleBounds = new Rect();
    private LinearGradient shimmer;

    public ExperimentalBadgeView(Context context) {
        super(context);
        setContentDescription("EXP, экспериментальная версия");
        setClickable(false);
        setFocusable(false);
        setWillNotDraw(false);
        float density = getResources().getDisplayMetrics().density;
        setPadding(Math.round(6 * density), Math.round(3 * density),
                Math.round(10 * density), Math.round(3 * density));
        setMinimumHeight(Math.round(19 * density));
        text.setColor(0xFF3F2200); // readable on every colour stop in GOLD
        text.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        text.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 10f,
                getResources().getDisplayMetrics()));
        border.setColor(0x99763F00);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(Math.max(1f, density * 0.7f));
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        Paint.FontMetrics metrics = text.getFontMetrics();
        int width = (int) Math.ceil(text.measureText(LABEL)) + getPaddingLeft() + getPaddingRight();
        int height = (int) Math.ceil(metrics.descent - metrics.ascent) + getPaddingTop() + getPaddingBottom();
        setMeasuredDimension(resolveSize(Math.max(width, getSuggestedMinimumWidth()), widthSpec),
                resolveSize(Math.max(height, getSuggestedMinimumHeight()), heightSpec));
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        flag.reset();
        if (w <= 0 || h <= 0) { shimmer = null; return; }
        float density = getResources().getDisplayMetrics().density;
        float radius = Math.min(4 * density, h / 3f);
        float notch = Math.min(4 * density, w / 6f);
        float inset = border.getStrokeWidth() / 2f;
        float right = w - inset, bottom = h - inset;
        flag.moveTo(inset + radius, inset);
        flag.lineTo(right, inset);
        flag.lineTo(right - notch, h / 2f);
        flag.lineTo(right, bottom);
        flag.lineTo(inset + radius, bottom);
        flag.quadTo(inset, bottom, inset, bottom - radius);
        flag.lineTo(inset, inset + radius);
        flag.quadTo(inset, inset, inset + radius, inset);
        flag.close();
        shimmer = new LinearGradient(-w, 0, 0, 0, GOLD, null, Shader.TileMode.REPEAT);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (shimmer == null) return;
        boolean animate = ValueAnimator.areAnimatorsEnabled();
        float phase = animate ? (SystemClock.uptimeMillis() % CYCLE_MS) / (float) CYCLE_MS : 0.45f;
        shift.reset();
        shift.setTranslate(phase * getWidth(), 0);
        shimmer.setLocalMatrix(shift);
        fill.setShader(shimmer);
        canvas.drawPath(flag, fill);
        canvas.drawPath(flag, border);
        Paint.FontMetrics metrics = text.getFontMetrics();
        float centerX = (getWidth() + getPaddingLeft() - getPaddingRight()) / 2f;
        float baseline = (getHeight() - metrics.ascent - metrics.descent) / 2f;
        canvas.drawText(LABEL, centerX - text.measureText(LABEL) / 2f, baseline, text);
        if (animate && isAttachedToWindow() && isShown()
                && getWindowVisibility() == View.VISIBLE && getGlobalVisibleRect(visibleBounds)) {
            postInvalidateDelayed(FRAME_MS);
        }
    }
}
