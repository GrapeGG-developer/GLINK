package grp.gs.gplus;
import org.junit.Test;import java.io.*;import java.nio.file.Files;import java.security.SecureRandom;import java.util.Arrays;import static org.junit.Assert.*;
public class MediaForwardTest {
 @Test public void forwardedMediaIsReencryptedForDestinationWithoutPlaintextFile()throws Exception{
  File dir=Files.createTempDirectory("gplus-forward-test").toFile(),source=new File(dir,"source.enc"),dest=new File(dir,"destination.enc");byte[] original=new byte[1_100_123];new SecureRandom().nextBytes(original);String oldChat="d_AAAAAAAAAAAAAAAAAAAAAA",oldAsset="AAAAAAAAAAAAAAAAAAAAAA",newChat="g_BBBBBBBBBBBBBBBBBBBBBB",newAsset="CCCCCCCCCCCCCCCCCCCCCC";
  try{MediaCrypto.Prepared first=MediaCrypto.encrypt(new ByteArrayInputStream(original),source,oldChat,oldAsset);MediaCrypto.Prepared second=MediaCrypto.reencrypt(source,dest,first.keyset,oldChat,oldAsset,original.length,newChat,newAsset);assertEquals(original.length,second.plainSize);assertFalse(Arrays.equals(Files.readAllBytes(source.toPath()),Files.readAllBytes(dest.toPath())));ByteArrayOutputStream out=new ByteArrayOutputStream();MediaCrypto.decrypt(new FileInputStream(dest),out,second.keyset,newChat,newAsset,original.length);assertArrayEquals(original,out.toByteArray());
   try{MediaCrypto.decrypt(new FileInputStream(dest),new ByteArrayOutputStream(),first.keyset,newChat,newAsset,original.length);fail();}catch(Exception expected){}
   File bad=new File(dir,"bad.enc");byte[] corrupt=Files.readAllBytes(source.toPath());corrupt[corrupt.length/2]^=1;Files.write(bad.toPath(),corrupt);File refused=new File(dir,"refused.enc");try{MediaCrypto.reencrypt(bad,refused,first.keyset,oldChat,oldAsset,original.length,newChat,newAsset);fail();}catch(Exception expected){}assertFalse(refused.exists());
   File wrongSize=new File(dir,"wrong-size.enc");try{MediaCrypto.reencrypt(source,wrongSize,first.keyset,oldChat,oldAsset,original.length-1,newChat,newAsset);fail();}catch(Exception expected){}assertFalse(wrongSize.exists());
   File wrongKey=new File(dir,"wrong-key.enc");try{MediaCrypto.reencrypt(source,wrongKey,second.keyset,oldChat,oldAsset,original.length,newChat,newAsset);fail();}catch(Exception expected){}assertFalse(wrongKey.exists());
   File wrongAad=new File(dir,"wrong-aad.enc");try{MediaCrypto.reencrypt(source,wrongAad,first.keyset,oldChat,"DDDDDDDDDDDDDDDDDDDDDD",original.length,newChat,newAsset);fail();}catch(Exception expected){}assertFalse(wrongAad.exists());
   File truncated=new File(dir,"truncated.enc");byte[] bytes=Files.readAllBytes(source.toPath());Files.write(truncated.toPath(),Arrays.copyOf(bytes,bytes.length-10));File truncatedOut=new File(dir,"truncated-out.enc");try{MediaCrypto.reencrypt(truncated,truncatedOut,first.keyset,oldChat,oldAsset,original.length,newChat,newAsset);fail();}catch(Exception expected){}assertFalse(truncatedOut.exists());
  }finally{File[] fs=dir.listFiles();if(fs!=null)for(File f:fs)f.delete();dir.delete();}
 }
}
