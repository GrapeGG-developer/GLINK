package com.prilozhi.app.net;

import org.junit.Test;
import java.io.File;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import static org.junit.Assert.*;

public class SealedUploadTest {
    @Test public void onlyExactSealedCiphertextCanResume() throws Exception {
        File f=File.createTempFile("glink-seal-", ".enc");
        try {
            byte[] a="ciphertext-a".getBytes(StandardCharsets.UTF_8);
            Files.write(f.toPath(),a);
            SealedUpload s=new SealedUpload(a.length,SealedUpload.sha256().digest(a));
            assertTrue(s.matches(f));
            Files.write(f.toPath(),"ciphertext-b".getBytes(StandardCharsets.UTF_8));
            assertFalse(s.matches(f));
            Files.write(f.toPath(),new byte[]{1,2,3});
            assertFalse(s.matches(f));
            assertTrue(f.delete());assertFalse(s.matches(f));
        } finally { f.delete(); }
    }
}
