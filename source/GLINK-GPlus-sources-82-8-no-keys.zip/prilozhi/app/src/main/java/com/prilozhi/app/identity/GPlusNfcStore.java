package com.prilozhi.app.identity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.util.AtomicFile;
import com.prilozhi.app.net.StreamCompat;
import com.prilozhi.app.util.State;
import grp.gs.protocol.Protocol;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Arrays;

/** Private bridge for one NFC pairing. The verified contact is queued until G+ acknowledges it. */
public final class GPlusNfcStore {
    private static final String CARD_FILE = "gplus_own_contact_v1.bin";
    private static final String PENDING_DIR = "gplus_contact_inbox_v1";
    private static volatile long pairingUntil;
    private GPlusNfcStore() {}
    private static File cardFile(Context c) { return new File(c.getNoBackupFilesDir(), CARD_FILE); }
    private static File pendingDir(Context c) { return new File(c.getNoBackupFilesDir(), PENDING_DIR); }
    private static void atomic(File path,byte[] bytes)throws Exception {
        AtomicFile f=new AtomicFile(path);FileOutputStream out=null;
        try{out=f.startWrite();out.write(bytes);f.finishWrite(out);}catch(Exception e){if(out!=null)f.failWrite(out);throw e;}
    }
    public static synchronized void setOwn(Context c,byte[] bytes)throws Exception {
        Protocol.Card card=Protocol.decodeCard(bytes);
        if(!card.id.equals(InstallationIdentity.publicId())
                || !Arrays.equals(card.identityPublic,InstallationIdentity.publicKey())
                || !Arrays.equals(card.encryptionPublic,GPlusCryptoIdentity.publicKeyset(c)))
            throw new SecurityException("Contact card does not belong to this GLINK device");
        atomic(cardFile(c),bytes);
    }
    public static synchronized byte[] own(Context c)throws Exception {
        File f=cardFile(c);if(!f.exists())return null;
        byte[] bytes;try(FileInputStream in=new FileInputStream(f)){bytes=StreamCompat.readAll(in,Protocol.MAX_CARD);}
        Protocol.Card card=Protocol.decodeCard(bytes);
        if(!card.id.equals(InstallationIdentity.publicId())
                || !Arrays.equals(card.encryptionPublic,GPlusCryptoIdentity.publicKeyset(c)))throw new SecurityException("Stale contact card");
        return bytes;
    }
    public static void begin() { pairingUntil=SystemClock.elapsedRealtime()+120_000L; }
    public static boolean active() { return pairingUntil>SystemClock.elapsedRealtime(); }
    public static void end() { pairingUntil=0; }

    public static synchronized void accept(Context context,byte[] bytes)throws Exception {
        Context c=context.getApplicationContext();Protocol.Card card=Protocol.decodeCard(bytes);
        if(card.id.equals(InstallationIdentity.publicId()))throw new SecurityException("Cannot add this device");
        File dir=pendingDir(c);if(!dir.exists()&&!dir.mkdirs())throw new IllegalStateException("Contact inbox unavailable");
        atomic(new File(dir,card.id+".bin"),bytes);
        end();
        // Explicit broadcast is restricted by G+'s signature permission; the inbox is a fallback.
        Intent i=new Intent("grp.gs.gplus.CONTACT_FROM_GLINK");
        i.setComponent(new ComponentName("grp.gs.gplus","grp.gs.gplus.ContactReceiver"));
        i.putExtra("card",bytes);
        try{c.sendBroadcast(i);}catch(Exception ignored){}
        State st=State.get();st.gplusContactDone=card.display;st.notifyChanged();
    }
    public static synchronized String[] pending(Context c) {
        File[] files=pendingDir(c).listFiles((d,n)->n.matches("[A-Za-z0-9_-]{19}\\.bin"));
        if(files==null)return new String[0];
        java.util.List<String> out=new java.util.ArrayList<>();
        for(File f:files) {
            if(out.size()>=40)break;
            try(FileInputStream in=new FileInputStream(f)){
                byte[] b=StreamCompat.readAll(in,Protocol.MAX_CARD);Protocol.decodeCard(b);out.add(Protocol.b64(b));
            }catch(Exception ignored){}
        }
        return out.toArray(new String[0]);
    }
    public static synchronized void ack(Context c,String id) {
        if(Protocol.validId(id))new File(pendingDir(c),id+".bin").delete();
    }
}
