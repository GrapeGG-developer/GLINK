package grp.gs.gplus;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import grp.gs.protocol.Protocol;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;

/** Forwards to NFC contacts or joined groups; attachments are decrypted and re-encrypted as a stream. */
final class Forwarder {
    private Forwarder(){}
    static final class Destination {final Protocol.Card peer;final SignedGroup group;final String title,id;Destination(Protocol.Card p,SignedGroup g,String t,String id){peer=p;group=g;title=t;this.id=id;}}
    static void choose(Activity activity,ExecutorService io,GlinkBridge bridge,GPlusApi api,GPlusStore store,SharedPreferences prefs,String sourceChat,Timeline.Item item,Runnable onQueued){
        Handler main=new Handler(Looper.getMainLooper());io.execute(()->{try{String self=bridge.id();GroupEngine groupEngine=new GroupEngine(bridge,api,store);List<Destination> targets=new ArrayList<>();for(Protocol.Card p:store.contacts())targets.add(new Destination(p,null,p.display+" · @"+p.nick,Protocol.directChat(self,p.id)));for(String raw:store.groupStates()){try{SignedGroup g=groupEngine.parse(new JSONObject(raw));if(g.canPost(self))targets.add(new Destination(null,g,g.title+("channel".equals(g.kind)?" · канал":" · группа"),g.id));}catch(Exception ignored){}}
            main.post(()->{if(activity.isFinishing()||activity.isDestroyed())return;if(targets.isEmpty()){Toast.makeText(activity,"Нет доступных контактов или групп",Toast.LENGTH_LONG).show();return;}String[] labels=new String[targets.size()];for(int i=0;i<labels.length;i++)labels[i]=targets.get(i).title;new AlertDialog.Builder(activity).setTitle("Переслать в чат").setItems(labels,(d,n)->{Destination target=targets.get(n);Toast.makeText(activity,"Добавляем в очередь…",Toast.LENGTH_SHORT).show();io.execute(()->{try{forward(activity,bridge,api,store,prefs,sourceChat,item,target);main.post(()->{if(!activity.isFinishing()&&!activity.isDestroyed()){Toast.makeText(activity,"Переслано в очередь",Toast.LENGTH_SHORT).show();onQueued.run();}});}catch(Exception e){main.post(()->{if(!activity.isFinishing()&&!activity.isDestroyed())Toast.makeText(activity,"Не удалось переслать: проверьте подключение и место",Toast.LENGTH_LONG).show();});}});}).setNegativeButton("Отмена",null).show();});
        }catch(Exception e){main.post(()->{if(!activity.isFinishing()&&!activity.isDestroyed())Toast.makeText(activity,"Получатели недоступны",Toast.LENGTH_SHORT).show();});}});
    }
    static void forward(Activity activity,GlinkBridge bridge,GPlusApi api,GPlusStore store,SharedPreferences prefs,String sourceChat,Timeline.Item item,Destination target)throws Exception{
        ChatEngine direct=new ChatEngine(bridge,api,store);GroupEngine groups=new GroupEngine(bridge,api,store);String self=bridge.id();if(target==null||(target.peer==null)==(target.group==null)||target.peer!=null&&!Protocol.directChat(self,target.peer.id).equals(target.id)||target.group!=null&&(!target.group.id.equals(target.id)||!target.group.canPost(self)))throw new SecurityException("Недоступный получатель");String type=item.content.optString("type");
        if("file".equals(type)){
            String asset=item.content.getString("asset"),sha=item.content.getString("sha256"),name=item.content.optString("name","Файл"),mime=item.content.optString("mime","application/octet-stream");long size=item.content.getLong("size"),cipherSize=item.content.getLong("cipher_size");if(!Protocol.validChatId(sourceChat)||!Protocol.validEventId(asset)||size<0||cipherSize<1||!sha.matches("[0-9a-f]{64}"))throw new SecurityException("Invalid source attachment");
            File dir=new File(activity.getNoBackupFilesDir(),"encrypted_media");if(!dir.exists()&&!dir.mkdirs())throw new java.io.IOException("No storage");File cached=new File(dir,asset+".bin");boolean cachedReady=MainActivity.mediaMatches(cached,cipherSize,sha);long reserve=20L*1024*1024,downloadNeed=cachedReady?0:cipherSize;if(size>Long.MAX_VALUE-reserve||downloadNeed>Long.MAX_VALUE-reserve-size||dir.getUsableSpace()<size+reserve+downloadNeed)throw new java.io.IOException("Insufficient storage");MediaCrypto.Prepared prepared=null;boolean queued=false;byte[] key=null;
            try{if(!cachedReady){if(!api.isSignedIn())api.login(prefs.getString("nickname",""));try{api.downloadAsset(asset,cached,cipherSize,sha);}catch(GPlusApi.ApiException e){if(e.status!=401)throw e;api.login(prefs.getString("nickname",""));api.downloadAsset(asset,cached,cipherSize,sha);}}
                byte[] random=new byte[16];new SecureRandom().nextBytes(random);String newAsset=Protocol.b64(random);key=Protocol.unb64(item.content.getString("key"));prepared=MediaCrypto.reencrypt(cached,new File(dir,newAsset+".bin"),key,sourceChat,asset,size,target.id,newAsset);boolean voice=item.content.optBoolean("voice");if(target.peer!=null)direct.queueForwardedFile(target.peer,newAsset,prepared,name,mime,voice);else groups.queueForwardedFile(target.group,newAsset,prepared,name,mime,voice);queued=true;
                try{MediaReceipts.verified(store,asset,item.id,sha);}catch(Exception ignored){}
            }finally{if(key!=null)Arrays.fill(key,(byte)0);if(prepared!=null&&!queued)prepared.file.delete();}
        }else{
            JSONObject message;if("text".equals(type))message=new JSONObject().put("v",1).put("type","text").put("text",item.text);else if("sticker".equals(type))message=new JSONObject().put("v",1).put("type","sticker").put("sticker",item.content.getString("sticker"));else if("poll".equals(type)){JSONArray options=new JSONArray();for(String option:item.pollOptions)options.put(option);message=new JSONObject().put("v",1).put("type","poll").put("question",item.content.getString("question")).put("options",options);}else throw new IllegalArgumentException("Unsupported message");message.put("forwarded",true);if(target.peer!=null)direct.queue(target.peer,message);else groups.queue(target.group,message);
        }
        // Queue persists locally even when delivery is temporarily unavailable.
        try{if(!api.isSignedIn())api.login(prefs.getString("nickname",""));if(target.peer!=null)direct.sync(target.peer,false);else groups.sync(target.group,false);}catch(Exception ignored){}
    }
}
