package grp.gs.gplus;

import android.app.Activity;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import grp.gs.protocol.Protocol;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutorService;

/** Authenticates a voice attachment before playback; private plaintext temp is deleted on stop. */
final class VoicePlayback {
    private final Activity activity;private final GPlusApi api;private final GPlusStore store;private final SharedPreferences prefs;private final ExecutorService io;private final Handler main=new Handler(Looper.getMainLooper());
    private MediaPlayer player;private File clear;private int generation;
    VoicePlayback(Activity a,GPlusApi api,GPlusStore store,SharedPreferences prefs,ExecutorService io){activity=a;this.api=api;this.store=store;this.prefs=prefs;this.io=io;}
    void play(String chat,String event,JSONObject file){stop();final int ticket=generation;Toast.makeText(activity,"Проверяем голосовое сообщение…",Toast.LENGTH_SHORT).show();io.execute(()->{File plain=null;try{
        String asset=file.getString("asset"),sha=file.getString("sha256");long size=file.getLong("size"),cipher=file.getLong("cipher_size");if(!file.optBoolean("voice")||!Protocol.validChatId(chat)||!Protocol.validEventId(asset)||size<1||size>32L*1024*1024||cipher<1||cipher>40L*1024*1024||!sha.matches("[0-9a-f]{64}"))throw new SecurityException("Invalid voice");File dir=new File(activity.getNoBackupFilesDir(),"encrypted_media");if(!dir.exists()&&!dir.mkdirs())throw new java.io.IOException("No storage");File encrypted=new File(dir,asset+".bin");if(!MainActivity.mediaMatches(encrypted,cipher,sha)){if(!api.isSignedIn())api.login(prefs.getString("nickname",""));try{api.downloadAsset(asset,encrypted,cipher,sha);}catch(GPlusApi.ApiException e){if(e.status!=401)throw e;api.login(prefs.getString("nickname",""));api.downloadAsset(asset,encrypted,cipher,sha);}}
        plain=File.createTempFile("gplus-voice-play-",".m4a",activity.getCacheDir());byte[] key=Protocol.unb64(file.getString("key"));try{MediaCrypto.decrypt(new FileInputStream(encrypted),new FileOutputStream(plain),key,chat,asset,size);}finally{java.util.Arrays.fill(key,(byte)0);}try{MediaReceipts.verified(store,asset,event,sha);}catch(Exception ignored){}File ready=plain;plain=null;main.post(()->{if(ticket!=generation||activity.isFinishing()||activity.isDestroyed()){ready.delete();return;}try{clear=ready;player=new MediaPlayer();player.setDataSource(ready.getAbsolutePath());player.setOnPreparedListener(MediaPlayer::start);player.setOnCompletionListener(p->stop());player.setOnErrorListener((p,w,e)->{stop();Toast.makeText(activity,"Не удалось воспроизвести",Toast.LENGTH_SHORT).show();return true;});player.prepareAsync();}catch(Exception e){stop();Toast.makeText(activity,"Не удалось воспроизвести",Toast.LENGTH_SHORT).show();}});
    }catch(Exception e){if(plain!=null)plain.delete();main.post(()->{if(ticket==generation&&!activity.isFinishing()&&!activity.isDestroyed())Toast.makeText(activity,"Не удалось проверить голосовое сообщение",Toast.LENGTH_LONG).show();});}});}
    void stop(){generation++;if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}if(clear!=null){clear.delete();clear=null;}}
}
