package com.prilozhi.app.net;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class DownloadRange {
    private static final Pattern HEADER=Pattern.compile("bytes (\\d+)-(\\d+)/(\\d+)");
    private DownloadRange() { }
    static boolean valid(String header,long offset,long total,long contentLength) {
        if (header==null || offset<0 || total<=0 || offset>=total) return false;
        Matcher m=HEADER.matcher(header);
        if (!m.matches()) return false;
        try {
            long a=Long.parseLong(m.group(1)), b=Long.parseLong(m.group(2)), t=Long.parseLong(m.group(3));
            return a==offset && t==total && b>=a && b<t && (contentLength<0 || contentLength==b-a+1);
        } catch (NumberFormatException e) { return false; }
    }
}
