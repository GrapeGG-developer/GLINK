'use strict';
/* GSERVER Windows signed updater: strict feed, zip extraction, and reversible
   file replacement. It never deletes unknown files or writes inside dataRoot. */
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const https = require('node:https');
const crypto = require('node:crypto');
const { pipeline } = require('node:stream/promises');
const ARTIFACT_URL = 'https://raw.githubusercontent.com/GrapeGG-developer/GLINK/main/GSERVER-Windows-Tunnel.zip';
const MANIFEST_URL = 'https://raw.githubusercontent.com/GrapeGG-developer/GLINK/main/gserver-windows-version.json';
const MAX_ARCHIVE = 25 * 1024 * 1024, MAX_EXPANDED = 70 * 1024 * 1024, MAX_FILES = 1200;
const MODULES = new Set(['ws', 'better-sqlite3', 'bindings', 'file-uri-to-path', 'yauzl', 'pend', 'buffer-crc32']);
const REQUIRED = ['GSERVER.exe', 'gserver/backend.js', 'gserver/tls-handshake-fallback.js', 'gserver/update-client.js', 'gserver/update-core.js',
  'gserver/update-cert.pem', 'node_modules/yauzl/index.js', 'node_modules/pend/index.js', 'node_modules/buffer-crc32/index.js'];

function canonical(m, expectedUrl = ARTIFACT_URL) {
  if (!m || m.schema !== 1 || !Number.isSafeInteger(m.versionCode) || m.versionCode < 1 || m.versionCode > 999999999
      || typeof m.versionName !== 'string' || !/^[0-9]+\.[0-9]+\.[0-9]+$/.test(m.versionName)
      || !Number.isSafeInteger(m.size) || m.size < 1 || m.size > MAX_ARCHIVE
      || typeof m.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(m.sha256)
      || m.url !== expectedUrl) throw Error('invalid_manifest');
  return Buffer.from('GSERVER-WINDOWS-UPDATE-1\n' + m.versionCode + '\n' + m.versionName + '\n'
      + m.size + '\n' + m.sha256 + '\n' + m.url + '\n', 'utf8');
}
function verifyManifest(m, publicKey, currentCode, expectedUrl = ARTIFACT_URL) {
  const bytes = canonical(m, expectedUrl);
  if (typeof m.signature !== 'string' || !/^[A-Za-z0-9+/]+={0,2}$/.test(m.signature)) throw Error('invalid_signature');
  const signature = Buffer.from(m.signature, 'base64');
  if (signature.length < 128 || signature.length > 1024 || !crypto.verify('RSA-SHA256', bytes, publicKey, signature))
    throw Error('invalid_signature');
  if (!Number.isSafeInteger(currentCode) || currentCode < 0) throw Error('invalid_current_version');
  return m.versionCode > currentCode;
}
function fetchBuffer(url, max, timeout = 20000) {
  return new Promise((resolve, reject) => {
    let u; try { u = new URL(url); } catch (_) { return reject(Error('invalid_url')); }
    if (u.protocol !== 'https:' || u.hostname !== 'raw.githubusercontent.com' || u.username || u.password || u.port) return reject(Error('invalid_url'));
    const req = https.get(u, { headers: { 'Cache-Control': 'no-cache', 'Accept': 'application/octet-stream' }, timeout, rejectUnauthorized: true }, res => {
      if (res.statusCode !== 200) { res.resume(); return reject(Error('http_' + res.statusCode)); }
      let size = 0, parts = [];
      res.on('data', b => { size += b.length; if (size > max) res.destroy(Error('too_large')); else parts.push(b); });
      res.on('error', reject); res.on('end', () => resolve(Buffer.concat(parts)));
    });
    req.on('timeout', () => req.destroy(Error('timeout'))); req.on('error', reject);
  });
}
function verifyArchive(bytes, m) {
  if (!Buffer.isBuffer(bytes) || bytes.length !== m.size) throw Error('archive_size_mismatch');
  const hash = crypto.createHash('sha256').update(bytes).digest('hex');
  if (hash !== m.sha256) throw Error('archive_hash_mismatch');
}
function validRelative(raw, directory = false) {
  if (typeof raw !== 'string' || !raw || raw.length > 512 || raw.includes('\\') || raw.startsWith('/') || raw.includes('\0')) throw Error('bad_archive_path');
  let p = directory && raw.endsWith('/') ? raw.slice(0, -1) : raw;
  const segs = p.split('/');
  if (segs.some(s => !s || s === '.' || s === '..' || !/^[A-Za-z0-9._-]+$/.test(s)
      || s.endsWith('.') || /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$/i.test(s))) throw Error('bad_archive_path');
  if (segs.length === 1 && ['GSERVER.exe', 'README-GSERVER.md'].includes(segs[0])) return p;
  if (segs.length >= 2 && ['gserver', 'gplus-server', 'glink-relay'].includes(segs[0])) return p;
  if (segs.length >= 2 && segs[0] === 'node_modules' && MODULES.has(segs[1])) return p;
  if (directory && segs.length === 1 && ['gserver', 'gplus-server', 'glink-relay', 'node_modules'].includes(segs[0])) return p;
  throw Error('unexpected_archive_path');
}
function childOf(parent, target) {
  let a = path.resolve(parent), b = path.resolve(target);
  if (process.platform === 'win32') { a = a.toLowerCase(); b = b.toLowerCase(); }
  const r = path.relative(a, b); return r === '' || (!r.startsWith('..' + path.sep) && r !== '..' && !path.isAbsolute(r));
}
function samePath(a,b){return childOf(a,b)&&childOf(b,a);}
async function ensureSafeTarget(root, dataRoot, rel) {
  const target = path.resolve(root, ...rel.split('/'));
  if (!childOf(root, target) || childOf(dataRoot, target)) throw Error('protected_data_path');
  const relative = path.relative(root, path.dirname(target)).split(path.sep).filter(Boolean);
  let cursor = root;
  for (const seg of relative) {
    cursor = path.join(cursor, seg);
    try { const st = await fsp.lstat(cursor); if (st.isSymbolicLink() || !st.isDirectory()) throw Error('unsafe_target_directory'); }
    catch (e) { if (e.code !== 'ENOENT') throw e; }
  }
  try { const st = await fsp.lstat(target); if (st.isSymbolicLink() || !st.isFile()) throw Error('unsafe_target_file'); }
  catch (e) { if (e.code !== 'ENOENT') throw e; }
  return target;
}
async function extractArchive(archive, outDir) {
  const yauzl = require('yauzl');
  await fsp.mkdir(outDir, { recursive: true });
  const files = [], seen = new Set(); let total = 0, count = 0;
  await new Promise((resolve, reject) => {
    yauzl.open(archive, { lazyEntries: true, autoClose: true, decodeStrings: true, validateEntrySizes: true }, (err, zip) => {
      if (err) return reject(Error('invalid_zip'));
      let finished = false;
      const fail = e => { if (finished) return; finished = true; try { zip.close(); } catch (_) {} reject(e instanceof Error ? e : Error('invalid_zip')); };
      zip.on('error', fail); zip.on('end', () => { if (!finished) { finished = true; resolve(); } });
      zip.on('entry', entry => {
        (async () => {
          const directory = entry.fileName.endsWith('/'), rel = validRelative(entry.fileName, directory);
          const folded = rel.toLowerCase();
          if (seen.has(folded)) throw Error('duplicate_archive_path'); seen.add(folded);
          if (++count > MAX_FILES || entry.uncompressedSize < 0 || entry.uncompressedSize > MAX_EXPANDED) throw Error('archive_limit');
          total += entry.uncompressedSize; if (total > MAX_EXPANDED) throw Error('archive_limit');
          const mode = (entry.externalFileAttributes >>> 16) & 0xf000;
          if (mode === 0xa000 || (entry.externalFileAttributes & 0x400)) throw Error('archive_link');
          const dest = path.join(outDir, ...rel.split('/'));
          if (!childOf(outDir, dest)) throw Error('bad_archive_path');
          if (directory) { await fsp.mkdir(dest, { recursive: true }); zip.readEntry(); return; }
          if (mode && mode !== 0x8000) throw Error('archive_special_file');
          await fsp.mkdir(path.dirname(dest), { recursive: true });
          const input = await new Promise((ok, no) => zip.openReadStream(entry, (e, s) => e ? no(e) : ok(s)));
          await pipeline(input, fs.createWriteStream(dest, { flags: 'wx', mode: 0o600 }));
          files.push(rel); zip.readEntry();
        })().catch(fail);
      });
      zip.readEntry();
    });
  });
  if (REQUIRED.some(p => !files.includes(p))) throw Error('incomplete_archive');
  return files.sort((a, b) => a === 'GSERVER.exe' ? 1 : b === 'GSERVER.exe' ? -1 : a.localeCompare(b));
}
async function atomicJson(file, value) {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  const tmp = file + '.part-' + crypto.randomBytes(5).toString('hex');
  const f = await fsp.open(tmp, 'wx', 0o600);
  try { await f.writeFile(JSON.stringify(value), 'utf8'); await f.sync(); } finally { await f.close(); }
  await fsp.rename(tmp, file);
}
async function safeCopyAtomic(source, dest) {
  await fsp.mkdir(path.dirname(dest), { recursive: true });
  const tmp = dest + '.gserver-update-' + crypto.randomBytes(5).toString('hex') + '.tmp';
  try {
    await fsp.copyFile(source, tmp, fs.constants.COPYFILE_EXCL);
    const f = await fsp.open(tmp, 'r+'); try { await f.sync(); } finally { await f.close(); }
    await fsp.rename(tmp, dest);
  } finally { await fsp.rm(tmp, { force: true }).catch(() => {}); }
}
async function recover(root, dataRoot, work) {
  const file = path.join(work, 'journal.json'); let j;
  try { j = JSON.parse(await fsp.readFile(file, 'utf8')); } catch (e) { if (e.code === 'ENOENT') return false; throw Error('invalid_update_journal'); }
  if (!j || j.schema !== 1 || !['prepared', 'installing', 'committed'].includes(j.state)
      || !Array.isArray(j.entries) || j.entries.length > MAX_FILES || !/^[a-f0-9]{24}$/.test(j.tx || '')
      || typeof j.root !== 'string' || typeof j.dataRoot !== 'string'
      || !samePath(j.root,root) || !samePath(j.dataRoot,dataRoot)) throw Error('invalid_update_journal');
  const backup = path.join(work, 'rollback-' + j.tx);
  try { const st=await fsp.lstat(backup);if(st.isSymbolicLink()||!st.isDirectory())throw Error('unsafe_update_backup'); }
  catch(e){if(e.code!=='ENOENT')throw e;}
  if (j.state === 'installing') {
    for (const entry of j.entries) {
      if (typeof entry.existed !== 'boolean' || typeof entry.touched !== 'boolean') throw Error('invalid_update_journal');
      if (!entry.touched) continue;
      const rel = validRelative(entry.path, false), target = await ensureSafeTarget(root, dataRoot, rel);
      if (entry.existed) {
        const source = await ensureSafeTarget(backup,dataRoot,rel);
        const st = await fsp.lstat(source); if (!st.isFile() || st.isSymbolicLink()) throw Error('missing_update_backup');
        await safeCopyAtomic(source, target);
      } else {
        await fsp.rm(target, { force: true });
      }
    }
  }
  await fsp.rm(file, { force: true });
  await fsp.rm(backup, { recursive: true, force: true });
  return j.state === 'installing';
}
async function applyFiles(root, dataRoot, work, stage, files, onInstalled) {
  if (!root || !dataRoot || !work || !path.isAbsolute(root) || !path.isAbsolute(dataRoot) || !path.isAbsolute(work)) throw Error('invalid_update_path');
  root = await fsp.realpath(root);
  try { dataRoot = await fsp.realpath(dataRoot); } catch (e) { if (e.code === 'ENOENT') dataRoot = path.resolve(dataRoot); else throw e; }
  work = path.resolve(work);
  if (childOf(dataRoot, work) || childOf(work, dataRoot)) throw Error('protected_data_path');
  if (await recover(root, dataRoot, work)) throw Error('recovered_previous_update');
  const tx = crypto.randomBytes(12).toString('hex'), backup = path.join(work, 'rollback-' + tx);
  const entries = [];
  for (const rel of files) {
    validRelative(rel, false);
    const target = await ensureSafeTarget(root, dataRoot, rel);
    let existed = true;
    try { await fsp.lstat(target); } catch (e) { if (e.code === 'ENOENT') existed = false; else throw e; }
    entries.push({ path: rel, existed, touched: false });
  }
  const journal = { schema: 1, tx, root, dataRoot, state: 'prepared', entries };
  const journalFile = path.join(work, 'journal.json');
  await fsp.mkdir(work, { recursive: true });
  await fsp.mkdir(backup, { recursive: false });
  try {
    for (const e of entries) if (e.existed) {
      const target = await ensureSafeTarget(root, dataRoot, e.path), b = path.join(backup, ...e.path.split('/'));
      await fsp.mkdir(path.dirname(b), { recursive: true }); await fsp.copyFile(target, b, fs.constants.COPYFILE_EXCL);
      const bf=await fsp.open(b,'r+');try{await bf.sync();}finally{await bf.close();}
    }
    await atomicJson(journalFile, journal); journal.state = 'installing'; await atomicJson(journalFile, journal);
    for (const e of entries) {
      const target = await ensureSafeTarget(root, dataRoot, e.path), src = path.join(stage, ...e.path.split('/'));
      const stat = await fsp.lstat(src); if (!stat.isFile() || stat.isSymbolicLink()) throw Error('unsafe_stage_file');
      e.touched = true; await atomicJson(journalFile, journal);
      await safeCopyAtomic(src, target);
    }
    if (onInstalled) await onInstalled(tx);
    journal.state = 'committed'; await atomicJson(journalFile, journal);
    await fsp.rm(journalFile, { force: true });
    await fsp.rm(backup, { recursive: true, force: true });
    return tx;
  } catch (e) {
    try { await recover(root, dataRoot, work); } catch (_) { throw Error('rollback_failed_keep_backups'); }
    throw e;
  }
}
module.exports = { ARTIFACT_URL, MANIFEST_URL, MAX_ARCHIVE, canonical, verifyManifest, verifyArchive, fetchBuffer,
  validRelative, childOf, ensureSafeTarget, extractArchive, atomicJson, safeCopyAtomic, recover, applyFiles };
