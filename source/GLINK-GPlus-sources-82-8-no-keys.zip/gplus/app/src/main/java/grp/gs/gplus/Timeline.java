package grp.gs.gplus;

import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Applies authenticated, encrypted message operations; only the author may edit/delete. */
public final class Timeline {
    private Timeline(){}
    public static final class Item {
        public final String id,sender,state,reply;public final long seq,created;public final JSONObject content;
        public String text;public boolean deleted,edited,forwarded;public final Map<String,String> reactions=new LinkedHashMap<>();
        public final List<String> pollOptions=new ArrayList<>();public final Map<String,Integer> pollVotes=new LinkedHashMap<>();
        Item(ChatEngine.Message m){id=m.id;sender=m.sender;state=m.state;seq=m.seq;created=m.created;content=m.content;String type=content.optString("type");text="file".equals(type)?(content.optBoolean("voice")?"Голосовое сообщение · нажмите для прослушивания":"Файл · "+content.optString("name","Файл")):"poll".equals(type)?"Опрос · "+content.optString("question",""):"sticker".equals(type)?"Стикер · "+StickerView.title(content.optString("sticker")):content.optString("text","");reply=m.content.optString("reply","");forwarded=m.content.optBoolean("forwarded",false);if("poll".equals(type)){org.json.JSONArray options=content.optJSONArray("options");if(options!=null)for(int i=0;i<options.length();i++)pollOptions.add(options.optString(i));}}
    }
    public static List<Item> apply(List<ChatEngine.Message> events){
        Map<String,Item> items=new LinkedHashMap<>();
        for(ChatEngine.Message e:events){JSONObject v=e.content;String type=v.optString("type"),target=v.optString("target");
            if(type.equals("text")){String body=v.optString("text","");if(!body.isEmpty()&&body.length()<=16000)items.put(e.id,new Item(e));}
            else if(type.equals("file")){String asset=v.optString("asset"),name=v.optString("name");if(grp.gs.protocol.Protocol.validEventId(asset)&&!name.isEmpty()&&name.length()<=180)items.put(e.id,new Item(e));}
            else if(type.equals("sticker")){if(StickerView.known(v.optString("sticker")))items.put(e.id,new Item(e));}
            else if(type.equals("poll")){String q=v.optString("question","").trim();org.json.JSONArray options=v.optJSONArray("options");boolean valid=!q.isEmpty()&&q.length()<=500&&options!=null&&options.length()>=2&&options.length()<=8;if(valid)for(int i=0;i<options.length();i++){String choice=options.optString(i,"").trim();if(choice.isEmpty()||choice.length()>120){valid=false;break;}}if(valid)items.put(e.id,new Item(e));}
            else if(type.equals("vote")){Item m=items.get(target);int option=v.optInt("option",-2);if(m!=null&&!m.deleted&&!m.pollOptions.isEmpty()){if(option==-1)m.pollVotes.remove(e.sender);else if(option>=0&&option<m.pollOptions.size())m.pollVotes.put(e.sender,option);}}
            else if(type.equals("edit")){Item m=items.get(target);String body=v.optString("text","");if(m!=null&&!m.deleted&&m.sender.equals(e.sender)&&!body.isEmpty()&&body.length()<=16000){m.text=body;m.edited=true;}}
            else if(type.equals("delete")){Item m=items.get(target);if(m!=null&&m.sender.equals(e.sender)){m.deleted=true;m.text="Сообщение удалено";m.reactions.clear();m.pollVotes.clear();}}
            else if(type.equals("reaction")){Item m=items.get(target);String reaction=v.optString("reaction","");if(m!=null&&!m.deleted&&reaction.length()<=16){if(reaction.isEmpty())m.reactions.remove(e.sender);else m.reactions.put(e.sender,reaction);}}
        }return new ArrayList<>(items.values());
    }
}
