package grp.gs.gplus;
import org.junit.Test;import java.io.*;import java.nio.file.Files;import java.security.SecureRandom;import java.util.Arrays;import static org.junit.Assert.*;
public class MediaCryptoTest {
 @Test public void originalBytesSurviveAndTamperingIsRejected()throws Exception{
  byte[] original=new byte[2_300_123];new SecureRandom().nextBytes(original);File dir=Files.createTempDirectory("gplus-media-test").toFile(),f=new File(dir,"asset.bin");String chat="d_AAAAAAAAAAAAAAAAAAAAAA",asset="AAAAAAAAAAAAAAAAAAAAAA";
  MediaCrypto.Prepared p=MediaCrypto.encrypt(new ByteArrayInputStream(original),f,chat,asset);assertEquals(original.length,p.plainSize);assertTrue(p.cipherSize>p.plainSize);assertFalse(Arrays.equals(original,Files.readAllBytes(f.toPath())));
  ByteArrayOutputStream out=new ByteArrayOutputStream();MediaCrypto.decrypt(new FileInputStream(f),out,p.keyset,chat,asset,p.plainSize);assertArrayEquals(original,out.toByteArray());
  byte[] intact=Files.readAllBytes(f.toPath()),tampered=intact.clone();tampered[tampered.length/2]^=1;try{MediaCrypto.decrypt(new ByteArrayInputStream(tampered),new ByteArrayOutputStream(),p.keyset,chat,asset,p.plainSize);fail();}catch(Exception expected){}
  try{MediaCrypto.decrypt(new FileInputStream(f),new ByteArrayOutputStream(),p.keyset,chat,"BBBBBBBBBBBBBBBBBBBBBB",p.plainSize);fail();}catch(Exception expected){}
  try{MediaCrypto.decrypt(new ByteArrayInputStream(Arrays.copyOf(intact,intact.length-20)),new ByteArrayOutputStream(),p.keyset,chat,asset,p.plainSize);fail();}catch(Exception expected){}
  f.delete();dir.delete();
 }
}
