package grp.gs.gplus;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

/** Calls only the signature-protected provider of the separately installed GLINK. */
public final class GlinkBridge {
    private static final Uri AUTHORITY = Uri.parse("content://grp.gs.glink.identity");
    private final Context app;
    private byte[] publicKey;
    private String id;
    public GlinkBridge(Context context) { app = context.getApplicationContext(); }

    public synchronized void load() throws Exception {
        Bundle result = app.getContentResolver().call(AUTHORITY, "get_public_identity", null, null);
        if (result == null) throw new IllegalStateException("Установите актуальный GLINK");
        byte[] key = result.getByteArray("public_key");
        String value = result.getString("id");
        if (key == null || value == null || !value.equals(IdentityUtil.id(key)))
            throw new SecurityException("Не удалось проверить ID приложения GLINK");
        publicKey = key.clone(); id = value;
    }
    public synchronized byte[] publicKey() throws Exception { if (publicKey == null) load(); return publicKey.clone(); }
    public synchronized String id() throws Exception { if (id == null) load(); return id; }

    public synchronized byte[] encryptionPublic() throws Exception {
        Bundle b=app.getContentResolver().call(AUTHORITY,"get_gplus_encryption_public",null,null);
        byte[] pub=b==null?null:b.getByteArray("public_keyset");
        if(pub==null || pub.length<50 || pub.length>2048)throw new SecurityException("Нужна обновлённая версия GLINK");
        return pub;
    }
    public synchronized byte[] signDigest(byte[] digest) throws Exception {
        if(digest==null||digest.length!=32)throw new IllegalArgumentException("Invalid G+ digest");
        Bundle args=new Bundle();args.putByteArray("digest",digest);
        Bundle result=app.getContentResolver().call(AUTHORITY,"sign_gplus_digest",null,args);
        byte[] signature=result==null?null:result.getByteArray("signature");
        if(signature==null||!grp.gs.protocol.Protocol.verifySignature(publicKey(),digest,signature))
            throw new SecurityException("Подпись GLINK не прошла проверку");
        return signature;
    }
    public byte[] encrypt(byte[] publicKeyset,byte[] context,byte[] plaintext)throws Exception {
        if(publicKeyset==null||publicKeyset.length>2048||context==null||context.length>1024||plaintext==null||plaintext.length>64000)throw new IllegalArgumentException("Invalid envelope");
        com.google.crypto.tink.hybrid.HybridConfig.register();
        com.google.crypto.tink.KeysetHandle key=com.google.crypto.tink.KeysetHandle.readNoSecret(com.google.crypto.tink.BinaryKeysetReader.withBytes(publicKeyset));
        return key.getPrimitive(com.google.crypto.tink.HybridEncrypt.class).encrypt(plaintext,context);
    }
    public byte[] decrypt(byte[] context,byte[] ciphertext)throws Exception{return openEnvelope(ciphertext,context);}
    public synchronized byte[] openEnvelope(byte[] cipher,byte[] context)throws Exception {
        Bundle args=new Bundle();args.putByteArray("ciphertext",cipher);args.putByteArray("context",context);
        Bundle result=app.getContentResolver().call(AUTHORITY,"open_gplus_envelope",null,args);
        byte[] out=result==null?null:result.getByteArray("plaintext");
        if(out==null)throw new SecurityException("Не удалось расшифровать сообщение");return out;
    }
    public synchronized void setContactCard(byte[] card)throws Exception {
        Bundle args=new Bundle();args.putByteArray("card",card);
        if(app.getContentResolver().call(AUTHORITY,"set_gplus_contact_card",null,args)==null)
            throw new IllegalStateException("Не удалось подготовить NFC-контакт");
    }
    public synchronized String[] pendingContacts() {
        Bundle result=app.getContentResolver().call(AUTHORITY,"get_gplus_pending_contacts",null,null);
        String[] cards=result==null?null:result.getStringArray("cards");return cards==null?new String[0]:cards;
    }
    public synchronized void ackContact(String id) {
        Bundle args=new Bundle();args.putString("id",id);
        app.getContentResolver().call(AUTHORITY,"ack_gplus_contact",null,args);
    }

    public synchronized byte[] sign(byte[] nonce) throws Exception {
        if (nonce == null || nonce.length != 32) throw new IllegalArgumentException("Неверный запрос");
        if (publicKey == null) load();
        Bundle args = new Bundle(); args.putByteArray("nonce", nonce);
        Bundle result = app.getContentResolver().call(AUTHORITY, "sign_gplus_challenge", null, args);
        byte[] signature = result == null ? null : result.getByteArray("signature");
        if (signature == null || !IdentityUtil.verify(publicKey, nonce, signature))
            throw new SecurityException("Подтверждение GLINK не прошло");
        return signature;
    }
}
