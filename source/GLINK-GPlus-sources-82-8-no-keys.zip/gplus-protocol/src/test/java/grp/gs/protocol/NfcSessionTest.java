package grp.gs.protocol;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.security.*;
import java.security.spec.ECGenParameterSpec;
import java.util.Arrays;
import static org.junit.Assert.*;
public class NfcSessionTest {
 static class Device implements NfcSession.Host {
  final KeyPair key;final byte[] card;int accepted;boolean active;
  Device(String name)throws Exception{KeyPairGenerator g=KeyPairGenerator.getInstance("EC");g.initialize(new ECGenParameterSpec("secp256r1"));key=g.generateKeyPair();byte[] enc=new byte[100];new SecureRandom().nextBytes(enc);String id=Protocol.identityId(key.getPublic().getEncoded());Protocol.Card c=new Protocol.Card(id,name,name,"","","",key.getPublic().getEncoded(),enc,null);card=Protocol.encodeCard(new Protocol.Card(id,name,name,"","","",c.identityPublic,enc,signDigest(c.digest())));}
  public byte[] ownCard(){return card;}
  public byte[] signDigest(byte[] digest)throws Exception{Signature s=Signature.getInstance("SHA256withECDSA");s.initSign(key.getPrivate());s.update(Protocol.SIGN_DOMAIN);s.update(digest);return s.sign();}
  public void acceptCard(byte[] c)throws Exception{Protocol.decodeCard(c);accepted++;}
  public void setContactActive(boolean v){active=v;}
 }
 static int status(byte[] b){return ((b[b.length-2]&255)<<8)|(b[b.length-1]&255);}
 static byte[] data(byte[] b){return Arrays.copyOf(b,b.length-2);}
 static byte[] apdu(int ins,byte[] data){byte[] out=new byte[5+data.length];out[1]=(byte)ins;out[4]=(byte)data.length;System.arraycopy(data,0,out,5,data.length);return out;}
 static void write(NfcSession session,byte[] bytes){for(int off=0,i=0;off<bytes.length;i++){int n=Math.min(180,bytes.length-off);byte[] c=new byte[5+n];c[1]=(byte)0xda;c[2]=(byte)i;c[3]=(byte)(off+n==bytes.length?1:0);c[4]=(byte)n;System.arraycopy(bytes,off,c,5,n);assertEquals(0x9000,status(session.process(c)));assertEquals(0x9000,status(session.process(c)));off+=n;}}
 static byte[] read(NfcSession session){ByteArrayOutputStream out=new ByteArrayOutputStream();for(int i=0;i<100;i++){byte[] r=session.process(new byte[]{0,(byte)0xcb,(byte)i,0,0});assertEquals(0x9000,status(r));byte[] d=data(r);out.write(d,0,d.length);if(d.length<180)break;}return out.toByteArray();}
 @Test public void mutualProofRetryAndReplay()throws Exception{
  Device reader=new Device("alice"),hce=new Device("bobby");NfcSession s=new NfcSession(hce);
  assertEquals(0x6985,status(s.process(new byte[]{0,(byte)0xcb,0,0,0})));
  byte[] n=new byte[32];new SecureRandom().nextBytes(n);byte[] hn=data(s.process(apdu(0xd9,n)));assertEquals(32,hn.length);
  write(s,reader.card);assertTrue(hce.active);byte[] other=read(s);assertArrayEquals(hce.card,other);
  byte[] hsig=data(s.process(new byte[]{0,(byte)0xcd,0,0,0}));assertTrue(Protocol.verifySignature(hce.key.getPublic().getEncoded(),Protocol.nfcProof(reader.card,other,n,hn,"hce"),hsig));
  byte[] wrong=hce.signDigest(Protocol.nfcProof(reader.card,other,n,hn,"reader"));assertEquals(0x6982,status(s.process(apdu(0xdc,wrong))));assertEquals(0,hce.accepted);
  byte[] sig=reader.signDigest(Protocol.nfcProof(reader.card,other,n,hn,"reader"));byte[] commit=apdu(0xdc,sig);
  assertEquals(0x9000,status(s.process(commit)));assertEquals(1,hce.accepted);assertFalse(hce.active);
  assertEquals(0x9000,status(s.process(commit)));assertEquals(1,hce.accepted);
  s.reset();n[0]^=1;hn=data(s.process(apdu(0xd9,n)));write(s,reader.card);read(s);
  assertEquals(0x6982,status(s.process(commit)));assertEquals(1,hce.accepted);
 }
 @Test public void limitsAndSelfContactAreRejected()throws Exception{
  Device d=new Device("alice");NfcSession s=new NfcSession(d);assertEquals(0x6700,status(s.process(new byte[]{0,(byte)0xd9})));
  byte[] n=new byte[32];s.process(apdu(0xd9,n));byte[] c=new byte[5+180];c[1]=(byte)0xda;c[4]=(byte)180;System.arraycopy(d.card,0,c,5,180);assertEquals(0x9000,status(s.process(c)));
  s.reset();assertFalse(d.active);s.process(apdu(0xd9,n));int result=0;for(int off=0,i=0;off<d.card.length;i++){int len=Math.min(180,d.card.length-off);byte[] part=new byte[5+len];part[1]=(byte)0xda;part[2]=(byte)i;part[3]=(byte)(off+len==d.card.length?1:0);part[4]=(byte)len;System.arraycopy(d.card,off,part,5,len);result=status(s.process(part));off+=len;}assertEquals(0x6985,result);assertEquals(0,d.accepted);
 }
}
