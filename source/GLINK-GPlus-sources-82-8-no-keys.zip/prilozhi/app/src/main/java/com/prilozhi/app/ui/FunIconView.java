package com.prilozhi.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Hand-drawn icons for the prank tiles; no emoji glyphs or remote assets. */
public final class FunIconView extends View {
    private final String kind;
    private final int color;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public FunIconView(Context context, String kind, int color) {
        super(context);
        this.kind = kind;
        this.color = color;
        setContentDescription(null);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    @Override protected void onDraw(Canvas real) {
        super.onDraw(real);
        Canvas c = real;
        c.save();
        c.scale(getWidth() / 48f, getHeight() / 48f);
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawRoundRect(0, 0, 48, 48, 11, 11, p);
        p.setColor(0xFFFFFFFF);
        p.setStrokeWidth(2.5f);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStyle(Paint.Style.STROKE);
        path.reset();
        switch (kind) {
            case "ORBIT":
                c.drawOval(new RectF(7,16,41,32),p); c.drawOval(new RectF(16,7,32,41),p);
                p.setStyle(Paint.Style.FILL); c.drawCircle(24,24,3.5f,p); c.drawCircle(37,20,2.5f,p);
                break;
            case "STARS":
                p.setStyle(Paint.Style.FILL);
                path.moveTo(24,8); path.lineTo(27,19); path.lineTo(38,24); path.lineTo(27,27);
                path.lineTo(24,39); path.lineTo(21,27); path.lineTo(10,24); path.lineTo(21,19);
                path.close(); c.drawPath(path,p); c.drawCircle(36,11,2,p); c.drawCircle(11,37,2,p);
                break;
            case "WAVES":
                c.drawCircle(24,24,4,p); c.drawCircle(24,24,11,p); c.drawCircle(24,24,18,p);
                break;
            case "RAIN":
                p.setStyle(Paint.Style.FILL);
                for (int i=0; i<6; i++) c.drawCircle(13 + (i%3)*11, 16 + (i/3)*11, 3.5f, p);
                c.drawCircle(19, 38, 3, p); c.drawCircle(30, 38, 3, p);
                break;
            case "CONFETTI":
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(15,14,3,p); c.drawCircle(34,13,3,p); c.drawCircle(18,32,3,p);
                p.setStyle(Paint.Style.STROKE);
                c.drawLine(25,12,28,18,p); c.drawLine(31,29,35,34,p); c.drawLine(12,23,16,25,p);
                c.drawLine(24,26,24,33,p); c.drawLine(21,29.5f,27,29.5f,p);
                break;
            case "VIBRO":
                c.drawRoundRect(18,10,30,38,3,3,p);
                c.drawLine(12,16,12,32,p); c.drawLine(36,16,36,32,p);
                c.drawLine(8,20,8,28,p); c.drawLine(40,20,40,28,p);
                break;
            case "DISCO":
                c.drawCircle(24,23,10,p); c.drawLine(14,23,34,23,p);
                c.drawLine(24,13,24,33,p); c.drawLine(17,16,31,30,p); c.drawLine(31,16,17,30,p);
                break;
            case "QUAKE":
                path.moveTo(8,26); path.lineTo(16,26); path.lineTo(20,17); path.lineTo(25,33);
                path.lineTo(29,22); path.lineTo(33,26); path.lineTo(40,26); c.drawPath(path,p);
                break;
            case "FLIP":
                c.drawArc(new RectF(11,11,37,37),25,260,false,p);
                c.drawLine(36,13,36,20,p); c.drawLine(36,20,29,20,p);
                break;
            case "SIREN":
                c.drawRoundRect(15,21,33,35,4,4,p); c.drawLine(24,13,24,17,p);
                c.drawLine(12,14,15,17,p); c.drawLine(36,14,33,17,p); c.drawLine(12,38,36,38,p);
                break;
            case "TORCH":
                path.moveTo(16,13); path.lineTo(32,13); path.lineTo(29,23); path.lineTo(29,36);
                path.lineTo(19,36); path.lineTo(19,23); path.close(); c.drawPath(path,p);
                c.drawLine(19,18,29,18,p);
                break;
            case "PULSE":
                path.moveTo(8,25); path.lineTo(16,25); path.lineTo(20,18); path.lineTo(24,32);
                path.lineTo(28,21); path.lineTo(31,25); path.lineTo(40,25); c.drawPath(path,p);
                break;
            case "LOGO":
                c.drawRoundRect(11,11,37,37,5,5,p); c.drawCircle(19,20,2,p); c.drawCircle(29,20,2,p);
                c.drawArc(new RectF(17,20,31,32),15,150,false,p);
                break;
            default: // SALUTE
                c.drawLine(24,9,24,39,p); c.drawLine(9,24,39,24,p);
                c.drawLine(14,14,34,34,p); c.drawLine(34,14,14,34,p);
                break;
        }
        c.restore();
    }
}
