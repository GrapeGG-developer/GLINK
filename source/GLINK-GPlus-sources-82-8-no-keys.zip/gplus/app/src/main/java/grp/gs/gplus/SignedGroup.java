package grp.gs.gplus;

import grp.gs.protocol.Protocol;
import org.json.JSONArray;
import org.json.JSONObject;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/** Signed, immutable member list. Group participants are not added as NFC contacts. */
public final class SignedGroup {
    public final String id,kind,title,owner;
    public final List<Protocol.Card> members;
    private final JSONObject state;
    private SignedGroup(String id,String kind,String title,String owner,List<Protocol.Card> members,JSONObject state){this.id=id;this.kind=kind;this.title=title;this.owner=owner;this.members=java.util.Collections.unmodifiableList(members);this.state=state;}
    public JSONObject json()throws Exception{return new JSONObject(state.toString());}
    public Protocol.Card member(String id){for(Protocol.Card c:members)if(c.id.equals(id))return c;return null;}
    public boolean canPost(String user){return member(user)!=null&&(!"channel".equals(kind)||owner.equals(user));}
    public static SignedGroup create(String kind,String title,byte[] own,List<Protocol.Card> selected,GlinkBridge bridge)throws Exception{
        if(!"group".equals(kind)&&!"channel".equals(kind))throw new IllegalArgumentException("Invalid group type");
        List<byte[]> cards=new ArrayList<>();cards.add(own);for(Protocol.Card c:selected)cards.add(Protocol.encodeCard(c));
        cards.sort(Comparator.comparing(raw->{try{return Protocol.decodeCard(raw).id;}catch(Exception e){throw new IllegalArgumentException(e);}}));
        byte[] random=new byte[16];new SecureRandom().nextBytes(random);String id=("group".equals(kind)?"g_":"c_")+Protocol.b64(random),owner=bridge.id();
        String name=title==null?"":title.trim();byte[] digest=Protocol.groupDigest(id,kind,name,owner,cards),sig=bridge.signDigest(digest);
        JSONArray a=new JSONArray();for(byte[] c:cards)a.put(Protocol.b64(c));
        JSONObject state=new JSONObject().put("id",id).put("kind",kind).put("title",name).put("owner",owner).put("cards",a).put("signature",Protocol.b64(sig));
        return parse(state,owner,bridge.publicKey(),bridge.encryptionPublic());
    }
    public static SignedGroup parse(JSONObject state,String self,byte[] ownIdentity,byte[] ownEncryption)throws Exception{
        if(state==null||state.toString().length()>600000)throw new SecurityException("Invalid group state");
        String id=state.getString("id"),kind=state.getString("kind"),title=state.getString("title"),owner=state.getString("owner");JSONArray a=state.getJSONArray("cards");
        if(a.length()<2||a.length()>50)throw new SecurityException("Invalid group membership");
        List<byte[]> raw=new ArrayList<>();List<Protocol.Card> people=new ArrayList<>();Protocol.Card creator=null,me=null;
        for(int i=0;i<a.length();i++){String value=a.getString(i);byte[] bytes=Protocol.unb64(value);if(!Protocol.b64(bytes).equals(value))throw new SecurityException("Noncanonical card");Protocol.Card c=Protocol.decodeCard(bytes);raw.add(bytes);people.add(c);if(c.id.equals(owner))creator=c;if(c.id.equals(self))me=c;}
        if(creator==null||me==null||!Arrays.equals(me.identityPublic,ownIdentity)||!Arrays.equals(me.encryptionPublic,ownEncryption))throw new SecurityException("Group does not contain this device's current keys");
        byte[] digest=Protocol.groupDigest(id,kind,title,owner,raw),sig=Protocol.unb64(state.getString("signature"));
        if(!Protocol.verifySignature(creator.identityPublic,digest,sig))throw new SecurityException("Invalid group signature");
        return new SignedGroup(id,kind,title,owner,people,new JSONObject(state.toString()));
    }
}
