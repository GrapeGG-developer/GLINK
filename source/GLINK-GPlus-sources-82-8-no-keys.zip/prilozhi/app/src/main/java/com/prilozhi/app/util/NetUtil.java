package com.prilozhi.app.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class NetUtil {
    private NetUtil() {
    }

    public static List<String> localIpv4s() {
        List<String> out = new ArrayList<>();
        try {
            for (NetworkInterface nif : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!nif.isUp() || nif.isLoopback()) continue;
                for (InetAddress addr : Collections.list(nif.getInetAddresses())) {
                    if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                        String s = addr.getHostAddress();
                        if (s != null && !s.startsWith("169.254.")) out.add(s);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    public static boolean hasWifi(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(n);
            return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static String wifiSsid(Context c) {
        try {
            WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return null;
            String ssid = wm.getConnectionInfo().getSSID();
            if (ssid != null) ssid = ssid.replace("\"", "");
            if (ssid != null && (ssid.equals("<unknown ssid>") || ssid.isEmpty())) return null;
            return ssid;
        } catch (Throwable ignored) {
            return null;
        }
    }

    public static String networkLabel(Context c) {
        if (hasWifi(c)) {
            String ssid = wifiSsid(c);
            return ssid != null ? "Wi-Fi: " + ssid : "Wi-Fi подключён";
        }
        return "Wi-Fi не подключён — включите общую сеть или точку доступа";
    }
}
