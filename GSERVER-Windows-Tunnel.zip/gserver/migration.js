'use strict';
// Cold-snapshot migration for the *single* writer model. The caller MUST freeze
// requests, drain uploads, close both SQLite databases and suspend relay sweeps.
// No data is deleted: the target's previous root is retained beside it.
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const {Transform,pipeline}=require('node:stream');const {promisify}=require('node:util');const {pathToFileURL}=require('node:url');const {DatabaseSync}=require('node:sqlite');const pipe=promisify(pipeline);
const MAX_FILES=200000,MAX_MANIFEST=32*1024*1024;
const DB_SCHEMAS={
 'gplus-messages.sqlite3':{chats:['id','kind','creator','title','created'],members:['chat_id','user_id','role','joined','last_read'],group_states:['chat_id','state'],events:['seq','event_id','chat_id','sender','created','expires'],boxes:['seq','recipient','ciphertext','signature','delivered']},
 'gplus-assets.sqlite3':{assets:['id','chat','owner','size','sha','state','created'],asset_bindings:['asset_id','event_id','bound'],asset_receipts:['asset_id','recipient','received']}
};
function knownSchema(db,expected){
 const objects=db.prepare("SELECT name,type FROM sqlite_master WHERE type IN ('table','trigger','view') AND name NOT LIKE 'sqlite_%' ORDER BY name").all();
 if(objects.some(x=>x.type!=='table')||objects.map(x=>x.name).join(',')!==Object.keys(expected).sort().join(','))return false;
 if(Number(Object.values(db.prepare('PRAGMA user_version').get())[0])!==0||Number(Object.values(db.prepare('PRAGMA application_id').get())[0])!==0)return false;
 for(const [name,columns] of Object.entries(expected))if(db.prepare(`PRAGMA table_info("${name}")`).all().map(x=>x.name).join(',')!==columns.join(','))return false;
 return true;
}
function validTx(t){return typeof t==='string'&&/^[a-f0-9]{32}$/.test(t);}
function validPath(p){
 if(typeof p!=='string'||p.length>700||p.includes('\\')||p.startsWith('/')||p.endsWith('/'))return false;
 const parts=p.split('/');if(parts.length<2||!['gplus','glink'].includes(parts[0]))return false;
 return parts.every(x=>x!=='.'&&x!=='..'&&/^[A-Za-z0-9._-]{1,180}$/.test(x)&&
  !x.endsWith('.')&&!/^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(x));
}
function verifyManifest(m){
 if(!m||m.version!==1||!validTx(m.tx)||!Array.isArray(m.files)||m.files.length>MAX_FILES||!Number.isSafeInteger(m.total)||m.total<0)throw Error('invalid_manifest');
 // The source can be Linux while GDATA is NTFS: reject every spelling or
 // file/directory collision that a case-insensitive Windows filesystem merges.
 const windowsNames=new Map();let total=0,prev='';for(const e of m.files){
  if(!e||!validPath(e.path)||e.path<=prev||!Number.isSafeInteger(e.size)||e.size<0||!/^[0-9a-f]{64}$/.test(e.sha256||''))throw Error('invalid_manifest_entry');
  const parts=e.path.split('/');let prefix='';
  for(let i=0;i<parts.length;i++){
   prefix+=(i?'/':'')+parts[i];const folded=prefix.toLowerCase(),kind=i===parts.length-1?'file':'dir',prior=windowsNames.get(folded);
   if(prior&&(prior.path!==prefix||prior.kind!==kind))throw Error('invalid_manifest_collision');
   if(!prior)windowsNames.set(folded,{path:prefix,kind});
  }
  prev=e.path;total+=e.size;if(!Number.isSafeInteger(total))throw Error('invalid_manifest_size');
 }
 if(total!==m.total||Buffer.byteLength(JSON.stringify(m))>MAX_MANIFEST)throw Error('invalid_manifest_size');return m;
}
/* Build a no-write merge plan. Existing GDATA files are included rather than
   silently replaced; same-name different-content files stop the operation.
   The caller must still freeze both writers before taking the snapshots. */
function planMerge(target,source,tx,replaceEmptyTarget=()=>false){
 verifyManifest(target);verifyManifest(source);if(!validTx(tx)||typeof replaceEmptyTarget!=='function')throw Error('invalid_merge_transaction');
 const entries=new Map(),fromTarget=new Set(),fromSource=[];
 for(const e of target.files){entries.set(e.path,{path:e.path,size:e.size,sha256:e.sha256});fromTarget.add(e.path);}
 for(const e of source.files){
  const old=entries.get(e.path);
  if(old){
   if(old.size!==e.size||old.sha256!==e.sha256){
    if(!replaceEmptyTarget(old,e))throw Error('migration_file_conflict');
    entries.set(e.path,{path:e.path,size:e.size,sha256:e.sha256});fromTarget.delete(e.path);fromSource.push(e.path);
   }
  }else{entries.set(e.path,{path:e.path,size:e.size,sha256:e.sha256});fromSource.push(e.path);}
 }
 const files=[...entries.values()].sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
 let total=0;for(const e of files){total+=e.size;if(!Number.isSafeInteger(total))throw Error('invalid_manifest_size');}
 const manifest=verifyManifest({version:1,tx,total,files});
 return {manifest,fromTarget:[...fromTarget],fromSource};
}
// Only a demonstrably pristine, known-format destination file can be
// superseded without a semantic merge. In particular an empty-looking DB
// whose old sequence counter is nonzero may still have clients with cursors.
function replaceableEmptyFile(root,entry){
 if(!entry||!['gplus/accounts-v1.json','gplus/gplus-messages.sqlite3','gplus/gplus-assets.sqlite3','glink/wifi-offers-v2.json'].includes(entry.path))return false;
 const file=inside(root,entry.path);
 try{
  if(entry.path.endsWith('.json')){
   if(entry.size>16*1024*1024)return false;
   const o=JSON.parse(fs.readFileSync(file,'utf8'));if(!o||Array.isArray(o)||typeof o!=='object')return false;
   if(entry.path==='gplus/accounts-v1.json')return Object.keys(o).sort().join(',')==='accounts,version'&&o.version===1&&o.accounts&&typeof o.accounts==='object'&&!Array.isArray(o.accounts)&&Object.keys(o.accounts).length===0;
   return Object.keys(o).sort().join(',')==='offers,v'&&o.v===2&&o.offers&&typeof o.offers==='object'&&!Array.isArray(o.offers)&&Object.keys(o.offers).length===0;
  }
  const expected=DB_SCHEMAS[path.basename(entry.path)];
  const uri=pathToFileURL(file);uri.searchParams.set('immutable','1');const db=new DatabaseSync(uri,{readOnly:true});
  try{
   if(!knownSchema(db,expected))return false;
   for(const name of Object.keys(expected))if(Number(db.prepare(`SELECT count(*) AS n FROM "${name}"`).get().n)!==0)return false;
   const hasSeq=db.prepare("SELECT count(*) AS n FROM sqlite_master WHERE type='table' AND name='sqlite_sequence'").get().n;
   if(hasSeq&&Number(db.prepare('SELECT COALESCE(MAX(seq),0) AS n FROM sqlite_sequence').get().n)!==0)return false;
   return true;
  }finally{db.close();}
 }catch{return false;}
}
function isSnapshotIncluded(snapshot,prior){
 verifyManifest(snapshot);verifyManifest(prior);
 return snapshot.files.every(e=>{const p=findEntry(prior,e.path);return !!p&&p.size===e.size&&p.sha256===e.sha256;});
}
function inside(root,rel){if(!validPath(rel))throw Error('invalid_path');const p=path.resolve(root,...rel.split('/'));if(!p.startsWith(path.resolve(root)+path.sep))throw Error('invalid_path');return p;}
function findEntry(m,rel){let lo=0,hi=m.files.length-1;while(lo<=hi){const mid=(lo+hi)>>1,e=m.files[mid];if(e.path===rel)return e;if(e.path<rel)lo=mid+1;else hi=mid-1;}return null;}
async function safeParent(stage,rel){let p=stage;const root=await fsp.lstat(p);if(!root.isDirectory()||root.isSymbolicLink())throw Error('unsafe_stage');for(const part of rel.split('/').slice(0,-1)){p=path.join(p,part);try{await fsp.mkdir(p,{mode:0o700});}catch(e){if(e.code!=='EEXIST')throw e;}const st=await fsp.lstat(p);if(!st.isDirectory()||st.isSymbolicLink())throw Error('unsafe_stage');}}
async function hashFile(file){return new Promise((resolve,reject)=>{const h=crypto.createHash('sha256'),r=fs.createReadStream(file);r.on('error',reject);r.on('data',b=>h.update(b));r.on('end',()=>resolve(h.digest('hex')));});}
async function list(root,dir,prefix,out,hash=true){
 let names;try{names=await fsp.readdir(dir,{withFileTypes:true});}catch(e){if(e.code==='ENOENT')return;throw e;}
 for(const entry of names){const rel=prefix+'/'+entry.name;if(!validPath(rel))throw Error('unsafe_storage_name');const name=path.join(dir,entry.name),st=await fsp.lstat(name);
  if(st.isSymbolicLink())throw Error('storage_symlink');
  if(st.isDirectory())await list(root,name,rel,out,hash);
  else if(st.isFile()){if(!Number.isSafeInteger(st.size))throw Error('file_too_large');out.push(hash?{path:rel,size:st.size,sha256:await hashFile(name)}:{path:rel,size:st.size});if(out.length>MAX_FILES)throw Error('too_many_files');}
  else throw Error('unsafe_storage_entry');
 }
}
async function assertDedicatedRoot(root){
 if(!path.isAbsolute(root)||path.resolve(root)===path.parse(path.resolve(root)).root)throw Error('unsafe_storage_root');
 const st=await fsp.lstat(root);if(st.isSymbolicLink()||!st.isDirectory())throw Error('unsafe_storage_root');
 const top=await fsp.readdir(root,{withFileTypes:true});
 if(top.some(e=>!['gplus','glink'].includes(e.name)||!e.isDirectory()||e.isSymbolicLink()))throw Error('dedicated_storage_required');
}
async function snapshot(root,tx){
 if(!path.isAbsolute(root)||!validTx(tx))throw Error('invalid_snapshot');
 await assertDedicatedRoot(root);
 const all=[];await list(root,path.join(root,'gplus'),'gplus',all);await list(root,path.join(root,'glink'),'glink',all);all.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
 let total=0;for(const e of all)total+=e.size;return verifyManifest({version:1,tx,total,files:all});
}
function stagePath(root,tx){if(!path.isAbsolute(root)||!validTx(tx))throw Error('invalid_stage');return path.join(path.dirname(root),'.'+path.basename(root)+'-stage-'+tx);}
function manifestPath(root,tx){return stagePath(root,tx)+'.manifest.json';}
// Bind every prepared stage to the exact prior destination. A verified copy
// alone is not sufficient if GDATA changed while it was being prepared.
function targetManifestPath(root,tx){return stagePath(root,tx)+'.target-manifest.json';}
function backupPath(root,tx){return path.join(path.dirname(root),path.basename(root)+'-backup-'+tx);}
function freeBytes(dir){let s=fs.statfsSync(dir);const n=Number(s.bavail)*Number(s.bsize);if(!Number.isFinite(n)||n<0)throw Error('cannot_check_disk');return n;}
async function syncFile(file){const f=await fsp.open(file,'r+');try{await f.sync();}finally{await f.close();}}
async function syncDir(dir){try{const f=await fsp.open(dir,'r');try{await f.sync();}finally{await f.close();}}catch(e){
 // Windows may not allow opening or syncing a directory. On supported
 // platforms a real I/O error must stop the migration rather than be hidden.
 if(process.platform==='win32'&&['EPERM','EACCES','EINVAL','EISDIR','ENOTSUP'].includes(e.code))return;
 throw e;
}}
async function prepare(root,m,reserveBytes=0,expectedTarget=null){
 verifyManifest(m);if(!Number.isSafeInteger(reserveBytes)||reserveBytes<0)throw Error('invalid_reserve');
 if(expectedTarget){verifyManifest(expectedTarget);if(expectedTarget.tx!==m.tx)throw Error('target_transaction_mismatch');}
 await assertDedicatedRoot(root);
 const parent=path.dirname(root);if(!Number.isSafeInteger(m.total+reserveBytes))throw Error('invalid_reserve');
 if(freeBytes(parent)<m.total+reserveBytes)throw Error('not_enough_space');
 const stage=stagePath(root,m.tx),mp=manifestPath(root,m.tx),tp=targetManifestPath(root,m.tx),backup=backupPath(root,m.tx);
 if(fs.existsSync(stage)||fs.existsSync(mp)||fs.existsSync(tp)||fs.existsSync(backup))throw Error('transaction_exists');
 const original=await snapshot(root,m.tx);
 if(expectedTarget&&JSON.stringify(original)!==JSON.stringify(expectedTarget))throw Error('target_changed_since_plan');
 // The target must be a closed, internally consistent database tree. Do not
 // touch the target even if the preflight fails.
 await verifyTree(root,original);
 await fsp.mkdir(stage,{recursive:false,mode:0o700});
 try{
  await fsp.mkdir(path.join(stage,'gplus'));await fsp.mkdir(path.join(stage,'glink'));
  await fsp.writeFile(mp,JSON.stringify(m),{flag:'wx',mode:0o600});await syncFile(mp);
  await fsp.writeFile(tp,JSON.stringify(original),{flag:'wx',mode:0o600});await syncFile(tp);
  await syncDir(parent);await verifyTree(root,original);
 }catch(e){/* retain incomplete stage for inspection; never silently erase it */throw e;}
 return stage;
}
function loadManifestFile(file,tx){const st=fs.lstatSync(file);if(!st.isFile()||st.isSymbolicLink()||st.size>MAX_MANIFEST)throw Error('invalid_manifest_file');const m=verifyManifest(JSON.parse(fs.readFileSync(file,'utf8')));if(m.tx!==tx)throw Error('manifest_transaction_mismatch');return m;}
function loadManifest(root,tx){return loadManifestFile(manifestPath(root,tx),tx);}
function loadTargetManifest(root,tx){return loadManifestFile(targetManifestPath(root,tx),tx);}
async function receive(root,tx,rel,stream,declared){
 const m=loadManifest(root,tx),entry=findEntry(m,rel);if(!entry||declared!==entry.size)throw Error('unexpected_file');
 const stage=stagePath(root,tx),dest=inside(stage,rel),tmp=dest+'.uploading';
 await safeParent(stage,rel);
 if(fs.existsSync(dest)){const st=await fsp.stat(dest);if(st.size===entry.size&&await hashFile(dest)===entry.sha256){stream.resume();return;}throw Error('file_conflict');}
 if(fs.existsSync(tmp))throw Error('partial_upload_exists');
 let n=0;const hash=crypto.createHash('sha256');const meter=new Transform({transform(chunk,enc,cb){n+=chunk.length;if(n>entry.size)return cb(Error('file_too_large'));hash.update(chunk);cb(null,chunk);}});
 try{await pipe(stream,meter,fs.createWriteStream(tmp,{flags:'wx',mode:0o600}));if(n!==entry.size||hash.digest('hex')!==entry.sha256)throw Error('digest_mismatch');await syncFile(tmp);await fsp.rename(tmp,dest);await syncDir(path.dirname(dest));}
 catch(e){try{await fsp.unlink(tmp);}catch{}throw e;}
}
async function verifyTree(root,m){
 verifyManifest(m);await assertDedicatedRoot(root);
 // A SQLite WAL or shared-memory sidecar needs a checkpointed cold backup,
 // not an independent byte copy. Do not delete or ignore either file.
 if(m.files.some(e=>/^gplus\/gplus-(?:messages|assets)\.sqlite3-(?:wal|shm)$/.test(e.path)))throw Error('sqlite_checkpoint_required');
 for(const e of m.files){const file=inside(root,e.path),st=await fsp.lstat(file);if(!st.isFile()||st.isSymbolicLink()||st.size!==e.size||await hashFile(file)!==e.sha256)throw Error('snapshot_verification_failed');}
 // Hash each expected file once above, then independently enumerate names and
 // sizes to catch additions without rereading every large file a second time.
 const actual=[];await list(root,path.join(root,'gplus'),'gplus',actual,false);await list(root,path.join(root,'glink'),'glink',actual,false);actual.sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
 if(actual.length!==m.files.length||actual.some((e,i)=>e.path!==m.files[i].path||e.size!==m.files[i].size))throw Error('unexpected_snapshot_files');
 const account=path.join(root,'gplus','accounts-v1.json');if(fs.existsSync(account)){let a=JSON.parse(fs.readFileSync(account,'utf8'));if(a.version!==1||!a.accounts||typeof a.accounts!=='object'||Array.isArray(a.accounts))throw Error('invalid_accounts');}
 for(const dbName of ['gplus-messages.sqlite3','gplus-assets.sqlite3']){
  const file=path.join(root,'gplus',dbName);if(!fs.existsSync(file))continue;
  // Even a normal SQLite read-only connection can create -wal/-shm beside a
  // WAL-mode DB. With sidecars already rejected, immutable read-only URI mode
  // verifies the main file without modifying either original tree.
  const uri=pathToFileURL(file);uri.searchParams.set('immutable','1');
  const db=new DatabaseSync(uri,{readOnly:true});try{
   const integrity=db.prepare('PRAGMA integrity_check').get();
   if(!integrity||Object.values(integrity)[0]!=='ok'||db.prepare('PRAGMA foreign_key_check').all().length)throw Error('sqlite_integrity_failed');
   if(!knownSchema(db,DB_SCHEMAS[dbName]))throw Error('unsupported_sqlite_schema');
   if(dbName==='gplus-assets.sqlite3'){
    for(const a of db.prepare('SELECT id,size,sha,state FROM assets').all()){
     if(a.state!=='complete'||!/^[A-Za-z0-9_-]{22}$/.test(a.id)||!/^[0-9a-f]{64}$/.test(a.sha)||!Number.isSafeInteger(a.size))throw Error('invalid_asset_row');
     const entry=findEntry(m,'gplus/encrypted-assets/'+a.id+'.bin');if(!entry||entry.size!==a.size||entry.sha256!==a.sha)throw Error('asset_missing_or_damaged');
    }
   }
  }finally{db.close();}
 }
}
/* Offline staging primitive only. The caller MUST freeze and drain both stores,
   close their databases and suspend all sweeps before using it. It prepares
   and verifies a merged tree but deliberately never activates it. */
async function stageMerged(target,source,tx,reserveBytes=0){
 if(!path.isAbsolute(target)||!path.isAbsolute(source)||!validTx(tx))throw Error('invalid_merge');
 const [a,b]=await Promise.all([fsp.realpath(target),fsp.realpath(source)]);
 const contains=(parent,child)=>{const rel=path.relative(parent,child);return rel===''||(!path.isAbsolute(rel)&&rel!=='..'&&!rel.startsWith('..'+path.sep));};
 if(contains(a,b)||contains(b,a))throw Error('overlapping_storage_roots');
 const targetManifest=await snapshot(target,tx),sourceManifest=await snapshot(source,tx),plan=planMerge(targetManifest,sourceManifest,tx);
 await prepare(target,plan.manifest,reserveBytes);
 const fromTarget=new Set(plan.fromTarget);
 for(const e of plan.manifest.files){
  const root=fromTarget.has(e.path)?target:source;
  await receive(target,tx,e.path,fs.createReadStream(inside(root,e.path)),e.size);
 }
 await verifyTree(stagePath(target,tx),plan.manifest);
 // Detect additions, removals and changed files during the copy. Freezing and
 // draining remain mandatory: this check alone cannot lock other processes.
 await verifyTree(target,targetManifest);await verifyTree(source,sourceManifest);
 return {tx,manifest:plan.manifest,targetFiles:plan.fromTarget.length,sourceFiles:plan.fromSource.length,activated:false};
}
async function commit(root,tx){
 const m=loadManifest(root,tx),original=loadTargetManifest(root,tx),stage=stagePath(root,tx),backup=backupPath(root,tx);
 if(fs.existsSync(stage)){
  await verifyTree(stage,m);
  if(!fs.existsSync(backup)){
   if(!fs.existsSync(root))throw Error('target_root_missing');
   // Do not replace GDATA if any file changed since the snapshot. The owner
   // must keep writers stopped through the rename; otherwise a final TOCTOU
   // race remains outside the control of this offline primitive.
   await verifyTree(root,original);
   await fsp.rename(root,backup);await syncDir(path.dirname(root));
  }else await verifyTree(backup,original);
  if(fs.existsSync(root))throw Error('ambiguous_target_state');
  await fsp.rename(stage,root);await syncDir(path.dirname(root));
 } else {
  // A process may have stopped between the final rename and acknowledging it.
  if(!fs.existsSync(backup)||!fs.existsSync(root))throw Error('transaction_not_ready');
  await verifyTree(backup,original);await verifyTree(root,m);
 }
 return {tx,backup,files:m.files.length,total:m.total};
}
module.exports={MAX_MANIFEST,validPath,validTx,verifyManifest,planMerge,replaceableEmptyFile,isSnapshotIncluded,inside,hashFile,snapshot,prepare,receive,stageMerged,commit,verifyTree,stagePath,backupPath,loadManifest,loadTargetManifest,targetManifestPath};
