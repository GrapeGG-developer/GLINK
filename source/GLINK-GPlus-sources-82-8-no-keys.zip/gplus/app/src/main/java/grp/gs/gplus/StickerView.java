package grp.gs.gplus;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Original filled vector sticker shapes, not platform emoji. */
final class StickerView extends View {
    private final String id;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private final Path path=new Path();
    StickerView(Context c,String id){super(c);this.id=id;setContentDescription("Стикер · "+title(id));}
    static boolean known(String id){return "berry".equals(id)||"spark".equals(id)||"leaf".equals(id)||"orbit".equals(id);}
    static String title(String id){switch(id){case "berry":return "Ягода";case "spark":return "Искра";case "leaf":return "Лист";case "orbit":return "Орбита";default:return "Стикер";}}
    private void color(int c){paint.setColor(c);paint.setStyle(Paint.Style.FILL);}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);canvas.save();float scale=Math.min(getWidth(),getHeight())/100f;canvas.translate((getWidth()-100*scale)/2,(getHeight()-100*scale)/2);canvas.scale(scale,scale);
        switch(id){
            case "berry":color(0xff843bd0);canvas.drawCircle(50,57,34,paint);color(0xffae65eb);canvas.drawCircle(39,48,14,paint);color(0xff543195);canvas.drawCircle(60,65,17,paint);color(0xff43d77c);path.reset();path.moveTo(49,28);path.cubicTo(34,11,20,23,26,35);path.cubicTo(36,37,45,35,49,30);path.cubicTo(58,12,77,17,75,29);path.cubicTo(66,38,57,36,49,31);path.close();canvas.drawPath(path,paint);break;
            case "spark":color(0xffffd83d);path.reset();for(int i=0;i<10;i++){double a=-Math.PI/2+i*Math.PI/5;float r=i%2==0?42:19,x=50+(float)Math.cos(a)*r,y=50+(float)Math.sin(a)*r;if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}path.close();canvas.drawPath(path,paint);color(0xffffef9b);canvas.drawCircle(43,40,10,paint);break;
            case "leaf":color(0xff27c987);path.reset();path.moveTo(19,73);path.cubicTo(18,37,43,16,84,15);path.cubicTo(84,53,63,82,28,80);path.close();canvas.drawPath(path,paint);color(0xffa2f0cb);path.reset();path.moveTo(22,84);path.cubicTo(37,62,53,46,75,31);path.cubicTo(58,50,44,67,30,88);path.close();canvas.drawPath(path,paint);break;
            case "orbit":color(0xff55a6f0);canvas.drawCircle(50,50,30,paint);color(0xff96d0ff);canvas.drawCircle(39,41,11,paint);paint.setColor(0xff8e55d4);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(8);canvas.save();canvas.rotate(-25,50,50);canvas.drawOval(8,34,92,66,paint);canvas.restore();paint.setStyle(Paint.Style.FILL);color(0xffffd83d);canvas.drawCircle(80,29,6,paint);break;
        }canvas.restore();
    }
}
