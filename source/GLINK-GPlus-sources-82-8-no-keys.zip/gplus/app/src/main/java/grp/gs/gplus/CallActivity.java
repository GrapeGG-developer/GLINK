package grp.gs.gplus;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import grp.gs.protocol.CallCrypto;
import grp.gs.protocol.Protocol;
import java.security.KeyPair;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;
import org.json.JSONObject;

/** Experimental foreground one-to-one call. No recording occurs before permission and acceptance. */
public final class CallActivity extends Activity {
    private static final int PERMISSIONS=4921;private static final AtomicBoolean ACTIVE=new AtomicBoolean(false);
    private final Handler main=new Handler(Looper.getMainLooper());private final ExecutorService io=Executors.newSingleThreadExecutor(),decode=Executors.newSingleThreadExecutor();
    private final AtomicBoolean stopped=new AtomicBoolean(false),pollBusy=new AtomicBoolean(false),mediaStarted=new AtomicBoolean(false),decoding=new AtomicBoolean(false);
    private final Object sendLock=new Object();private GPlusStore store;private GlinkBridge bridge;private GPlusApi api;private ChatEngine engine;private Protocol.Card peer;
    private String offerId="",chat="",self="";private volatile String call="";private boolean outgoing,video,permissionPending,ownsActive;private volatile boolean muted,inForeground;private long lastSeq,startedAt;private volatile KeyPair ephemeral;private volatile CallCrypto.Session crypto;private volatile WebSocket socket;private OkHttpClient http;private volatile CallAudio audio;private volatile CallVideo camera;private AudioManager audioManager;private int oldMode;private boolean oldSpeaker;
    private TextView status;private ImageView remoteVideo;private Button hangup,mute;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);if(!ACTIVE.compareAndSet(false,true)){finish();return;}ownsActive=true;getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        store=new GPlusStore(this);bridge=new GlinkBridge(this);api=new GPlusApi(BuildConfig.GPLUS_API_BASE,bridge);engine=new ChatEngine(bridge,api,store);
        outgoing=getIntent().getBooleanExtra("outgoing",false);video=getIntent().getBooleanExtra("video",false);offerId=getIntent().getStringExtra("offer_id");if(offerId==null)offerId="";
        try{peer=store.contact(getIntent().getStringExtra("peer_id"));if(peer==null)throw new SecurityException("Контакт не найден");}catch(Exception e){finish();return;}
        ui();permissionPending=true;if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED&&(!video||checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)){permissionPending=false;begin();}else requestPermissions(video?new String[]{Manifest.permission.RECORD_AUDIO,Manifest.permission.CAMERA}:new String[]{Manifest.permission.RECORD_AUDIO},PERMISSIONS);
    }
    private void ui(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,36,24,36);root.setBackgroundColor(0xff0a1423);root.setGravity(Gravity.CENTER_HORIZONTAL);setContentView(root);
        TextView title=new TextView(this);title.setText(peer.display);title.setTextColor(Color.WHITE);title.setTextSize(24);title.setGravity(Gravity.CENTER);root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        status=new TextView(this);status.setText(outgoing?"Подготовка звонка…":"Подключаем звонок…");status.setTextColor(0xffb7c6db);status.setTextSize(16);status.setGravity(Gravity.CENTER);root.addView(status,new LinearLayout.LayoutParams(-1,60));
        remoteVideo=new ImageView(this);remoteVideo.setScaleType(ImageView.ScaleType.FIT_CENTER);remoteVideo.setBackgroundColor(0xff132238);root.addView(remoteVideo,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.CENTER);mute=new Button(this);mute.setText("Выключить микрофон");mute.setOnClickListener(v->{muted=!muted;mute.setText(muted?"Включить микрофон":"Выключить микрофон");});buttons.addView(mute);hangup=new Button(this);hangup.setText("Завершить");hangup.setOnClickListener(v->{stop(true,"Звонок завершён");finish();});buttons.addView(hangup);root.addView(buttons);
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request!=PERMISSIONS)return;permissionPending=false;boolean allowed=results.length>0&&results.length==permissions.length;for(int x:results)allowed&=x==PackageManager.PERMISSION_GRANTED;if(allowed)begin();else{if(!outgoing)declineWithoutMedia();stop(false,"Для звонка нужны разрешения");}}
    private void declineWithoutMedia(){io.execute(()->{try{api.login(getSharedPreferences("gplus_settings",MODE_PRIVATE).getString("nickname",""));for(ChatEngine.Message m:engine.messages(peer))if(m.id.equals(offerId)){CallSignal.Offer offer=CallSignal.parseOffer(m,peer.id,System.currentTimeMillis());if(offer!=null){engine.queueCallSignal(peer,CallSignal.end(offer.call));engine.sync(peer,false);}break;}}catch(Exception ignored){}});}
    private void begin(){startedAt=System.currentTimeMillis();io.execute(()->{try{
        String nick=getSharedPreferences("gplus_settings",MODE_PRIVATE).getString("nickname","");api.login(nick);if(stopped.get())return;self=bridge.id();chat=Protocol.directChat(self,peer.id);engine.sync(peer,false);if(stopped.get())return;ephemeral=CallCrypto.ephemeral();
        synchronized(sendLock){if(stopped.get())return;if(outgoing){call=CallSignal.newId();engine.queueCallSignal(peer,CallSignal.offer(call,ephemeral,video));}else{List<ChatEngine.Message> history=engine.messages(peer);ChatEngine.Message offer=null;for(ChatEngine.Message m:history)if(m.id.equals(offerId)){offer=m;break;}CallSignal.Offer valid=CallSignal.parseOffer(offer,peer.id,System.currentTimeMillis());if(valid==null||valid.video!=video)throw new SecurityException("Звонок устарел");for(ChatEngine.Message m:history)if(CallSignal.isEnd(m,peer.id,valid.call,System.currentTimeMillis()))throw new SecurityException("Звонок уже завершён");call=valid.call;crypto=CallCrypto.derive(ephemeral,valid.key,false,chat,call,peer.id,self);engine.queueCallSignal(peer,CallSignal.answer(call,ephemeral));}}
        engine.sync(peer,false);if(outgoing)show("Ожидаем ответа…");else{ephemeral=null;connect();}if(!stopped.get())main.post(poll);
    }catch(Exception e){failure("Не удалось начать звонок");}});}
    private final Runnable poll=new Runnable(){@Override public void run(){if(stopped.get())return;if(System.currentTimeMillis()-startedAt>120_000&&!mediaStarted.get()){stop(true,"Нет ответа или соединения");return;}if(pollBusy.compareAndSet(false,true))io.execute(()->{try{
        try{engine.sync(peer,false);}catch(GPlusApi.ApiException e){if(e.status!=401)throw e;api.login(getSharedPreferences("gplus_settings",MODE_PRIVATE).getString("nickname",""));engine.sync(peer,false);}
        List<ChatEngine.Message> messages=engine.messagesAfter(peer,lastSeq);for(ChatEngine.Message m:messages){lastSeq=Math.max(lastSeq,m.seq);if(CallSignal.isEnd(m,peer.id,call,System.currentTimeMillis())){main.post(()->stop(false,"Собеседник завершил звонок"));break;}if(outgoing&&crypto==null){byte[] key=CallSignal.parseAnswer(m,peer.id,call,System.currentTimeMillis());if(key!=null){synchronized(sendLock){if(stopped.get())return;crypto=CallCrypto.derive(ephemeral,key,true,chat,call,self,peer.id);ephemeral=null;}connect();}}}
    }catch(Exception e){if(!stopped.get())failure("Связь с сервером потеряна");}finally{pollBusy.set(false);}});main.postDelayed(this,2000);}};
    private void connect()throws Exception{
        synchronized(sendLock){if(stopped.get())return;String url=api.callUrl(chat,call),token=api.callToken();http=new OkHttpClient.Builder().readTimeout(0,TimeUnit.MILLISECONDS).pingInterval(25,TimeUnit.SECONDS).build();
        Request request=new Request.Builder().url(url).header("Authorization","Bearer "+token).build();socket=http.newWebSocket(request,new WebSocketListener(){
            @Override public void onOpen(WebSocket ws,Response response){show("Ожидаем соединения…");}
            @Override public void onMessage(WebSocket ws,String text){try{String type=new JSONObject(text).optString("type");if("peer_joined".equals(type))startMedia();else if("peer_left".equals(type))main.post(()->stop(false,"Собеседник отключился"));}catch(Exception ignored){}}
            @Override public void onMessage(WebSocket ws,ByteString bytes){try{CallCrypto.Session session=crypto;if(session==null||stopped.get())return;CallCrypto.Packet frame=session.open(bytes.toByteArray());if(frame.kind==CallCrypto.AUDIO&&audio!=null)audio.receive(frame.payload);else if(frame.kind==CallCrypto.VIDEO&&video)receiveVideo(frame.payload);}catch(Exception ignored){}}
            @Override public void onFailure(WebSocket ws,Throwable error,Response response){if(!stopped.get())failure("Не удалось соединиться для звонка");}
            @Override public void onClosed(WebSocket ws,int code,String reason){if(!stopped.get())failure("Соединение звонка закрыто");}
        });}
    }
    private void startMedia(){if(stopped.get())return;if(!inForeground){main.postDelayed(this::startMedia,200);return;}if(!mediaStarted.compareAndSet(false,true))return;io.execute(()->{try{
        synchronized(sendLock){if(stopped.get())return;audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);oldMode=audioManager.getMode();oldSpeaker=audioManager.isSpeakerphoneOn();audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);audioManager.setSpeakerphoneOn(video);
        audio=new CallAudio(new CallAudio.Sink(){public void send(byte[] pcm){if(!muted)sendFrame(CallCrypto.AUDIO,pcm);}public void failed(){failure("Ошибка микрофона или звука");}});audio.start();
        if(video){camera=new CallVideo(this,new CallVideo.Sink(){public void send(byte[] jpeg,int rotation){byte[] data=new byte[jpeg.length+1];data[0]=(byte)(rotation/90);System.arraycopy(jpeg,0,data,1,jpeg.length);sendFrame(CallCrypto.VIDEO,data);}public void failed(){failure("Ошибка камеры");}},getWindowManager().getDefaultDisplay().getRotation());camera.start();}
        show(video?"Видеозвонок · подключено":"Аудиозвонок · подключено");}
    }catch(Exception e){failure("Не удалось включить звук или камеру");}});}
    private void sendFrame(int kind,byte[] data){synchronized(sendLock){try{WebSocket ws=socket;CallCrypto.Session c=crypto;if(stopped.get()||ws==null||c==null||ws.queueSize()>256*1024)return;byte[] frame=c.seal(kind,SystemClock.elapsedRealtime(),data);if(!ws.send(ByteString.of(frame)))failure("Не удалось отправить звук или видео");}catch(Exception e){if(!stopped.get())failure("Ошибка шифрования звонка");}}}
    private void receiveVideo(byte[] data){if(data.length<2||data[0]<0||data[0]>3||!decoding.compareAndSet(false,true))return;byte[] jpeg=Arrays.copyOfRange(data,1,data.length);int rotation=data[0]*90;decode.execute(()->{try{BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(jpeg,0,jpeg.length,bounds);if(bounds.outWidth<1||bounds.outHeight<1||bounds.outWidth>1280||bounds.outHeight>1280)return;Bitmap b=BitmapFactory.decodeByteArray(jpeg,0,jpeg.length);if(b==null)return;if(rotation!=0){Matrix m=new Matrix();m.postRotate(rotation);b=Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);}Bitmap result=b;main.post(()->{if(!stopped.get())remoteVideo.setImageBitmap(result);});}catch(Exception ignored){}finally{decoding.set(false);}});}
    private void show(String s){main.post(()->{if(!stopped.get()&&status!=null)status.setText(s);});}
    private void failure(String s){main.post(()->stop(true,s));}
    private void stop(boolean sendEnd,String reason){
        if(!stopped.compareAndSet(false,true))return;main.removeCallbacks(poll);if(status!=null)status.setText(reason);if(mute!=null)mute.setEnabled(false);if(hangup!=null)hangup.setText("Закрыть");
        synchronized(sendLock){if(audio!=null)audio.close();if(camera!=null)camera.close();if(crypto!=null){crypto.close();crypto=null;}if(socket!=null){socket.close(1000,"done");socket=null;}if(audioManager!=null){try{audioManager.setSpeakerphoneOn(oldSpeaker);audioManager.setMode(oldMode);}catch(Exception ignored){}}}
        ephemeral=null;if(sendEnd&&!call.isEmpty())io.execute(()->{try{engine.queueCallSignal(peer,CallSignal.end(call));engine.sync(peer,false);}catch(Exception ignored){}});if(http!=null){http.dispatcher().executorService().shutdown();http.connectionPool().evictAll();}ACTIVE.set(false);
    }
    @Override protected void onResume(){super.onResume();inForeground=true;}
    @Override protected void onPause(){inForeground=false;super.onPause();if(ownsActive&&!permissionPending&&!isChangingConfigurations()&&!stopped.get())stop(true,"Звонок завершён: приложение свернуто");}
    @Override protected void onDestroy(){if(ownsActive)stop(true,"Звонок завершён");if(store!=null)io.execute(()->store.close());io.shutdown();decode.shutdownNow();super.onDestroy();}
}
