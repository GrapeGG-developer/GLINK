package grp.gs.gplus;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import java.io.File;
import java.util.function.Consumer;

/** Explicit microphone recording; temporary plaintext is removed after encryption or cancel. */
final class VoiceUi {
    private static final int REQUEST=4873;
    private final Activity activity;private final Consumer<File> ready;private final Handler main=new Handler(Looper.getMainLooper());
    private MediaRecorder recorder;private File recording;private AlertDialog dialog;private Runnable limit;
    VoiceUi(Activity a,Consumer<File> callback){activity=a;ready=callback;}
    void request(){if(activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){activity.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQUEST);return;}start();}
    void permissionResult(int code,int[] results){if(code!=REQUEST)return;if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)start();else Toast.makeText(activity,"Для записи нужен доступ к микрофону",Toast.LENGTH_LONG).show();}
    private void start(){if(recorder!=null||activity.isFinishing()||activity.isDestroyed())return;try{recording=File.createTempFile("gplus-voice-record-",".m4a",activity.getCacheDir());recorder=new MediaRecorder();recorder.setAudioSource(MediaRecorder.AudioSource.MIC);recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);recorder.setAudioSamplingRate(44100);recorder.setAudioEncodingBitRate(96000);recorder.setOutputFile(recording.getAbsolutePath());recorder.prepare();recorder.start();dialog=new AlertDialog.Builder(activity).setTitle("Запись голосового").setMessage("Запись с микрофона. До двух минут.").setNegativeButton("Отмена",(d,w)->finish(false)).setPositiveButton("Отправить",(d,w)->finish(true)).setOnCancelListener(d->finish(false)).create();dialog.show();limit=()->{if(recorder!=null){if(dialog!=null)dialog.dismiss();finish(true);}};main.postDelayed(limit,120000);}catch(Exception e){finish(false);Toast.makeText(activity,"Не удалось начать запись",Toast.LENGTH_LONG).show();}}
    void cancel(){if(dialog!=null){dialog.dismiss();dialog=null;}finish(false);}
    private void finish(boolean send){if(limit!=null){main.removeCallbacks(limit);limit=null;}MediaRecorder r=recorder;recorder=null;File file=recording;recording=null;dialog=null;if(r==null){if(file!=null)file.delete();return;}boolean stopped=false;try{r.stop();stopped=true;}catch(Exception ignored){}try{r.reset();r.release();}catch(Exception ignored){}if(send&&stopped&&file!=null&&file.isFile()&&file.length()>0){try{ready.accept(file);}catch(Exception e){file.delete();}}else if(file!=null)file.delete();}
    static void clearStale(Activity a){File[] files=a.getCacheDir().listFiles((dir,name)->name.startsWith("gplus-voice-record-")||name.startsWith("gplus-voice-play-"));if(files!=null)for(File f:files)if(System.currentTimeMillis()-f.lastModified()>3600000L)f.delete();}
}
