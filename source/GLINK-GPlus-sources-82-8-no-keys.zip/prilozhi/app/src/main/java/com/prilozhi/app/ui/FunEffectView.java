package com.prilozhi.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

/** Short, gentle vector effects drawn locally when a friend sends a prank. */
public final class FunEffectView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private String kind = "";
    private long started;
    private Runnable onFinished;
    private static final long DURATION = 3600;

    public FunEffectView(Context c, AttributeSet a) { super(c, a); }

    public void play(String kind, Runnable onFinished) {
        this.kind = kind;
        this.onFinished = onFinished;
        started = SystemClock.uptimeMillis();
        setVisibility(VISIBLE);
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        long elapsed = SystemClock.uptimeMillis() - started;
        if (elapsed >= DURATION) {
            setVisibility(GONE);
            Runnable finish = onFinished;
            onFinished = null;
            if (finish != null) post(finish);
            return;
        }
        float t = elapsed / 1000f;
        float w = getWidth(), h = getHeight();
        float density = getResources().getDisplayMetrics().density;
        c.drawColor(0xE90A0715);
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(null);
        if ("DISCO".equals(kind)) {
            int[] colors = {0xAA8B5CF6, 0xAA22E39A, 0xAAE975C3};
            for (int i = 0; i < 3; i++) {
                float x = w * (.22f + i * .28f) + (float) Math.sin(t * .8f + i) * w * .12f;
                float y = h * (.35f + .17f * i) + (float) Math.cos(t * .7f + i * 2) * h * .12f;
                float radius = Math.max(w, h) * .42f;
                paint.setShader(new RadialGradient(x, y, radius, colors[i], 0x00000000, Shader.TileMode.CLAMP));
                c.drawCircle(x, y, radius, paint);
            }
            paint.setShader(null);
        } else if ("RAIN".equals(kind)) {
            for (int i = 0; i < 23; i++) {
                float x = ((i * 73 + 29) % 101) / 101f * w;
                float speed = 80f + (i % 5) * 18f;
                float y = (t * speed * density + i * 83f * density) % (h + 50f * density) - 25f * density;
                float r = (2.5f + i % 3) * density;
                paint.setColor(i % 2 == 0 ? 0xFFB378FF : 0xFF8344D7);
                c.drawCircle(x - r, y, r, paint); c.drawCircle(x + r, y, r, paint);
                c.drawCircle(x, y + r * 1.6f, r, paint);
                paint.setColor(0xFF48DD85);
                c.drawRoundRect(x - r * .25f, y - r * 2.3f, x + r * .35f, y - r * .7f,
                        r * .3f, r * .3f, paint);
            }
        } else if ("ORBIT".equals(kind)) {
            float cx=w*.5f, cy=h*.5f, r=Math.min(w,h)*.25f;
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2*density); paint.setColor(0x668D6BDB);
            c.drawCircle(cx,cy,r,paint); c.drawCircle(cx,cy,r*.57f,paint);
            paint.setStyle(Paint.Style.FILL);
            int[] colors={0xFF9C70F1,0xFF32D993,0xFF9ACBFF};
            for(int i=0;i<3;i++){
                double a=t*.8+i*Math.PI*2/3;
                float x=cx+(float)Math.cos(a)*r, y=cy+(float)Math.sin(a)*r;
                paint.setColor(colors[i]);c.drawCircle(x,y,(7+i*2)*density,paint);
            }
            paint.setColor(0xFFDAD0FF);c.drawCircle(cx,cy,8*density,paint);
        } else if ("STARS".equals(kind)) {
            int[] colors={0xFFE1D4FF,0xFFA4EACE,0xFFC6DFFF};
            for(int i=0;i<35;i++){
                float phase=(t*.21f+(i%11)/11f)%1f;
                float dx=((i*73%101)-50)/50f,dy=((i*47%97)-48)/48f;
                float x=w*.5f+dx*w*.6f*phase,y=h*.5f+dy*h*.6f*phase;
                float r=(1.5f+phase*3.5f)*density;
                paint.setColor(colors[i%3]);c.drawCircle(x,y,r,paint);
                if(i%5==0){c.drawRect(x-r*.28f,y-r*2,x+r*.28f,y+r*2,paint);c.drawRect(x-r*2,y-r*.28f,x+r*2,y+r*.28f,paint);}
            }
        } else if ("WAVES".equals(kind)) {
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3*density);
            for(int i=0;i<5;i++){
                float phase=(t*.22f+i/5f)%1f;
                int alpha=Math.round((1-phase)*150);
                paint.setColor((alpha<<24)|0x00A978F2);
                c.drawCircle(w*.5f,h*.5f,phase*Math.max(w,h)*.62f,paint);
            }
            paint.setStyle(Paint.Style.FILL);
        } else { // CONFETTI
            int[] colors = {0xFF8B5CF6, 0xFF22E39A, 0xFFFFC46B, 0xFFF472B6, 0xFF77B7FF};
            for (int i = 0; i < 48; i++) {
                float x = ((i * 61 + 17) % 101) / 101f * w + (float) Math.sin(t * 1.5f + i) * 10 * density;
                float y = (t * (45f + i % 7 * 12f) * density + i * 51f * density) % (h + 30f * density) - 15f * density;
                paint.setColor(colors[i % colors.length]);
                c.save(); c.rotate((t * 80 + i * 39) % 360, x, y);
                c.drawRoundRect(x - 2 * density, y - 5 * density, x + 2 * density, y + 5 * density,
                        density, density, paint);
                c.restore();
            }
        }
        postInvalidateOnAnimation();
    }
}
