package com.prilozhi.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.prilozhi.app.util.Haptics;
import com.prilozhi.app.util.State;

import java.util.ArrayList;
import java.util.List;

/**
 * Островок-кружок сверху справа. ВСЕ иконки рисуются вектором (без эмодзи):
 * фирменная пара стрелок обмена, кольцо процентов, галочка, свои глифы категорий.
 * Обводка — вращающийся переливающийся SweepGradient.
 * Раскрытие — ТОЛЬКО по вертикали (ширина не меняется), пружина быстрая.
 * В приложении (expandable=false) островок только «живой» по тапу;
 * в оверлее раскрывается в выбор контента.
 */
public class IslandView extends View implements State.Listener {

    public interface OnPickListener {
        void onPick(String pick);
    }

    private static final String[] PICKS = {
            "media", "music", "files", "folder", "apps",
            "camera", "text", "contact", "geo", "__wifi", "__close"};

    private float lastAutoPulse = 0;
    private final float[] speedHist = new float[14];
    private int graphPos = 0;
    private float lastGraphAt = 0;
    private float density = 1f, scaledDensity = 1f;
    private float topInset = 0;
    private boolean expandable = true;

    private float hCur; // pixels; initialised using density in init()
    private boolean expanded = false;
    private float pulseT = -1;
    private float t = 0;
    private long lastNs = 0;
    private boolean animRunning = false;
    private boolean windowVisible = true;
    private State.Mode lastMode = State.Mode.IDLE;

    private final Paint bodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glyphPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringFg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pctPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint itemBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private final List<RectF> itemRects = new ArrayList<>();
    private final RectF closeRect = new RectF();
    private final Matrix rimMatrix = new Matrix();

    private OnPickListener pickListener;

    public IslandView(Context c) {
        super(c);
        init();
    }

    public IslandView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        density = getResources().getDisplayMetrics().density;
        scaledDensity = getResources().getDisplayMetrics().scaledDensity;
        hCur = IslandGeometry.targetHeightPx(false, density);
        pctPaint.setTextAlign(Paint.Align.CENTER);
        pctPaint.setColor(0xFFFFFFFF);
        pctPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        rimPaint.setStyle(Paint.Style.STROKE);
        glyphPaint.setStyle(Paint.Style.STROKE);
        glyphPaint.setStrokeCap(Paint.Cap.ROUND);
        glyphPaint.setStrokeJoin(Paint.Join.ROUND);
        ringBg.setStyle(Paint.Style.STROKE);
        ringFg.setStyle(Paint.Style.STROKE);
        ringFg.setStrokeCap(Paint.Cap.ROUND);
        setClickable(true);
    }

    private float dp(float v) {
        return v * density;
    }

    private float sp(float v) {
        return v * scaledDensity;
    }

    public void setTopInset(int px) {
        topInset = px;
    }

    public void setCutoutCenter(float cxPx) {
    }

    public void setCutoutCenterY(float cyPx) {
    }

    public void setOnPickListener(OnPickListener l) {
        pickListener = l;
    }

    public void setExpandable(boolean e) {
        expandable = e;
        if (!e) expanded = false;
    }

    public void pulse() {
        pulseT = 0;
        startFrame();
    }

    public void collapse() {
        if (expanded) {
            expanded = false;
            startFrame();
        }
    }

    @Override
    public void onStateChanged(State state) {
        if (state.mode != lastMode) {
            if (state.mode == State.Mode.SUCCESS) Haptics.success(getContext());
            if (state.mode == State.Mode.ERROR) Haptics.error(getContext());
            if (state.mode == State.Mode.TRANSFER || state.mode == State.Mode.TAP) expanded = false;
            lastMode = state.mode;
        }
        startFrame();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        State.get().addListener(this);
        lastNs = 0;
        startFrame();
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(frame);
        animRunning = false;
        lastNs = 0;
        State.get().removeListener(this);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        windowVisible = visibility == VISIBLE;
        if (windowVisible) startFrame();
        else {
            removeCallbacks(frame);
            animRunning = false;
            lastNs = 0;
        }
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (visibility == VISIBLE) startFrame();
    }

    private final Runnable frame = new Runnable() {
        @Override
        public void run() {
            if (!windowVisible || !isShown()) {
                animRunning = false;
                lastNs = 0;
                return;
            }
            step();
            invalidate();
            // УМНАЯ НАГРУЗКА: покой = 30 fps, анимация/передача = полные 60 fps
            boolean busy = IslandGeometry.animating(hCur, expanded, density) || pulseT >= 0
                    || State.get().mode == State.Mode.TRANSFER
                    || State.get().mode == State.Mode.CONNECTING
                    || State.get().mode == State.Mode.TAP;
            if (busy) postOnAnimation(this);
            else postOnAnimationDelayed(this, 33);
        }
    };

    private void startFrame() {
        if (!animRunning && windowVisible && isAttachedToWindow() && isShown()) {
            animRunning = true;
            lastNs = 0;
            postOnAnimation(frame);
        }
    }

    private void step() {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        t += dt;
        if (pulseT >= 0) {
            pulseT += dt;
            if (pulseT > 0.35f) pulseT = -1;
        }
        // живость: в готовности островок сам мягко пульсирует раз в ~5 с
        State stA = State.get();
        if (pulseT < 0 && (stA.mode == State.Mode.READY_SEND || stA.mode == State.Mode.READY_RECV)
                && t - lastAutoPulse > 5f) {
            pulseT = 0;
            lastAutoPulse = t;
        }
        // Height and width use the SAME density conversion. Smooth in both directions,
        // with no spring overshoot, abrupt snap or dependence on display refresh rate.
        hCur = IslandGeometry.nextHeightPx(hCur, expanded, density, dt);
    }

    private float right() {
        return getWidth() - dp(18);
    }

    private float top() {
        return topInset + dp(22);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        State st = State.get();
        final float w = IslandGeometry.widthPx(density);
        final float h = hCur;
        final float right = right(), top = top();
        final float left = right - w;
        final float cx = (left + right) / 2f, cyTop = top + w / 2f;
        rect.set(left, top, right, top + h);
        // At rest h == w exactly. During expansion morph continuously into a rounded pill.
        float expansion = clamp01((h - w) / dp(40));
        float rad = w / 2f - dp(5) * expansion;
        boolean panelVisible = h > dp(120);

        // ЖИВАЯ ПОДЛОЖКА под островком: мягкое свечение дышит по циклу (фиолет <-> зелень)
        float breath = 0.5f + 0.5f * (float) Math.sin(t * 1.15f);
        int underCol = blend(0xFF8B5CF6, 0xFF22E39A, breath);
        for (int li = 3; li >= 1; li--) {
            float grow = dp(3f) * li + dp(2.5f) * breath;
            glowPaint.setColor(underCol);
            glowPaint.setAlpha((int) (16 + 10 * breath) / li);
            canvas.drawRoundRect(new RectF(left - grow, top - grow + dp(2),
                    right + grow, top + h + grow + dp(2)), rad + grow, rad + grow, glowPaint);
        }
        glowPaint.setAlpha(255);
        // пульс: два мягких кольца расходятся друг за другом и тают
        if (pulseT >= 0) {
            for (int ring = 0; ring < 2; ring++) {
                float pp = Math.min(1f, Math.max(0f, pulseT / 0.35f - ring * 0.18f));
                if (pp <= 0f) continue;
                float ease = 1f - (1f - pp) * (1f - pp);
                glowPaint.setColor(ring == 0 ? 0xFF22E39A : 0xFF8B5CF6);
                glowPaint.setAlpha((int) (80 * (1f - pp)));
                float grow = dp(4) + dp(20) * ease;
                canvas.drawRoundRect(new RectF(left - grow, top - grow, right + grow, top + h + grow),
                        rad + grow, rad + grow, glowPaint);
            }
            glowPaint.setAlpha(255);
        }

        float hueShift = 0.5f + 0.5f * (float) Math.sin(t * 0.7f);
        int topCol = blend(0xFF3B1E6E, 0xFF123F2A, hueShift * 0.35f);
        int botCol = blend(0xFF123F2A, 0xFF3B1E6E, hueShift * 0.35f);
        bodyPaint.setShader(new LinearGradient(left, top, right, top + h,
                new int[]{topCol, 0xE61A0F38, botCol}, null, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, rad, rad, bodyPaint);
        bodyPaint.setShader(null);

        // обводка: у круга — медленное вращение; у раскрытого тела — ровный градиент без кручения
        if (panelVisible) {
            rimPaint.setShader(new LinearGradient(left, top, right, top + h,
                    new int[]{0xFF8B5CF6, 0xFF22E39A, 0xFFB388FF}, null, Shader.TileMode.CLAMP));
        } else {
            SweepGradient rimGrad = new SweepGradient(cx, cyTop,
                    new int[]{0xFF8B5CF6, 0xFF22E39A, 0xFFB388FF, 0xFF0FA968, 0xFF8B5CF6}, null);
            rimMatrix.reset();
            rimMatrix.postRotate((t * 14f) % 360f, cx, cyTop);
            rimGrad.setLocalMatrix(rimMatrix);
            rimPaint.setShader(rimGrad);
        }
        rimPaint.setStrokeWidth(dp(1.8f));
        canvas.drawRoundRect(new RectF(left + dp(0.9f), top + dp(0.9f), right - dp(0.9f), top + h - dp(0.9f)),
                rad, rad, rimPaint);
        rimPaint.setShader(null);
        if (!panelVisible) drawTechRing(canvas, cx, cyTop, w / 2f, st);

        // стеклянный верхний блик
        int save2 = canvas.save();
        android.graphics.Path clip = new android.graphics.Path();
        clip.addRoundRect(rect, rad, rad, android.graphics.Path.Direction.CW);
        canvas.clipPath(clip);
        Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
        sheen.setShader(new LinearGradient(left, top, left, top + h * 0.55f,
                new int[]{0x3AFFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        canvas.drawRect(left, top, right, top + h * 0.55f, sheen);
        // GRRLG realtime: жидкий световой шар медленно плавает внутри стекла
        Paint blob = new Paint(Paint.ANTI_ALIAS_FLAG);
        float bx2 = (left + right) / 2f + (float) Math.sin(t * 0.45f) * w * 0.22f;
        float by2 = top + h * 0.30f + (float) Math.cos(t * 0.33f) * h * 0.10f;
        blob.setShader(new android.graphics.RadialGradient(bx2, by2, dp(46),
                new int[]{0x2BFFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        canvas.drawCircle(bx2, by2, dp(46), blob);
        // айдл-шиммер: раз в ~4.5 c по островку проходит световая волна
        if (!expanded) {
            float ph = t % 4.5f;
            if (ph < 0.9f) {
                float sx = left - dp(24) + (w + dp(48)) * (ph / 0.9f);
                Paint shim = new Paint(Paint.ANTI_ALIAS_FLAG);
                shim.setShader(new LinearGradient(sx - dp(14), top, sx + dp(14), top,
                        new int[]{0x00FFFFFF, 0x2EFFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
                canvas.drawRect(left, top, right, top + h, shim);
            }
        }
        canvas.restoreToCount(save2);

        if (panelVisible) {
            // иконки строго внутри тела островка, не вылезают за фон
            int saveClip = canvas.save();
            canvas.clipRect(left, top, right, top + h);
            drawExpanded(canvas, left, top, right);
            canvas.restoreToCount(saveClip);
        } else {
            // живое дыхание: кружок чуть дышит, когда готов принимать/отправлять
            if (st.mode == State.Mode.READY_RECV || st.mode == State.Mode.READY_SEND) {
                float br = 1f + 0.03f * (float) Math.sin(t * 1.7f);
                canvas.save();
                canvas.scale(br, br, cx, cyTop);
                drawCollapsed(canvas, cx, cyTop, st);
                canvas.restore();
                // подпись: сразу понятно, что телефон готов
                Paint lp2 = new Paint(Paint.ANTI_ALIAS_FLAG);
                lp2.setTextAlign(Paint.Align.CENTER);
                lp2.setTextSize(sp(8.5f));
                lp2.setColor(st.mode == State.Mode.READY_SEND ? 0xFF22E39A : 0xFFB388FF);
                canvas.drawText(st.mode == State.Mode.READY_SEND
                                ? "ГОТОВ К ОТПРАВКЕ" : "ГОТОВ К ПРИЁМУ",
                        cx, cyTop + dp(46), lp2);
                if (st.mode == State.Mode.READY_SEND && st.peerProgress >= 0f) {
                    lp2.setTextSize(sp(8f));
                    lp2.setColor(0xFFB9F6DF);
                    canvas.drawText("друг скачал: "
                                    + Math.round(clamp01(st.peerProgress) * 100) + "%",
                            cx, cyTop + dp(58), lp2);
                }
            } else {
                drawCollapsed(canvas, cx, cyTop, st);
            }
            // РАДАР СБЛИЖЕНИЯ: волны внутри круга; телефон рядом — быстрее, ярче, с точкой касания
            if (!expanded && (st.mode == State.Mode.READY_RECV || st.mode == State.Mode.READY_SEND
                    || st.mode == State.Mode.CONNECTING || st.mode == State.Mode.TAP)) {
                boolean near = System.currentTimeMillis() - st.nfcNearAt < 2500;
                float speed = near ? 1.5f : 0.45f;
                Paint rp = new Paint(Paint.ANTI_ALIAS_FLAG);
                rp.setStyle(Paint.Style.STROKE);
                rp.setStrokeWidth(dp(1.6f));
                for (int ri = 0; ri < 3; ri++) {
                    float ph = (t * speed + ri / 3f) % 1f;
                    float rr = dp(5) + ph * dp(21);
                    rp.setColor(near ? 0xFF22E39A : 0xFF8B5CF6);
                    rp.setAlpha((int) ((1f - ph) * (near ? 190 : 70)));
                    canvas.drawCircle(cx, cyTop, rr, rp);
                }
                if (near) {
                    rp.setStyle(Paint.Style.FILL);
                    rp.setColor(0xFF22E39A);
                    rp.setAlpha(230);
                    canvas.drawCircle(cx, cyTop, dp(2.6f), rp);
                    rp.setStyle(Paint.Style.STROKE);
                    rp.setAlpha(160);
                    canvas.drawCircle(cx, cyTop, dp(6.5f), rp);
                    Paint np = new Paint(Paint.ANTI_ALIAS_FLAG);
                    np.setTextAlign(Paint.Align.CENTER);
                    np.setTextSize(sp(8f));
                    np.setColor(0xFF22E39A);
                    canvas.drawText("ТЕЛЕФОН РЯДОМ", cx, cyTop + dp(72), np);
                }
            }
            if (st.mode == State.Mode.TRANSFER) {
                // живой мини-график скорости (история последних замеров)
                if (t - lastGraphAt > 0.22f) {
                    lastGraphAt = t;
                    speedHist[graphPos % speedHist.length] = st.speed;
                    graphPos++;
                }
                float maxSp = 1f;
                for (float v : speedHist) if (v > maxSp) maxSp = v;
                Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);
                gp.setColor(0xFF22E39A);
                int bars = speedHist.length;
                for (int bi = 0; bi < bars; bi++) {
                    float v = speedHist[(graphPos + bi) % bars];
                    float bh = dp(2) + dp(12) * (v / maxSp);
                    float bx = cx - dp(29) + bi * (dp(58) / bars);
                    gp.setAlpha(70 + (int) (150 * (v / maxSp)));
                    canvas.drawRect(bx, cyTop + dp(70), bx + dp(3), cyTop + dp(70) + bh, gp);
                }
                // под кружком: скорость, остаток времени и "уже / всего"
                Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG);
                ip.setTextAlign(Paint.Align.CENTER);
                ip.setTextSize(sp(9.5f));
                ip.setColor(0xFFB9F6DF);
                String eta = st.speed > 1024 && st.total > st.transferred
                        ? " · ~" + etaText((st.total - st.transferred) / Math.max(1, (long) st.speed)) : "";
                canvas.drawText(speedText(st.speed) + eta, cx, cyTop + dp(48), ip);
                ip.setTextSize(sp(8.5f));
                ip.setColor(0xFF8FE3C0);
                canvas.drawText(sizeText(st.transferred) + " / " + sizeText(st.total),
                        cx, cyTop + dp(61), ip);
            }
            if (st.mode == State.Mode.TAP) {
                Paint tp2 = new Paint(Paint.ANTI_ALIAS_FLAG);
                tp2.setTextAlign(Paint.Align.CENTER);
                tp2.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                tp2.setTextSize(sp(10.5f));
                tp2.setColor(0xFF22E39A);
                canvas.drawText("КАСАНИЕ ПРИНЯТО!", cx, cyTop + dp(48), tp2);
                tp2.setTypeface(Typeface.DEFAULT);
                tp2.setTextSize(sp(9f));
                tp2.setColor(0xFFB9F6DF);
                canvas.drawText("телефоны можно разносить", cx, cyTop + dp(61), tp2);
            }
        }
    }

    // ---------- СВОИ ВЕКТОРНЫЕ ИКОНКИ (без эмодзи) ----------

    /** Фирменная пара стрелок обмена по кругу. */
    private void drawSwapArrows(Canvas c, float cx, float cy, float r, int colA, int colB) {
        glyphPaint.setStrokeWidth(dp(2.6f));
        glyphPaint.setColor(colA);
        RectF o = new RectF(cx - r, cy - r, cx + r, cy + r);
        c.drawArc(o, -160f, 130f, false, glyphPaint);
        arrowHead(c, cx + r * 0.94f, cy - r * 0.34f, 35f, colA);
        glyphPaint.setColor(colB);
        c.drawArc(o, 20f, 130f, false, glyphPaint);
        arrowHead(c, cx - r * 0.94f, cy + r * 0.34f, 215f, colB);
    }

    private void arrowHead(Canvas c, float x, float y, float angDeg, int col) {
        glyphPaint.setColor(col);
        float a = (float) Math.toRadians(angDeg);
        float s = dp(6.5f);
        path.reset();
        path.moveTo(x, y);
        path.lineTo(x - s * (float) Math.cos(a - 0.5f), y - s * (float) Math.sin(a - 0.5f));
        path.moveTo(x, y);
        path.lineTo(x - s * (float) Math.cos(a + 0.5f), y - s * (float) Math.sin(a + 0.5f));
        c.drawPath(path, glyphPaint);
    }

    private static String labelFor(String pick) {
        switch (pick) {
            case "media": return "Медиа";
            case "music": return "Музыка";
            case "files": return "Файлы";
            case "folder": return "Папка";
            case "apps": return "Приложения";
            case "camera": return "Камера";
            case "text": return "Текст";
            case "contact": return "Контакт";
            case "geo": return "Геопозиция";
            case "__wifi": return "Wi-Fi передача";
            case "__close": return "Свернуть приложение";
            default: return pick;
        }
    }

    private static int colorFor(String pick) {
        switch (pick) {
            case "media": return 0xFF8B5CF6;
            case "music": return 0xFF22C55E;
            case "files": return 0xFFF59E0B;
            case "folder": return 0xFFFB923C;
            case "apps": return 0xFF38BDF8;
            case "camera": return 0xFFF472B6;
            case "text": return 0xFF22E39A;
            case "contact": return 0xFFA78BFA;
            case "geo": return 0xFF34D399;
            case "__wifi": return 0xFF38BDF8;
            case "__close": return 0xFFFFB74D;
            default: return 0xFF8B5CF6;
        }
    }

    /** Свои ЦВЕТНЫЕ иконки: заполненные, фирменные, без эмодзи и без контуров. */
    private void drawItemIcon(Canvas c, String pick, float cx, float cy) {
        float s = dp(11);
        int col = colorFor(pick);
        Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
        f.setStyle(Paint.Style.FILL);
        f.setColor(col);
        Paint w = new Paint(Paint.ANTI_ALIAS_FLAG);
        w.setStyle(Paint.Style.FILL);
        w.setColor(0xFFFFFFFF);
        path.reset();
        switch (pick) {
            case "media":
                c.drawRoundRect(new RectF(cx - s, cy - s * 0.8f, cx + s, cy + s * 0.8f), dp(3.5f), dp(3.5f), f);
                w.setColor(0xFFFFE066);
                c.drawCircle(cx + s * 0.45f, cy - s * 0.32f, dp(2.6f), w);
                w.setColor(0xFFFFFFFF);
                path.moveTo(cx - s * 0.8f, cy + s * 0.55f);
                path.lineTo(cx - s * 0.15f, cy - s * 0.05f);
                path.lineTo(cx + s * 0.3f, cy + s * 0.32f);
                path.lineTo(cx + s * 0.55f, cy + s * 0.05f);
                path.lineTo(cx + s * 0.8f, cy + s * 0.55f);
                path.close();
                c.drawPath(path, w);
                break;
            case "music": {
                // пара восьмых нот: Ровная горизонтальная балка, одинаковые штили,
                // головки на одной высоте, наклонены одинаково
                float topY = cy - s * 0.88f;
                float headY = cy + s * 0.52f;
                float stemW = dp(2.8f);
                float x1 = cx - s * 0.52f; // центр левой головки
                float x2 = cx + s * 0.58f; // центр правой головки
                // штили (от правого края головок вверх до балки)
                c.drawRect(x1 + dp(3.4f), topY, x1 + dp(3.4f) + stemW, headY, f);
                c.drawRect(x2 + dp(3.4f), topY, x2 + dp(3.4f) + stemW, headY, f);
                // балка строго горизонтальная
                c.drawRect(x1 + dp(3.4f), topY, x2 + dp(3.4f) + stemW, topY + dp(4.6f), f);
                // головки: одинаковый наклон -20 градусов
                c.save();
                c.rotate(-20f, x1, headY);
                c.drawOval(new RectF(x1 - dp(5.2f), headY - dp(3.7f), x1 + dp(5.2f), headY + dp(3.7f)), f);
                c.restore();
                c.save();
                c.rotate(-20f, x2, headY);
                c.drawOval(new RectF(x2 - dp(5.2f), headY - dp(3.7f), x2 + dp(5.2f), headY + dp(3.7f)), f);
                c.restore();
                break;
            }
            case "files": {
                // РОВНАЯ скрепка: две симметричные дуги, круглые концы, наклон 35°
                c.save();
                c.rotate(35f, cx, cy);
                Paint clipP = new Paint(Paint.ANTI_ALIAS_FLAG);
                clipP.setStyle(Paint.Style.STROKE);
                clipP.setStrokeCap(Paint.Cap.ROUND);
                clipP.setColor(col);
                clipP.setStrokeWidth(dp(2.7f));
                c.drawRoundRect(new RectF(cx - s * 0.42f, cy - s * 0.95f, cx + s * 0.42f, cy + s * 0.95f), s * 0.42f, s * 0.42f, clipP);
                clipP.setStrokeWidth(dp(2.3f));
                c.drawRoundRect(new RectF(cx - s * 0.20f, cy - s * 0.52f, cx + s * 0.20f, cy + s * 0.72f), s * 0.20f, s * 0.20f, clipP);
                c.restore();
                break;
            }
            case "folder": {
                // папка: выступ-язычок слева сверху и крышка
                float x0 = cx - s, x1 = cx + s;
                float y0 = cy - s * 0.78f, y1 = cy + s * 0.78f;
                path.moveTo(x0, y1);
                path.lineTo(x0, y0 + dp(3f));
                path.lineTo(cx - s * 0.25f, y0 + dp(3f));
                path.lineTo(cx - s * 0.02f, y0);
                path.lineTo(x1, y0);
                path.lineTo(x1, y1);
                path.close();
                c.drawPath(path, f);
                w.setAlpha(60);
                c.drawRect(x0, cy - dp(1f), x1, y1, w);
                w.setAlpha(255);
                break;
            }
            case "apps":
                int[] cols = {0xFF22E39A, 0xFF8B5CF6, 0xFF38BDF8, 0xFFF59E0B};
                int k = 0;
                for (int i2 = 0; i2 < 2; i2++) {
                    for (int j2 = 0; j2 < 2; j2++) {
                        f.setColor(cols[k++]);
                        float x0 = cx - s + j2 * s, y0 = cy - s + i2 * s;
                        c.drawRoundRect(new RectF(x0 + dp(1.2f), y0 + dp(1.2f),
                                x0 + s - dp(1.2f), y0 + s - dp(1.2f)), dp(3), dp(3), f);
                    }
                }
                break;
            case "camera":
                c.drawRoundRect(new RectF(cx - s, cy - s * 0.55f, cx + s, cy + s * 0.72f), dp(4), dp(4), f);
                c.drawCircle(cx, cy + s * 0.08f, dp(5.4f), w);
                f.setColor(0xFF123F2A);
                c.drawCircle(cx, cy + s * 0.08f, dp(3.2f), f);
                w.setColor(0xFF22E39A);
                c.drawCircle(cx + s * 0.55f, cy - s * 0.25f, dp(1.8f), w);
                break;
            case "text":
                for (int i2 = 0; i2 < 3; i2++) {
                    float y = cy - s * 0.62f + i2 * s * 0.62f;
                    c.drawRoundRect(new RectF(cx - s, y - dp(1.8f),
                            cx + s * (i2 == 2 ? 0.2f : 1f), y + dp(1.8f)), dp(1.8f), dp(1.8f), f);
                }
                break;
            case "contact":
                c.drawCircle(cx, cy - s * 0.38f, dp(5f), f);
                path.arcTo(new RectF(cx - s * 0.9f, cy, cx + s * 0.9f, cy + s * 1.6f), 180f, 180f);
                path.close();
                c.drawPath(path, f);
                break;
            case "geo":
                path.moveTo(cx, cy + s);
                path.cubicTo(cx - s * 0.95f, cy - s * 0.05f, cx - s * 0.6f, cy - s, cx, cy - s);
                path.cubicTo(cx + s * 0.6f, cy - s, cx + s * 0.95f, cy - s * 0.05f, cx, cy + s);
                path.close();
                c.drawPath(path, f);
                c.drawCircle(cx, cy - s * 0.3f, dp(3.4f), w);
                break;
            case "__wifi": {
                // Wi-Fi: три дуги и точка
                glyphPaint.setStrokeWidth(dp(2.4f));
                glyphPaint.setColor(col);
                glyphPaint.setStyle(Paint.Style.STROKE);
                glyphPaint.setStrokeCap(Paint.Cap.ROUND);
                for (int a = 0; a < 3; a++) {
                    float rr = dp(4.5f) + a * dp(4.2f);
                    c.drawArc(new RectF(cx - rr, cy - rr + dp(3), cx + rr, cy + rr + dp(3)), -155f, 130f, false, glyphPaint);
                }
                glyphPaint.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy + dp(5.5f), dp(2.1f), glyphPaint);
                glyphPaint.setStyle(Paint.Style.STROKE);
                break;
            }
            case "__close":
                glyphPaint.setStrokeWidth(dp(3f));
                glyphPaint.setColor(col);
                c.drawLine(cx - s * 0.6f, cy - s * 0.6f, cx + s * 0.6f, cy + s * 0.6f, glyphPaint);
                c.drawLine(cx + s * 0.6f, cy - s * 0.6f, cx - s * 0.6f, cy + s * 0.6f, glyphPaint);
                break;
            default:
                break;
        }
    }

    private static String sizeText(long b) {
        if (b >= 1_000_000_000L) return String.format(java.util.Locale.US, "%.1f ГБ", b / 1e9);
        if (b >= 1_000_000L) return String.format(java.util.Locale.US, "%.1f МБ", b / 1e6);
        if (b >= 1_000L) return String.format(java.util.Locale.US, "%.0f КБ", b / 1e3);
        return b + " Б";
    }

    private static String speedText(float bps) {
        if (bps >= 1_000_000f) return String.format(java.util.Locale.US, "%.1f МБ/с", bps / 1e6);
        if (bps >= 1_000f) return String.format(java.util.Locale.US, "%.0f КБ/с", bps / 1e3);
        return (int) bps + " Б/с";
    }

    private static String etaText(long sec) {
        if (sec >= 3600) return (sec / 3600) + " ч " + ((sec % 3600) / 60) + " мин";
        if (sec >= 60) return (sec / 60) + " мин " + (sec % 60) + " с";
        return sec + " с";
    }

    private void drawCollapsed(Canvas canvas, float cx, float cy, State st) {
        if (st.relayUploading && st.mode != State.Mode.TRANSFER) {
            float r = dp(24);
            ringBg.setStrokeWidth(dp(3.4f));
            ringBg.setColor(0x2EFFFFFF);
            canvas.drawCircle(cx, cy, r, ringBg);
            ringFg.setStrokeWidth(dp(3.4f));
            ringFg.setColor(0xFF8B5CF6);
            canvas.drawArc(new RectF(cx - r, cy - r, cx + r, cy + r), -90,
                    360f * clamp01(st.progress), false, ringFg);
            pctPaint.setTextSize(sp(12.5f));
            pctPaint.setColor(0xFFFFFFFF);
            canvas.drawText((int) Math.round(clamp01(st.progress) * 100) + "%", cx,
                    cy - (pctPaint.ascent() + pctPaint.descent()) / 2f, pctPaint);
            return;
        }
        switch (st.mode) {
            case TRANSFER: {
                float r = dp(24);
                ringBg.setStrokeWidth(dp(3.4f));
                ringBg.setColor(0x2EFFFFFF);
                canvas.drawCircle(cx, cy, r, ringBg);
                ringFg.setStrokeWidth(dp(3.4f));
                ringFg.setColor(0xFF22E39A);
                canvas.drawArc(new RectF(cx - r, cy - r, cx + r, cy + r), -90,
                        360f * clamp01(st.progress), false, ringFg);
                pctPaint.setTextSize(sp(12.5f));
                String p = (int) Math.round(clamp01(st.progress) * 100) + "%";
                canvas.drawText(p, cx, cy - (pctPaint.ascent() + pctPaint.descent()) / 2f, pctPaint);
                break;
            }
            case SUCCESS: {
                glyphPaint.setStrokeWidth(dp(3.4f));
                glyphPaint.setColor(0xFF22E39A);
                path.reset();
                path.moveTo(cx - dp(10), cy);
                path.lineTo(cx - dp(3.5f), cy + dp(8));
                path.lineTo(cx + dp(11), cy - dp(8));
                canvas.drawPath(path, glyphPaint);
                break;
            }
            case ERROR: {
                // не восклицательный знак, а перечёркнутая подсказка касания:
                // две стрелки обмена + красная диагональ «не вышло»
                drawSwapArrows(canvas, cx, cy, dp(10.5f), 0xFFB388FF, 0xFF22E39A);
                glyphPaint.setStrokeWidth(dp(3.4f));
                glyphPaint.setStrokeCap(Paint.Cap.ROUND);
                glyphPaint.setColor(0xFFFF5252);
                canvas.drawLine(cx - dp(14), cy + dp(14), cx + dp(14), cy - dp(14), glyphPaint);
                break;
            }
            case CONNECTING:
            case TAP:
                glyphPaint.setStrokeWidth(dp(3f));
                glyphPaint.setColor(0xFFB388FF);
                canvas.drawArc(new RectF(cx - dp(15), cy - dp(15), cx + dp(15), cy + dp(15)),
                        (t * 330f) % 360f, 250f, false, glyphPaint);
                drawSwapArrows(canvas, cx, cy, dp(8.5f), 0xFF22E39A, 0xFFB388FF);
                break;
            case READY_SEND: {
                drawSwapArrows(canvas, cx, cy, dp(13), 0xFF22E39A, 0xFFB388FF);
                int n;
                synchronized (st.outbound) {
                    n = st.outbound.size();
                }
                if (n > 0) {
                    Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
                    bp.setColor(0xFF22E39A);
                    float bx = cx + dp(19), by = cy - dp(19);
                    canvas.drawCircle(bx, by, dp(8.5f), bp);
                    pctPaint.setTextSize(sp(10));
                    pctPaint.setColor(0xFF06130C);
                    canvas.drawText(String.valueOf(Math.min(99, n)), bx,
                            by - (pctPaint.ascent() + pctPaint.descent()) / 2f, pctPaint);
                    pctPaint.setColor(0xFFFFFFFF);
                }
                break;
            }
            case READY_RECV: {
                canvas.save();
                canvas.rotate((float) Math.sin(t * 0.55f) * 9f, cx, cy);
                drawSwapArrows(canvas, cx, cy, dp(13), 0xFFB388FF, 0xFF22E39A);
                canvas.restore();
                break;
            }
            default: {
                canvas.save();
                canvas.rotate((float) Math.sin(t * 0.55f) * 9f, cx, cy);
                drawSwapArrows(canvas, cx, cy, dp(13), 0xFF8B5CF6, 0xFF22E39A);
                canvas.restore();
                break;
            }
        }
    }

    private void drawExpanded(Canvas canvas, float left, float top, float right) {
        itemRects.clear();
        float cx = (left + right) / 2f;
        // шапка: крестик закрытия
        glyphPaint.setStrokeWidth(dp(2.6f));
        glyphPaint.setColor(0xFFFFFFFF);
        float hx = cx, hy = top + dp(27);
        canvas.drawLine(hx - dp(7), hy - dp(7), hx + dp(7), hy + dp(7), glyphPaint);
        canvas.drawLine(hx + dp(7), hy - dp(7), hx - dp(7), hy + dp(7), glyphPaint);
        closeRect.set(left, top, right, top + dp(48));

        float y = top + dp(56); // ссылки удалены; остаются NFC и Wi-Fi
        float itemH = dp(43);
        itemBg.setColor(0x14FFFFFF);
        // фон уже раскрылся пружиной — кнопки контента въезжают каскадом следом
        // Rows stay fixed while the panel is clipped to its animated height.
        // This avoids staggered jumps and preserves stable hit targets.
        for (String pick : PICKS) {
            // разделители групп с отступом: [файлы] | ПРИЁМ | [закрыть]
            if ("__wifi".equals(pick) || "__close".equals(pick)) {
                y += dp(16);
                Paint sep = new Paint(Paint.ANTI_ALIAS_FLAG);
                sep.setColor(0x59FFFFFF);
                sep.setStrokeWidth(dp(1.2f));
                canvas.drawLine(left + dp(12), y - dp(11), right - dp(12), y - dp(11), sep);
                Paint cap = new Paint(Paint.ANTI_ALIAS_FLAG);
                cap.setTextAlign(Paint.Align.CENTER);
                cap.setTextSize(sp(7.5f));
                cap.setColor(0xFFB9C4E8);
                canvas.drawText("__wifi".equals(pick) ? "WI-FI" : "—", cx, y - dp(14), cap);
            }
            RectF ir = new RectF(left + dp(7), y, right - dp(7), y + itemH - dp(5));
            itemBg.setColor(0xA9141414);
            canvas.drawRoundRect(ir, dp(7), dp(7), itemBg);
            itemBg.setColor(colorFor(pick));
            canvas.drawRoundRect(new RectF(ir.left, ir.top, ir.left + dp(3), ir.bottom),
                    dp(1.5f), dp(1.5f), itemBg);
            drawItemIcon(canvas, pick, cx, y + itemH / 2f - dp(2.5f));
            itemRects.add(new RectF(ir));
            y += itemH;
        }
    }


    /** Техно-кольцо: риски-шкала, встречно вращающиеся дуги, радар в готовности. */
    private void drawTechRing(Canvas c, float cx, float cy, float R, State st) {
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setStyle(Paint.Style.STROKE);
        boolean active = st.mode == State.Mode.TRANSFER || st.mode == State.Mode.TAP
                || st.mode == State.Mode.CONNECTING;
        // шкала рисок: 48 делений, каждое 6-е длиннее
        for (int i = 0; i < 48; i++) {
            double a = Math.toRadians(i * 7.5);
            boolean major = i % 6 == 0;
            float r0 = R + dp(4.5f), r1 = R + dp(major ? 9.5f : 7f);
            tp.setStrokeWidth(dp(major ? 1.5f : 1f));
            tp.setColor(major ? 0x8C8B5CF6 : 0x3D8B5CF6);
            c.drawLine(cx + r0 * (float) Math.cos(a), cy + r0 * (float) Math.sin(a),
                    cx + r1 * (float) Math.cos(a), cy + r1 * (float) Math.sin(a), tp);
        }
        // две дуги навстречу друг другу
        tp.setStrokeWidth(dp(1.8f));
        tp.setStrokeCap(Paint.Cap.ROUND);
        tp.setColor(0xFF22E39A);
        c.drawArc(new RectF(cx - R - dp(2.5f), cy - R - dp(2.5f), cx + R + dp(2.5f), cy + R + dp(2.5f)),
                (t * (active ? 32f : 16f)) % 360f, 64f, false, tp);
        tp.setColor(0xFF8B5CF6);
        c.drawArc(new RectF(cx - R - dp(2.5f), cy - R - dp(2.5f), cx + R + dp(2.5f), cy + R + dp(2.5f)),
                180f - (t * (active ? 32f : 16f)) % 360f, 64f, false, tp);
        // радарные волны, когда телефон готов
        if (st.mode == State.Mode.READY_RECV || st.mode == State.Mode.READY_SEND) {
            tp.setStrokeCap(Paint.Cap.BUTT);
            for (int k = 0; k < 2; k++) {
                float ph = (t * 0.55f + k * 0.5f) % 1f;
                float rr = R + dp(3) + ph * dp(13);
                tp.setStrokeWidth(dp(1.2f));
                tp.setColor((int) ((1f - ph) * 90) << 24 | 0x22E39A);
                c.drawCircle(cx, cy, rr, tp);
            }
        }
    }

    private static int blend(int a, int b, float f) {
        int r = (int) (((a >> 16) & 0xFF) + (((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * f);
        int g = (int) (((a >> 8) & 0xFF) + (((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * f);
        int bl = (int) ((a & 0xFF) + ((b & 0xFF) - (a & 0xFF)) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static float clamp01(float v) {
        return v < 0 ? 0 : Math.min(1, v);
    }

    private float downX = 0, downY = 0;
    private long downAt = 0;

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            downX = e.getX();
            downY = e.getY();
            downAt = System.currentTimeMillis();
            // Касания принимаем ТОЛЬКО по телу островка — вокруг него экран свободен
            float lx = right() - IslandGeometry.widthPx(density), tp = top();
            boolean inside = e.getX() >= lx - dp(8) && e.getX() <= right() + dp(4)
                    && e.getY() >= tp - dp(8) && e.getY() <= tp + hCur + dp(8);
            if (!inside) return false;
            pulse();
            return true;
        }
        if (e.getAction() == MotionEvent.ACTION_UP) {
            float x = e.getX(), y = e.getY();
            long heldMs = System.currentTimeMillis() - downAt;
            float adx = Math.abs(x - downX), ady = y - downY;
            if (expanded) {
                if (ady < -dp(36) && adx < dp(30)) { // свайп вверх по раскрытому — свернуть
                    collapse();
                    return true;
                }
                if (closeRect.contains(x, y)) {
                    collapse();
                    return true;
                }
                for (int i = 0; i < itemRects.size() && i < PICKS.length; i++) {
                    if (itemRects.get(i).contains(x, y)) {
                        String pick = PICKS[i];
                        collapse();
                        if (pickListener != null) pickListener.onPick(pick);
                        return true;
                    }
                }
                collapse();
                return true;
            }
            float cx = right() - dp(29), cy = top() + dp(29);
            if (Math.hypot(x - cx, y - cy) <= dp(42) && expandable) {
                State.Mode m = State.get().mode;
                boolean busyMode = m == State.Mode.TRANSFER || m == State.Mode.CONNECTING
                        || m == State.Mode.TAP;
                if (!busyMode && heldMs > 600 && adx < dp(24) && Math.abs(ady) < dp(24)) {
                    // долгий тап по островку: выбор устройства по Wi-Fi
                    if (pickListener != null) pickListener.onPick("__wifi");
                    return true;
                }
                if (!busyMode && ady > dp(30)) { // свайп вниз — раскрыть
                    expanded = true;
                    startFrame();
                    return true;
                }
                if (!busyMode && Math.abs(ady) <= dp(30)) {
                    expanded = true;
                    startFrame();
                }
            }
            return super.onTouchEvent(e);
        }
        return super.onTouchEvent(e);
    }
}
