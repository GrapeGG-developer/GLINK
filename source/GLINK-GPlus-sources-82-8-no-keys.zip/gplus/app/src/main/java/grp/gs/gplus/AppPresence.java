package grp.gs.gplus;

/** Process-local hint only; it does not assert network presence or delivery. */
final class AppPresence {
    static volatile String visibleChat="";
    private AppPresence(){}
}
