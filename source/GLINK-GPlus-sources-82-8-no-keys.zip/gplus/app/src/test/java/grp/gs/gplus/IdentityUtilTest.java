package grp.gs.gplus;
import org.junit.Test;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.ECGenParameterSpec;
import static org.junit.Assert.*;

public class IdentityUtilTest {
    @Test public void idMatchesServerAndGlinkVector() throws Exception {
        byte[] der=IdentityUtil.unb64("MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEHny7K-MKTdnKJl5NRI8_bMBw-Uv318i4Bm6juD2IEC6_OZYL7F0egtIjZPt3ikJROoyB1S4XLL2o7hvSvIqp6Q");
        assertEquals("d3wu-riJk-0XkL-edEU",IdentityUtil.id(der));
    }
    @Test public void nicknamesAreNormalizedAndChecked() {
        assertEquals("alice_123",IdentityUtil.nickname(" @Alice_123 "));
        assertEquals("алиса",IdentityUtil.nickname("Алиса"));
        assertEquals("abc",IdentityUtil.nickname("ＡＢＣ"));
        assertNull(IdentityUtil.nickname("ab")); assertNull(IdentityUtil.nickname("one two")); assertNull(IdentityUtil.nickname("@"));
    }
    @Test public void validProofPassesAndWrongChallengeFails() throws Exception {
        KeyPairGenerator g=KeyPairGenerator.getInstance("EC");g.initialize(new ECGenParameterSpec("secp256r1")); KeyPair kp=g.generateKeyPair();
        byte[] nonce=new byte[32];new SecureRandom().nextBytes(nonce);
        Signature signer=Signature.getInstance("SHA256withECDSA");signer.initSign(kp.getPrivate());signer.update("G+ AUTH v1\0".getBytes(StandardCharsets.UTF_8));signer.update(nonce);
        byte[] signature=signer.sign();assertTrue(IdentityUtil.verify(kp.getPublic().getEncoded(),nonce,signature));
        nonce[0]^=1;assertFalse(IdentityUtil.verify(kp.getPublic().getEncoded(),nonce,signature));
    }
    @Test(expected=IllegalArgumentException.class) public void wrongChallengeLengthIsRejected() throws Exception { IdentityUtil.verify(new byte[0],new byte[31],new byte[0]); }
}
