package com.prilozhi.app.util;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Arrays;

/**
 * Автообновление GLINK из интернета.
 * Приложение само качает version.json вида:
 * {"versionCode":3,"versionName":"1.2","apk":"https://.../GLINK.apk","notes":"..."}
 * Если versionCode новее текущего — скачивает APK и само открывает установку.
 * (Полностью тихая установка без root на Android невозможна: система покажет
 *  одно стандартное подтверждение «Установить».)
 * Адрес фида меняется долгим нажатием на строку версии в приложении.
 */
public final class UpdateManager {

    public static final String DEFAULT_FEED =
            "https://raw.githubusercontent.com/GrapeGG-developer/GLINK/main/version.json";
    public static final String OFFICIAL_APK =
            "https://raw.githubusercontent.com/GrapeGG-developer/GLINK/main/GLINK.apk";
    private static final long MAX_APK_SIZE = 200L * 1024 * 1024;

    public interface CheckCallback {
        void onResult(boolean updateAvailable, Info info, String error);
    }

    public interface DlCallback {
        void onProgress(long done, long total);

        void onDone(Uri apkUri, String error);
    }

    public static final class Info {
        public int versionCode;
        public String versionName;
        public String apk;
        public String notes;
        public String sha256;
        public long size;
    }

    private final Context ctx;
    private final SharedPreferences prefs;
    private final Handler main = new Handler(Looper.getMainLooper());

    public UpdateManager(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.prefs = ctx.getSharedPreferences("glink_upd", Context.MODE_PRIVATE);
    }

    public String feedUrl() {
        return prefs.getString("feed", DEFAULT_FEED);
    }

    public void setFeedUrl(String url) {
        prefs.edit().putString("feed", url).apply();
    }

    public static int currentVersionCode(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return (int) pi.getLongVersionCode();
        } catch (Exception e) {
            return 1;
        }
    }

    public static String currentVersionName(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return pi.versionName != null ? pi.versionName : "1.0";
        } catch (Exception e) {
            return "1.0";
        }
    }

    /** Удалить все старые установочные APK обновлений из Download/GLINK (чтобы не копились
     *  и MediaStore не падал с "Failed to build unique file"). */
    private static volatile long lastCleanupAt = 0;
    private static final java.util.Set<String> ACTIVE_UPDATES = java.util.Collections.synchronizedSet(new java.util.HashSet<>());
    private static final java.util.concurrent.atomic.AtomicBoolean DOWNLOADING = new java.util.concurrent.atomic.AtomicBoolean(false);

    public void cleanupStaleApks() {
        long now = System.currentTimeMillis();
        if (now - lastCleanupAt < 60_000) return; // не долбить MediaStore на каждый чих
        lastCleanupAt = now;
        try {
            android.database.Cursor c = ctx.getContentResolver().query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME},
                    MediaStore.Downloads.DISPLAY_NAME + " LIKE ?",
                    new String[]{"GLINK-update%"}, null);
            String keepName = prefs.getString("upd_keep_name", "");
            if (c != null) {
                int nameCol = c.getColumnIndex(MediaStore.Downloads.DISPLAY_NAME);
                while (c.moveToNext()) {
                    // не удалять APK, который прямо сейчас ждёт установки
                    if (nameCol >= 0 && ((keepName != null && keepName.equals(c.getString(nameCol)))
                            || ACTIVE_UPDATES.contains(c.getString(nameCol)))) continue;
                    long id = c.getLong(0);
                    try {
                        ctx.getContentResolver().delete(
                                android.content.ContentUris.withAppendedId(
                                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, id),
                                null, null);
                    } catch (Exception ignored) {
                    }
                }
                c.close();
            }
        } catch (Exception ignored) {
        }
        // и локальный временный файл обновления, если остался
        try {
            new java.io.File(ctx.getCacheDir(), "GLINK-update.apk").delete();
        } catch (Exception ignored) {
        }
    }

    /** Older feeds can lack hashes; a newer update must include size, SHA-256 and the official URL. */
    public static Info parseFeed(String body, int currentCode) throws Exception {
        JSONObject o = new JSONObject(body);
        int code = o.getInt("versionCode");
        if (code < 1) throw new SecurityException("Неверная версия обновления");
        if (code <= currentCode) return null;
        Info info = new Info();
        info.versionCode = code;
        info.versionName = o.getString("versionName");
        info.apk = o.getString("apk");
        info.notes = o.optString("notes", "");
        info.size = o.getLong("size");
        info.sha256 = o.getString("sha256");
        if (!info.versionName.matches("[0-9]+(?:\\.[0-9]+){5}") || !OFFICIAL_APK.equals(info.apk)
                || info.size < 1 || info.size > MAX_APK_SIZE
                || !info.sha256.matches("[0-9a-f]{64}") || info.notes.length() > 8192) {
            throw new SecurityException("Неверный файл сведений об обновлении");
        }
        return info;
    }

    public void check(CheckCallback cb) {
        cleanupStaleApks();
        new Thread(() -> {
            HttpURLConnection con = null;
            try {
                URL url = new URL(feedUrl());
                if (!"https".equalsIgnoreCase(url.getProtocol())) throw new SecurityException("Нужен HTTPS");
                con = (HttpURLConnection) url.openConnection();
                con.setInstanceFollowRedirects(false);
                con.setUseCaches(false);
                con.setConnectTimeout(6000);
                con.setReadTimeout(6000);
                con.setRequestProperty("User-Agent", "GLINK-Android");
                if (con.getResponseCode() != 200) throw new Exception("HTTP " + con.getResponseCode());
                String body;
                try (InputStream in = con.getInputStream()) {
                    body = new String(readAll(in), java.nio.charset.StandardCharsets.UTF_8);
                }
                Info info = parseFeed(body, currentVersionCode(ctx));
                main.post(() -> cb.onResult(info != null, info, null));
            } catch (Exception e) {
                main.post(() -> cb.onResult(false, null, String.valueOf(e.getMessage())));
            } finally {
                if (con != null) con.disconnect();
            }
        }, "glink-upd-check").start();
    }

    interface Progress { void accept(long count); }
    static void copyAndVerify(InputStream in, OutputStream out, long expected, String expectedSha,
                              Progress progress) throws Exception {
        if (expected < 1 || expected > MAX_APK_SIZE || expectedSha == null
                || !expectedSha.matches("[0-9a-f]{64}")) throw new SecurityException("Неверные параметры APK");
        MessageDigest hash = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[64 * 1024];
        long total = 0;
        int count;
        while ((count = in.read(buffer)) != -1) {
            if (count == 0) continue;
            total += count;
            if (total > expected) throw new SecurityException("Размер APK не совпадает");
            hash.update(buffer, 0, count);
            if (out != null) out.write(buffer, 0, count);
            if (progress != null) progress.accept(total);
        }
        if (out != null) out.flush();
        StringBuilder hex = new StringBuilder();
        for (byte b : hash.digest()) hex.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
        if (total != expected || !expectedSha.equals(hex.toString())) throw new SecurityException("Проверка APK не прошла");
    }

    @SuppressWarnings("deprecation")
    private void verifyPackage(File apk, Info info) throws Exception {
        PackageManager pm = ctx.getPackageManager();
        int flags = PackageManager.GET_SIGNING_CERTIFICATES | PackageManager.GET_SIGNATURES;
        PackageInfo candidate = pm.getPackageArchiveInfo(apk.getAbsolutePath(), flags);
        PackageInfo installed = pm.getPackageInfo(ctx.getPackageName(), flags);
        if (candidate == null || !ctx.getPackageName().equals(candidate.packageName)
                || candidate.getLongVersionCode() != info.versionCode
                || !info.versionName.equals(candidate.versionName)
                || info.versionCode <= installed.getLongVersionCode()) throw new SecurityException("Неверный пакет GLINK");
        Signature[] a = candidate.signingInfo != null ? candidate.signingInfo.getApkContentsSigners() : candidate.signatures;
        Signature[] b = installed.signingInfo != null ? installed.signingInfo.getApkContentsSigners() : installed.signatures;
        if (a == null || b == null || a.length == 0 || a.length != b.length) throw new SecurityException("Нет подписи APK");
        for (Signature s : a) {
            boolean match = false;
            for (Signature t : b) if (Arrays.equals(s.toByteArray(), t.toByteArray())) match = true;
            if (!match) throw new SecurityException("Подпись обновления не совпадает");
        }
    }

    /** Download privately; verify size, SHA-256, package, version and signing key before publication. */
    public void download(Info info, DlCallback cb) {
        if (!DOWNLOADING.compareAndSet(false, true)) { main.post(() -> cb.onDone(null, "Обновление уже скачивается")); return; }
        new Thread(() -> {
            Uri uri = null;
            File temporary = null;
            HttpURLConnection con = null;
            String previousKeep = prefs.getString("upd_keep_name", "");
            String activeName = null;
            boolean keepChanged = false;
            try {
                if (info == null || !OFFICIAL_APK.equals(info.apk) || info.versionCode <= currentVersionCode(ctx)
                        || info.versionName == null || !info.versionName.matches("[0-9]+(?:\\.[0-9]+){5}")) {
                    throw new SecurityException("Неверные сведения об обновлении");
                }
                con = (HttpURLConnection) new URL(OFFICIAL_APK).openConnection();
                con.setInstanceFollowRedirects(false);
                con.setUseCaches(false);
                con.setConnectTimeout(8000);
                con.setReadTimeout(15000);
                con.setRequestProperty("User-Agent", "GLINK-Android");
                if (con.getResponseCode() != 200) throw new Exception("HTTP " + con.getResponseCode());
                long declared = con.getContentLengthLong();
                if (declared > 0 && declared != info.size) throw new SecurityException("Размер APK не совпадает");
                temporary = File.createTempFile("GLINK-update-check-", ".apk", ctx.getCacheDir());
                final long[] last = {0};
                try (InputStream in = con.getInputStream(); FileOutputStream out = new FileOutputStream(temporary)) {
                    copyAndVerify(in, out, info.size, info.sha256, done -> {
                        if (System.currentTimeMillis() - last[0] > 150) {
                            last[0] = System.currentTimeMillis();
                            main.post(() -> cb.onProgress(done, info.size));
                        }
                    });
                    out.getFD().sync();
                }
                verifyPackage(temporary, info);
                lastCleanupAt = 0;
                cleanupStaleApks(); // always leaves the previous upd_keep_name alone
                String name = "GLINK-update-" + info.versionCode + "-" + Long.toUnsignedString(System.nanoTime()) + ".apk";
                activeName = name;
                ACTIVE_UPDATES.add(name);
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                cv.put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive");
                cv.put(MediaStore.Downloads.RELATIVE_PATH, "Download/GLINK");
                cv.put(MediaStore.Downloads.IS_PENDING, 1);
                uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new Exception("MediaStore недоступен");
                try (InputStream in = new FileInputStream(temporary);
                     OutputStream out = ctx.getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Нет доступа к файлу");
                    copyAndVerify(in, out, info.size, info.sha256, null);
                }
                try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new Exception("Не удалось проверить файл");
                    copyAndVerify(in, null, info.size, info.sha256, null);
                }
                prefs.edit().putString("upd_keep_name", name).apply();
                keepChanged = true;
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                if (ctx.getContentResolver().update(uri, done, null, null) < 1) throw new Exception("Не удалось сохранить APK");
                Uri result = uri;
                main.post(() -> cb.onDone(result, null));
            } catch (Exception e) {
                if (uri != null) try { ctx.getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                if (keepChanged) prefs.edit().putString("upd_keep_name", previousKeep).apply();
                main.post(() -> cb.onDone(null, String.valueOf(e.getMessage())));
            } finally {
                if (con != null) con.disconnect();
                if (temporary != null) temporary.delete();
                if (activeName != null) ACTIVE_UPDATES.remove(activeName);
                DOWNLOADING.set(false);
            }
        }, "glink-upd-dl").start();
    }

    /** Открыть системную установку скачанного APK. */
    public static void install(Activity act, Uri apkUri) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(apkUri, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        act.startActivity(i);
    }

    private static byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) { if (bos.size() + n > 65536) throw new java.io.IOException("Слишком большой ответ"); bos.write(buf, 0, n); }
        return bos.toByteArray();
    }
}
